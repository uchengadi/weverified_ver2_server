<?php

/**
 * This is the model class for table "address_verification_consumption_request".
 *
 * The followings are the available columns in table 'address_verification_consumption_request':
 * @property string $id
 * @property string $address_id
 * @property string $status
 * @property string $invoice_id
 * @property string $requestor_id
 * @property string $requestor_domain_id
 * @property string $date_requested
 */
class AddressVerificationConsumptionRequest extends CActiveRecord
{
	/**
	 * @return string the associated database table name
	 */
	public function tableName()
	{
		return 'address_verification_consumption_request';
	}

	/**
	 * @return array validation rules for model attributes.
	 */
	public function rules()
	{
		// NOTE: you should only define rules for those attributes that
		// will receive user inputs.
		return array(
			array('address_id, status, invoice_id, requestor_id, requestor_domain_id', 'required'),
			array('address_id, invoice_id, requestor_id, requestor_domain_id', 'length', 'max'=>10),
			array('status', 'length', 'max'=>27),
			array('date_requested', 'safe'),
			// The following rule is used by search().
			// @todo Please remove those attributes that should not be searched.
			array('id, address_id, status, invoice_id, requestor_id, requestor_domain_id, date_requested', 'safe', 'on'=>'search'),
		);
	}

	/**
	 * @return array relational rules.
	 */
	public function relations()
	{
		// NOTE: you may need to adjust the relation name and the related
		// class name for the relations automatically generated below.
		return array(
		);
	}

	/**
	 * @return array customized attribute labels (name=>label)
	 */
	public function attributeLabels()
	{
		return array(
			'id' => 'ID',
			'address_id' => 'Address',
			'status' => 'Status',
			'invoice_id' => 'Invoice',
			'requestor_id' => 'Requestor',
			'requestor_domain_id' => 'Requestor Domain',
			'date_requested' => 'Date Requested',
		);
	}

	/**
	 * Retrieves a list of models based on the current search/filter conditions.
	 *
	 * Typical usecase:
	 * - Initialize the model fields with values from filter form.
	 * - Execute this method to get CActiveDataProvider instance which will filter
	 * models according to data in model fields.
	 * - Pass data provider to CGridView, CListView or any similar widget.
	 *
	 * @return CActiveDataProvider the data provider that can return the models
	 * based on the search/filter conditions.
	 */
	public function search()
	{
		// @todo Please modify the following code to remove attributes that should not be searched.

		$criteria=new CDbCriteria;

		$criteria->compare('id',$this->id,true);
		$criteria->compare('address_id',$this->address_id,true);
		$criteria->compare('status',$this->status,true);
		$criteria->compare('invoice_id',$this->invoice_id,true);
		$criteria->compare('requestor_id',$this->requestor_id,true);
		$criteria->compare('requestor_domain_id',$this->requestor_domain_id,true);
		$criteria->compare('date_requested',$this->date_requested,true);

		return new CActiveDataProvider($this, array(
			'criteria'=>$criteria,
		));
	}

	/**
	 * Returns the static model of the specified AR class.
	 * Please note that you should have this exact method in all your CActiveRecord descendants!
	 * @param string $className active record class name.
	 * @return AddressVerificationConsumptionRequest the static model class
	 */
	public static function model($className=__CLASS__)
	{
		return parent::model($className);
	}
        
        
        /**
         * This is the function that registers address verification consumption
         */
        public function isTheConsumptionOfThisVerificationRequestASuccess($user_id,$address_id,$domain_id,$address_is_verified){
            
            //get the location id of this user
            $model = new Invoice;
            
            //confirm if these domain has a live transaction tree. create it if unavailable
            if($this->isDomainWithLiveTransaction($domain_id) == false){
                //add a new domain transaction tree
                $domain_trans_id = $this->newDomainTransactionTreeAdded($domain_id);
            }else{
                $domain_trans_id = $this->getTheLiveDomainTransId($domain_id);
            }
            
         
            //get this user's location invoice that is pending
            $invoice = $model->getThisUserPendingLocationInvoice($user_id,$domain_id,$domain_trans_id);
            
           
            
            
            if($address_is_verified == 1){
                //determine if domain is the owner of this verification
                if($this->isDomainTheOwnerOfThisAddressVerification($domain_id,$address_id)){
                    $status = "consumed_but_not_chargeable";
                }else{
                    $status = "consumed";
                }
                
            }else{
                $status = "not_consumed";
            }
            
            //register this consumption request
            
            $this->address_id = $address_id;
            $this->status = $status;
            $this->invoice_id = $invoice;
            $this->requestor_id = $user_id;
            $this->requestor_domain_id =  $domain_id;
            $this->domain_transaction_id =  $domain_trans_id;
            $this->date_requested = new CDbExpression('NOW()');
            if($invoice >0){
                 if($this->save()){
                    return true;
                }else{
                    return false;
                }
                
            }else{
                return false;
                
            }
           
        }
        
        
        /**
         * This is the function that will determine if domain is the owner of an address verification
         */
        public function isDomainTheOwnerOfThisAddressVerification($domain_id,$address_id){
            $model = new Address;
            return $model->isDomainTheOwnerOfThisAddressVerification($domain_id,$address_id);
        }
        
        /**
         * This is the function that confirms if a domain has an existing transaction tree
         */
        public function isDomainWithLiveTransaction($domain_id){
            $model = new DomainTransactions;
            return $model->isDomainWithLiveTransaction($domain_id);
        }
        
        
        /**
         * This is the function that creates a new domain transaction tree
         */
        public function newDomainTransactionTreeAdded($domain_id){
            $model = new DomainTransactions;
            return $model->newDomainTransactionTreeAdded($domain_id);
        }
        
        
        /**
         * This is the function that returns the live domain transaction code
         */
        public function getTheLiveDomainTransId($domain_id){
            $model = new DomainTransactions;
            return $model->getTheLiveDomainTransId($domain_id);
        }
}
