<?php

/**
 * This is the model class for table "media_has_keywords".
 *
 * The followings are the available columns in table 'media_has_keywords':
 * @property string $id
 * @property integer $media_id
 * @property string $keyword_id
 * @property integer $designation_id
 * @property integer $actor_id
 * @property integer $context_id
 * @property string $frame_start_time
 * @property string $frame_end_time
 * @property string $create_time
 * @property string $update_time
 * @property integer $create_user_id
 * @property integer $update_user_id
 *
 * The followings are the available model relations:
 * @property Keywords $keyword
 * @property Resources $media
 */
class MediaHasKeywords extends CActiveRecord
{
	/**
	 * @return string the associated database table name
	 */
	public function tableName()
	{
		return 'media_has_keywords';
	}

	/**
	 * @return array validation rules for model attributes.
	 */
	public function rules()
	{
		// NOTE: you should only define rules for those attributes that
		// will receive user inputs.
		return array(
			array('media_id, keyword_id', 'required'),
			array('media_id, designation_id, actor_id, context_id, create_user_id, update_user_id', 'numerical', 'integerOnly'=>true),
			array('keyword_id', 'length', 'max'=>10),
			array('frame_start_time, frame_end_time, create_time, update_time', 'safe'),
			// The following rule is used by search().
			// @todo Please remove those attributes that should not be searched.
			array('id, media_id, keyword_id, designation_id, actor_id, context_id, frame_start_time, frame_end_time, create_time, update_time, create_user_id, update_user_id', 'safe', 'on'=>'search'),
		);
	}

	/**
	 * @return array relational rules.
	 */
	public function relations()
	{
		// NOTE: you may need to adjust the relation name and the related
		// class name for the relations automatically generated below.
		return array(
			'keyword' => array(self::BELONGS_TO, 'Keywords', 'keyword_id'),
			'media' => array(self::BELONGS_TO, 'Resources', 'media_id'),
		);
	}

	/**
	 * @return array customized attribute labels (name=>label)
	 */
	public function attributeLabels()
	{
		return array(
			'id' => 'ID',
			'media_id' => 'Media',
			'keyword_id' => 'Keyword',
			'designation_id' => 'Designation',
			'actor_id' => 'Actor',
			'context_id' => 'Context',
			'frame_start_time' => 'Frame Start Time',
			'frame_end_time' => 'Frame End Time',
			'create_time' => 'Create Time',
			'update_time' => 'Update Time',
			'create_user_id' => 'Create User',
			'update_user_id' => 'Update User',
		);
	}

	/**
	 * Retrieves a list of models based on the current search/filter conditions.
	 *
	 * Typical usecase:
	 * - Initialize the model fields with values from filter form.
	 * - Execute this method to get CActiveDataProvider instance which will filter
	 * models according to data in model fields.
	 * - Pass data provider to CGridView, CListView or any similar widget.
	 *
	 * @return CActiveDataProvider the data provider that can return the models
	 * based on the search/filter conditions.
	 */
	public function search()
	{
		// @todo Please modify the following code to remove attributes that should not be searched.

		$criteria=new CDbCriteria;

		$criteria->compare('id',$this->id,true);
		$criteria->compare('media_id',$this->media_id);
		$criteria->compare('keyword_id',$this->keyword_id,true);
		$criteria->compare('designation_id',$this->designation_id);
		$criteria->compare('actor_id',$this->actor_id);
		$criteria->compare('context_id',$this->context_id);
		$criteria->compare('frame_start_time',$this->frame_start_time,true);
		$criteria->compare('frame_end_time',$this->frame_end_time,true);
		$criteria->compare('create_time',$this->create_time,true);
		$criteria->compare('update_time',$this->update_time,true);
		$criteria->compare('create_user_id',$this->create_user_id);
		$criteria->compare('update_user_id',$this->update_user_id);

		return new CActiveDataProvider($this, array(
			'criteria'=>$criteria,
		));
	}

	/**
	 * Returns the static model of the specified AR class.
	 * Please note that you should have this exact method in all your CActiveRecord descendants!
	 * @param string $className active record class name.
	 * @return MediaHasKeywords the static model class
	 */
	public static function model($className=__CLASS__)
	{
		return parent::model($className);
	}
}
