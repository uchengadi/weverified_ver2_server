<?php

/**
 * This is the model class for table "user_has_resourcegroup".
 *
 * The followings are the available columns in table 'user_has_resourcegroup':
 * @property string $user_id
 * @property string $resourcegroup_id
 * @property string $assign_name
 * @property string $assign_description
 * @property integer $isfirst_assignement
 * @property string $date_assigned
 * @property string $date_last_assigned
 * @property string $date_first_assigned
 * @property string $update_time
 * @property integer $assigned_by
 * @property integer $assigment_approved_by
 * @property string $schedule_description
 * @property integer $isfirst_schedule
 * @property string $start_date
 * @property string $end_date
 * @property string $min_date
 * @property string $max_date
 * @property string $date_scheduled
 * @property string $excluded_days
 * @property string $date_last_scheduled
 * @property string $date_first_scheduled
 * @property integer $scheduled_by
 * @property integer $schedule_approved_by
 * @property integer $scheduled_frequency
 * @property integer $total_number_of_schedules
 * @property integer $downloadable
 * @property integer $editable
 */
class UserHasResourcegroup extends CActiveRecord
{
	/**
	 * Returns the static model of the specified AR class.
	 * @param string $className active record class name.
	 * @return UserHasResourcegroup the static model class
	 */
	public static function model($className=__CLASS__)
	{
		return parent::model($className);
	}

	/**
	 * @return string the associated database table name
	 */
	public function tableName()
	{
		return 'user_has_resourcegroup';
	}

	/**
	 * @return array validation rules for model attributes.
	 */
	public function rules()
	{
		// NOTE: you should only define rules for those attributes that
		// will receive user inputs.
		return array(
			array('user_id, resourcegroup_id', 'required'),
			array('isfirst_assignement,downloadble, editable, assigned_by, assigment_approved_by, isfirst_schedule, scheduled_by, schedule_approved_by, scheduled_frequency, total_number_of_schedules', 'numerical', 'integerOnly'=>true),
			array('user_id, resourcegroup_id', 'length', 'max'=>10),
			array('assign_name', 'length', 'max'=>100),
			array('assign_description, date_assigned, date_last_assigned, date_first_assigned, update_time, schedule_description, start_date, end_date, min_date, max_date, date_scheduled, excluded_days, date_last_scheduled, date_first_scheduled', 'safe'),
			// The following rule is used by search().
			// Please remove those attributes that should not be searched.
			array('user_id, resourcegroup_id, assign_name, assign_description, isfirst_assignement, date_assigned, date_last_assigned, date_first_assigned, update_time, assigned_by, assigment_approved_by, schedule_description, isfirst_schedule, downloadable, editable, start_date, end_date, min_date, max_date, date_scheduled, excluded_days, date_last_scheduled, date_first_scheduled, scheduled_by, schedule_approved_by, scheduled_frequency, total_number_of_schedules', 'safe', 'on'=>'search'),
		);
	}

	/**
	 * @return array relational rules.
	 */
	public function relations()
	{
		// NOTE: you may need to adjust the relation name and the related
		// class name for the relations automatically generated below.
		return array(
		);
	}

	/**
	 * @return array customized attribute labels (name=>label)
	 */
	public function attributeLabels()
	{
		return array(
			'user_id' => 'User',
			'resourcegroup_id' => 'Resourcegroup',
			'assign_name' => 'Assign Name',
			'assign_description' => 'Assign Description',
			'isfirst_assignement' => 'Isfirst Assignement',
			'date_assigned' => 'Date Assigned',
			'date_last_assigned' => 'Date Last Assigned',
			'date_first_assigned' => 'Date First Assigned',
			'update_time' => 'Update Time',
			'assigned_by' => 'Assigned By',
			'assigment_approved_by' => 'Assigment Approved By',
			'schedule_description' => 'Schedule Description',
			'isfirst_schedule' => 'Isfirst Schedule',
			'start_date' => 'Start Date',
			'end_date' => 'End Date',
			'min_date' => 'Min Date',
			'max_date' => 'Max Date',
			'date_scheduled' => 'Date Scheduled',
			'excluded_days' => 'Excluded Days',
			'date_last_scheduled' => 'Date Last Scheduled',
			'date_first_scheduled' => 'Date First Scheduled',
			'scheduled_by' => 'Scheduled By',
			'schedule_approved_by' => 'Schedule Approved By',
			'scheduled_frequency' => 'Scheduled Frequency',
			'total_number_of_schedules' => 'Total Number Of Schedules',
                        'downloable' => 'Downloable ?',
                        'editable' => 'Editable ?',
		);
	}

	/**
	 * Retrieves a list of models based on the current search/filter conditions.
	 * @return CActiveDataProvider the data provider that can return the models based on the search/filter conditions.
	 */
	public function search()
	{
		// Warning: Please modify the following code to remove attributes that
		// should not be searched.

		$criteria=new CDbCriteria;

		$criteria->compare('user_id',$this->user_id,true);
		$criteria->compare('resourcegroup_id',$this->resourcegroup_id,true);
		$criteria->compare('assign_name',$this->assign_name,true);
		$criteria->compare('assign_description',$this->assign_description,true);
		$criteria->compare('isfirst_assignement',$this->isfirst_assignement);
		$criteria->compare('date_assigned',$this->date_assigned,true);
		$criteria->compare('date_last_assigned',$this->date_last_assigned,true);
		$criteria->compare('date_first_assigned',$this->date_first_assigned,true);
		$criteria->compare('update_time',$this->update_time,true);
		$criteria->compare('assigned_by',$this->assigned_by);
		$criteria->compare('assigment_approved_by',$this->assigment_approved_by);
		$criteria->compare('schedule_description',$this->schedule_description,true);
		$criteria->compare('isfirst_schedule',$this->isfirst_schedule);
		$criteria->compare('start_date',$this->start_date,true);
		$criteria->compare('end_date',$this->end_date,true);
		$criteria->compare('min_date',$this->min_date,true);
		$criteria->compare('max_date',$this->max_date,true);
		$criteria->compare('date_scheduled',$this->date_scheduled,true);
		$criteria->compare('excluded_days',$this->excluded_days,true);
		$criteria->compare('date_last_scheduled',$this->date_last_scheduled,true);
		$criteria->compare('date_first_scheduled',$this->date_first_scheduled,true);
		$criteria->compare('scheduled_by',$this->scheduled_by);
		$criteria->compare('schedule_approved_by',$this->schedule_approved_by);
		$criteria->compare('scheduled_frequency',$this->scheduled_frequency);
		$criteria->compare('total_number_of_schedules',$this->total_number_of_schedules);
                $criteria->compare('downloable',$this->downloadable);
                $criteria->compare('editable',$this->editable);

		return new CActiveDataProvider($this, array(
			'criteria'=>$criteria,
		));
	}
}