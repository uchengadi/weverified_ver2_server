<?php

/**
 * This is the model class for table "resourcegroup".
 *
 * The followings are the available columns in table 'resourcegroup':
 * @property string $id
 * @property string $name
 * @property string $description
 * @property string $icon
 * @property double $price
 * @property integer $min_discountable_number
 * @property integer $enforce_min_discountable_number
 * @property integer $min_subscription_required
 * @property double $discount_rate
 * @property string $visibility
 * @property string $domain_id
 * @property integer $original_toolbox_id
 * @property integer $duplicate
 * @property integer $is_duplicate
 * @property integer $reconstruct_toolbox
 * @property integer $discount_proof
 * @property string $create_time
 * @property integer $create_user_id
 * @property integer $verifier_user_id
 * @property string $update_time
 * @property integer $is_document_initiated_or_updated
 * @property integer $is_storage_confirmed_by_domain_verifier
 * @property integer $is_storage_checked_by_platform_checker
 * @property integer $is_storage_verified_by_platform_verifier
 * @property integer $is_box_in_storage
 * @property integer $update_user_id
 * @property integer $select_value
 * @property integer $cumulative_component_price
 * @property integer $price_preference
 * @property string $storage_location
 * @property string $storage_room
 * @property integer $rack_number
 * @property integer $rack_row_number
 * @property integer $rack_column_number
 * @property integer $is_storage_confirmed_by_domain_verifier
 * @property integer $is_storage_checked_by_platform_checker
 * @property integer $is_storage_verified_by_platform_verifier
 *
 * The followings are the available model relations:
 * @property DomainHasTreaty[] $domainHasTreaties
 * @property DomainPolicy[] $domainPolicies
 * @property Group[] $groups
 * @property Network[] $networks
 * @property Order[] $orders
 * @property Resources[] $resources
 * @property Resourcegroupcategory[] $resourcegroupcategories
 * @property Subgroup[] $subgroups
 * @property TaskToTask[] $taskToTasks
 * @property Treaty[] $treaties
 * @property UserHasNeed[] $userHasNeeds
 * @property User[] $users
 * @property Wishes[] $wishes
 */
class Resourcegroup extends CActiveRecord
{
	/**
	 * @return string the associated database table name
	 */
	public function tableName()
	{
		return 'resourcegroup';
	}

	/**
	 * @return array validation rules for model attributes.
	 */
	public function rules()
	{
		// NOTE: you should only define rules for those attributes that
		// will receive user inputs.
		return array(
			array('name, visibility, domain_id', 'required'),
			array('min_discountable_number, enforce_min_discountable_number, min_subscription_required, original_toolbox_id, duplicate, is_duplicate, reconstruct_toolbox, discount_proof, create_user_id, update_user_id, select_value, cumulative_component_price, price_preference', 'numerical', 'integerOnly'=>true),
			array('price, discount_rate', 'numerical'),
			array('name, icon', 'length', 'max'=>200),
			array('description', 'length', 'max'=>250),
			array('visibility', 'length', 'max'=>27),
			array('domain_id', 'length', 'max'=>10),
			array('create_time, update_time', 'safe'),
			// The following rule is used by search().
			// @todo Please remove those attributes that should not be searched.
			array('id, name, description, icon, price, min_discountable_number, enforce_min_discountable_number, min_subscription_required, discount_rate, visibility, domain_id, original_toolbox_id, duplicate, is_duplicate, reconstruct_toolbox, discount_proof, create_time, create_user_id, update_time, update_user_id, select_value, cumulative_component_price, price_preference', 'safe', 'on'=>'search'),
		);
	}

	/**
	 * @return array relational rules.
	 */
	public function relations()
	{
		// NOTE: you may need to adjust the relation name and the related
		// class name for the relations automatically generated below.
		return array(
			'domainHasTreaties' => array(self::HAS_MANY, 'DomainHasTreaty', 'resourcegroup_id'),
			'domainPolicies' => array(self::HAS_MANY, 'DomainPolicy', 'domain_id'),
			'groups' => array(self::MANY_MANY, 'Group', 'group_has_resourcegroup(resourcegroup_id, group_id)'),
			'networks' => array(self::MANY_MANY, 'Network', 'network_has_toolboxes(toolbox_id, network_id)'),
			'orders' => array(self::MANY_MANY, 'Order', 'order_has_toolboxes(toolbox_id, order_id)'),
			'resources' => array(self::MANY_MANY, 'Resources', 'resource_has_resourcegroups(resourcegroup_id, resource_id)'),
			'resourcegroupcategories' => array(self::MANY_MANY, 'Resourcegroupcategory', 'resourcegroup_has_resourcegroupcategory(resourcegroup_id, category_id)'),
			'subgroups' => array(self::MANY_MANY, 'Subgroup', 'subgroup_has_resourcegroup(resourcegroup_id, subgroup_id)'),
			'taskToTasks' => array(self::HAS_MANY, 'TaskToTask', 'slave_toolbox_id'),
			'treaties' => array(self::HAS_MANY, 'Treaty', 'resourcegroup_id'),
			'userHasNeeds' => array(self::HAS_MANY, 'UserHasNeed', 'resourcegroup_id'),
			'users' => array(self::MANY_MANY, 'User', 'user_has_resourcegroup(resourcegroup_id, user_id)'),
			'wishes' => array(self::HAS_MANY, 'Wishes', 'resourcegroup_id'),
		);
	}

	/**
	 * @return array customized attribute labels (name=>label)
	 */
	public function attributeLabels()
	{
		return array(
			'id' => 'ID',
			'name' => 'Name',
			'description' => 'Description',
			'icon' => 'Icon',
			'price' => 'Price',
			'min_discountable_number' => 'Min Discountable Number',
			'enforce_min_discountable_number' => 'Enforce Min Discountable Number',
			'min_subscription_required' => 'Min Subscription Required',
			'discount_rate' => 'Discount Rate',
			'visibility' => 'Visibility',
			'domain_id' => 'Domain',
			'original_toolbox_id' => 'Original Toolbox',
			'duplicate' => 'Duplicate',
			'is_duplicate' => 'Is Duplicate',
			'reconstruct_toolbox' => 'Reconstruct Toolbox',
			'discount_proof' => 'Discount Proof',
			'create_time' => 'Create Time',
			'create_user_id' => 'Create User',
			'update_time' => 'Update Time',
			'update_user_id' => 'Update User',
			'select_value' => 'Select Value',
			'cumulative_component_price' => 'Cumulative Component Price',
			'price_preference' => 'Price Preference',
		);
	}

	/**
	 * Retrieves a list of models based on the current search/filter conditions.
	 *
	 * Typical usecase:
	 * - Initialize the model fields with values from filter form.
	 * - Execute this method to get CActiveDataProvider instance which will filter
	 * models according to data in model fields.
	 * - Pass data provider to CGridView, CListView or any similar widget.
	 *
	 * @return CActiveDataProvider the data provider that can return the models
	 * based on the search/filter conditions.
	 */
	public function search()
	{
		// @todo Please modify the following code to remove attributes that should not be searched.

		$criteria=new CDbCriteria;

		$criteria->compare('id',$this->id,true);
		$criteria->compare('name',$this->name,true);
		$criteria->compare('description',$this->description,true);
		$criteria->compare('icon',$this->icon,true);
		$criteria->compare('price',$this->price);
		$criteria->compare('min_discountable_number',$this->min_discountable_number);
		$criteria->compare('enforce_min_discountable_number',$this->enforce_min_discountable_number);
		$criteria->compare('min_subscription_required',$this->min_subscription_required);
		$criteria->compare('discount_rate',$this->discount_rate);
		$criteria->compare('visibility',$this->visibility,true);
		$criteria->compare('domain_id',$this->domain_id,true);
		$criteria->compare('original_toolbox_id',$this->original_toolbox_id);
		$criteria->compare('duplicate',$this->duplicate);
		$criteria->compare('is_duplicate',$this->is_duplicate);
		$criteria->compare('reconstruct_toolbox',$this->reconstruct_toolbox);
		$criteria->compare('discount_proof',$this->discount_proof);
		$criteria->compare('create_time',$this->create_time,true);
		$criteria->compare('create_user_id',$this->create_user_id);
		$criteria->compare('update_time',$this->update_time,true);
		$criteria->compare('update_user_id',$this->update_user_id);
		$criteria->compare('select_value',$this->select_value);
		$criteria->compare('cumulative_component_price',$this->cumulative_component_price);
		$criteria->compare('price_preference',$this->price_preference);

		return new CActiveDataProvider($this, array(
			'criteria'=>$criteria,
		));
	}

	/**
	 * Returns the static model of the specified AR class.
	 * Please note that you should have this exact method in all your CActiveRecord descendants!
	 * @param string $className active record class name.
	 * @return Resourcegroup the static model class
	 */
	public static function model($className=__CLASS__)
	{
		return parent::model($className);
	}
        
        
       
}
