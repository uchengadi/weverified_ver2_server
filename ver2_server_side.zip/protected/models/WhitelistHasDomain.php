<?php

/**
 * This is the model class for table "whitelist_has_domain".
 *
 * The followings are the available columns in table 'whitelist_has_domain':
 * @property string $whitelist_id
 * @property string $domain_id
 * @property integer $is_conditional
 * @property string $condition
 * @property string $date_whitelisted
 * @property string $date_removed_from_whitelist
 * @property integer $whitelisted_by
 * @property integer $removed_id
 */
class WhitelistHasDomain extends CActiveRecord
{
	/**
	 * @return string the associated database table name
	 */
	public function tableName()
	{
		return 'whitelist_has_domain';
	}

	/**
	 * @return array validation rules for model attributes.
	 */
	public function rules()
	{
		// NOTE: you should only define rules for those attributes that
		// will receive user inputs.
		return array(
			array('whitelist_id, domain_id', 'required'),
			array('is_conditional, whitelisted_by, removed_id', 'numerical', 'integerOnly'=>true),
			array('whitelist_id, domain_id', 'length', 'max'=>10),
			array('condition, date_whitelisted, date_removed_from_whitelist', 'safe'),
			// The following rule is used by search().
			// @todo Please remove those attributes that should not be searched.
			array('whitelist_id, domain_id, is_conditional, condition, date_whitelisted, date_removed_from_whitelist, whitelisted_by, removed_id', 'safe', 'on'=>'search'),
		);
	}

	/**
	 * @return array relational rules.
	 */
	public function relations()
	{
		// NOTE: you may need to adjust the relation name and the related
		// class name for the relations automatically generated below.
		return array(
		);
	}

	/**
	 * @return array customized attribute labels (name=>label)
	 */
	public function attributeLabels()
	{
		return array(
			'whitelist_id' => 'Whitelist',
			'domain_id' => 'Domain',
			'is_conditional' => 'Is Conditional',
			'condition' => 'Condition',
			'date_whitelisted' => 'Date Whitelisted',
			'date_removed_from_whitelist' => 'Date Removed From Whitelist',
			'whitelisted_by' => 'Whitelisted By',
			'removed_id' => 'Removed',
		);
	}

	/**
	 * Retrieves a list of models based on the current search/filter conditions.
	 *
	 * Typical usecase:
	 * - Initialize the model fields with values from filter form.
	 * - Execute this method to get CActiveDataProvider instance which will filter
	 * models according to data in model fields.
	 * - Pass data provider to CGridView, CListView or any similar widget.
	 *
	 * @return CActiveDataProvider the data provider that can return the models
	 * based on the search/filter conditions.
	 */
	public function search()
	{
		// @todo Please modify the following code to remove attributes that should not be searched.

		$criteria=new CDbCriteria;

		$criteria->compare('whitelist_id',$this->whitelist_id,true);
		$criteria->compare('domain_id',$this->domain_id,true);
		$criteria->compare('is_conditional',$this->is_conditional);
		$criteria->compare('condition',$this->condition,true);
		$criteria->compare('date_whitelisted',$this->date_whitelisted,true);
		$criteria->compare('date_removed_from_whitelist',$this->date_removed_from_whitelist,true);
		$criteria->compare('whitelisted_by',$this->whitelisted_by);
		$criteria->compare('removed_id',$this->removed_id);

		return new CActiveDataProvider($this, array(
			'criteria'=>$criteria,
		));
	}

	/**
	 * Returns the static model of the specified AR class.
	 * Please note that you should have this exact method in all your CActiveRecord descendants!
	 * @param string $className active record class name.
	 * @return WhitelistHasDomain the static model class
	 */
	public static function model($className=__CLASS__)
	{
		return parent::model($className);
	}
}
