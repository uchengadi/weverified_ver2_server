<?php

/**
 * This is the model class for table "engagement_for_enlistment".
 *
 * The followings are the available columns in table 'engagement_for_enlistment':
 * @property string $id
 * @property string $code_id
 * @property string $appointment_date
 * @property string $appointment_time
 * @property integer $reachme_by_email
 * @property integer $reachme_by_phone
 * @property integer $reachme_by_whatsapp
 */
class EngagementForEnlistment extends CActiveRecord
{
	/**
	 * @return string the associated database table name
	 */
	public function tableName()
	{
		return 'engagement_for_enlistment';
	}

	/**
	 * @return array validation rules for model attributes.
	 */
	public function rules()
	{
		// NOTE: you should only define rules for those attributes that
		// will receive user inputs.
		return array(
			array('code_id', 'required'),
			array('reachme_by_email, reachme_by_phone, reachme_by_whatsapp', 'numerical', 'integerOnly'=>true),
			array('code_id', 'length', 'max'=>10),
			array('appointment_time', 'length', 'max'=>250),
			array('appointment_date', 'safe'),
			// The following rule is used by search().
			// @todo Please remove those attributes that should not be searched.
			array('id, code_id, appointment_date, appointment_time, reachme_by_email, reachme_by_phone, reachme_by_whatsapp', 'safe', 'on'=>'search'),
		);
	}

	/**
	 * @return array relational rules.
	 */
	public function relations()
	{
		// NOTE: you may need to adjust the relation name and the related
		// class name for the relations automatically generated below.
		return array(
		);
	}

	/**
	 * @return array customized attribute labels (name=>label)
	 */
	public function attributeLabels()
	{
		return array(
			'id' => 'ID',
			'code_id' => 'Code',
			'appointment_date' => 'Appointment Date',
			'appointment_time' => 'Appointment Time',
			'reachme_by_email' => 'Reachme By Email',
			'reachme_by_phone' => 'Reachme By Phone',
			'reachme_by_whatsapp' => 'Reachme By Whatsapp',
		);
	}

	/**
	 * Retrieves a list of models based on the current search/filter conditions.
	 *
	 * Typical usecase:
	 * - Initialize the model fields with values from filter form.
	 * - Execute this method to get CActiveDataProvider instance which will filter
	 * models according to data in model fields.
	 * - Pass data provider to CGridView, CListView or any similar widget.
	 *
	 * @return CActiveDataProvider the data provider that can return the models
	 * based on the search/filter conditions.
	 */
	public function search()
	{
		// @todo Please modify the following code to remove attributes that should not be searched.

		$criteria=new CDbCriteria;

		$criteria->compare('id',$this->id,true);
		$criteria->compare('code_id',$this->code_id,true);
		$criteria->compare('appointment_date',$this->appointment_date,true);
		$criteria->compare('appointment_time',$this->appointment_time,true);
		$criteria->compare('reachme_by_email',$this->reachme_by_email);
		$criteria->compare('reachme_by_phone',$this->reachme_by_phone);
		$criteria->compare('reachme_by_whatsapp',$this->reachme_by_whatsapp);

		return new CActiveDataProvider($this, array(
			'criteria'=>$criteria,
		));
	}

	/**
	 * Returns the static model of the specified AR class.
	 * Please note that you should have this exact method in all your CActiveRecord descendants!
	 * @param string $className active record class name.
	 * @return EngagementForEnlistment the static model class
	 */
	public static function model($className=__CLASS__)
	{
		return parent::model($className);
	}
        
        
        /**
         * This is function that confirms if a user is not already on appointment
         */
        public function isUserAlreadyOnAppointment($code_id,$user_id){
            $cmd =Yii::app()->db->createCommand();
                $cmd->select('COUNT(*)')
                    ->from('engagement_for_enlistment')
                    ->where("code_id = $code_id and user_id=$user_id");
                $result = $cmd->queryScalar();
                
                if($result > 0){
                    return true;
                }else{
                    return false;
                }
        }
        
        
         /**
         * This is the function that confirms if a user is permitted to provide a feedback response
         */
        public function isUserPermittedToScheduleAnAppointmentEngagement($code_id,$user_id){
            $model = new EnlistmentVerificationCode;
            if($model->isCodeSupportMultipleEngagementScheduling($code_id)){
                return true;
            }else{
                if($this->isUserAlreadyOnAppointment($code_id,$user_id)){
                    return false;
                }else{
                    return true;
                }
            }
        }
}
