<?php

/**
 * This is the model class for table "member_has_colleagues".
 *
 * The followings are the available columns in table 'member_has_colleagues':
 * @property string $member_id
 * @property string $colleague_id
 * @property string $type
 * @property integer $issues_and_values_id
 * @property string $request
 * @property string $status
 * @property string $date_initiated
 * @property string $date_accepted
 * @property integer $initiated_user_id
 * @property integer $accepted_user_id
 */
class MemberHasColleagues extends CActiveRecord
{
	/**
	 * @return string the associated database table name
	 */
	public function tableName()
	{
		return 'member_has_colleagues';
	}

	/**
	 * @return array validation rules for model attributes.
	 */
	public function rules()
	{
		// NOTE: you should only define rules for those attributes that
		// will receive user inputs.
		return array(
			array('member_id, colleague_id, type', 'required'),
			array('issues_and_values_id, initiated_user_id, accepted_user_id', 'numerical', 'integerOnly'=>true),
			array('member_id, colleague_id, status', 'length', 'max'=>10),
			array('type, request', 'length', 'max'=>8),
			array('date_initiated, date_accepted', 'safe'),
			// The following rule is used by search().
			// @todo Please remove those attributes that should not be searched.
			array('member_id, colleague_id, type, issues_and_values_id, request, status, date_initiated, date_accepted, initiated_user_id, accepted_user_id', 'safe', 'on'=>'search'),
		);
	}

	/**
	 * @return array relational rules.
	 */
	public function relations()
	{
		// NOTE: you may need to adjust the relation name and the related
		// class name for the relations automatically generated below.
		return array(
		);
	}

	/**
	 * @return array customized attribute labels (name=>label)
	 */
	public function attributeLabels()
	{
		return array(
			'member_id' => 'Member',
			'colleague_id' => 'Colleague',
			'type' => 'Type',
			'issues_and_values_id' => 'Issues And Values',
			'request' => 'Request',
			'status' => 'Status',
			'date_initiated' => 'Date Initiated',
			'date_accepted' => 'Date Accepted',
			'initiated_user_id' => 'Initiated User',
			'accepted_user_id' => 'Accepted User',
		);
	}

	/**
	 * Retrieves a list of models based on the current search/filter conditions.
	 *
	 * Typical usecase:
	 * - Initialize the model fields with values from filter form.
	 * - Execute this method to get CActiveDataProvider instance which will filter
	 * models according to data in model fields.
	 * - Pass data provider to CGridView, CListView or any similar widget.
	 *
	 * @return CActiveDataProvider the data provider that can return the models
	 * based on the search/filter conditions.
	 */
	public function search()
	{
		// @todo Please modify the following code to remove attributes that should not be searched.

		$criteria=new CDbCriteria;

		$criteria->compare('member_id',$this->member_id,true);
		$criteria->compare('colleague_id',$this->colleague_id,true);
		$criteria->compare('type',$this->type,true);
		$criteria->compare('issues_and_values_id',$this->issues_and_values_id);
		$criteria->compare('request',$this->request,true);
		$criteria->compare('status',$this->status,true);
		$criteria->compare('date_initiated',$this->date_initiated,true);
		$criteria->compare('date_accepted',$this->date_accepted,true);
		$criteria->compare('initiated_user_id',$this->initiated_user_id);
		$criteria->compare('accepted_user_id',$this->accepted_user_id);

		return new CActiveDataProvider($this, array(
			'criteria'=>$criteria,
		));
	}

	/**
	 * Returns the static model of the specified AR class.
	 * Please note that you should have this exact method in all your CActiveRecord descendants!
	 * @param string $className active record class name.
	 * @return MemberHasColleagues the static model class
	 */
	public static function model($className=__CLASS__)
	{
		return parent::model($className);
	}
        
        /**
         * This is the function that retrieves all awaiting colleagues request
         */
        public function getAllTheColleaguesAwaitingRequestOfThisMember($userid){
            
            $pending_colleagues = [];
             $criteria = new CDbCriteria();
             $criteria->select = '*';
             $criteria->condition='member_id=:memberid and request=:request';   
             $criteria->params = array(':memberid'=>$userid, ':request'=>'pending');
             $colleagues = MemberHasColleagues::model()->findAll($criteria);
             
             foreach($colleagues as $colleague){
                 $pending_colleagues[] = $colleague['colleague_id'];
             }
             return $pending_colleagues;
        }
        
        
        
        /**
         * This is the function that retrieves all colleagues members of a user
         */
        public function getAllTheColleaguesOfThisMember($userid){
            
            $member_colleagues = [];
             $criteria = new CDbCriteria();
             $criteria->select = '*';
             $criteria->condition='member_id=:memberid and request=:request';   
             $criteria->params = array(':memberid'=>$userid, ':request'=>'accepted');
             $colleagues = MemberHasColleagues::model()->findAll($criteria);
             
             foreach($colleagues as $colleague){
                 $member_colleagues[] = $colleague['colleague_id'];
             }
             return $member_colleagues;
        }
        
        
        /**
         * This is the function that confirms if a member is eligible to initiate colleague request to  the target member
         */
        public function isThisMemberEligibleForAColleagueRequestToTheTargetColleague($member_id, $colleague){
            
            if($this->isSimilarColleagueRequestPending($member_id,$colleague)){
                return false;
            }else if($this->isThisMemberAlreadyAColleagueToTheTargetColleague($member_id,$colleague)){
                return false;
            }else{
                return true;
            }
            
        }
        
        
        /**
         * This is the function that confirms if a similar colleague request is existing
         */
        public function isSimilarColleagueRequestPending($member_id,$colleague){
            
            if($this->isSimilarMemberToColleagueRequestPending($member_id,$colleague)){
                return true;
            }else if($this->isColleagueToMemberColleagueRequestPending($colleague,$member_id)){
                return true;
            }else{
                return false;
            }
        }
        
        
        /**
         * This is the function that confirms if a similar member to colleague request is pending
         */
        public function isSimilarMemberToColleagueRequestPending($member_id,$colleague_id){
            $cmd =Yii::app()->db->createCommand();
                $cmd->select('COUNT(*)')
                    ->from('member_has_colleagues')
                    ->where("(member_id = $member_id and colleague_id=$colleague_id) and request='pending'");
                $result = $cmd->queryScalar();
                
                if($result>0){
                    return true;
                }else{
                    return false;
                }
        }
        
        
        
         /**
         * This is the function that confirms if a similar colleague to member request is pending
         */
        public function isColleagueToMemberColleagueRequestPending($colleague_id,$member_id){
            $cmd =Yii::app()->db->createCommand();
                $cmd->select('COUNT(*)')
                    ->from('member_has_colleagues')
                    ->where("(member_id = $colleague_id and colleague_id=$member_id) and request='pending'");
                $result = $cmd->queryScalar();
                
                if($result>0){
                    return true;
                }else{
                    return false;
                }
        }
        
        
        /**
         * This is the function that confirms the initiation of a colleague request
         */
        public function isColleagueRequestSuccessfullyInitiated($member_id,$colleague_id){
            
             if($this->isAPreviouslyRejectedRequestRemoved($member_id,$colleague_id)){
                
                $cmd =Yii::app()->db->createCommand();
                $result = $cmd->insert('member_has_colleagues',
                                  array(
                                    'member_id'=>$member_id,
                                    'colleague_id'=>$colleague_id,
                                    'request'=>"pending",   
                                    'date_initiated'=>new CDbExpression('NOW()'),
                                    'initiated_user_id'=>Yii::app()->user->id  
                                  )
			
                        );
                if($result>0){
                    return true;
                }else{
                    return false;
                }
            }else{
                return false;
            }
            
        }
        
         /**
         * This is the function that confirms if the previoue rejected colleague request was successfuly removed
         */
        public function isAPreviouslyRejectedRequestRemoved($member_id,$colleague_id){
            
            if($this->isPreviouslyRejectedRequestFromMemberToColleagueRemoved($member_id,$colleague_id)){
                if($this->isPreviouslyRejectedRequestFromColleagueToMemberRemoved($colleague_id,$member_id)){
                    return true;
                }else{
                    return false;
                }
            }else{
                return false;
            }
             
        }
        
        
        /**
         * This is the function that removes previously rejected from member to colleague
         */
        public function isPreviouslyRejectedRequestFromMemberToColleagueRemoved($member_id,$colleague_id){
            
            if($this->isRejectedRequestFromMemberToColleagueExist($member_id,$colleague_id)){
                $cmd =Yii::app()->db->createCommand();  
                $result = $cmd->delete('member_has_colleagues','(member_id=:memberid and colleague_id=:collid) and request=:request', array(':memberid'=>$member_id,':collid'=>$colleague_id,':request'=>"rejected"));
            
                if($result>0){
                    return true;
                    
                }else{
                    return false;
                }
            }else{
                return true;
            }
        }
        
        
         /**
         * This is the function that removes previously rejected from  colleague to member
         */
        public function isPreviouslyRejectedRequestFromColleagueToMemberRemoved($colleague_id,$member_id){
            
            if($this->isRejectedRequestFromMemberToColleagueExist($colleague_id,$member_id)){
                $cmd =Yii::app()->db->createCommand();  
                $result = $cmd->delete('member_has_colleagues','(member_id=:memberid and colleague_id=:collid) and request=:request', array(':memberid'=>$colleague_id,':collid'=>$member_id,':request'=>"rejected"));
            
                if($result>0){
                    return true;
                    
                }else{
                    return false;
                }
            }else{
                return true;
            }
        }
        
        
        /**
         * This function is confirm the existence of a rejected colleague between two members
         */
        public function isRejectedRequestFromMemberToColleagueExist($member_id,$colleague_id){
            
            $cmd =Yii::app()->db->createCommand();
                $cmd->select('COUNT(*)')
                    ->from('member_has_colleagues')
                    ->where("(member_id = $colleague_id and colleague_id=$member_id) and request='rejected'");
                $result = $cmd->queryScalar();
                
                if($result>0){
                    return true;
                }else{
                    return false;
                }
        }
        
        
        /**
         * This is the function that rejects a colleague request by a member
         */
        public function isTheRejectionOfThisColleagueRequestASuccess($member_id,$colleague_id){
            
             if($this->isThisColleaguRequestPending($member_id,$colleague_id)){
                     $cmd =Yii::app()->db->createCommand();
                     $result = $cmd->insert('member_has_colleagues',
                                  array(
                                    'member_id'=>$member_id,
                                    'colleague_id'=>$colleague_id,
                                    'pending'=>"rejected",   
                                    
                                  )
			
                        );
                if($result>0){
                    return true;
                }else{
                    return false;
                }
                    
                }else{
                    return false;
                }   
            
        }
        
        
        /**
         * This is the function that confirms if a colleague request is pending
         */
        public function isThisColleaguRequestPending($member_id,$colleague_id){
            
             $cmd =Yii::app()->db->createCommand();
                $cmd->select('COUNT(*)')
                    ->from('member_has_colleagues')
                    ->where("(member_id = $member_id and colleague_id=$colleague_id) and request='pending'");
                $result = $cmd->queryScalar();
                
                if($result>0){
                    return true;
                }else{
                    return false;
                }
        }
        
        
        
        /**
         * This is the function that confirms if a colleague requested is accepted
         */
        public function isTheAcceptanceOfThisColleagueRequestASuccess($member_id,$colleague_id){
            
            if($this->isThisColleaguRequestPending($member_id,$colleague_id)){
                    $cmd =Yii::app()->db->createCommand();
                     $result = $cmd->insert('member_has_colleagues',
                                  array(
                                    'member_id'=>$member_id,
                                    'colleague_id'=>$colleague_id,
                                    'pending'=>"accepted",   
                                    
                                  )
			
                        );
                if($result>0){
                    return true;
                }else{
                    return false;
                }
                    
                }else{
                    return false;
                }     
        }
        
        
        
        /*8
         * This is the function that gets the total number of colleagues of a member
         */
        public function getTheTotalNumberOfThisUserColleagues($member_id){
            $cmd =Yii::app()->db->createCommand();
                $cmd->select('COUNT(*)')
                    ->from('member_has_colleagues')
                    ->where("member_id = $member_id and request='accepted'");
                $result = $cmd->queryScalar();
                
                return $result;
        }
}
