<?php

/**
 * This is the model class for table "domain_verification".
 *
 * The followings are the available columns in table 'domain_verification':
 * @property string $id
 * @property string $domain_id
 * @property string $issue_of_verification
 * @property string $status
 * @property integer $is_paid_for
 */
class DomainVerification extends CActiveRecord
{
	/**
	 * @return string the associated database table name
	 */
	public function tableName()
	{
		return 'domain_verification';
	}

	/**
	 * @return array validation rules for model attributes.
	 */
	public function rules()
	{
		// NOTE: you should only define rules for those attributes that
		// will receive user inputs.
		return array(
			array('domain_id, issue_of_verification, status', 'required'),
			array('is_paid_for', 'numerical', 'integerOnly'=>true),
			array('domain_id', 'length', 'max'=>10),
			array('issue_of_verification', 'length', 'max'=>41),
			array('status', 'length', 'max'=>9),
			// The following rule is used by search().
			// @todo Please remove those attributes that should not be searched.
			array('id, domain_id, issue_of_verification, status, is_paid_for', 'safe', 'on'=>'search'),
		);
	}

	/**
	 * @return array relational rules.
	 */
	public function relations()
	{
		// NOTE: you may need to adjust the relation name and the related
		// class name for the relations automatically generated below.
		return array(
		);
	}

	/**
	 * @return array customized attribute labels (name=>label)
	 */
	public function attributeLabels()
	{
		return array(
			'id' => 'ID',
			'domain_id' => 'Domain',
			'issue_of_verification' => 'Issue Of Verification',
			'status' => 'Status',
			'is_paid_for' => 'Is Paid For',
		);
	}

	/**
	 * Retrieves a list of models based on the current search/filter conditions.
	 *
	 * Typical usecase:
	 * - Initialize the model fields with values from filter form.
	 * - Execute this method to get CActiveDataProvider instance which will filter
	 * models according to data in model fields.
	 * - Pass data provider to CGridView, CListView or any similar widget.
	 *
	 * @return CActiveDataProvider the data provider that can return the models
	 * based on the search/filter conditions.
	 */
	public function search()
	{
		// @todo Please modify the following code to remove attributes that should not be searched.

		$criteria=new CDbCriteria;

		$criteria->compare('id',$this->id,true);
		$criteria->compare('domain_id',$this->domain_id,true);
		$criteria->compare('issue_of_verification',$this->issue_of_verification,true);
		$criteria->compare('status',$this->status,true);
		$criteria->compare('is_paid_for',$this->is_paid_for);

		return new CActiveDataProvider($this, array(
			'criteria'=>$criteria,
		));
	}

	/**
	 * Returns the static model of the specified AR class.
	 * Please note that you should have this exact method in all your CActiveRecord descendants!
	 * @param string $className active record class name.
	 * @return DomainVerification the static model class
	 */
	public static function model($className=__CLASS__)
	{
		return parent::model($className);
	}
        
        
           /**
         * This is the function that determines the type and size of icon file
         */
        public function isFileTypeLegal(){
            
           if(isset($_FILES['filename']['name'])){
                $tmpName = $_FILES['filename']['tmp_name'];
                $iconFileName = $_FILES['filename']['name'];    
                $iconFileType = $_FILES['filename']['type'];
                $iconFileSize = $_FILES['filename']['size'];
            } 
          if(($iconFileType === 'application/pdf')){
              return true;
               
            }else{
                return false;
            }
            
        }
        
        
        /**
         * This is the function that moves file to its destination
         */
        public function moveTheDocumentToItsPathAndReturnTheFilenameName($model,$icon_filename){
            
            if(isset($_FILES['filename']['name'])){
                        $tmpName = $_FILES['filename']['tmp_name'];
                        $iconName = $_FILES['filename']['name'];    
                        $iconType = $_FILES['filename']['type'];
                        $iconSize = $_FILES['filename']['size'];
                  
                   }
                    
                    if($iconName !== null) {
                        if($model->id === null){
                          //$iconFileName = $icon_filename; 
                          if($icon_filename != ""){
                                $iconFileName = time().'_'.$icon_filename;  
                            }else{
                                $iconFileName = $icon_filename;  
                            }    
                          
                           // upload the icon file
                        if($iconName !== null){
                            	$iconPath = Yii::app()->params['documents'].$iconFileName;
				move_uploaded_file($tmpName,$iconPath);
                                        
                        
                                return $iconFileName;
                        }else{
                            $iconFileName = $icon_filename;
                            return $iconFileName;
                        } // validate to save file
                        }else{
                            if($this->noNewVerificationFileProvided($model->id,$icon_filename)){
                                $iconFileName = $icon_filename; 
                                return $iconFileName;
                            }else{
                            if($icon_filename != ""){
                                
                                if($this->removeTheExistingVerificatioFile($model->id)){
                                 $iconFileName = time().'_'.$icon_filename; 
                                 //$iconFileName = time().$icon_filename;  
                                   $iconPath = Yii::app()->params['documents'].$iconFileName;
                                   move_uploaded_file($tmpName,$iconPath);
                                   return $iconFileName;
                                    
                                   // $iconFileName = time().'_'.$icon_filename;  
                                    
                             }
                            }
                                
                                
                            }
                            
                            //$iconFileName = $icon_filename; 
                                              
                            
                        }
                      
                     }else{
                         $iconFileName = $icon_filename;
                         return $iconFileName;
                     }
        }
        
        
        	/**
         * This is the function to ascertain if a new verification file was provided or not
         */
        public function noNewVerificationFileProvided($id,$filename){
            
                $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition='id=:id';
                $criteria->params = array(':id'=>$id);
                $filename= DomainVerification::model()->find($criteria);
                
                if($filename['filename']==$filename){
                    return true;
                }else{
                    return false;
                }
            
        }
        
        
        	 /**
         * This is the function that removes an existing video file
         */
        public function removeTheExistingVerificatioFile($id){
            
            //retreve the existing zip file from the database
            
            if($this->isTheVerificationFilenameNotTheDefault($id)){
                
                $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition='id=:id';
                $criteria->params = array(':id'=>$id);
                $filename= DomainVerification::model()->find($criteria);
                
                //$directoryPath =  dirname(Yii::app()->request->scriptFile);
               $directoryPath = "c:\\xampp\htdocs\appspace_assets\\documents\\";
               // $iconpath = '..\appspace_assets\icons'.$icon['icon'];
                $filepath =$directoryPath.$filename['filename'];
                //$filepath = $directoryPath.$iconpath;
                
                if(unlink($filepath)){
                    return true;
                }else{
                    return false;
                }
                
            }else{
                return true;
            }
                
            
            
        }
        
        
        
          /**
         * This is the function that determines if  the filename is the default
         */
        public function isTheVerificationFilenameNotTheDefault($id){
            
                $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition='id=:id';
                $criteria->params = array(':id'=>$id);
                $filename= DomainVerification::model()->find($criteria);
                
                if($filename['filename'] == "" || $filename['filename'] ===NULL){
                    return false;
                }else{
                    return true;
                }
        }
     
        
        /**
         * This is the function that updates a user verification request information
         */
        public function isTheUpdateOfTheVerificationIssueASuccess($id,$issue_for_verification){
            
             $cmd =Yii::app()->db->createCommand();
                $result = $cmd->update('domain_verification',
                                  array(
                                    'issue_of_verification'=>$issue_for_verification
                   ),
                     ("id=$id"));
            if($result>0){
                return true;
            }else{
                return false;
            }
        }
        
        
        
        /**
         * This is the function that determines if a member has veried a subject somain
         */
        public function isThisDomainRequestedForVericationByThisUser($userid,$subject_domain_id){
            
             $cmd =Yii::app()->db->createCommand();
                $cmd->select('COUNT(*)')
                    ->from('domain_verification')
                    ->where("domain_id = $subject_domain_id and (requestor_id=$userid and status='verified')");
                $result = $cmd->queryScalar();
                
                if($result>0){
                    return true;
                }else{
                    return false;
                }
            
        }
         
        
        /**
         * Thisn is the function that retrieves all verified domains
         */
        public function retrieveAllVerifiedDomains(){
                $all_verified = [];
                $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition='status=:status';
                $criteria->params = array(':status'=>"verified");
                $verified= DomainVerification::model()->findAll($criteria);
                
                foreach($verified as $ver){
                    $all_verified[] = $ver['domain_id'];
                    
                }
                
                return array_unique($all_verified);
            
        }
        
        
         /**
         * Thisn is the function that retrieves all verified domains
         */
        public function retrieveThisUserVerifiedDomains($userid,$user_domain_id){
                $all_verified = [];
                $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition='status=:status and (requestor_id=:requestorid and requestor_domain_id=:reqdomid)';
                $criteria->params = array(':status'=>"verified", ':requestorid'=>$userid,':reqdomid'=>$user_domain_id);
                $verified= DomainVerification::model()->findAll($criteria);
                
                foreach($verified as $ver){
                    $all_verified[] = $ver['domain_id'];
                    
                }
                
                return $all_verified;
            
        }
        
        
        
        /**
         * This is the function that retrieves the corresponding domain given the verification id
         */
        public function getTheDomainForThisVerification($verification_id){
            
                $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition='id=:id';
                $criteria->params = array(':id'=>$verification_id);
                $verify= DomainVerification::model()->find($criteria);
                
                return $verify['domain_id'];
                
        }
        
        
        /**
         * This is the function that list all domain with pending verification request
         */
        public function retrieveAllDomainsWithPendingVerificationRequest(){
                $all_request = [];
                $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition='status=:status and is_paid_for=:paidfor';
                $criteria->params = array(':status'=>"requested",':paidfor'=>1);
                $requests= DomainVerification::model()->findAll($criteria);
                
                foreach($requests as $request){
                    $all_request[] = $request['domain_id'];
                    
                }
                
                return array_unique($all_request);
        }
        
        
}
