<?php
/* @var $this VirtualBatchRequestController */
/* @var $model VirtualBatchRequest */

$this->breadcrumbs=array(
	'Virtual Batch Requests'=>array('index'),
	$model->id,
);

$this->menu=array(
	array('label'=>'List VirtualBatchRequest', 'url'=>array('index')),
	array('label'=>'Create VirtualBatchRequest', 'url'=>array('create')),
	array('label'=>'Update VirtualBatchRequest', 'url'=>array('update', 'id'=>$model->id)),
	array('label'=>'Delete VirtualBatchRequest', 'url'=>'#', 'linkOptions'=>array('submit'=>array('delete','id'=>$model->id),'confirm'=>'Are you sure you want to delete this item?')),
	array('label'=>'Manage VirtualBatchRequest', 'url'=>array('admin')),
);
?>

<h1>View VirtualBatchRequest #<?php echo $model->id; ?></h1>

<?php $this->widget('zii.widgets.CDetailView', array(
	'data'=>$model,
	'attributes'=>array(
		'id',
		'virtual_batch_id',
		'virtual_box_id',
		'virtual_requesting_domain_id',
		'virtual_requesting_user_id',
		'virtual_requesting_group_id',
		'virtual_requesting_subgroup_id',
		'status',
		'virtual_is_requested',
		'virtual_maximum_requesting_period_in_days',
		'virtual_request_initiation_date',
		'virtual_request_initiated_by',
		'virtual_is_request_initiated',
		'virtual_is_request_accepted',
		'virtual_request_accepted_date',
		'virtual_request_accepted_by',
		'virtual_is_group_request',
		'virtual_is_subgroup_request',
		'virtual_is_single_user_request',
		'virtual_is_electronic_instrument_request_included',
	),
)); ?>
