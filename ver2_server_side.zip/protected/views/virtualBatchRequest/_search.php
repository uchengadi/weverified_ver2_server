<?php
/* @var $this VirtualBatchRequestController */
/* @var $model VirtualBatchRequest */
/* @var $form CActiveForm */
?>

<div class="wide form">

<?php $form=$this->beginWidget('CActiveForm', array(
	'action'=>Yii::app()->createUrl($this->route),
	'method'=>'get',
)); ?>

	<div class="row">
		<?php echo $form->label($model,'id'); ?>
		<?php echo $form->textField($model,'id',array('size'=>10,'maxlength'=>10)); ?>
	</div>

	<div class="row">
		<?php echo $form->label($model,'virtual_batch_id'); ?>
		<?php echo $form->textField($model,'virtual_batch_id'); ?>
	</div>

	<div class="row">
		<?php echo $form->label($model,'virtual_box_id'); ?>
		<?php echo $form->textField($model,'virtual_box_id'); ?>
	</div>

	<div class="row">
		<?php echo $form->label($model,'virtual_requesting_domain_id'); ?>
		<?php echo $form->textField($model,'virtual_requesting_domain_id'); ?>
	</div>

	<div class="row">
		<?php echo $form->label($model,'virtual_requesting_user_id'); ?>
		<?php echo $form->textField($model,'virtual_requesting_user_id'); ?>
	</div>

	<div class="row">
		<?php echo $form->label($model,'virtual_requesting_group_id'); ?>
		<?php echo $form->textField($model,'virtual_requesting_group_id'); ?>
	</div>

	<div class="row">
		<?php echo $form->label($model,'virtual_requesting_subgroup_id'); ?>
		<?php echo $form->textField($model,'virtual_requesting_subgroup_id'); ?>
	</div>

	<div class="row">
		<?php echo $form->label($model,'status'); ?>
		<?php echo $form->textField($model,'status',array('size'=>8,'maxlength'=>8)); ?>
	</div>

	<div class="row">
		<?php echo $form->label($model,'virtual_is_requested'); ?>
		<?php echo $form->textField($model,'virtual_is_requested'); ?>
	</div>

	<div class="row">
		<?php echo $form->label($model,'virtual_maximum_requesting_period_in_days'); ?>
		<?php echo $form->textField($model,'virtual_maximum_requesting_period_in_days'); ?>
	</div>

	<div class="row">
		<?php echo $form->label($model,'virtual_request_initiation_date'); ?>
		<?php echo $form->textField($model,'virtual_request_initiation_date'); ?>
	</div>

	<div class="row">
		<?php echo $form->label($model,'virtual_request_initiated_by'); ?>
		<?php echo $form->textField($model,'virtual_request_initiated_by'); ?>
	</div>

	<div class="row">
		<?php echo $form->label($model,'virtual_is_request_initiated'); ?>
		<?php echo $form->textField($model,'virtual_is_request_initiated'); ?>
	</div>

	<div class="row">
		<?php echo $form->label($model,'virtual_is_request_accepted'); ?>
		<?php echo $form->textField($model,'virtual_is_request_accepted'); ?>
	</div>

	<div class="row">
		<?php echo $form->label($model,'virtual_request_accepted_date'); ?>
		<?php echo $form->textField($model,'virtual_request_accepted_date'); ?>
	</div>

	<div class="row">
		<?php echo $form->label($model,'virtual_request_accepted_by'); ?>
		<?php echo $form->textField($model,'virtual_request_accepted_by'); ?>
	</div>

	<div class="row">
		<?php echo $form->label($model,'virtual_is_group_request'); ?>
		<?php echo $form->textField($model,'virtual_is_group_request'); ?>
	</div>

	<div class="row">
		<?php echo $form->label($model,'virtual_is_subgroup_request'); ?>
		<?php echo $form->textField($model,'virtual_is_subgroup_request'); ?>
	</div>

	<div class="row">
		<?php echo $form->label($model,'virtual_is_single_user_request'); ?>
		<?php echo $form->textField($model,'virtual_is_single_user_request'); ?>
	</div>

	<div class="row">
		<?php echo $form->label($model,'virtual_is_electronic_instrument_request_included'); ?>
		<?php echo $form->textField($model,'virtual_is_electronic_instrument_request_included'); ?>
	</div>

	<div class="row buttons">
		<?php echo CHtml::submitButton('Search'); ?>
	</div>

<?php $this->endWidget(); ?>

</div><!-- search-form -->