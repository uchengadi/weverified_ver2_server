<?php
/* @var $this VirtualBatchRequestController */
/* @var $model VirtualBatchRequest */

$this->breadcrumbs=array(
	'Virtual Batch Requests'=>array('index'),
	'Manage',
);

$this->menu=array(
	array('label'=>'List VirtualBatchRequest', 'url'=>array('index')),
	array('label'=>'Create VirtualBatchRequest', 'url'=>array('create')),
);

Yii::app()->clientScript->registerScript('search', "
$('.search-button').click(function(){
	$('.search-form').toggle();
	return false;
});
$('.search-form form').submit(function(){
	$('#virtual-batch-request-grid').yiiGridView('update', {
		data: $(this).serialize()
	});
	return false;
});
");
?>

<h1>Manage Virtual Batch Requests</h1>

<p>
You may optionally enter a comparison operator (<b>&lt;</b>, <b>&lt;=</b>, <b>&gt;</b>, <b>&gt;=</b>, <b>&lt;&gt;</b>
or <b>=</b>) at the beginning of each of your search values to specify how the comparison should be done.
</p>

<?php echo CHtml::link('Advanced Search','#',array('class'=>'search-button')); ?>
<div class="search-form" style="display:none">
<?php $this->renderPartial('_search',array(
	'model'=>$model,
)); ?>
</div><!-- search-form -->

<?php $this->widget('zii.widgets.grid.CGridView', array(
	'id'=>'virtual-batch-request-grid',
	'dataProvider'=>$model->search(),
	'filter'=>$model,
	'columns'=>array(
		'id',
		'virtual_batch_id',
		'virtual_box_id',
		'virtual_requesting_domain_id',
		'virtual_requesting_user_id',
		'virtual_requesting_group_id',
		/*
		'virtual_requesting_subgroup_id',
		'status',
		'virtual_is_requested',
		'virtual_maximum_requesting_period_in_days',
		'virtual_request_initiation_date',
		'virtual_request_initiated_by',
		'virtual_is_request_initiated',
		'virtual_is_request_accepted',
		'virtual_request_accepted_date',
		'virtual_request_accepted_by',
		'virtual_is_group_request',
		'virtual_is_subgroup_request',
		'virtual_is_single_user_request',
		'virtual_is_electronic_instrument_request_included',
		*/
		array(
			'class'=>'CButtonColumn',
		),
	),
)); ?>
