<?php
/* @var $this VirtualBatchRequestController */
/* @var $model VirtualBatchRequest */
/* @var $form CActiveForm */
?>

<div class="form">

<?php $form=$this->beginWidget('CActiveForm', array(
	'id'=>'virtual-batch-request-form',
	// Please note: When you enable ajax validation, make sure the corresponding
	// controller action is handling ajax validation correctly.
	// There is a call to performAjaxValidation() commented in generated controller code.
	// See class documentation of CActiveForm for details on this.
	'enableAjaxValidation'=>false,
)); ?>

	<p class="note">Fields with <span class="required">*</span> are required.</p>

	<?php echo $form->errorSummary($model); ?>

	<div class="row">
		<?php echo $form->labelEx($model,'virtual_batch_id'); ?>
		<?php echo $form->textField($model,'virtual_batch_id'); ?>
		<?php echo $form->error($model,'virtual_batch_id'); ?>
	</div>

	<div class="row">
		<?php echo $form->labelEx($model,'virtual_box_id'); ?>
		<?php echo $form->textField($model,'virtual_box_id'); ?>
		<?php echo $form->error($model,'virtual_box_id'); ?>
	</div>

	<div class="row">
		<?php echo $form->labelEx($model,'virtual_requesting_domain_id'); ?>
		<?php echo $form->textField($model,'virtual_requesting_domain_id'); ?>
		<?php echo $form->error($model,'virtual_requesting_domain_id'); ?>
	</div>

	<div class="row">
		<?php echo $form->labelEx($model,'virtual_requesting_user_id'); ?>
		<?php echo $form->textField($model,'virtual_requesting_user_id'); ?>
		<?php echo $form->error($model,'virtual_requesting_user_id'); ?>
	</div>

	<div class="row">
		<?php echo $form->labelEx($model,'virtual_requesting_group_id'); ?>
		<?php echo $form->textField($model,'virtual_requesting_group_id'); ?>
		<?php echo $form->error($model,'virtual_requesting_group_id'); ?>
	</div>

	<div class="row">
		<?php echo $form->labelEx($model,'virtual_requesting_subgroup_id'); ?>
		<?php echo $form->textField($model,'virtual_requesting_subgroup_id'); ?>
		<?php echo $form->error($model,'virtual_requesting_subgroup_id'); ?>
	</div>

	<div class="row">
		<?php echo $form->labelEx($model,'status'); ?>
		<?php echo $form->textField($model,'status',array('size'=>8,'maxlength'=>8)); ?>
		<?php echo $form->error($model,'status'); ?>
	</div>

	<div class="row">
		<?php echo $form->labelEx($model,'virtual_is_requested'); ?>
		<?php echo $form->textField($model,'virtual_is_requested'); ?>
		<?php echo $form->error($model,'virtual_is_requested'); ?>
	</div>

	<div class="row">
		<?php echo $form->labelEx($model,'virtual_maximum_requesting_period_in_days'); ?>
		<?php echo $form->textField($model,'virtual_maximum_requesting_period_in_days'); ?>
		<?php echo $form->error($model,'virtual_maximum_requesting_period_in_days'); ?>
	</div>

	<div class="row">
		<?php echo $form->labelEx($model,'virtual_request_initiation_date'); ?>
		<?php echo $form->textField($model,'virtual_request_initiation_date'); ?>
		<?php echo $form->error($model,'virtual_request_initiation_date'); ?>
	</div>

	<div class="row">
		<?php echo $form->labelEx($model,'virtual_request_initiated_by'); ?>
		<?php echo $form->textField($model,'virtual_request_initiated_by'); ?>
		<?php echo $form->error($model,'virtual_request_initiated_by'); ?>
	</div>

	<div class="row">
		<?php echo $form->labelEx($model,'virtual_is_request_initiated'); ?>
		<?php echo $form->textField($model,'virtual_is_request_initiated'); ?>
		<?php echo $form->error($model,'virtual_is_request_initiated'); ?>
	</div>

	<div class="row">
		<?php echo $form->labelEx($model,'virtual_is_request_accepted'); ?>
		<?php echo $form->textField($model,'virtual_is_request_accepted'); ?>
		<?php echo $form->error($model,'virtual_is_request_accepted'); ?>
	</div>

	<div class="row">
		<?php echo $form->labelEx($model,'virtual_request_accepted_date'); ?>
		<?php echo $form->textField($model,'virtual_request_accepted_date'); ?>
		<?php echo $form->error($model,'virtual_request_accepted_date'); ?>
	</div>

	<div class="row">
		<?php echo $form->labelEx($model,'virtual_request_accepted_by'); ?>
		<?php echo $form->textField($model,'virtual_request_accepted_by'); ?>
		<?php echo $form->error($model,'virtual_request_accepted_by'); ?>
	</div>

	<div class="row">
		<?php echo $form->labelEx($model,'virtual_is_group_request'); ?>
		<?php echo $form->textField($model,'virtual_is_group_request'); ?>
		<?php echo $form->error($model,'virtual_is_group_request'); ?>
	</div>

	<div class="row">
		<?php echo $form->labelEx($model,'virtual_is_subgroup_request'); ?>
		<?php echo $form->textField($model,'virtual_is_subgroup_request'); ?>
		<?php echo $form->error($model,'virtual_is_subgroup_request'); ?>
	</div>

	<div class="row">
		<?php echo $form->labelEx($model,'virtual_is_single_user_request'); ?>
		<?php echo $form->textField($model,'virtual_is_single_user_request'); ?>
		<?php echo $form->error($model,'virtual_is_single_user_request'); ?>
	</div>

	<div class="row">
		<?php echo $form->labelEx($model,'virtual_is_electronic_instrument_request_included'); ?>
		<?php echo $form->textField($model,'virtual_is_electronic_instrument_request_included'); ?>
		<?php echo $form->error($model,'virtual_is_electronic_instrument_request_included'); ?>
	</div>

	<div class="row buttons">
		<?php echo CHtml::submitButton($model->isNewRecord ? 'Create' : 'Save'); ?>
	</div>

<?php $this->endWidget(); ?>

</div><!-- form -->