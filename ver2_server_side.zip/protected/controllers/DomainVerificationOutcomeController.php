<?php

class DomainVerificationOutcomeController extends Controller
{
	/**
	 * @var string the default layout for the views. Defaults to '//layouts/column2', meaning
	 * using two-column layout. See 'protected/views/layouts/column2.php'.
	 */
	public $layout='//layouts/column2';

	/**
	 * @return array action filters
	 */
	public function filters()
	{
		return array(
			'accessControl', // perform access control for CRUD operations
			'postOnly + delete', // we only allow deletion via POST request
		);
	}

	/**
	 * Specifies the access control rules.
	 * This method is used by the 'accessControl' filter.
	 * @return array access control rules
	 */
	public function accessRules()
	{
		return array(
			array('allow',  // allow all users to perform 'index' and 'view' actions
				'actions'=>array('index','view'),
				'users'=>array('*'),
			),
			array('allow', // allow authenticated user to perform 'create' and 'update' actions
				'actions'=>array('create','update','requestdomainverificationrequest','updatedomainverificationrequest',
                                    'verifyingthisdomainverificationrequest'),
				'users'=>array('@'),
			),
			array('allow', // allow admin user to perform 'admin' and 'delete' actions
				'actions'=>array('admin','delete'),
				'users'=>array('admin'),
			),
			array('deny',  // deny all users
				'users'=>array('*'),
			),
		);
	}

	/**
         *  * This is the function that makes a domain verification request
         */
        public function actionrequestdomainverificationrequest(){
            
            $model = new DomainVerificationOutcome;
            
            $user_id = Yii::app()->user->id;
            
            $domain_id = $_REQUEST['domain_id'];
            $model->domain_id = $domain_id;
            if(isset($_REQUEST['is_name_verification_requested'])){
                 $model->is_name_verification_requested=$_REQUEST['is_name_verification_requested'];
                 $model->date_name_verification_was_requested = new CDbExpression('NOW()');
                 $model->name_verification_was_requested_by = $user_id;
                 $name = $_REQUEST['name'];
                
            }else{
                $name = $_REQUEST['name'];
            }
            if(isset($_REQUEST['is_address_verification_requested'])){
                $model->is_address_verification_requested = $_REQUEST['is_address_verification_requested'];
                    $model->date_address_verification_was_requested = new CDbExpression('NOW()');
                    $model->address_verification_was_requested_by = $user_id;
                    $address = $_REQUEST['address'];
            }else{
                $address = $_REQUEST['address'];
            }
            if(isset($_REQUEST['is_registration_number_verification_requested'])){
                    $model->is_registration_number_verification_requested = $_REQUEST['is_registration_number_verification_requested'];
                    $model->date_registration_number_verification_was_requested = new CDbExpression('NOW()');
                    $model->registration_number_verification_was_requested_by = $user_id;
                    $rc_number = $_REQUEST['rc_number'];
            }else{
                $rc_number = $_REQUEST['rc_number'];
            }
            if(isset($_REQUEST['is_website_verification_requested'])){
                    $model->is_website_verification_requested = $_REQUEST['is_website_verification_requested'];
                     $model->date_website_verification_was_requested = new CDbExpression('NOW()');
                     $model->website_verification_was_requested_by = $user_id;
                     $website = $_REQUEST['website'];
            }else{
                    $website = $_REQUEST['website'];
            }
            if(isset($_REQUEST['is_website_expiry_date_requested'])){
                    $model->is_website_expiry_date_requested = $_REQUEST['is_website_expiry_date_requested'];
                     $model->date_website_expiry_verification_was_requested = new CDbExpression('NOW()');
                     $model->website_expiry_verification_was_requested_by = $user_id;
                     $website_expiry_date = date("Y-m-d H:i:s", strtotime($_REQUEST['website_expiry_date'])); 
            }else{
                $website_expiry_date = date("Y-m-d H:i:s", strtotime($_REQUEST['website_expiry_date'])); 
            }
            if(isset($_REQUEST['is_residency_expiry_date_requested'])){
                      $model->is_residency_expiry_date_requested = $_REQUEST['is_residency_expiry_date_requested'];
                      $model->date_residency_expiry_verification_was_requested = new CDbExpression('NOW()');
                      $model->residency_expiry_verification_was_requested_by = $user_id;
                      $residency_expiry_date = date("Y-m-d H:i:s", strtotime($_REQUEST['residency_expiry_date'])); 
            }else{
               $residency_expiry_date = date("Y-m-d H:i:s", strtotime($_REQUEST['residency_expiry_date']));  
            }
            if(isset($_REQUEST['is_email_verification_requested'])){
                    $model->is_email_verification_requested = $_REQUEST['is_email_verification_requested'];
                     $model->date_email_verification_was_requested = new CDbExpression('NOW()');
                     $model->email_verification_was_requested_by = $user_id;
                     $official_emal = $_REQUEST['email_address'];
            }else{
                 $official_emal = $_REQUEST['email_address'];
            }
            if(isset($_REQUEST['is_wechat_verification_requested'])){
                    $model->is_wechat_verification_requested = $_REQUEST['is_wechat_verification_requested'];
                    $model->date_wechat_verification_was_requested = new CDbExpression('NOW()');
                    $model->wechat_verification_was_requested_by = $user_id;
                    $wechat_profile = $_REQUEST['wechat_profile'];
            }else{
                $wechat_profile = $_REQUEST['wechat_profile'];
            }
            if(isset($_REQUEST['is_telegram_verification_requested'])){
                    $model->is_telegram_verification_requested= $_REQUEST['is_telegram_verification_requested'];
                     $model->date_telegram_verification_was_requested = new CDbExpression('NOW()');
                     $model->telegram_verification_was_requested_by = $user_id;
                     $telegram_profile = $_REQUEST['telegram_profile'];
            }else{
                $telegram_profile = $_REQUEST['telegram_profile'];
            }
            if(isset($_REQUEST['is_whatsapp_verification_requested'])){
                    $model->is_whatsapp_verification_requested = $_REQUEST['is_whatsapp_verification_requested'];
                     $model->date_whatsapp_verification_was_requested = new CDbExpression('NOW()');
                     $model->whatsapp_verification_was_requested_by = $user_id;
                     $whatsapp_profile = $_REQUEST['whatsapp_profile'];
            }else{
                $whatsapp_profile = $_REQUEST['whatsapp_profile'];
            }
            if(isset($_REQUEST['is_facebook_verification_requested'])){
                    $model->is_facebook_verification_requested = $_REQUEST['is_facebook_verification_requested'];
                     $model->date_facebook_verification_was_requested = new CDbExpression('NOW()');
                     $model->facebook_verification_was_requested_by = $user_id;
                     $facebook_profile = $_REQUEST['facebook_profile'];
            }else{
                $facebook_profile = $_REQUEST['facebook_profile'];
            }
            if(isset($_REQUEST['is_tweeter_verification_requested'])){
                    $model->is_tweeter_verification_requested = $_REQUEST['is_tweeter_verification_requested'];
                     $model->date_tweeter_verification_was_requested = new CDbExpression('NOW()');
                     $model->tweeter_verification_was_requested_by = $user_id;
                     $tweeter_handle = $_REQUEST['tweeter_handle'];
            }else{
                $tweeter_handle = $_REQUEST['tweeter_handle'];
            }
            if(isset($_REQUEST['is_youtube_verification_requested'])){
                    $model->is_youtube_verification_requested = $_REQUEST['is_youtube_verification_requested'];
                     $model->date_youtube_verification_was_requested = new CDbExpression('NOW()');
                     $model->youtube_verification_was_requested_by = $user_id;
                     $youtube_channel = $_REQUEST['youtube_channel'];
            }else{
                $youtube_channel = $_REQUEST['youtube_channel'];
            }
            if(isset($_REQUEST['is_logo_verification_requested'])){
                    $model->is_logo_verification_requested = $_REQUEST['is_logo_verification_requested'];
                    $model->date_logo_verification_was_requested = new CDbExpression('NOW()');
                    $model->logo_verification_was_requested_by = $user_id;
                   // $icon = $_REQUEST['icon'];
                 if($_FILES['icon']['name'] != ""){
                    if($this->isFileTypeSuitable()){
                       
                       $logo = $_FILES['icon']['name'];
                      //$iconsize = $_FILES['filename']['size'];
                        
                    }else{
                       
                        $logo="";
                         
                    }//end of the determine size and type statement
                }else{
                   $logo=""; 
                }
            }else{
                if($_FILES['icon']['name'] != ""){
                    if($this->isFileTypeSuitable()){
                       
                       $logo = $_FILES['icon']['name'];
                      //$iconsize = $_FILES['filename']['size'];
                        
                    }else{
                       
                        $logo="";
                         
                    }//end of the determine size and type statement
                }else{
                   $logo=""; 
                }
            }
            if(isset($_REQUEST['is_instagram_verification_requested'])){
                    $model->is_instagram_verification_requested = $_REQUEST['is_instagram_verification_requested'];
                     $model->date_instagram_verification_was_requested = new CDbExpression('NOW()');
                     $model->instagram_verification_was_requested_by = $user_id;
                     $instagram_profile = $_REQUEST['instagram_profile'];
            }else{
                $instagram_profile = $_REQUEST['instagram_profile'];
            }
            if(isset($_REQUEST['is_first_telephone_number_verification_requested'])){
                    $model->is_first_telephone_number_verification_requested = $_REQUEST['is_first_telephone_number_verification_requested'];
                    $model->date_first_telephone_number_verification_was_requested = new CDbExpression('NOW()');
                    $model->first_telephone_number_verification_was_requested_by = $user_id;
                    $first_office_phone_number = $_REQUEST['first_office_phone_number'];
            }else{
                $first_office_phone_number = $_REQUEST['first_office_phone_number'];
            }
            if(isset($_REQUEST['is_second_telephone_number_verification_requested'])){
                      $model->is_second_telephone_number_verification_requested = $_REQUEST['is_second_telephone_number_verification_requested'];
                      $model->date_second_telephone_number_verification_was_requested = new CDbExpression('NOW()');
                      $model->second_telephone_number_verification_was_requested_by = $user_id;
                      $second_office_phone_number = $_REQUEST['second_office_phone_number'];
            }else{
                $second_office_phone_number = $_REQUEST['second_office_phone_number'];
            }
            
          //request for this domain verification
            if($this->isDomainVerificationRequestMadeSuccesfully($domain_id)){
                if($model->save()){
                    if($this->isDomainRecordSuccessfullyUpdated($domain_id,$name,$address,$rc_number,$website,$website_expiry_date,$residency_expiry_date,$official_emal,$wechat_profile,$telegram_profile,$whatsapp_profile,$facebook_profile,$tweeter_handle,$youtube_channel,$logo,$instagram_profile,$first_office_phone_number,$second_office_phone_number)){
                         header('Content-Type: application/json');
                            echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                           "msg" =>"Your request for the verification of your domain/organization had been recieved. We will inform you when we will commence work"
                        ));
                        
                        
                    }else{
                         header('Content-Type: application/json');
                            echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                           "msg" =>"There were issues trying to request for your domain/organization verification. Please contact service desk for assistance"
                        ));
                    }
                }else{
                     header('Content-Type: application/json');
                            echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                           "msg" =>"There are validation issues hence the domain verification request was not successful. Please check your inputs data and try again  or contact customer service for assistance"
                        ));
                }
            }else{
                 header('Content-Type: application/json');
                            echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                           "msg" =>"Is possible you have a pending domain verification request or that this domain had already been verified. In this case all you could do is to update the domain verification request. Please contact customer service if you need further assistance"
                        ));
            }
            
        }
        
        /**
         * This is the function that determines if domain verification request was made successfully
         */
        public function isDomainVerificationRequestMadeSuccesfully($domain_id){
            $model = new DomainVerificationRequest;
            return $model->isDoaminVerificationRequestMadeSuccesfully($domain_id);
        }
        
        
        /**
         * This is the function that updates domain information at verification
         */
        public function isDomainRecordSuccessfullyUpdated($domain_id,$name,$address,$rc_number,$website,$website_expiry_date,$residency_expiry_date,$official_emal,$wechat_profile,$telegram_profile,$whatsapp_profile,$facebook_profile,$tweeter_handle,$youtube_channel,$logo,$instagram_profile,$first_office_phone_number,$second_office_phone_number){
            $model = new Resourcegroupcategory;
            return $model->isDomainRecordSuccessfullyUpdated($domain_id,$name,$address,$rc_number,$website,$website_expiry_date,$residency_expiry_date,$official_emal,$wechat_profile,$telegram_profile,$whatsapp_profile,$facebook_profile,$tweeter_handle,$youtube_channel,$logo,$instagram_profile,$first_office_phone_number,$second_office_phone_number);
        }
        
        
        /**
         * This is the function that test for the suitability of an icon type
         */
        public function isFileTypeSuitable(){
            $model = new Resourcegroupcategory;
            return $model->isFileTypeSuitable();
        }
        
        
        /**
         * This is the function that updates domain verification request
         */
        public function actionupdatedomainverificationrequest(){
           
            $user_id = Yii::app()->user->id;
             $_id = $_POST['verification_id'];
            $model=  DomainVerificationOutcome::model()->findByPk($_id);
            $domain_id = $_REQUEST['domain_id'];
            $model->domain_id = $domain_id;
            if(isset($_REQUEST['is_name_verification_requested'])){
                 $model->is_name_verification_requested=$_REQUEST['is_name_verification_requested'];
                 $model->date_name_verification_was_requested = new CDbExpression('NOW()');
                 $model->name_verification_was_requested_by = $user_id;
                 $name = $_REQUEST['name'];
                
            }else{
                $name = $_REQUEST['name'];
            }
            if(isset($_REQUEST['is_address_verification_requested'])){
                $model->is_address_verification_requested = $_REQUEST['is_address_verification_requested'];
                    $model->date_address_verification_was_requested = new CDbExpression('NOW()');
                    $model->address_verification_was_requested_by = $user_id;
                    $address = $_REQUEST['address'];
            }else{
                $address = $_REQUEST['address'];
            }
            if(isset($_REQUEST['is_registration_number_verification_requested'])){
                    $model->is_registration_number_verification_requested = $_REQUEST['is_registration_number_verification_requested'];
                    $model->date_registration_number_verification_was_requested = new CDbExpression('NOW()');
                    $model->registration_number_verification_was_requested_by = $user_id;
                    $rc_number = $_REQUEST['rc_number'];
            }else{
                $rc_number = $_REQUEST['rc_number'];
            }
            if(isset($_REQUEST['is_website_verification_requested'])){
                    $model->is_website_verification_requested = $_REQUEST['is_website_verification_requested'];
                     $model->date_website_verification_was_requested = new CDbExpression('NOW()');
                     $model->website_verification_was_requested_by = $user_id;
                     $website = $_REQUEST['website'];
            }else{
                    $website = $_REQUEST['website'];
            }
            if(isset($_REQUEST['is_website_expiry_date_requested'])){
                    $model->is_website_expiry_date_requested = $_REQUEST['is_website_expiry_date_requested'];
                     $model->date_website_expiry_verification_was_requested = new CDbExpression('NOW()');
                     $model->website_expiry_verification_was_requested_by = $user_id;
                     $website_expiry_date = date("Y-m-d H:i:s", strtotime($_REQUEST['website_expiry_date'])); 
            }else{
                $website_expiry_date = date("Y-m-d H:i:s", strtotime($_REQUEST['website_expiry_date'])); 
            }
            if(isset($_REQUEST['is_residency_expiry_date_requested'])){
                      $model->is_residency_expiry_date_requested = $_REQUEST['is_residency_expiry_date_requested'];
                      $model->date_residency_expiry_verification_was_requested = new CDbExpression('NOW()');
                      $model->residency_expiry_verification_was_requested_by = $user_id;
                      $residency_expiry_date = date("Y-m-d H:i:s", strtotime($_REQUEST['residency_expiry_date'])); 
            }else{
               $residency_expiry_date = date("Y-m-d H:i:s", strtotime($_REQUEST['residency_expiry_date']));  
            }
            if(isset($_REQUEST['is_email_verification_requested'])){
                    $model->is_email_verification_requested = $_REQUEST['is_email_verification_requested'];
                     $model->date_email_verification_was_requested = new CDbExpression('NOW()');
                     $model->email_verification_was_requested_by = $user_id;
                     $official_emal = $_REQUEST['email_address'];
            }else{
                 $official_emal = $_REQUEST['email_address'];
            }
            if(isset($_REQUEST['is_wechat_verification_requested'])){
                    $model->is_wechat_verification_requested = $_REQUEST['is_wechat_verification_requested'];
                    $model->date_wechat_verification_was_requested = new CDbExpression('NOW()');
                    $model->wechat_verification_was_requested_by = $user_id;
                    $wechat_profile = $_REQUEST['wechat_profile'];
            }else{
                $wechat_profile = $_REQUEST['wechat_profile'];
            }
            if(isset($_REQUEST['is_telegram_verification_requested'])){
                    $model->is_telegram_verification_requested= $_REQUEST['is_telegram_verification_requested'];
                     $model->date_telegram_verification_was_requested = new CDbExpression('NOW()');
                     $model->telegram_verification_was_requested_by = $user_id;
                     $telegram_profile = $_REQUEST['telegram_profile'];
            }else{
                $telegram_profile = $_REQUEST['telegram_profile'];
            }
            if(isset($_REQUEST['is_whatsapp_verification_requested'])){
                    $model->is_whatsapp_verification_requested = $_REQUEST['is_whatsapp_verification_requested'];
                     $model->date_whatsapp_verification_was_requested = new CDbExpression('NOW()');
                     $model->whatsapp_verification_was_requested_by = $user_id;
                     $whatsapp_profile = $_REQUEST['whatsapp_profile'];
            }else{
                $whatsapp_profile = $_REQUEST['whatsapp_profile'];
            }
            if(isset($_REQUEST['is_facebook_verification_requested'])){
                    $model->is_facebook_verification_requested = $_REQUEST['is_facebook_verification_requested'];
                     $model->date_facebook_verification_was_requested = new CDbExpression('NOW()');
                     $model->facebook_verification_was_requested_by = $user_id;
                     $facebook_profile = $_REQUEST['facebook_profile'];
            }else{
                $facebook_profile = $_REQUEST['facebook_profile'];
            }
            if(isset($_REQUEST['is_tweeter_verification_requested'])){
                    $model->is_tweeter_verification_requested = $_REQUEST['is_tweeter_verification_requested'];
                     $model->date_tweeter_verification_was_requested = new CDbExpression('NOW()');
                     $model->tweeter_verification_was_requested_by = $user_id;
                     $tweeter_handle = $_REQUEST['tweeter_handle'];
            }else{
                $tweeter_handle = $_REQUEST['tweeter_handle'];
            }
            if(isset($_REQUEST['is_youtube_verification_requested'])){
                    $model->is_youtube_verification_requested = $_REQUEST['is_youtube_verification_requested'];
                     $model->date_youtube_verification_was_requested = new CDbExpression('NOW()');
                     $model->youtube_verification_was_requested_by = $user_id;
                     $youtube_channel = $_REQUEST['youtube_channel'];
            }else{
                $youtube_channel = $_REQUEST['youtube_channel'];
            }
            if(isset($_REQUEST['is_logo_verification_requested'])){
                    $model->is_logo_verification_requested = $_REQUEST['is_logo_verification_requested'];
                    $model->date_logo_verification_was_requested = new CDbExpression('NOW()');
                    $model->logo_verification_was_requested_by = $user_id;
                   // $icon = $_REQUEST['icon'];
                 if($_FILES['icon']['name'] != ""){
                    if($this->isFileTypeSuitable()){
                       
                       $logo = $_FILES['icon']['name'];
                      //$iconsize = $_FILES['filename']['size'];
                        
                    }else{
                       
                        $logo="";
                         
                    }//end of the determine size and type statement
                }else{
                   $logo=""; 
                }
            }else{
                if($_FILES['icon']['name'] != ""){
                    if($this->isFileTypeSuitable()){
                       
                       $logo = $_FILES['icon']['name'];
                      //$iconsize = $_FILES['filename']['size'];
                        
                    }else{
                       
                        $logo="";
                         
                    }//end of the determine size and type statement
                }else{
                   $logo=""; 
                }
            }
            if(isset($_REQUEST['is_instagram_verification_requested'])){
                    $model->is_instagram_verification_requested = $_REQUEST['is_instagram_verification_requested'];
                     $model->date_instagram_verification_was_requested = new CDbExpression('NOW()');
                     $model->instagram_verification_was_requested_by = $user_id;
                     $instagram_profile = $_REQUEST['instagram_profile'];
            }else{
                $instagram_profile = $_REQUEST['instagram_profile'];
            }
            if(isset($_REQUEST['is_first_telephone_number_verification_requested'])){
                    $model->is_first_telephone_number_verification_requested = $_REQUEST['is_first_telephone_number_verification_requested'];
                    $model->date_first_telephone_number_verification_was_requested = new CDbExpression('NOW()');
                    $model->first_telephone_number_verification_was_requested_by = $user_id;
                    $first_office_phone_number = $_REQUEST['first_office_phone_number'];
            }else{
                $first_office_phone_number = $_REQUEST['first_office_phone_number'];
            }
            if(isset($_REQUEST['is_second_telephone_number_verification_requested'])){
                      $model->is_second_telephone_number_verification_requested = $_REQUEST['is_second_telephone_number_verification_requested'];
                      $model->date_second_telephone_number_verification_was_requested = new CDbExpression('NOW()');
                      $model->second_telephone_number_verification_was_requested_by = $user_id;
                      $second_office_phone_number = $_REQUEST['second_office_phone_number'];
            }else{
                $second_office_phone_number = $_REQUEST['second_office_phone_number'];
            }
            
           //request for this domain verification
            if($this->isUpdateOfDomainVerificationRequestMadeSuccesfully($domain_id)){
                if($model->save()){
                    if($this->isDomainRecordSuccessfullyUpdated($domain_id,$name,$address,$rc_number,$website,$website_expiry_date,$residency_expiry_date,$official_emal,$wechat_profile,$telegram_profile,$whatsapp_profile,$facebook_profile,$tweeter_handle,$youtube_channel,$logo,$instagram_profile,$first_office_phone_number,$second_office_phone_number)){
                         header('Content-Type: application/json');
                            echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                           "msg" =>"Your request for the update of the verification of your domain/organization had been recieved. We will inform you when we will commence work"
                        ));
                        
                        
                    }else{
                         header('Content-Type: application/json');
                            echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                           "msg" =>"There were issues trying to update the request for your domain/organization verification. Please contact service desk for assistance"
                        ));
                    }
                }else{
                     header('Content-Type: application/json');
                            echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                           "msg" =>"There are validation issues hence the domain verification request was not successful. Please check your inputs data and try again  or contact customer service for assistance"
                        ));
                }
            }else{
                 header('Content-Type: application/json');
                            echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                           "msg" =>"Is possible you have a pending domain verification request or that this domain had already been verified. Please try again or contact customer service if you need further assistance"
                        ));
            }
            
        }
        
        
        /**
         * This is the function confirms if an update to domain verification was a success
         */
        public function isUpdateOfDomainVerificationRequestMadeSuccesfully($domain_id){
            $model = new DomainVerificationRequest;
            return $model->isUpdateOfDomainVerificationRequestMadeSuccesfully($domain_id);
            
        }
        
        
        /**
         * This is the function that effects a domain verification
         */
        public function actionverifyingthisdomainverificationrequest(){
            
            $user_id = Yii::app()->user->id;
             $_id = $_POST['verification_id'];
            $model=  DomainVerificationOutcome::model()->findByPk($_id);
            $domain_id = $_REQUEST['domain_id'];
            $model->domain_id = $domain_id;
            if(isset($_REQUEST['is_name_verified'])){
                 $model->is_name_verified=$_REQUEST['is_name_verified'];
                 $model->date_name_was_verified = new CDbExpression('NOW()');
                 $model->name_was_verified_by = $user_id;
                                
            }
            if(isset($_REQUEST['is_address_verified'])){
                $model->is_address_verified = $_REQUEST['is_address_verified'];
                    $model->date_address_was_verified = new CDbExpression('NOW()');
                    $model->address_was_verified_by = $user_id;
                    
            }
            if(isset($_REQUEST['is_registration_number_verified'])){
                    $model->is_registration_number_verified = $_REQUEST['is_registration_number_verified'];
                    $model->date_registration_number_was_verified = new CDbExpression('NOW()');
                    $model->registration_number_was_verified_by = $user_id;
                    
            }
            if(isset($_REQUEST['is_website_verified'])){
                    $model->is_website_verified = $_REQUEST['is_website_verified'];
                     $model->date_website_was_verified = new CDbExpression('NOW()');
                     $model->website_was_verified_by = $user_id;
                    
            }
            if(isset($_REQUEST['is_website_expiry_date_verified'])){
                    $model->is_website_expiry_date_verified = $_REQUEST['is_website_expiry_date_verified'];
                     $model->date_website_expiry_was_verified = new CDbExpression('NOW()');
                     $model->website_expiry_was_verified_by = $user_id;
                     
            }
            if(isset($_REQUEST['is_residency_expiry_date_verified'])){
                      $model->is_residency_expiry_date_verified = $_REQUEST['is_residency_expiry_date_verified'];
                      $model->date_residency_expiry_was_verified = new CDbExpression('NOW()');
                      $model->residency_expiry_was_verified_by = $user_id;
                      
            }
            if(isset($_REQUEST['is_email_verified'])){
                    $model->is_email_verified = $_REQUEST['is_email_verified'];
                     $model->date_email_was_verified = new CDbExpression('NOW()');
                     $model->email_was_verified_by = $user_id;
                     
            }
            if(isset($_REQUEST['is_wechat_verified'])){
                    $model->is_wechat_verified = $_REQUEST['is_wechat_verified'];
                    $model->date_wechat_was_verified = new CDbExpression('NOW()');
                    $model->wechat_was_verified_by = $user_id;
                   
            }
            if(isset($_REQUEST['is_telegram_verified'])){
                    $model->is_telegram_verified= $_REQUEST['is_telegram_verified'];
                     $model->date_telegram_was_verified = new CDbExpression('NOW()');
                     $model->telegram_was_verified_by = $user_id;
                     
            }
            if(isset($_REQUEST['is_whatsapp_verified'])){
                    $model->is_whatsapp_verified = $_REQUEST['is_whatsapp_verified'];
                     $model->date_whatsapp_was_verified = new CDbExpression('NOW()');
                     $model->whatsapp_was_verified_by = $user_id;
                    
            }
            if(isset($_REQUEST['is_facebook_verified'])){
                    $model->is_facebook_verified = $_REQUEST['is_facebook_verified'];
                     $model->date_facebook_was_verified = new CDbExpression('NOW()');
                     $model->facebook_was_verified_by = $user_id;
                    
            }
            if(isset($_REQUEST['is_tweeter_verified'])){
                    $model->is_tweeter_verified = $_REQUEST['is_tweeter_verified'];
                     $model->date_tweeter_was_verified = new CDbExpression('NOW()');
                     $model->tweeter_was_verified_by = $user_id;
                     
            }
            if(isset($_REQUEST['is_youtube_verified'])){
                    $model->is_youtube_verified = $_REQUEST['is_youtube_verified'];
                     $model->date_youtube_was_verified = new CDbExpression('NOW()');
                     $model->youtube_was_verified_by = $user_id;
                     
            }
            if(isset($_REQUEST['is_logo_verified'])){
                    $model->is_logo_verified = $_REQUEST['is_logo_verified'];
                    $model->date_logo_was_verified = new CDbExpression('NOW()');
                    $model->logo_was_verified_by = $user_id;
                   // $icon = $_REQUEST['icon'];
                 if($_FILES['icon']['name'] != ""){
                    if($this->isFileTypeSuitable()){
                       
                       $logo = $_FILES['icon']['name'];
                      //$iconsize = $_FILES['filename']['size'];
                        
                    }else{
                       
                        $logo="";
                         
                    }//end of the determine size and type statement
                }else{
                   $logo=""; 
                }
            }else{
                if($_FILES['icon']['name'] != ""){
                    if($this->isFileTypeSuitable()){
                       
                       $logo = $_FILES['icon']['name'];
                      //$iconsize = $_FILES['filename']['size'];
                        
                    }else{
                       
                        $logo="";
                         
                    }//end of the determine size and type statement
                }else{
                   $logo=""; 
                }
            }
            if(isset($_REQUEST['is_instagram_verified'])){
                    $model->is_instagram_verified = $_REQUEST['is_instagram_verified'];
                     $model->date_instagram_was_verified = new CDbExpression('NOW()');
                     $model->instagram_was_verified_by = $user_id;
                     
            }
            if(isset($_REQUEST['is_first_telephone_number_verified'])){
                    $model->is_first_telephone_number_verified = $_REQUEST['is_first_telephone_number_verified'];
                    $model->date_first_telephone_number_was_verified = new CDbExpression('NOW()');
                    $model->first_telephone_number_was_verified_by = $user_id;
                   
            }
            if(isset($_REQUEST['is_second_telephone_number_verified'])){
                      $model->is_second_telephone_number_verified = $_REQUEST['is_second_telephone_number_verified'];
                      $model->date_second_telephone_number_was_verified = new CDbExpression('NOW()');
                      $model->second_telephone_number_was_verified_by = $user_id;
                      
            }
            
           //request for this domain verification
            if($this->isTheVerificationOfThisOfDomainVerificationRequestMadeSuccesfully($domain_id)){
                if($model->save()){
                    header('Content-Type: application/json');
                            echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                           "msg" =>"This verification request is effected successfully"
                        ));
                }else{
                     header('Content-Type: application/json');
                            echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                           "msg" =>"There was a validation issue hence the domain verification request was not successful verified. Please check your inputs data and try again  or contact customer service for assistance"
                        ));
                }
            }else{
                 header('Content-Type: application/json');
                            echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                           "msg" =>"Is possible there is no pending domain verification request for this domain or that this domain had already been verified. In this case all you could do is to update the domain verification request. Please contact customer service if you need further assistance"
                        ));
            }
            
        }
        
        
        /**
         * This is the function that effects verifications on a domain verification request
         */
        public function isTheVerificationOfThisOfDomainVerificationRequestMadeSuccesfully($domain_id){
            $model = new DomainVerificationRequest;
            return $model->isTheVerificationOfThisOfDomainVerificationRequestMadeSuccesfully($domain_id);
        }
}
