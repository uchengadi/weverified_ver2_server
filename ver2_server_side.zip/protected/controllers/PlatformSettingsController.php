<?php

class PlatformSettingsController extends Controller
{
	/**
	 * @var string the default layout for the views. Defaults to '//layouts/column2', meaning
	 * using two-column layout. See 'protected/views/layouts/column2.php'.
	 */
	public $layout='//layouts/column2';

	/**
	 * @return array action filters
	 */
	public function filters()
	{
		return array(
			'accessControl', // perform access control for CRUD operations
			'postOnly + delete', // we only allow deletion via POST request
		);
	}

	/**
	 * Specifies the access control rules.
	 * This method is used by the 'accessControl' filter.
	 * @return array access control rules
	 */
	public function accessRules()
	{
		return array(
			array('allow',  // allow all users to perform 'index' and 'view' actions
				'actions'=>array('index','view'),
				'users'=>array('*'),
			),
			array('allow', // allow authenticated user to perform 'create' and 'update' actions
				'actions'=>array('create','update','ListAllPlatformsettingParamters','DeleteOnePlatformSettings',
                                    'AddNewPlatformSettings','UpdatePlatformSettings','retrieveSettingsInfo','retrieveTheNeighbourhoodsThatArePermittedToRequestForBoxes',
                                    'retrieveTheNeighbourhoodsThatArePermittedToRequestForBoxes','AddPermittedNeighbourhoodsForBoxesOnPlatform','AddPermittedClustersForBoxesOnPlatform',
                                    'retrieveTheClustersThatArePermittedToRequestForBoxes','AddPermittedClustersForDocumentCaputuringOnPlatform',
                                    'retrieveTheClustersThatArePermittedToCaptureDocuments','retrieveDocumentTpesThatDeterminesTheBatchToAcceptInABox',
                                    'retrieveDocumentCategoriesThatDeterminesTheBatchToAcceptInABox','AddDocumentTypesThatAreAcceptableToBatchesInBoxesOnPlatform',
                                    'AddDocumentCategoriesThatAreAcceptableToBatchesInBoxesOnPlatform','AddNeighbourhoodsWithPermissionToCollectBoxesOnPlatform',
                                    'retrieveNeighbourhoodsWithThePermissionToConsumeBoxes','retrieveClustersWithThePermissionToConsumeBoxes',
                                    'AddClustersWithPermissionToCollectBoxesOnPlatform','retrieveTheDocumentTypesThatAreAvailableForExchange',
                                    'retrieveTheNeighbourhoodsThatDocumentTypesAreRestrictedToOnExchange','retrieveTheClustersThatDocumentTypesAreRestrictedToOnExchange',
                                    'AddDocumentTypesThatAreAvailableForExchangeOnPlatform','AddDocumentTypesRestrictedToNeighbourhoodsAtExchangeOnPlatform',
                                    'AddDocumentTypesRestrictedToClustersAtExchangeOnPlatform','retrieveTheNeighbourhoodsThatDocumentTypesAreRestrictedToOnSharing',
                                    'AddDocumentTypeRestrictedToNeighbourhoodsAtSharingOnPlatform','AddDocumentTypeRestrictedToClustersAtSharingOnPlatform',
                                    'AddDocumentTypesThatAreAvailableForSharingOnPlatform','retrieveTheDocumentTypesThatAreAvailableForSharing','retrieveTheClustersThatDocumentTypesAreRestrictedToOnSharing',
                                    'retrieveTheNeighbourhoodsThatDocumentTypesAreRestrictedToOnTransfers','retrieveTheDocumentTypesThatAreAvailableOnTransfers','retrieveTheClustersThatDocumentTypesAreRestrictedToOnTransfers',
                                    'AddDocumentTypesThatAreRestrictedToNeighbourhoodsAtTransfersOnPlatform','AddDocumentTypesThatAreAvailableAtTransfersOnPlatform','AddDocumentTypesThatAreRestrictedToClustersAtTransfersOnPlatform',
                                    'retrieveTheDocumentTypesThatAreAvailableOnTrading','retrieveTheNeighbourhoodsThatDocumentTypesAreRestrictedToOnTrading','restrictTradingOfDocumenttypesOnStoresOwnByTheseNeighbourhoodsOnTrading',
                                    'allowTheseNeighbourhoodsToTradeOnOwnPrivateStoreOnTrading','allowTheseDocumentTypesFromSomeNeighbourhoodToTradeOnOwnStoreOnTrading','AddDocumentTypesThatAreAvailableAtTradingOnPlatform',
                                    'AddDocumentTypesThatAreRestrictedToNeighbourhoodsAtTradingOnPlatform','AddDocumentTypesThatAreRestrictedToClustersAtTradingOnPlatform','AddAllowTheseNeighbourhoodsToTradeOnOwnStoreAtTradingOnPlatform',
                                    'AddAllowTheseDocumenttypesFromSomeNeighbourhoodsToTradeOnOwnStoreAtTradingOnPlatform','AddDocumentTypesThatAreRestrictedToClustersAtTradingOnPlatform',
                                    'retrieveTheClustersThatDocumentTypesAreRestrictedToOnTrading','retrieveNeighbourhoodsThatDocumentMovementsHadBeenRestrictedToAtMovement','retrieveAllTheDocumentsThatCannotBeMovedAtMovement',
                                    'retrieveAllTheDocumentsThatCannotBeMovedOutsideOwnDomainAtMovement','retrieveAllProcessorsWhoseDocumentsCannotBeMovedAtMovement','retrieveAllProcessorsWhoseDocumentsCannotBeMovedOutsideOwnDomainAtMovement',
                                    'retrieveAllTheBatchesThatCannotBeMovedAtMovement','retrieveNeighbourhoodsThatBatchMovementsHadBeenRestrictedToAtMovement','retrieveAllTheBatchesThatCannotBeMovedOutsideOwnDomainAtMovement',
                                    'retrieveAllTheBoxesThatCannotBeMovedAtMovement','retrieveNeighbourhoodsThatBoxMovementsHadBeenRestrictedToAtMovement','retrieveAllTheBoxesThatCannotBeMovedOutsideOwnDomainAtMovement','retrieveAllTheDocumentsThatCannotBeReassignedAtMovement',
                                    'retrieveAllTheBatchesThatCannotBeReassignedAtMovement','retrieveAllTheBoxesThatCannotBeReassignedAtMovement','retrieveNeighbourhoodsThatBatchReassignmentIsRestrictedToAtMovement',
                                    'retrieveNeighbourhoodsThatDocumentReassignmentIsRestrictedToAtMovement','retrieveNeighbourhoodsThatBoxReassignmentIsRestrictedToAtMovement','retrieveClustersThatDocumentReassignmentIsRestrictedToAtMovement',
                                    'retrieveClustersThatBatchReassignmentIsRestrictedToAtMovement','retrieveClustersThatBoxReassignmentIsRestrictedToAtMovement','retrieveNeighbourhoodsWhoseDocumentsCannotBeDestroyedAtDestruction','retrieveClustersWhoseDocumentsCannotBeDestroyedAtDestruction',
                                    'retrieveProcessorsWhoseDocumentsCannotBeDestroyedAtDestruction','retrieveTypesWhoseDocumentsCannotBeDestroyedAtDestruction','retrieveCategoriesWhoseDocumentsCannotBeDestroyedAtDestruction',
                                    'retrieveTypesWhoseElectronicCopyBeRetainedAfterDestructionAtDestruction','retrieveCategoriesWhoseElectronicCopyBeRetainedAfterDestructionAtDestruction','retrieveTypesWhoseDestroyedTypesWillHaveNoGlobalRequestAtDestruction',
                                    'retrieveAllTheDestroyedDocumentsThatCannotBeAccessedByAllAtDestruction','retrieveClustersThatCouldAccessAllDestroyedDocumentAtDestruction','retrieveBatchesThatCanOnlyBeReassignedOrMovedAsAWholeAtMovement',
                                    'retrieveBoxesThatCanOnlyBeReassignedOrMovedAsAWholeAtMovement','retrieveRetainedDestroyedDocumentsAtDestruction','retrieveNeighbourhoodsThatCouldAccessAllDestroyedDocumentAtDestruction',
                                    'AddDocumentsThatCannotBeMovedOnPlatform','AddNeighbourhoodsForRestrictedDocumentMovementsOnPlatform','AddDocumentsThatCannotBeMovedOutsideOwnDomainOnPlatform','AddDocumentsByTheseProcessorsCannotBeMovedOnPlatform',
                                    'AddProcessorsWhoseDocumentsAreMoveableOnlyWithinOwnDomainOnPlatform','AddBatchesThatCannotBeMovedOnPlatform','AddNeighboursForRestrictedBatchMovementOnPlatform','AddBatchesThatCannotBeMovedOutsideOwnDomainOnPlatform',
                                    'AddBoxesThatCannotBeMovedOnPlatform','AddNeighbourhoodsForRestrictedDocumentMovementsOnPlatform','AddBoxesThatCannotBeMovedOutsideOwnDomainsOnPlatform','AddDocumentsThatAreNotReassignableOnPlatform',
                                    'AddBatchesThatAreNotReassignableOnPlatform','AddBoxesThatAreNotReassignableOnPlatform','AddNeighbourhoodsForRestrictedDocumentsReassignmentOnPlatform','AddNeighbourhoodsForRestrictedBatchReassignmentOnPlatform',
                                    'AddNeighbourhoodsForRestrictedBoxReassignmentOnPlatform','AddClustersForRestrictedDocumentsReassignmentOnPlatform','AddNeighboursForRestrictedBatchMovementOnPlatform',
                                    'AddClustersForRestrictedBatchReassignmentOnPlatform','AddClustersForRestrictedBoxReassignmentOnPlatform','AddNeighbourhoodsWhereDocumentsCannotBeDestroyedOnPlatform',
                                    'AddClustersWhereDocumentsCannotBeDestroyedOnPlatform','AddProcessorsWhoseDocumentsCannotBeDestroyedOnPlatform','AddDocumentTypesCannotBeDestroyedOnPlatform','AddDocumentCategoriesCannotBeDestroyedOnPlatform',
                                    'AddDocumentTypesOfElectronicCopyToRetainAfterDestructionOnPlatform','AddDocumentCategoriesOfElectronicCopyToRetainAfterDestructionOnPlatform','AddDocumentTypeWithNoGlobalRequestAfterDestructionOnPlatform','AddDestroyedDocumentsThatCannotBeAccessedOnPlatform',
                                    'AddNeighbourhoodsThatCouldAccessDestroyedDocumentsOnPlatform','AddClustersThatCouldAccessDestroyedDocumentsOnPlatform','AssignDocumentsForDestructionToImplementersOnPlatform','AddBatchesThatMustBeMovedAsAWholeOnPlatform','AddBoxesThatMustBeMovedAsAWholeOnPlatform',
                                    'AddDocumentsThatWillBeRetainedAfterDestructionOnPlatform','AddBatchesThatCannotBeMovedOnDomain','AddNeighbourhoodsForRestrictedBoxMovementsOnPlatform','AddApplicableBlacklistAtExchangeOnPlatform',
                                    'AddApplicableWhitelistAtExchangeOnPlatform','retrieveTheWhitelistsApplicableAtExchange','retrieveTheBlacklistsApplicableAtExchange','retrieveTheBlacklistsApplicableAtSharing','retrieveTheWhitelistsApplicableAtSharing',
                                    'retrieveTheBlacklistsApplicableAtTransfers','retrieveTheWhitelistsApplicableAtTransfers','retrieveTheBlacklistsApplicableAtTradings','retrieveTheWhitelistsApplicableAtTradings','retrieveTheBlacklistsApplicableAtRequest',
                                    'retrieveTheWhitelistsApplicableAtRequest','retrieveTheBlacklistsApplicableAtConsumption','retrieveTheWhitelistsApplicableAtConsumption','retrieveTheBlacklistsApplicableAtMovement','retrieveTheWhitelistsApplicableAtMovement',
                                    'retrieveTheBlacklistsApplicableAtDestruction','retrieveTheWhitelistsApplicableAtDestruction','AddApplicableBlacklistAtSharingOnPlatform','AddApplicableWhitelistAtSharingOnPlatform','AddApplicableBlacklistsAtTransfersOnPlatform',
                                    'AddApplicableWhitelistsAtTransfersOnPlatform','AddApplicableBlacklistAtTradingOnPlatform','AddApplicableWhitelistAtTradingOnPlatform','AddApplicableBlacklistAtRequestOnPlatform','AddApplicableWhitelistAtRequestOnPlatform','AddApplicableBlacklistAtConsumptionOnPlatform',
                                    'AddApplicableWhitelistAtConsumptionOnPlatform','AddApplicableBlacklistAtMovementOnPlatform','AddApplicableWhitelistAtMovementOnPlatform','AddApplicableBlacklistAtDestructionOnPlatform',
                                    'AddApplicableWhitelistAtDestructionOnPlatform','retrieveTheLifespanOfThisDocumentType','AssignThisLifespanToThisDocumentTypeOnPlatform','AssignThisLifespanToThisDocumentTypeOnPlatform','RemoveLifespanFromDocumentType',
                                    'AssignThisLifespanToThisDocumentCategoryOnPlatform','retrieveTheLifespanOfThisDocumentCategory','RemoveLifespanFromDocumentCategory'),
				'users'=>array('@'),
			),
			array('allow', // allow admin user to perform 'admin' and 'delete' actions
				'actions'=>array('admin','delete'),
				'users'=>array('admin'),
			),
			array('deny',  // deny all users
				'users'=>array('*'),
			),
		);
	}

        /**
         * This is the function that will add a platform settings to a database
         */
        public function actionAddNewPlatformSettings(){
            
            $model=new PlatformSettings;
            
            
            //get the logged in user id
            $userid = Yii::app()->user->id;
            
            //determine the domain of the logged in user
            $domainid = $this->determineAUserDomainIdGiven($userid);
                    
            $model->icon_height = $_POST['icon_height'];
            $model->icon_width = $_POST['icon_width'];
            $model->poster_height = $_POST['poster_height'];
            $model->poster_width = $_POST['poster_width'];
            $model->video_size = $_POST['video_size'];
            $model->zip_file_size = $_POST['zip_file_size'];
            $model->platform_revenue_share = $_POST['platform_revenue_share'];
            $model->payment_holding_period = $_POST['payment_holding_period'];
            $model->default_allowable_min_percentage_task_share = $_POST['default_allowable_min_percentage_task_share'];
            $model->platform_default_currency_id = $_POST['platform_default_currency'];
            $model->platform_default_time_zone_id = $_POST['platform_default_time_zone'];
            if(isset($_POST['default_min_discount_settings'])){
                $model->default_min_discount_settings = $_POST['default_min_discount_settings'];
            }else{
                $model->default_min_discount_settings = 1000000;
            }
            if(isset($_POST['xml_validation'])){
                $model->xml_validation = $_POST['xml_validation'];
            }else{
                $model->xml_validation = 0;
            }
            if(isset($_POST['json+validation'])){
                $model->json_validation = $_POST['json_validation'];
            }else{
                $model->json_validation = 0;
            }
            if(isset($_POST['enable_platform_checker_verifier'])){
                $model->enable_platform_checker_verifier = $_POST['enable_platform_checker_verifier'];
            }else{
                $model->enable_platform_checker_verifier = 0;
            }
             if(isset($_POST['enable_domain_initiator_verifier'])){
                $model->enable_domain_initiator_verifier = $_POST['enable_domain_initiator_verifier'];
            }else{
                $model->enable_domain_initiator_verifier = 0;
            }
            $model->max_renewal_activation_number = $_POST['max_renewal_activation_number'];
            $model->price_for_one_gigabyte_size = $_POST['price_for_one_gigabyte_size'];
             if(isset($_POST['include_private_toolboxes_in_space_calculation'])){
                $model->include_private_toolboxes_in_space_calculation = $_POST['include_private_toolboxes_in_space_calculation'];
            }else{
                $model->include_private_toolboxes_in_space_calculation = 0;
            }
            if(isset($_POST['include_public_toolboxes_in_space_calculation'])){
                $model->include_public_toolboxes_in_space_calculation = $_POST['include_public_toolboxes_in_space_calculation'];
            }else{
                $model->include_public_toolboxes_in_space_calculation = 0;
            }
            if(isset($_POST['include_restricted_public_toolboxes_in_space_calculation'])){
                $model->include_restricted_public_toolboxes_in_space_calculation = $_POST['include_restricted_public_toolboxes_in_space_calculation'];
            }else{
                $model->include_restricted_public_toolboxes_in_space_calculation = 0;
            }
            if(isset($_POST['include_private_and_public_toolboxes_in_space_calculation'])){
                $model->include_private_and_public_toolboxes_in_space_calculation = $_POST['include_private_and_public_toolboxes_in_space_calculation'];
            }else{
                $model->include_private_and_public_toolboxes_in_space_calculation = 0;
            }
            if(isset($_POST['include_private_restricted_toolboxes_in_space_calculation'])){
                $model->include_private_restricted_toolboxes_in_space_calculation = $_POST['include_private_restricted_toolboxes_in_space_calculation'];
            }else{
                $model->include_private_restricted_toolboxes_in_space_calculation = 0;
            }
            if(isset($_POST['include_reserved_toolboxes_in_space_calculation'])){
                $model->include_reserved_toolboxes_in_space_calculation = $_POST['include_reserved_toolboxes_in_space_calculation'];
            }else{
                $model->include_reserved_toolboxes_in_space_calculation = 0;
            }
            if(isset($_POST['private_toolbox_min_subscription_no'])){
                $model->private_toolbox_min_subscription_no = $_POST['private_toolbox_min_subscription_no'];
            }
            if(isset($_POST['private_toolboxes_price_per_task'])){
                $model->private_toolboxes_price_per_task = $_POST['private_toolboxes_price_per_task'];
            }
           // $model->max_file_at_closure = $_POST['max_file_at_closure'];
            //$model->min_file_at_closure = $_POST['min_file_at_closure'];
             if(isset($_POST['is_closeable'])){
                $model->is_closeable = $_POST['is_closeable'];
            }else{
                $model->is_closeable = 0;
                        
            }
            if(isset($_POST['could_be_reopened'])){
                $model->could_be_reopened = $_POST['could_be_reopened'];
            }else{
                $model->could_be_reopened = 0;
                        
            }
            if(isset($_POST['could_be_reopened_when_max_number_not_reached'])){
                $model->could_be_reopened_when_max_number_not_reached = $_POST['could_be_reopened_when_max_number_not_reached'];
            }else{
                $model->could_be_reopened_when_max_number_not_reached = 0;
                        
            }
            if(isset($_POST['overide_external_influence_on_parameters'])){
                $model->overide_external_influence_on_parameters = $_POST['overide_external_influence_on_parameters'];
            }else{
                $model->overide_external_influence_on_parameters = 0;
                        
            }
            if(isset($_POST['could_be_requested_by_all'])){
                $model->could_be_requested_by_all = $_POST['could_be_requested_by_all'];
            }else{
                $model->could_be_requested_by_all = 0;
                        
            }
            if(isset($_POST['consummable_by_hood_members'])){
                $model->consummable_by_hood_members = $_POST['consummable_by_hood_members'];
            }else{
                $model->consummable_by_hood_members = 0;
                        
            }
            if(isset($_POST['consummable_by_hood_clusters'])){
                $model->consummable_by_hood_clusters = $_POST['consummable_by_hood_clusters'];
            }else{
                $model->consummable_by_hood_clusters = 0;
                        
            }
             if(isset($_POST['restrict_doc_capture_to_members_of_cluster'])){
                $model->restrict_doc_capture_to_members_of_cluster = $_POST['restrict_doc_capture_to_members_of_cluster'];
            }else{
                $model->restrict_doc_capture_to_members_of_cluster = 0;
                        
            }
             if(isset($_POST['capture_only_these_document_types'])){
                $model->capture_only_these_document_types = $_POST['capture_only_these_document_types'];
            }else{
                $model->capture_only_these_document_types = 0;
                        
            }
             if(isset($_POST['accept_only_unique_batches'])){
                $model->accept_only_unique_batches = $_POST['accept_only_unique_batches'];
            }else{
                $model->accept_only_unique_batches = 0;
                        
            }
             if(isset($_POST['accept_batches_containing_doc_of_these_type'])){
                $model->accept_batches_containing_doc_of_these_type = $_POST['accept_batches_containing_doc_of_these_type'];
            }else{
                $model->accept_batches_containing_doc_of_these_type = 0;
                        
            }
             if(isset($_POST['accept_batches_containing_doc_of_these_category'])){
                $model->accept_batches_containing_doc_of_these_category = $_POST['accept_batches_containing_doc_of_these_category'];
            }else{
                $model->accept_batches_containing_doc_of_these_category = 0;
                        
            }
             if(isset($_POST['are_boxes_closeable'])){
                $model->are_boxes_closeable = $_POST['are_boxes_closeable'];
            }else{
                $model->are_boxes_closeable = 0;
                        
            }
             if(isset($_POST['effect_blacklist_during_request'])){
                $model->effect_blacklist_during_request = $_POST['effect_blacklist_during_request'];
            }else{
                $model->effect_blacklist_during_request = 0;
                        
            }
            if(isset($_POST['effect_whitelist_during_request'])){
                $model->effect_whitelist_during_request = $_POST['effect_whitelist_during_request'];
            }else{
                $model->effect_whitelist_during_request = 0;
                        
            }
            if(isset($_POST['effect_blacklist_at_consumption'])){
                $model->effect_blacklist_at_consumption = $_POST['effect_blacklist_at_consumption'];
            }else{
                $model->effect_blacklist_at_consumption = 0;
                        
            }
            if(isset($_POST['effect_whitelist_at_consumption'])){
                $model->effect_whitelist_at_consumption = $_POST['effect_whitelist_at_consumption'];
            }else{
                $model->effect_whitelist_at_consumption = 0;
                        
            }
            if(isset($_POST['list_conflict_resolution_preference'])){
                $model->list_conflict_resolution_preference = $_POST['list_conflict_resolution_preference'];
            }else{
                $model->list_conflict_resolution_preference = 0;
                        
            }
            if(isset($_POST['accept_all_box_on_request'])){
                $model->accept_all_box_on_request = $_POST['accept_all_box_on_request'];
            }else{
                $model->accept_all_box_on_request = 0;
                        
            }
             if(isset($_POST['box_is_consummable_by_hood_members'])){
                $model->box_is_consummable_by_hood_members = $_POST['box_is_consummable_by_hood_members'];
            }else{
                $model->box_is_consummable_by_hood_members = 0;
                        
            }
             if(isset($_POST['box_is_consummable_by_hood_clusters'])){
                $model->box_is_consummable_by_hood_clusters = $_POST['box_is_consummable_by_hood_clusters'];
            }else{
                $model->box_is_consummable_by_hood_clusters = 0;
                        
            }
             if(isset($_POST['apply_whitelist_during_request'])){
                $model->apply_whitelist_during_request = $_POST['apply_whitelist_during_request'];
            }else{
                $model->apply_whitelist_during_request = 0;
                        
            }
              if(isset($_POST['apply_blacklist_during_request'])){
                $model->apply_blacklist_during_request = $_POST['apply_blacklist_during_request'];
            }else{
                $model->apply_blacklist_during_request = 0;
                        
            }
              if(isset($_POST['are_closed_boxes_openable'])){
                $model->are_closed_boxes_openable = $_POST['are_closed_boxes_openable'];
            }else{
                $model->are_closed_boxes_openable = 0;
                        
            }
             if(isset($_POST['closed_boxes_are_openable_only_max_batch_not_reached'])){
                $model->closed_boxes_are_openable_only_max_batch_not_reached = $_POST['closed_boxes_are_openable_only_max_batch_not_reached'];
            }else{
                $model->closed_boxes_are_openable_only_max_batch_not_reached = 0;
                        
            }
              if(isset($_POST['need_special_permission_to_open_closed_boxes'])){
                $model->need_special_permission_to_open_closed_boxes = $_POST['need_special_permission_to_open_closed_boxes'];
            }else{
                $model->need_special_permission_to_open_closed_boxes = 0;
                        
            }
             if(isset($_POST['need_special_permission_to_add_to_closed_boxes'])){
                $model->need_special_permission_to_add_to_closed_boxes = $_POST['need_special_permission_to_add_to_closed_boxes'];
            }else{
                $model->need_special_permission_to_add_to_closed_boxes = 0;
                        
            }
            if(isset($_POST['documents_that_cannot_be_moved'])){
                $model->documents_that_cannot_be_moved = $_POST['documents_that_cannot_be_moved'];
            }else{
                $model->documents_that_cannot_be_moved = 0;
                        
            }
            if(isset($_POST['restrict_doc_movement_to_hoods'])){
                $model->restrict_doc_movement_to_hoods = $_POST['restrict_doc_movement_to_hoods'];
            }else{
                $model->restrict_doc_movement_to_hoods = 0;
                        
            }
            if(isset($_POST['documents_that_cannot_be_moved_outside_own_domain'])){
                $model->documents_that_cannot_be_moved_outside_own_domain = $_POST['documents_that_cannot_be_moved_outside_own_domain'];
            }else{
                $model->documents_that_cannot_be_moved_outside_own_domain = 0;
                        
            }
            if(isset($_POST['processor_docs_that_cant_be_moved_beyond_domain'])){
                $model->processor_docs_that_cant_be_moved_beyond_domain = $_POST['processor_docs_that_cant_be_moved_beyond_domain'];
            }else{
                $model->processor_docs_that_cant_be_moved_beyond_domain = 0;
                        
            }
             if(isset($_POST['processor_docs_that_cant_be_moved'])){
                $model->processor_docs_that_cant_be_moved = $_POST['processor_docs_that_cant_be_moved'];
            }else{
                $model->processor_docs_that_cant_be_moved = 0;
                        
            }
             if(isset($_POST['batches_cannot_be_moved'])){
                $model->batches_cannot_be_moved = $_POST['batches_cannot_be_moved'];
            }else{
                $model->batches_cannot_be_moved = 0;
                        
            }
            if(isset($_POST['restrict_batch_movement_to_these_hood'])){
                $model->restrict_batch_movement_to_these_hood = $_POST['restrict_batch_movement_to_these_hood'];
            }else{
                $model->restrict_batch_movement_to_these_hood = 0;
                        
            }
            if(isset($_POST['batch_cannot_be_moved_outside_own_domain'])){
                $model->batch_cannot_be_moved_outside_own_domain = $_POST['batch_cannot_be_moved_outside_own_domain'];
            }else{
                $model->batch_cannot_be_moved_outside_own_domain = 0;
                        
            }
             if(isset($_POST['restrict_movement_of_boxes_to_hoods'])){
                $model->restrict_movement_of_boxes_to_hoods = $_POST['restrict_movement_of_boxes_to_hoods'];
            }else{
                $model->restrict_movement_of_boxes_to_hoods = 0;
                        
            }
            if(isset($_POST['boxes_cannot_be_moved'])){
                $model->boxes_cannot_be_moved = $_POST['boxes_cannot_be_moved'];
            }else{
                $model->boxes_cannot_be_moved = 0;
                        
            }
            if(isset($_POST['boxes_cannot_be_moved_beyond_own_domain'])){
                $model->boxes_cannot_be_moved_beyond_own_domain = $_POST['boxes_cannot_be_moved_beyond_own_domain'];
            }else{
                $model->boxes_cannot_be_moved_beyond_own_domain = 0;
                        
            }
             if(isset($_POST['effect_blacklist_at_movement'])){
                $model->effect_blacklist_at_movement = $_POST['effect_blacklist_at_movement'];
            }else{
                $model->effect_blacklist_at_movement = 0;
                        
            }
             if(isset($_POST['effect_whitelist_at_movement'])){
                $model->effect_whitelist_at_movement = $_POST['effect_whitelist_at_movement'];
            }else{
                $model->effect_whitelist_at_movement = 0;
                        
            }
            if(isset($_POST['these_documents_not_reassignable'])){
                $model->these_documents_not_reassignable = $_POST['these_documents_not_reassignable'];
            }else{
                $model->these_documents_not_reassignable = 0;
                        
            }
            if(isset($_POST['these_batches_not_reassignable'])){
                $model->these_batches_not_reassignable = $_POST['these_batches_not_reassignable'];
            }else{
                $model->these_batches_not_reassignable = 0;
                        
            }
            if(isset($_POST['these_boxes_not_reassignable'])){
                $model->these_boxes_not_reassignable = $_POST['these_boxes_not_reassignable'];
            }else{
                $model->these_boxes_not_reassignable = 0;
                        
            }
             if(isset($_POST['restrict_document_reassignment_to_hoods'])){
                $model->restrict_document_reassignment_to_hoods = $_POST['restrict_document_reassignment_to_hoods'];
            }else{
                $model->restrict_document_reassignment_to_hoods = 0;
                        
            }
             if(isset($_POST['restrict_batches_reassignment_to_hoods'])){
                $model->restrict_batches_reassignment_to_hoods = $_POST['restrict_batches_reassignment_to_hoods'];
            }else{
                $model->restrict_batches_reassignment_to_hoods = 0;
                        
            }
             if(isset($_POST['restrict_boxes_reassignment_to_hoods'])){
                $model->restrict_boxes_reassignment_to_hoods = $_POST['restrict_boxes_reassignment_to_hoods'];
            }else{
                $model->restrict_boxes_reassignment_to_hoods = 0;
                        
            }
            if(isset($_POST['restrict_documents_reassignment_to_hood_clusters'])){
                $model->restrict_documents_reassignment_to_hood_clusters = $_POST['restrict_documents_reassignment_to_hood_clusters'];
            }else{
                $model->restrict_documents_reassignment_to_hood_clusters = 0;
                        
            }
            if(isset($_POST['restrict_batches_reassignment_to_hood_clusters'])){
                $model->restrict_batches_reassignment_to_hood_clusters = $_POST['restrict_batches_reassignment_to_hood_clusters'];
            }else{
                $model->restrict_batches_reassignment_to_hood_clusters = 0;
                        
            }
             if(isset($_POST['restrict_boxes_reassignment_to_hood_clusters'])){
                $model->restrict_boxes_reassignment_to_hood_clusters = $_POST['restrict_boxes_reassignment_to_hood_clusters'];
            }else{
                $model->restrict_boxes_reassignment_to_hood_clusters = 0;
                        
            }
             if(isset($_POST['no_destroy_documents_from_hoods'])){
                $model->no_destroy_documents_from_hoods = $_POST['no_destroy_documents_from_hoods'];
            }else{
                $model->no_destroy_documents_from_hoods = 0;
                        
            }
             if(isset($_POST['no_destroy_documents_from_hood_clusters'])){
                $model->no_destroy_documents_from_hood_clusters = $_POST['no_destroy_documents_from_hood_clusters'];
            }else{
                $model->no_destroy_documents_from_hood_clusters = 0;
                        
            }
            if(isset($_POST['no_destroy_documents_from_hood_processors'])){
                $model->no_destroy_documents_from_hood_processors = $_POST['no_destroy_documents_from_hood_processors'];
            }else{
                $model->no_destroy_documents_from_hood_processors = 0;
                        
            }
            if(isset($_POST['no_destroy_documents_from_hood_processors'])){
                $model->no_destroy_documents_from_hood_processors = $_POST['no_destroy_documents_from_hood_processors'];
            }else{
                $model->no_destroy_documents_from_hood_processors = 0;
                        
            }
            if(isset($_POST['no_destroy_documents_of_these_types'])){
                $model->no_destroy_documents_of_these_types = $_POST['no_destroy_documents_of_these_types'];
            }else{
                $model->no_destroy_documents_of_these_types = 0;
                        
            }
            if(isset($_POST['no_destroy_documents_of_these_categories'])){
                $model->no_destroy_documents_of_these_categories = $_POST['no_destroy_documents_of_these_categories'];
            }else{
                $model->no_destroy_documents_of_these_categories = 0;
                        
            }
            if(isset($_POST['effect_lifespan_to_document_type'])){
                $model->effect_lifespan_to_document_type = $_POST['effect_lifespan_to_document_type'];
            }else{
                $model->effect_lifespan_to_document_type = 0;
                        
            }
            if(isset($_POST['effect_lifespan_to_document_categories'])){
                $model->effect_lifespan_to_document_categories = $_POST['effect_lifespan_to_document_categories'];
            }else{
                $model->effect_lifespan_to_document_categories = 0;
                        
            }
            if(isset($_POST['retain_electronic_copy_of_destroyed_docs'])){
                $model->retain_electronic_copy_of_destroyed_docs = $_POST['retain_electronic_copy_of_destroyed_docs'];
            }else{
                $model->retain_electronic_copy_of_destroyed_docs = 0;
                        
            }
            if(isset($_POST['could_request_electronic_copy_of_destroyed_doc'])){
                $model->could_request_electronic_copy_of_destroyed_doc = $_POST['could_request_electronic_copy_of_destroyed_doc'];
            }else{
                $model->could_request_electronic_copy_of_destroyed_doc = 0;
                        
            }
            if(isset($_POST['no_global_request_for_destroyed_documents_of_type'])){
                $model->no_global_request_for_destroyed_documents_of_type = $_POST['no_global_request_for_destroyed_documents_of_type'];
            }else{
                $model->no_global_request_for_destroyed_documents_of_type = 0;
                        
            }
             if(isset($_POST['hood_that_could_access_destroyed_docs'])){
                $model->hood_that_could_access_destroyed_docs = $_POST['hood_that_could_access_destroyed_docs'];
            }else{
                $model->hood_that_could_access_destroyed_docs = 0;
                        
            }
            if(isset($_POST['clusters_that_could_access_destroyed_docs'])){
                $model->clusters_that_could_access_destroyed_docs = $_POST['clusters_that_could_access_destroyed_docs'];
            }else{
                $model->clusters_that_could_access_destroyed_docs = 0;
                        
            }
            if(isset($_POST['destroyed_doc_that_cannot_be_accessed_by_all'])){
                $model->destroyed_doc_that_cannot_be_accessed_by_all = $_POST['destroyed_doc_that_cannot_be_accessed_by_all'];
            }else{
                $model->destroyed_doc_that_cannot_be_accessed_by_all = 0;
                        
            }
            if(isset($_POST['effect_blacklist_at_destruction'])){
                $model->effect_blacklist_at_destruction = $_POST['effect_blacklist_at_destruction'];
            }else{
                $model->effect_blacklist_at_destruction = 0;
                        
            }
             if(isset($_POST['effect_whitelist_at_destruction'])){
                $model->effect_whitelist_at_destruction = $_POST['effect_whitelist_at_destruction'];
            }else{
                $model->effect_whitelist_at_destruction = 0;
                        
            }
             if(isset($_POST['all_doc_types_available_for_exchange'])){
                $model->all_doc_types_available_for_exchange = $_POST['all_doc_types_available_for_exchange'];
            }else{
                $model->all_doc_types_available_for_exchange = 0;
                        
            }
              if(isset($_POST['doc_types_available_for_exchange'])){
                $model->doc_types_available_for_exchange = $_POST['doc_types_available_for_exchange'];
            }else{
                $model->doc_types_available_for_exchange = 0;
                        
            }
            if(isset($_POST['restrict_exchange_of_doc_types_to_hood'])){
                $model->restrict_exchange_of_doc_types_to_hood = $_POST['restrict_exchange_of_doc_types_to_hood'];
            }else{
                $model->restrict_exchange_of_doc_types_to_hood = 0;
                        
            }
            if(isset($_POST['restrict_exchange_of_doc_types_to_clusters'])){
                $model->restrict_exchange_of_doc_types_to_clusters = $_POST['restrict_exchange_of_doc_types_to_clusters'];
            }else{
                $model->restrict_exchange_of_doc_types_to_clusters = 0;
                        
            }
             if(isset($_POST['effect_blacklist_at_exchange'])){
                $model->effect_blacklist_at_exchange = $_POST['effect_blacklist_at_exchange'];
            }else{
                $model->effect_blacklist_at_exchange = 0;
                        
            }
             if(isset($_POST['effect_whitelist_at_exchange'])){
                $model->effect_whitelist_at_exchange = $_POST['effect_whitelist_at_exchange'];
            }else{
                $model->effect_whitelist_at_exchange = 0;
                        
            }
            if(isset($_POST['all_doc_types_available_for_sharing'])){
                $model->all_doc_types_available_for_sharing = $_POST['all_doc_types_available_for_sharing'];
            }else{
                $model->all_doc_types_available_for_sharing = 0;
                        
            }
            if(isset($_POST['doc_types_available_for_sharing'])){
                $model->doc_types_available_for_sharing = $_POST['doc_types_available_for_sharing'];
            }else{
                $model->doc_types_available_for_sharing = 0;
                        
            }
            if(isset($_POST['restrict_sharing_of_doc_types_to_hood'])){
                $model->restrict_sharing_of_doc_types_to_hood = $_POST['restrict_sharing_of_doc_types_to_hood'];
            }else{
                $model->restrict_sharing_of_doc_types_to_hood = 0;
                        
            }
             if(isset($_POST['restrict_sharing_of_doc_types_to_clusters'])){
                $model->restrict_sharing_of_doc_types_to_clusters = $_POST['restrict_sharing_of_doc_types_to_clusters'];
            }else{
                $model->restrict_sharing_of_doc_types_to_clusters = 0;
                        
            }
             if(isset($_POST['effect_blacklist_at_sharing'])){
                $model->effect_blacklist_at_sharing = $_POST['effect_blacklist_at_sharing'];
            }else{
                $model->effect_blacklist_at_sharing = 0;
                        
            }
             if(isset($_POST['effect_whitelist_at_sharing'])){
                $model->effect_whitelist_at_sharing = $_POST['effect_whitelist_at_sharing'];
            }else{
                $model->effect_whitelist_at_sharing = 0;
                        
            }
             if(isset($_POST['all_doc_types_available_for_transfer'])){
                $model->all_doc_types_available_for_transfer = $_POST['all_doc_types_available_for_transfer'];
            }else{
                $model->all_doc_types_available_for_transfer = 0;
                        
            }
             if(isset($_POST['doc_types_available_for_transfer'])){
                $model->doc_types_available_for_transfer = $_POST['doc_types_available_for_transfer'];
            }else{
                $model->doc_types_available_for_transfer = 0;
                        
            }
             if(isset($_POST['restrict_transfer_of_doc_types_to_hood'])){
                $model->restrict_transfer_of_doc_types_to_hood = $_POST['restrict_transfer_of_doc_types_to_hood'];
            }else{
                $model->restrict_transfer_of_doc_types_to_hood = 0;
                        
            }
              if(isset($_POST['restrict_transfer_of_doc_types_to_clusters'])){
                $model->restrict_transfer_of_doc_types_to_clusters = $_POST['restrict_transfer_of_doc_types_to_clusters'];
            }else{
                $model->restrict_transfer_of_doc_types_to_clusters = 0;
                        
            }
              if(isset($_POST['effect_blacklist_at_transfer'])){
                $model->effect_blacklist_at_transfer = $_POST['effect_blacklist_at_transfer'];
            }else{
                $model->effect_blacklist_at_transfer = 0;
                        
            }
             if(isset($_POST['effect_whitelist_at_transfer'])){
                $model->effect_whitelist_at_transfer = $_POST['effect_whitelist_at_transfer'];
            }else{
                $model->effect_whitelist_at_transfer = 0;
                        
            }
            if(isset($_POST['all_doc_type_available_for_trading'])){
                $model->all_doc_type_available_for_trading = $_POST['all_doc_type_available_for_trading'];
            }else{
                $model->all_doc_type_available_for_trading = 0;
                        
            }
             if(isset($_POST['these_doctypes_available_for_trading'])){
                $model->these_doctypes_available_for_trading = $_POST['these_doctypes_available_for_trading'];
            }else{
                $model->these_doctypes_available_for_trading = 0;
                        
            }
            if(isset($_POST['restrict_trading_of_doctype_to_hoods'])){
                $model->restrict_trading_of_doctype_to_hoods = $_POST['restrict_trading_of_doctype_to_hoods'];
            }else{
                $model->restrict_trading_of_doctype_to_hoods = 0;
                        
            }
            if(isset($_POST['restrict_trading_of_doctype_to_clusters'])){
                $model->restrict_trading_of_doctype_to_clusters = $_POST['restrict_trading_of_doctype_to_clusters'];
            }else{
                $model->restrict_trading_of_doctype_to_clusters = 0;
                        
            }
            if(isset($_POST['allow_hood_to_trade_on_own_private_store'])){
                $model->allow_hood_to_trade_on_own_private_store = $_POST['allow_hood_to_trade_on_own_private_store'];
            }else{
                $model->allow_hood_to_trade_on_own_private_store = 0;
                        
            }
            if(isset($_POST['allow_doctypes_from_hoods_to_trade_on_store'])){
                $model->allow_doctypes_from_hoods_to_trade_on_store = $_POST['allow_doctypes_from_hoods_to_trade_on_store'];
            }else{
                $model->allow_doctypes_from_hoods_to_trade_on_store = 0;
                        
            }
            if(isset($_POST['retain_electronic_copy_of_destroyed_doc_types'])){
                $model->retain_electronic_copy_of_destroyed_doc_types = $_POST['retain_electronic_copy_of_destroyed_doc_types'];
            }else{
                $model->retain_electronic_copy_of_destroyed_doc_types = 0;
                        
            }
            if(isset($_POST['retain_electronic_copy_of_destroyed_doc_categories'])){
                $model->retain_electronic_copy_of_destroyed_doc_categories = $_POST['retain_electronic_copy_of_destroyed_doc_categories'];
            }else{
                $model->retain_electronic_copy_of_destroyed_doc_categories = 0;
                        
            }
            if(isset($_POST['assign_docs_for_destruction_against_those_in_charge'])){
                $model->assign_docs_for_destruction_against_those_in_charge = $_POST['assign_docs_for_destruction_against_those_in_charge'];
            }else{
                $model->assign_docs_for_destruction_against_those_in_charge = 0;
                        
            }
            if(isset($_POST['effect_blacklist_at_trading'])){
                $model->effect_blacklist_at_trading = $_POST['effect_blacklist_at_trading'];
            }else{
                $model->effect_blacklist_at_trading = 0;
                        
            }
            if(isset($_POST['effect_whitelist_at_trading'])){
                $model->effect_whitelist_at_trading = $_POST['effect_whitelist_at_trading'];
            }else{
                $model->effect_whitelist_at_trading = 0;
                        
            }
             if(isset($_POST['prefer_whitelist_over_blacklist'])){
                $model->prefer_whitelist_over_blacklist = $_POST['prefer_whitelist_over_blacklist'];
            }else{
                $model->prefer_whitelist_over_blacklist = 0;
                        
            }
            if(isset($_POST['prefer_blacklist_over_whitelist'])){
                $model->prefer_blacklist_over_whitelist = $_POST['prefer_blacklist_over_whitelist'];
            }else{
                $model->prefer_blacklist_over_whitelist = 0;
                        
            }
              if(isset($_POST['retain_electronic_copy_of_these_destroyed_documents'])){
                $model->retain_electronic_copy_of_these_destroyed_documents = $_POST['retain_electronic_copy_of_these_destroyed_documents'];
            }else{
                $model->retain_electronic_copy_of_these_destroyed_documents = 0;
                        
            }
             if(isset($_POST['these_boxes_to_be_moved_or_reassigned_as_a_whole'])){
                $model->these_boxes_to_be_moved_or_reassigned_as_a_whole = $_POST['these_boxes_to_be_moved_or_reassigned_as_a_whole'];
            }else{
                $model->these_boxes_to_be_moved_or_reassigned_as_a_whole = 0;
                        
            }
             if(isset($_POST['these_batches_to_be_moved_or_reassigned_as_a_whole'])){
                $model->these_batches_to_be_moved_or_reassigned_as_a_whole = $_POST['these_batches_to_be_moved_or_reassigned_as_a_whole'];
            }else{
                $model->these_batches_to_be_moved_or_reassigned_as_a_whole = 0;
                        
            }
            if(isset($_POST['all_boxes_to_be_moved_or_reassigned_as_a_whole'])){
                $model->all_boxes_to_be_moved_or_reassigned_as_a_whole = $_POST['all_boxes_to_be_moved_or_reassigned_as_a_whole'];
            }else{
                $model->all_boxes_to_be_moved_or_reassigned_as_a_whole = 0;
                        
            }
             if(isset($_POST['all_batches_to_be_moved_or_reassigned_as_a_whole'])){
                $model->all_batches_to_be_moved_or_reassigned_as_a_whole = $_POST['all_batches_to_be_moved_or_reassigned_as_a_whole'];
            }else{
                $model->all_batches_to_be_moved_or_reassigned_as_a_whole = 0;
                        
            }
            $model->max_number_of_batches_before_closing = $_POST['max_number_of_batches_before_closing'];
            $model->min_number_of_batches_before_closing = $_POST['min_number_of_batches_before_closing'];
            $model->excess_space_grace_period = $_POST['excess_space_grace_period'];
            $model->number_of_months_before_expiration = $_POST['number_of_months_before_expiration'];
            $model->create_user_id = $userid;
            $model->create_time = new CDbExpression('NOW()');
                      
           
             if($model->save()){
                        if($this->createorUpdateTheVariousMimeTypes($model->id)){
                            $msg = "Platform Settings were successfully added";
                            header('Content-Type: application/json');
                            echo CJSON::encode(array(
                                    "success" => mysql_errno() == 0,
                                        "msg" => $msg)
                            );
                        }else{
                            $msg = "All except some of the Mime Type Platform Settings were successfully added";
                            header('Content-Type: application/json');
                            echo CJSON::encode(array(
                                    "success" => mysql_errno() == 0,
                                        "msg" => $msg)
                            ); 
                        }
                           
                           
                       
                        
                 }else {
                         //$result['success'] = 'false';
                         $msg = "Validation Error: Platform Settings not added";
                         header('Content-Type: application/json');
                         echo CJSON::encode(array(
                                    "success" => mysql_errno() != 0,
                                        "msg" => $msg)
                           );
                  } 
            
        }
        
        
        /**
         * This is the function that updates platform settings information
         */
        public function actionUpdatePlatformSettings(){
            
            $_id = $_POST['id'];
            $model=PlatformSettings::model()->findByPk($_id);
            
             //get the logged in user id
            $userid = Yii::app()->user->id;
            
            $model->icon_height = $_POST['icon_height'];
            $model->icon_width = $_POST['icon_width'];
            $model->poster_height = $_POST['poster_height'];
            $model->poster_width = $_POST['poster_width'];
            $model->video_size = $_POST['video_size'];
            $model->zip_file_size = $_POST['zip_file_size'];
            $model->platform_revenue_share = $_POST['platform_revenue_share'];
            $model->payment_holding_period = $_POST['payment_holding_period'];
            $model->default_allowable_min_percentage_task_share = $_POST['default_allowable_min_percentage_task_share'];
            if(is_numeric($_POST['platform_default_currency'])){
                $model->platform_default_currency_id = $_POST['platform_default_currency'];
            }else{
                $model->platform_default_currency_id = $_POST['platform_default_currency_id'];
            }
            if(is_numeric($_POST['platform_default_time_zone'])){
                $model->platform_default_time_zone_id = $_POST['platform_default_time_zone'];
            }else{
                $model->platform_default_time_zone_id = $_POST['platform_default_time_zone_id'];
            }
            if(isset($_POST['default_min_discount_settings'])){
                $model->default_min_discount_settings = $_POST['default_min_discount_settings'];
            }else{
                $model->default_min_discount_settings = 1000000;
            }
            if(isset($_POST['xml_validation'])){
                $model->xml_validation = $_POST['xml_validation'];
            }else{
               $model->xml_validation = 0; 
            }
            if(isset($_POST['json_validation'])){
                $model->json_validation = $_POST['json_validation'];
            }else{
                $model->json_validation = 0;
            }
            if(isset($_POST['enable_platform_checker_verifier'])){
                $model->enable_platform_checker_verifier = $_POST['enable_platform_checker_verifier'];
            }else{
                $model->enable_platform_checker_verifier = 0;
            }
             if(isset($_POST['enable_domain_initiator_verifier'])){
                $model->enable_domain_initiator_verifier = $_POST['enable_domain_initiator_verifier'];
            }else{
                $model->enable_domain_initiator_verifier = 0;
            }
            $model->max_renewal_activation_number = $_POST['max_renewal_activation_number'];
            $model->price_for_one_gigabyte_size = $_POST['price_for_one_gigabyte_size'];
            if(isset($_POST['include_private_toolboxes_in_space_calculation'])){
                $model->include_private_toolboxes_in_space_calculation = $_POST['include_private_toolboxes_in_space_calculation'];
            }else{
                $model->include_private_toolboxes_in_space_calculation = 0;
            }
            if(isset($_POST['include_public_toolboxes_in_space_calculation'])){
                $model->include_public_toolboxes_in_space_calculation = $_POST['include_public_toolboxes_in_space_calculation'];
            }else{
                $model->include_public_toolboxes_in_space_calculation = 0;
            }
            if(isset($_POST['include_restricted_public_toolboxes_in_space_calculation'])){
                $model->include_restricted_public_toolboxes_in_space_calculation = $_POST['include_restricted_public_toolboxes_in_space_calculation'];
            }else{
                $model->include_restricted_public_toolboxes_in_space_calculation = 0;
            }
            if(isset($_POST['include_private_and_public_toolboxes_in_space_calculation'])){
                $model->include_private_and_public_toolboxes_in_space_calculation = $_POST['include_private_and_public_toolboxes_in_space_calculation'];
            }else{
                $model->include_private_and_public_toolboxes_in_space_calculation = 0;
            }
            if(isset($_POST['include_private_restricted_toolboxes_in_space_calculation'])){
                $model->include_private_restricted_toolboxes_in_space_calculation = $_POST['include_private_restricted_toolboxes_in_space_calculation'];
            }else{
                $model->include_private_restricted_toolboxes_in_space_calculation = 0;
            }
            if(isset($_POST['include_reserved_toolboxes_in_space_calculation'])){
                $model->include_reserved_toolboxes_in_space_calculation = $_POST['include_reserved_toolboxes_in_space_calculation'];
            }else{
                $model->include_reserved_toolboxes_in_space_calculation = 0;
            }
            if(isset($_POST['private_toolbox_min_subscription_no'])){
                $model->private_toolbox_min_subscription_no = $_POST['private_toolbox_min_subscription_no'];
            }
            if(isset($_POST['private_toolboxes_price_per_task'])){
                $model->private_toolboxes_price_per_task = $_POST['private_toolboxes_price_per_task'];
            }
            //$model->max_file_at_closure = $_POST['max_file_at_closure'];
           // $model->min_file_at_closure = $_POST['min_file_at_closure'];
             if(isset($_POST['is_closeable'])){
                $model->is_closeable = $_POST['is_closeable'];
            }else{
                $model->is_closeable = 0;
                        
            }
            if(isset($_POST['could_be_reopened'])){
                $model->could_be_reopened = $_POST['could_be_reopened'];
            }else{
                $model->could_be_reopened = 0;
                        
            }
            if(isset($_POST['could_be_reopened_when_max_number_not_reached'])){
                $model->could_be_reopened_when_max_number_not_reached = $_POST['could_be_reopened_when_max_number_not_reached'];
            }else{
                $model->could_be_reopened_when_max_number_not_reached = 0;
                        
            }
            if(isset($_POST['overide_external_influence_on_parameters'])){
                $model->overide_external_influence_on_parameters = $_POST['overide_external_influence_on_parameters'];
            }else{
                $model->overide_external_influence_on_parameters = 0;
                        
            }
            if(isset($_POST['could_be_requested_by_all'])){
                $model->could_be_requested_by_all = $_POST['could_be_requested_by_all'];
            }else{
                $model->could_be_requested_by_all = 0;
                        
            }
            if(isset($_POST['consummable_by_hood_members'])){
                $model->consummable_by_hood_members = $_POST['consummable_by_hood_members'];
            }else{
                $model->consummable_by_hood_members = 0;
                        
            }
            if(isset($_POST['consummable_by_hood_clusters'])){
                $model->consummable_by_hood_clusters = $_POST['consummable_by_hood_clusters'];
            }else{
                $model->consummable_by_hood_clusters = 0;
                        
            }
             if(isset($_POST['restrict_doc_capture_to_members_of_cluster'])){
                $model->restrict_doc_capture_to_members_of_cluster = $_POST['restrict_doc_capture_to_members_of_cluster'];
            }else{
                $model->restrict_doc_capture_to_members_of_cluster = 0;
                        
            }
             if(isset($_POST['capture_only_these_document_types'])){
                $model->capture_only_these_document_types = $_POST['capture_only_these_document_types'];
            }else{
                $model->capture_only_these_document_types = 0;
                        
            }
             if(isset($_POST['accept_only_unique_batches'])){
                $model->accept_only_unique_batches = $_POST['accept_only_unique_batches'];
            }else{
                $model->accept_only_unique_batches = 0;
                        
            }
             if(isset($_POST['accept_batches_containing_doc_of_these_type'])){
                $model->accept_batches_containing_doc_of_these_type = $_POST['accept_batches_containing_doc_of_these_type'];
            }else{
                $model->accept_batches_containing_doc_of_these_type = 0;
                        
            }
             if(isset($_POST['accept_batches_containing_doc_of_these_category'])){
                $model->accept_batches_containing_doc_of_these_category = $_POST['accept_batches_containing_doc_of_these_category'];
            }else{
                $model->accept_batches_containing_doc_of_these_category = 0;
                        
            }
             if(isset($_POST['are_boxes_closeable'])){
                $model->are_boxes_closeable = $_POST['are_boxes_closeable'];
            }else{
                $model->are_boxes_closeable = 0;
                        
            }
             if(isset($_POST['effect_blacklist_during_request'])){
                $model->effect_blacklist_during_request = $_POST['effect_blacklist_during_request'];
            }else{
                $model->effect_blacklist_during_request = 0;
                        
            }
            if(isset($_POST['effect_whitelist_during_request'])){
                $model->effect_whitelist_during_request = $_POST['effect_whitelist_during_request'];
            }else{
                $model->effect_whitelist_during_request = 0;
                        
            }
            if(isset($_POST['effect_blacklist_at_consumption'])){
                $model->effect_blacklist_at_consumption = $_POST['effect_blacklist_at_consumption'];
            }else{
                $model->effect_blacklist_at_consumption = 0;
                        
            }
            if(isset($_POST['effect_whitelist_at_consumption'])){
                $model->effect_whitelist_at_consumption = $_POST['effect_whitelist_at_consumption'];
            }else{
                $model->effect_whitelist_at_consumption = 0;
                        
            }
            if(isset($_POST['list_conflict_resolution_preference'])){
                $model->list_conflict_resolution_preference = $_POST['list_conflict_resolution_preference'];
            }else{
                $model->list_conflict_resolution_preference = 0;
                        
            }
            if(isset($_POST['accept_all_box_on_request'])){
                $model->accept_all_box_on_request = $_POST['accept_all_box_on_request'];
            }else{
                $model->accept_all_box_on_request = 0;
                        
            }
             if(isset($_POST['box_is_consummable_by_hood_members'])){
                $model->box_is_consummable_by_hood_members = $_POST['box_is_consummable_by_hood_members'];
            }else{
                $model->box_is_consummable_by_hood_members = 0;
                        
            }
             if(isset($_POST['box_is_consummable_by_hood_clusters'])){
                $model->box_is_consummable_by_hood_clusters = $_POST['box_is_consummable_by_hood_clusters'];
            }else{
                $model->box_is_consummable_by_hood_clusters = 0;
                        
            }
             if(isset($_POST['apply_whitelist_during_request'])){
                $model->apply_whitelist_during_request = $_POST['apply_whitelist_during_request'];
            }else{
                $model->apply_whitelist_during_request = 0;
                        
            }
              if(isset($_POST['apply_blacklist_during_request'])){
                $model->apply_blacklist_during_request = $_POST['apply_blacklist_during_request'];
            }else{
                $model->apply_blacklist_during_request = 0;
                        
            }
              if(isset($_POST['are_closed_boxes_openable'])){
                $model->are_closed_boxes_openable = $_POST['are_closed_boxes_openable'];
            }else{
                $model->are_closed_boxes_openable = 0;
                        
            }
             if(isset($_POST['closed_boxes_are_openable_only_max_batch_not_reached'])){
                $model->closed_boxes_are_openable_only_max_batch_not_reached = $_POST['closed_boxes_are_openable_only_max_batch_not_reached'];
            }else{
                $model->closed_boxes_are_openable_only_max_batch_not_reached = 0;
                        
            }
              if(isset($_POST['need_special_permission_to_open_closed_boxes'])){
                $model->need_special_permission_to_open_closed_boxes = $_POST['need_special_permission_to_open_closed_boxes'];
            }else{
                $model->need_special_permission_to_open_closed_boxes = 0;
                        
            }
             if(isset($_POST['need_special_permission_to_add_to_closed_boxes'])){
                $model->need_special_permission_to_add_to_closed_boxes = $_POST['need_special_permission_to_add_to_closed_boxes'];
            }else{
                $model->need_special_permission_to_add_to_closed_boxes = 0;
                        
            }
            if(isset($_POST['documents_that_cannot_be_moved'])){
                $model->documents_that_cannot_be_moved = $_POST['documents_that_cannot_be_moved'];
            }else{
                $model->documents_that_cannot_be_moved = 0;
                        
            }
            if(isset($_POST['restrict_doc_movement_to_hoods'])){
                $model->restrict_doc_movement_to_hoods = $_POST['restrict_doc_movement_to_hoods'];
            }else{
                $model->restrict_doc_movement_to_hoods = 0;
                        
            }
            if(isset($_POST['documents_that_cannot_be_moved_outside_own_domain'])){
                $model->documents_that_cannot_be_moved_outside_own_domain = $_POST['documents_that_cannot_be_moved_outside_own_domain'];
            }else{
                $model->documents_that_cannot_be_moved_outside_own_domain = 0;
                        
            }
            if(isset($_POST['processor_docs_that_cant_be_moved_beyond_domain'])){
                $model->processor_docs_that_cant_be_moved_beyond_domain = $_POST['processor_docs_that_cant_be_moved_beyond_domain'];
            }else{
                $model->processor_docs_that_cant_be_moved_beyond_domain = 0;
                        
            }
             if(isset($_POST['processor_docs_that_cant_be_moved'])){
                $model->processor_docs_that_cant_be_moved = $_POST['processor_docs_that_cant_be_moved'];
            }else{
                $model->processor_docs_that_cant_be_moved = 0;
                        
            }
             if(isset($_POST['batches_cannot_be_moved'])){
                $model->batches_cannot_be_moved = $_POST['batches_cannot_be_moved'];
            }else{
                $model->batches_cannot_be_moved = 0;
                        
            }
            if(isset($_POST['restrict_batch_movement_to_these_hood'])){
                $model->restrict_batch_movement_to_these_hood = $_POST['restrict_batch_movement_to_these_hood'];
            }else{
                $model->restrict_batch_movement_to_these_hood = 0;
                        
            }
            if(isset($_POST['batch_cannot_be_moved_outside_own_domain'])){
                $model->batch_cannot_be_moved_outside_own_domain = $_POST['batch_cannot_be_moved_outside_own_domain'];
            }else{
                $model->batch_cannot_be_moved_outside_own_domain = 0;
                        
            }
             if(isset($_POST['restrict_movement_of_boxes_to_hoods'])){
                $model->restrict_movement_of_boxes_to_hoods = $_POST['restrict_movement_of_boxes_to_hoods'];
            }else{
                $model->restrict_movement_of_boxes_to_hoods = 0;
                        
            }
            if(isset($_POST['boxes_cannot_be_moved'])){
                $model->boxes_cannot_be_moved = $_POST['boxes_cannot_be_moved'];
            }else{
                $model->boxes_cannot_be_moved = 0;
                        
            }
            if(isset($_POST['boxes_cannot_be_moved_beyond_own_domain'])){
                $model->boxes_cannot_be_moved_beyond_own_domain = $_POST['boxes_cannot_be_moved_beyond_own_domain'];
            }else{
                $model->boxes_cannot_be_moved_beyond_own_domain = 0;
                        
            }
             if(isset($_POST['effect_blacklist_at_movement'])){
                $model->effect_blacklist_at_movement = $_POST['effect_blacklist_at_movement'];
            }else{
                $model->effect_blacklist_at_movement = 0;
                        
            }
             if(isset($_POST['effect_whitelist_at_movement'])){
                $model->effect_whitelist_at_movement = $_POST['effect_whitelist_at_movement'];
            }else{
                $model->effect_whitelist_at_movement = 0;
                        
            }
            if(isset($_POST['these_documents_not_reassignable'])){
                $model->these_documents_not_reassignable = $_POST['these_documents_not_reassignable'];
            }else{
                $model->these_documents_not_reassignable = 0;
                        
            }
            if(isset($_POST['these_batches_not_reassignable'])){
                $model->these_batches_not_reassignable = $_POST['these_batches_not_reassignable'];
            }else{
                $model->these_batches_not_reassignable = 0;
                        
            }
            if(isset($_POST['these_boxes_not_reassignable'])){
                $model->these_boxes_not_reassignable = $_POST['these_boxes_not_reassignable'];
            }else{
                $model->these_boxes_not_reassignable = 0;
                        
            }
             if(isset($_POST['restrict_document_reassignment_to_hoods'])){
                $model->restrict_document_reassignment_to_hoods = $_POST['restrict_document_reassignment_to_hoods'];
            }else{
                $model->restrict_document_reassignment_to_hoods = 0;
                        
            }
             if(isset($_POST['restrict_batches_reassignment_to_hoods'])){
                $model->restrict_batches_reassignment_to_hoods = $_POST['restrict_batches_reassignment_to_hoods'];
            }else{
                $model->restrict_batches_reassignment_to_hoods = 0;
                        
            }
             if(isset($_POST['restrict_boxes_reassignment_to_hoods'])){
                $model->restrict_boxes_reassignment_to_hoods = $_POST['restrict_boxes_reassignment_to_hoods'];
            }else{
                $model->restrict_boxes_reassignment_to_hoods = 0;
                        
            }
            if(isset($_POST['restrict_documents_reassignment_to_hood_clusters'])){
                $model->restrict_documents_reassignment_to_hood_clusters = $_POST['restrict_documents_reassignment_to_hood_clusters'];
            }else{
                $model->restrict_documents_reassignment_to_hood_clusters = 0;
                        
            }
            if(isset($_POST['restrict_batches_reassignment_to_hood_clusters'])){
                $model->restrict_batches_reassignment_to_hood_clusters = $_POST['restrict_batches_reassignment_to_hood_clusters'];
            }else{
                $model->restrict_batches_reassignment_to_hood_clusters = 0;
                        
            }
             if(isset($_POST['restrict_boxes_reassignment_to_hood_clusters'])){
                $model->restrict_boxes_reassignment_to_hood_clusters = $_POST['restrict_boxes_reassignment_to_hood_clusters'];
            }else{
                $model->restrict_boxes_reassignment_to_hood_clusters = 0;
                        
            }
             if(isset($_POST['no_destroy_documents_from_hoods'])){
                $model->no_destroy_documents_from_hoods = $_POST['no_destroy_documents_from_hoods'];
            }else{
                $model->no_destroy_documents_from_hoods = 0;
                        
            }
             if(isset($_POST['no_destroy_documents_from_hood_clusters'])){
                $model->no_destroy_documents_from_hood_clusters = $_POST['no_destroy_documents_from_hood_clusters'];
            }else{
                $model->no_destroy_documents_from_hood_clusters = 0;
                        
            }
            if(isset($_POST['no_destroy_documents_from_hood_processors'])){
                $model->no_destroy_documents_from_hood_processors = $_POST['no_destroy_documents_from_hood_processors'];
            }else{
                $model->no_destroy_documents_from_hood_processors = 0;
                        
            }
            if(isset($_POST['no_destroy_documents_from_hood_processors'])){
                $model->no_destroy_documents_from_hood_processors = $_POST['no_destroy_documents_from_hood_processors'];
            }else{
                $model->no_destroy_documents_from_hood_processors = 0;
                        
            }
            if(isset($_POST['no_destroy_documents_of_these_types'])){
                $model->no_destroy_documents_of_these_types = $_POST['no_destroy_documents_of_these_types'];
            }else{
                $model->no_destroy_documents_of_these_types = 0;
                        
            }
            if(isset($_POST['no_destroy_documents_of_these_categories'])){
                $model->no_destroy_documents_of_these_categories = $_POST['no_destroy_documents_of_these_categories'];
            }else{
                $model->no_destroy_documents_of_these_categories = 0;
                        
            }
            if(isset($_POST['effect_lifespan_to_document_type'])){
                $model->effect_lifespan_to_document_type = $_POST['effect_lifespan_to_document_type'];
            }else{
                $model->effect_lifespan_to_document_type = 0;
                        
            }
            if(isset($_POST['effect_lifespan_to_document_categories'])){
                $model->effect_lifespan_to_document_categories = $_POST['effect_lifespan_to_document_categories'];
            }else{
                $model->effect_lifespan_to_document_categories = 0;
                        
            }
            if(isset($_POST['retain_electronic_copy_of_destroyed_docs'])){
                $model->retain_electronic_copy_of_destroyed_docs = $_POST['retain_electronic_copy_of_destroyed_docs'];
            }else{
                $model->retain_electronic_copy_of_destroyed_docs = 0;
                        
            }
            if(isset($_POST['could_request_electronic_copy_of_destroyed_doc'])){
                $model->could_request_electronic_copy_of_destroyed_doc = $_POST['could_request_electronic_copy_of_destroyed_doc'];
            }else{
                $model->could_request_electronic_copy_of_destroyed_doc = 0;
                        
            }
            if(isset($_POST['no_global_request_for_destroyed_documents_of_type'])){
                $model->no_global_request_for_destroyed_documents_of_type = $_POST['no_global_request_for_destroyed_documents_of_type'];
            }else{
                $model->no_global_request_for_destroyed_documents_of_type = 0;
                        
            }
             if(isset($_POST['hood_that_could_access_destroyed_docs'])){
                $model->hood_that_could_access_destroyed_docs = $_POST['hood_that_could_access_destroyed_docs'];
            }else{
                $model->hood_that_could_access_destroyed_docs = 0;
                        
            }
            if(isset($_POST['clusters_that_could_access_destroyed_docs'])){
                $model->clusters_that_could_access_destroyed_docs = $_POST['clusters_that_could_access_destroyed_docs'];
            }else{
                $model->clusters_that_could_access_destroyed_docs = 0;
                        
            }
            if(isset($_POST['destroyed_doc_that_cannot_be_accessed_by_all'])){
                $model->destroyed_doc_that_cannot_be_accessed_by_all = $_POST['destroyed_doc_that_cannot_be_accessed_by_all'];
            }else{
                $model->destroyed_doc_that_cannot_be_accessed_by_all = 0;
                        
            }
            if(isset($_POST['effect_blacklist_at_destruction'])){
                $model->effect_blacklist_at_destruction = $_POST['effect_blacklist_at_destruction'];
            }else{
                $model->effect_blacklist_at_destruction = 0;
                        
            }
             if(isset($_POST['effect_whitelist_at_destruction'])){
                $model->effect_whitelist_at_destruction = $_POST['effect_whitelist_at_destruction'];
            }else{
                $model->effect_whitelist_at_destruction = 0;
                        
            }
             if(isset($_POST['all_doc_types_available_for_exchange'])){
                $model->all_doc_types_available_for_exchange = $_POST['all_doc_types_available_for_exchange'];
            }else{
                $model->all_doc_types_available_for_exchange = 0;
                        
            }
              if(isset($_POST['doc_types_available_for_exchange'])){
                $model->doc_types_available_for_exchange = $_POST['doc_types_available_for_exchange'];
            }else{
                $model->doc_types_available_for_exchange = 0;
                        
            }
            if(isset($_POST['restrict_exchange_of_doc_types_to_hood'])){
                $model->restrict_exchange_of_doc_types_to_hood = $_POST['restrict_exchange_of_doc_types_to_hood'];
            }else{
                $model->restrict_exchange_of_doc_types_to_hood = 0;
                        
            }
            if(isset($_POST['restrict_exchange_of_doc_types_to_clusters'])){
                $model->restrict_exchange_of_doc_types_to_clusters = $_POST['restrict_exchange_of_doc_types_to_clusters'];
            }else{
                $model->restrict_exchange_of_doc_types_to_clusters = 0;
                        
            }
             if(isset($_POST['effect_blacklist_at_exchange'])){
                $model->effect_blacklist_at_exchange = $_POST['effect_blacklist_at_exchange'];
            }else{
                $model->effect_blacklist_at_exchange = 0;
                        
            }
             if(isset($_POST['effect_whitelist_at_exchange'])){
                $model->effect_whitelist_at_exchange = $_POST['effect_whitelist_at_exchange'];
            }else{
                $model->effect_whitelist_at_exchange = 0;
                        
            }
            if(isset($_POST['all_doc_types_available_for_sharing'])){
                $model->all_doc_types_available_for_sharing = $_POST['all_doc_types_available_for_sharing'];
            }else{
                $model->all_doc_types_available_for_sharing = 0;
                        
            }
            if(isset($_POST['doc_types_available_for_sharing'])){
                $model->doc_types_available_for_sharing = $_POST['doc_types_available_for_sharing'];
            }else{
                $model->doc_types_available_for_sharing = 0;
                        
            }
            if(isset($_POST['restrict_sharing_of_doc_types_to_hood'])){
                $model->restrict_sharing_of_doc_types_to_hood = $_POST['restrict_sharing_of_doc_types_to_hood'];
            }else{
                $model->restrict_sharing_of_doc_types_to_hood = 0;
                        
            }
             if(isset($_POST['restrict_sharing_of_doc_types_to_clusters'])){
                $model->restrict_sharing_of_doc_types_to_clusters = $_POST['restrict_sharing_of_doc_types_to_clusters'];
            }else{
                $model->restrict_sharing_of_doc_types_to_clusters = 0;
                        
            }
             if(isset($_POST['effect_blacklist_at_sharing'])){
                $model->effect_blacklist_at_sharing = $_POST['effect_blacklist_at_sharing'];
            }else{
                $model->effect_blacklist_at_sharing = 0;
                        
            }
             if(isset($_POST['effect_whitelist_at_sharing'])){
                $model->effect_whitelist_at_sharing = $_POST['effect_whitelist_at_sharing'];
            }else{
                $model->effect_whitelist_at_sharing = 0;
                        
            }
             if(isset($_POST['all_doc_types_available_for_transfer'])){
                $model->all_doc_types_available_for_transfer = $_POST['all_doc_types_available_for_transfer'];
            }else{
                $model->all_doc_types_available_for_transfer = 0;
                        
            }
             if(isset($_POST['doc_types_available_for_transfer'])){
                $model->doc_types_available_for_transfer = $_POST['doc_types_available_for_transfer'];
            }else{
                $model->doc_types_available_for_transfer = 0;
                        
            }
             if(isset($_POST['restrict_transfer_of_doc_types_to_hood'])){
                $model->restrict_transfer_of_doc_types_to_hood = $_POST['restrict_transfer_of_doc_types_to_hood'];
            }else{
                $model->restrict_transfer_of_doc_types_to_hood = 0;
                        
            }
              if(isset($_POST['restrict_transfer_of_doc_types_to_clusters'])){
                $model->restrict_transfer_of_doc_types_to_clusters = $_POST['restrict_transfer_of_doc_types_to_clusters'];
            }else{
                $model->restrict_transfer_of_doc_types_to_clusters = 0;
                        
            }
              if(isset($_POST['effect_blacklist_at_transfer'])){
                $model->effect_blacklist_at_transfer = $_POST['effect_blacklist_at_transfer'];
            }else{
                $model->effect_blacklist_at_transfer = 0;
                        
            }
             if(isset($_POST['effect_whitelist_at_transfer'])){
                $model->effect_whitelist_at_transfer = $_POST['effect_whitelist_at_transfer'];
            }else{
                $model->effect_whitelist_at_transfer = 0;
                        
            }
            if(isset($_POST['all_doc_type_available_for_trading'])){
                $model->all_doc_type_available_for_trading = $_POST['all_doc_type_available_for_trading'];
            }else{
                $model->all_doc_type_available_for_trading = 0;
                        
            }
             if(isset($_POST['these_doctypes_available_for_trading'])){
                $model->these_doctypes_available_for_trading = $_POST['these_doctypes_available_for_trading'];
            }else{
                $model->these_doctypes_available_for_trading = 0;
                        
            }
            if(isset($_POST['restrict_trading_of_doctype_to_hoods'])){
                $model->restrict_trading_of_doctype_to_hoods = $_POST['restrict_trading_of_doctype_to_hoods'];
            }else{
                $model->restrict_trading_of_doctype_to_hoods = 0;
                        
            }
            if(isset($_POST['restrict_trading_of_doctype_to_clusters'])){
                $model->restrict_trading_of_doctype_to_clusters = $_POST['restrict_trading_of_doctype_to_clusters'];
            }else{
                $model->restrict_trading_of_doctype_to_clusters = 0;
                        
            }
            if(isset($_POST['allow_hood_to_trade_on_own_private_store'])){
                $model->allow_hood_to_trade_on_own_private_store = $_POST['allow_hood_to_trade_on_own_private_store'];
            }else{
                $model->allow_hood_to_trade_on_own_private_store = 0;
                        
            }
            if(isset($_POST['allow_doctypes_from_hoods_to_trade_on_store'])){
                $model->allow_doctypes_from_hoods_to_trade_on_store = $_POST['allow_doctypes_from_hoods_to_trade_on_store'];
            }else{
                $model->allow_doctypes_from_hoods_to_trade_on_store = 0;
                        
            }
            if(isset($_POST['retain_electronic_copy_of_destroyed_doc_types'])){
                $model->retain_electronic_copy_of_destroyed_doc_types = $_POST['retain_electronic_copy_of_destroyed_doc_types'];
            }else{
                $model->retain_electronic_copy_of_destroyed_doc_types = 0;
                        
            }
            if(isset($_POST['retain_electronic_copy_of_destroyed_doc_categories'])){
                $model->retain_electronic_copy_of_destroyed_doc_categories = $_POST['retain_electronic_copy_of_destroyed_doc_categories'];
            }else{
                $model->retain_electronic_copy_of_destroyed_doc_categories = 0;
                        
            }
            if(isset($_POST['assign_docs_for_destruction_against_those_in_charge'])){
                $model->assign_docs_for_destruction_against_those_in_charge = $_POST['assign_docs_for_destruction_against_those_in_charge'];
            }else{
                $model->assign_docs_for_destruction_against_those_in_charge = 0;
                        
            }
            if(isset($_POST['effect_blacklist_at_trading'])){
                $model->effect_blacklist_at_trading = $_POST['effect_blacklist_at_trading'];
            }else{
                $model->effect_blacklist_at_trading = 0;
                        
            }
            if(isset($_POST['effect_whitelist_at_trading'])){
                $model->effect_whitelist_at_trading = $_POST['effect_whitelist_at_trading'];
            }else{
                $model->effect_whitelist_at_trading = 0;
                        
            }
             if(isset($_POST['prefer_whitelist_over_blacklist'])){
                $model->prefer_whitelist_over_blacklist = $_POST['prefer_whitelist_over_blacklist'];
            }else{
                $model->prefer_whitelist_over_blacklist = 0;
                        
            }
            if(isset($_POST['prefer_blacklist_over_whitelist'])){
                $model->prefer_blacklist_over_whitelist = $_POST['prefer_blacklist_over_whitelist'];
            }else{
                $model->prefer_blacklist_over_whitelist = 0;
                        
            }
              if(isset($_POST['retain_electronic_copy_of_these_destroyed_documents'])){
                $model->retain_electronic_copy_of_these_destroyed_documents = $_POST['retain_electronic_copy_of_these_destroyed_documents'];
            }else{
                $model->retain_electronic_copy_of_these_destroyed_documents = 0;
                        
            }
             if(isset($_POST['these_boxes_to_be_moved_or_reassigned_as_a_whole'])){
                $model->these_boxes_to_be_moved_or_reassigned_as_a_whole = $_POST['these_boxes_to_be_moved_or_reassigned_as_a_whole'];
            }else{
                $model->these_boxes_to_be_moved_or_reassigned_as_a_whole = 0;
                        
            }
             if(isset($_POST['these_batches_to_be_moved_or_reassigned_as_a_whole'])){
                $model->these_batches_to_be_moved_or_reassigned_as_a_whole = $_POST['these_batches_to_be_moved_or_reassigned_as_a_whole'];
            }else{
                $model->these_batches_to_be_moved_or_reassigned_as_a_whole = 0;
                        
            }
            if(isset($_POST['all_boxes_to_be_moved_or_reassigned_as_a_whole'])){
                $model->all_boxes_to_be_moved_or_reassigned_as_a_whole = $_POST['all_boxes_to_be_moved_or_reassigned_as_a_whole'];
            }else{
                $model->all_boxes_to_be_moved_or_reassigned_as_a_whole = 0;
                        
            }
             if(isset($_POST['all_batches_to_be_moved_or_reassigned_as_a_whole'])){
                $model->all_batches_to_be_moved_or_reassigned_as_a_whole = $_POST['all_batches_to_be_moved_or_reassigned_as_a_whole'];
            }else{
                $model->all_batches_to_be_moved_or_reassigned_as_a_whole = 0;
                        
            }
            $model->max_number_of_batches_before_closing = $_POST['max_number_of_batches_before_closing'];
            $model->min_number_of_batches_before_closing = $_POST['min_number_of_batches_before_closing'];
            $model->excess_space_grace_period = $_POST['excess_space_grace_period'];
            $model->number_of_months_before_expiration = $_POST['number_of_months_before_expiration'];
            $model->update_user_id = $userid;
            $model->update_time = new CDbExpression('NOW()');
                      
           
             if($model->save()){
                            if($this->createorUpdateTheVariousMimeTypes($_id)){
                                $msg = "Platform Settings were successfully updated";
                                header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysql_errno() == 0,
                                        "msg" => $msg)
                                ); 
                            }else{
                               $msg = "All except some of the Mime Type Platform Settings were successfully added";
                               header('Content-Type: application/json');
                               echo CJSON::encode(array(
                                    "success" => mysql_errno() == 0,
                                        "msg" => $msg)
                                ); 
                            }
                           
                           
                       
                        
                 }else {
                         //$result['success'] = 'false';
                         $msg = "Validation Error: Platform Settings not updated";
                         header('Content-Type: application/json');
                         echo CJSON::encode(array(
                                    "success" => mysql_errno() != 0,
                                        "msg" => $msg)
                           );
                  } 
            
        }
        
        /**
         * This is the function that creates the mimetypes during platform parameter createion or updates
         */
        public function createOrUpdateTheVariousMimeTypes($id){
            
            if(($this->createOrUpdateIconMimeTypes($id) && $this->createOrUpdatePosterMimeTypes($id)) && ($this->createOrUpdateDocumentMimeTypes($id) && $this->createOrUpdateZipMimeTypes($id))){
                return true;
            }else{
                return false;
            }
            
        }
        
        /**
         * This is the function that creates or updates an icon  mime type in the system
         */
        public function createOrUpdateIconMimeTypes($id){
            
           if(isset($_POST['icon_mime_type'])){
                 
                if(is_array($_POST['icon_mime_type'])) {
                  
                    $num = 0;
                    foreach($_POST['icon_mime_type'] as $value){
                        if($value == 'image/png' ) {
                            $num = $num + 1;
                            $this->saveThisIconMimeType($id,$num);
                        }else if($value == 'image/jpg'){
                            $num = $num + 2;
                            $this->saveThisIconMimeType($id,$num);
                        }elseif($value == 'image/jpeg'){
                            $num = $num + 4;
                            $this->saveThisIconMimeType($id,$num);
                        }elseif($value == 'image/gif'){
                            $num = $num + 8;
                            $this->saveThisIconMimeType($id,$num);
                        }elseif($value == 'application/x-shockwave-flash'){
                            $num = $num + 16;
                            $this->saveThisIconMimeType($id,$num);
                        }elseif($value == 'image/psd'){
                            $num = $num + 32;
                            $this->saveThisIconMimeType($id,$num);
                        }elseif($value == 'image/bmp'){
                            $num = $num + 64;
                            $this->saveThisIconMimeType($id,$num);
                        }elseif($value == 'image/tiff'){
                            $num = $num + 128;
                            $this->saveThisIconMimeType($id,$num);
                        }elseif($value == 'application/octet-stream'){
                            $num = $num + 256;
                            $this->saveThisIconMimeType($id,$num);
                        }elseif($value == 'image/jp2'){
                            $num = $num + 512;
                            $this->saveThisIconMimeType($id,$num);
                        }elseif($value == 'image/vnd.wap.wbmp'){
                            $num = $num + 1024;
                            $this->saveThisIconMimeType($id,$num);
                        }elseif($value == 'image/xbm'){
                            $num = $num + 2048;
                            $this->saveThisIconMimeType($id,$num);
                        }elseif($value == 'image/vnd.microsoft.icon'){
                            $num = $num + 4096;
                            $this->saveThisIconMimeType($id,$num);
                        }
                        
                    }
                    
                }//end of the if is_array statement
                 
             }//end of the icon isset if statement
            
            return true;
        }
        
        
        /**
         * This is the function that creates or updates a poster mime type in the system
         * 
         */
        public function createOrUpdatePosterMimeTypes($id){
            
            if(isset($_POST['poster_mime_type'])){
                 
                if(is_array($_POST['poster_mime_type'])) {
                  
                    $num = 0;
                    foreach($_POST['poster_mime_type'] as $value){
                        if($value == 'image/png' ) {
                            $num = $num + 1;
                            $this->saveThisPosterMimeType($id,$num);
                        }else if($value == 'image/jpg'){
                            $num = $num + 2;
                            $this->saveThisPosterMimeType($id,$num);
                        }elseif($value == 'image/jpeg'){
                            $num = $num + 4;
                            $this->saveThisPosterMimeType($id,$num);
                        }elseif($value == 'image/gif'){
                            $num = $num + 8;
                            $this->saveThisPosterMimeType($id,$num);
                        }elseif($value == 'application/x-shockwave-flash'){
                            $num = $num + 16;
                            $this->saveThisPosterMimeType($id,$num);
                        }elseif($value == 'image/psd'){
                            $num = $num + 32;
                            $this->saveThisPosterMimeType($id,$num);
                        }elseif($value == 'image/bmp'){
                            $num = $num + 64;
                            $this->saveThisPosterMimeType($id,$num);
                        }elseif($value == 'image/tiff'){
                            $num = $num + 128;
                            $this->saveThisPosterMimeType($id,$num);
                        }elseif($value == 'application/octet-stream'){
                            $num = $num + 256;
                            $this->saveThisPosterMimeType($id,$num);
                        }elseif($value == 'image/jp2'){
                            $num = $num + 512;
                            $this->saveThisPosterMimeType($id,$num);
                        }elseif($value == 'image/vnd.wap.wbmp'){
                            $num = $num + 1024;
                            $this->saveThisPosterMimeType($id,$num);
                        }elseif($value == 'image/xbm'){
                            $num = $num + 2048;
                            $this->saveThisPosterMimeType($id,$num);
                        }elseif($value == 'image/vnd.microsoft.icon'){
                            $num = $num + 4096;
                            $this->saveThisPosterMimeType($id,$num);
                        }
                        
                    }
                    
                }//end of the if is_array statement
                 
             }//end of the poster isset if statement
            
            return true;
            
            
        }
        
        
        /**
         * This is the function that creates or updates a video mime type in the system
         */
        public function createOrUpdateVideoMimeTypes($id){
            
            if(isset($_POST['video_mime_type'])){
                 
                if(is_array($_POST['video_mime_type'])) {
                  
                    $num = 0;
                    foreach($_POST['video_mime_type'] as $value){
                        if($value == 'video/mp4' ) {
                            $num = $num + 1;
                            $this->saveThisVideoMimeType($id, $num);
                        }else if($value == 'video/ogg'){
                            $num = $num + 2;
                            $this->saveThisVideoMimeType($id,$num);
                        }elseif($value == 'video/webm'){
                            $num = $num + 4;
                            $this->saveThisVideoMimeType($id,$num);
                        }elseif($value == 'video/x-flv'){
                            $num = $num + 8;
                            $this->saveThisVideoMimeType($id,$num);
                        }elseif($value == 'application/x-mpegURL'){
                            $num = $num + 16;
                            $this->saveThisVideoMimeType($id,$num);
                        }elseif($value == 'video/MP2T'){
                            $num = $num + 32;
                            $this->saveThisVideoMimeType($id,$num);
                        }elseif($value == 'video/3gpp'){
                            $num = $num + 64;
                            $this->saveThisVideoMimeType($id,$num);
                        }elseif($value == 'video/quicktime'){
                            $num = $num + 128;
                            $this->saveThisVideoMimeType($id,$num);
                        }elseif($value == 'video/x-msvideo'){
                            $num = $num + 256;
                            $this->saveThisVideoMimeType($id,$num);
                        }elseif($value == 'video/x-ms-wmv'){
                            $num = $num + 512;
                            $this->saveThisVideoMimeType($id,$num);
                        }
                    }
                    
                }//end of the if is_array statement
                 
             }//end of the video isset if statement
            
            return true;
            
        }
        
        
        /**
         * This is the function that creates or updates document mine types
         */
        public function createOrUpdateDocumentMimeTypes($id){
            
            if(isset($_POST['document_mime_type'])){
                 
                if(is_array($_POST['document_mime_type'])) {
                  
                    $num = 0;
                    foreach($_POST['document_mime_type'] as $value){
                        if($value == 'application/pdf' ) {
                            $num = $num + 1;
                            $this->saveThisDocumentMimeType($id, $num);
                        }else if($value == 'application/xml'){
                            $num = $num + 2;
                            $this->saveThisDocumentMimeType($id,$num);
                        }elseif($value == 'application/json'){
                            $num = $num + 4;
                            $this->saveThisDocumentMimeType($id,$num);
                        }elseif($value == 'text/csv'){
                            $num = $num + 8;
                            $this->saveThisDocumentMimeType($id,$num);
                        }elseif($value == 'text/plain'){
                            $num = $num + 16;
                            $this->saveThisDocumentMimeType($id,$num);
                        }elseif($value == 'application/plain'){
                            $num = $num + 32;
                            $this->saveThisDocumentMimeType($id,$num);
                        }elseif($value == 'application/msword'){
                            $num = $num + 64;
                            $this->saveThisDocumentMimeType($id,$num);
                        }elseif($value == 'application/vnd.ms-powerpoint'){
                            $num = $num + 128;
                            $this->saveThisDocumentMimeType($id,$num);
                        }elseif($value == 'application/vnd.ms-excel'){
                            $num = $num + 256;
                            $this->saveThisDocumentMimeType($id,$num);
                        }elseif($value == 'application/vnd.openxmlformats-officedocument.wordprocessingml.document'){
                            $num = $num + 512;
                            $this->saveThisDocumentMimeType($id,$num);
                        }elseif($value == 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'){
                            $num = $num + 1024;
                            $this->saveThisDocumentMimeType($id,$num);
                        }elseif($value == 'application/vnd.openxmlformats-officedocument.presentationml.presentation'){
                            $num = $num + 2048;
                            $this->saveThisDocumentMimeType($id,$num);
                        }
                    }
                    
                }//end of the if is_array statement
                 
             }//end of the video isset if statement
            
            return true;
            
        }
        
        /**
         * This is the function that creates or updates a zip mime type in the system
         */
        public function createOrUpdateZipMimeTypes($id){
            
            if(isset($_POST['zip_file_type'])){
                 
                if(is_array($_POST['zip_file_type'])) {
                  
                    $num = 0;
                    foreach($_POST['zip_file_type'] as $value){
                        if($value == 'application/zip' ) {
                            $num = $num + 1;
                            $this->saveThisZipMimeType($id,$num);
                        }else if($value == 'application/x-zip-compressed'){
                            $num = $num + 2;
                            $this->saveThisZipMimeType($id,$num);
                        }elseif($value == 'multipart/x-zip'){
                            $num = $num + 4;
                            $this->saveThisZipMimeType($id,$num);
                        }elseif($value == 'application/x-compressed'){
                            $num = $num + 8;
                            $this->saveThisZipMimeType($id,$num);
                        }
                    }
                    
                }//end of the if is_array statement
                 
             }//end of the zip isset if statement
            
            return true;
            
        }
        
        /**
         * This is the function to save an icon file type
         */
        public function saveThisIconMimeType($id,$num){
            $cmd =Yii::app()->db->createCommand();
            $result = $cmd->update('platform_settings',
                         array('icon_mime_type'=>'icon_mime_type'|$num),
                           "id = $id"
                     );
            
            if($result > 0){
                return true;
            }else{
                return false;
            }
            
            
        }
        
        /**
         * This is the function to save a poster file type
         */
        public function saveThisPosterMimeType($id,$num){
            
            $cmd =Yii::app()->db->createCommand();
            $result = $cmd->update('platform_settings',
                         array('poster_mime_type'=>'poster_mime_type'|$num),
                           "id = $id"
                     );
            
            if($result > 0){
                return true;
            }else{
                return false;
            }
              
        }
        
        
        /**
         * This is the function to save a video file mime type
         */
        public function saveThisVideoMimeType($id,$num){
            $cmd =Yii::app()->db->createCommand();
            $result = $cmd->update('platform_settings',
                         array('video_mime_type'=>'video_mime_type'|$num),
                           "id = $id"
                     );
            
            if($result > 0){
                return true;
            }else{
                return false;
            }
            
            
        }
        
        /**
         * This is the function to save a video file mime type
         */
        public function saveThisDocumentMimeType($id,$num){
            $cmd =Yii::app()->db->createCommand();
            $result = $cmd->update('platform_settings',
                         array('document_mime_type'=>'document_mime_type'|$num),
                           "id = $id"
                     );
            
            if($result > 0){
                return true;
            }else{
                return false;
            }
            
            
        }
        
        /**
         * This is the function to save a zip file mime type
         */
        public function saveThisZipMimeType($id,$num){
            $cmd =Yii::app()->db->createCommand();
            $result = $cmd->update('platform_settings',
                         array('zip_file_type'=>'zip_file_type'|$num),
                           "id = $id"
                     );
            
            if($result > 0){
                return true;
            }else{
                return false;
            }
            
            
            
        }
        
	/**
         * This is the function that will delete one platform settings from the database
         */
        public function actionDeleteOnePlatformSettings(){
            $_id = $_POST['id'];
            $model=PlatformSettings::model()->findByPk($_id);
            if($model === null){
                 $msg = 'No Such Record Exist'; 
                    header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            //"selected" => $selected,
                            "msg" => $msg
                            //"category" =>$category,
                           
                           
                          
                       ));
                                      
            }else if($model->delete()){
                    $msg = 'This Platform Settings had been deleted successfully'; 
                    header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            //"selected" => $selected,
                            "msg" => $msg
                            //"category" =>$category,
                           
                           
                          
                       ));
                       
            } else {
                    $msg = 'Validation Error: This Platform Settings were not deleted'; 
                    header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                            //"selected" => $selected,
                            "msg" => $msg
                            //"category" =>$category,
                           
                           
                          
                       ));
                            
                }
            
        }
        
        /**
         * This is the function to list all platform settings
         */
        public function actionListAllPlatformsettingParamters(){
            
              //obtain the id of the logged in user
            $userid = Yii::app()->user->id;
            
            //determine the domain of the logged in user
           // $domainid = $this->determineAUserDomainIdGiven($userid);
            
           //spool the products/technologies for this domain
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            //$criteria->condition='domain_id=:id';
            //$criteria->params = array(':id'=>$domainid);
            $settings= PlatformSettings::model()->findAll($criteria);
            
                if($settings===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            "settings" => $settings
                          
                           
                           
                          
                       ));
                       
                }
        }
        
        /**
         * This is the function to retrieve some info about the platform settings
         */
        public function actionRetrieveSettingsInfo(){
            
           $id = $_REQUEST['id'];
           $currency_id = $_REQUEST['platform_default_currency_id'];
           $timezone_id = $_REQUEST['platform_default_time_zone_id'];
            
           //$id = 7 ;
           // $currency_id = 3;
           // $timezone_id = 1;
            
            //get the currency name given the currency id
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='id=:id';
            $criteria->params = array(':id'=>$currency_id);
            $currency = Currencies::model()->find($criteria); 
            
            //get the timezone given the timezone id
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='id=:id';
            $criteria->params = array(':id'=>$timezone_id);
            $timezone = Timezones::model()->find($criteria); 
            
            //retrieve the icon mime types
            $icon_mimetype = [];
            $icon_types = [];
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='id=:id';
            $criteria->params = array(':id'=>$id);
            $icon_mime = PlatformSettings::model()->find($criteria); 
            
            $icon_mimetype = explode(',',$icon_mime['icon_mime_type']);
            foreach($icon_mimetype as $icon){
                $icon_types[] =$icon; 
                
            }
            
            //retrieve the poster mime types
            $poster_mimetype = [];
            $poster_types = [];
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='id=:id';
            $criteria->params = array(':id'=>$id);
            $poster_mime = PlatformSettings::model()->find($criteria); 
            
            $poster_mimetype = explode(',',$poster_mime['poster_mime_type']);
            foreach($poster_mimetype as $poster){
                $poster_types[] =$poster; 
                
            }
            
            //retrieve the video mime types
            $doc_mimetype = [];
            $video_types = [];
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='id=:id';
            $criteria->params = array(':id'=>$id);
            $doc_mime = PlatformSettings::model()->find($criteria); 
            
            $doc_mimetype = explode(',',$doc_mime['document_mime_type']);
            foreach($doc_mimetype as $doc){
                $doc_types[] =$doc; 
                
            }
            
            //retrieve the zip mime types
            $zip_mimetype = [];
            $zip_types = [];
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='id=:id';
            $criteria->params = array(':id'=>$id);
            $zip_mime = PlatformSettings::model()->find($criteria); 
            
            $zip_mimetype = explode(',',$zip_mime['zip_file_type']);
            foreach($zip_mimetype as $zip){
                $zip_types[] =$zip; 
                
            }
            
            
             if($id===null) {
                    http_response_code(404);
                    $msg ='No record found';
                   header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            "msg" =>$msg
                       ));
                       
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            "currency" =>$currency['currency_name'],
                           "timezone" =>$timezone['timezone'],
                           "icon"=>$icon_types,
                           "poster"=>$poster_types,
                           "document"=>$doc_types,
                           "zip"=>$zip_types
                       ));
                       
                } 
            
            
            
        }
        
        
        
        /**
         * Determine a domain id of a user given his user id 
         */
        public function determineAUserDomainIdGiven_old($userid){
            
            //determine the usertype id of the user
            $typeid = $this->determineAUserUsertypeId($userid);
            //determine the usertype name of this usertypeid
            $typename = $this->determineUserTypeName($typeid);
            
            //determine the domain id given usertype name
            $domainid = $this->determineDomainIdGiveUsertypeName($typename);
            
            //determine the domain name given its id
            $name = $this->determineDomainNameGivenItId($domainid);
            //determine the domain id given its name
            $domainname = $this->determineDomainIdGivenItsName($name);
            
            return $domainname;
            
            
        }
        
        
         /**
         * Determine a domain id of a user given his user id 
         */
        public function determineAUserDomainIdGiven($userid){
            
            $criteria1 = new CDbCriteria();
            $criteria1->select = '*';
            $criteria1->condition='id=:id';
            $criteria1->params = array(':id'=>$userid);
            $user= User::model()->find($criteria1);
            
            return $user['domain_id'];
        }
        
        
              
        /**
         * this is the function that retrieves the grouptype id given domain name
         */
        public function determineGrouptypeIdGivenDomainName($domainname){
            
            $criteria = new CDbCriteria();
            $criteria->select = 'id, name';
            $criteria->condition='name=:name';
            $criteria->params = array(':name'=>$domainname);
            $grouptypeid= GroupType::model()->find($criteria);
            
            return $grouptypeid['id'];
            
            
        }
           
        /**
         * Determine a users usertype_id
         */
        public function determineAUserUsertypeId($userid){
            
            $criteria = new CDbCriteria();
            $criteria->select = 'id, usertype_id';
            $criteria->condition='id=:id';
            $criteria->params = array(':id'=>$userid);
            $usertype= User::model()->find($criteria);
            
            return $usertype['usertype_id'];
            
            
        }
        
        /*
         * Determine a usertype name given its id
         */
        public function determineUserTypeName($usertypeid){
            $criteria1 = new CDbCriteria();
            $criteria1->select = 'id, name';
            $criteria1->condition='id=:id';
            $criteria1->params = array(':id'=>$usertypeid);
            $name= UserType::model()->find($criteria1);
            
            return $name['name'];
            
        }
        
        /*
         *  determine a usertype id given its name
         */
        public function determineUsertypeNameGiveId($usertypename){
            $criteria1 = new CDbCriteria();
            $criteria1->select = 'id, name';
            $criteria1->condition='name=:name';
            $criteria1->params = array(':name'=>$usertypename);
            $id= UserType::model()->find($criteria1);
            
            return $id['id'];
        }
        
        /*
         * Determine a domain name given a usetypername
         */
        public function determineDomainNameGiveUsertypeName($usertypename){
            
            $criteria1 = new CDbCriteria();
            $criteria1->select = 'id, name';
            $criteria1->condition='name=:name';
            $criteria1->params = array(':name'=>$usertypename);
            $name= ResourcegroupCategory::model()->find($criteria1);
            
            return $name['name'];
            
        }
        
        /*
         * Determine a domain id given a usetypername
         */
        public function determineDomainIdGiveUsertypeName($usertypename){
            
            $criteria1 = new CDbCriteria();
            $criteria1->select = 'id, name';
            $criteria1->condition='name=:name';
            $criteria1->params = array(':name'=>$usertypename);
            $id= ResourcegroupCategory::model()->find($criteria1);
            
            return $id['id'];
            
        }
        
        
        /**
         * Determine a domain id given its name
         */
        public function determineDomainIdGivenItsName($name){
            $criteria1 = new CDbCriteria();
            $criteria1->select = 'id, name';
            $criteria1->condition='name=:name';
            $criteria1->params = array(':name'=>$name);
            $id= ResourcegroupCategory::model()->find($criteria1);
            
            return $id['id'];
            
        }
        
        /**
         * Determine a domain name given its id
         */
        public function determineDomainNameGivenItId($domainid){
            $criteria1 = new CDbCriteria();
            $criteria1->select = 'id, name';
            $criteria1->condition='id=:id';
            $criteria1->params = array(':id'=>$domainid);
            $name= ResourcegroupCategory::model()->find($criteria1);
            
            return $name['name'];
            
            
        }
        
        /**
         * This is the function that retrieves a resource/tool id given its name
         */
        public function determineResourceOrToolId($toolname){
            
            $criteria1 = new CDbCriteria();
            $criteria1->select = 'id, name';
            $criteria1->condition='name=:name';
            $criteria1->params = array(':name'=>$toolname);
            $id= Resources::model()->find($criteria1);
            
            return $id['id'];
            
        }
        
        
        /**
         * This is the function that retrieves a resource/tool name given its id
         */
        public function determineResourceOrToolName($toolid){
            
            $criteria1 = new CDbCriteria();
            $criteria1->select = 'id, name';
            $criteria1->condition='id=:id';
            $criteria1->params = array(':id'=>$toolid);
            $name= Resources::model()->find($criteria1);
            
            return $name['name'];
            
        }
        
        /**
         * This is the function that retrieves a resource/tool name given its id
         */
        public function determineGrouptypeGivenDomainId($domainid){
            
            $criteria1 = new CDbCriteria();
            $criteria1->select = 'id, name';
            $criteria1->condition='id=:id';
            $criteria1->params = array(':id'=>$domainid);
            $name= GroupType::model()->find($criteria1);
            
            return $name['name'];
            
        }
        
        /**
         * This is the function the retrieves a group id given the group name
         */
        public function determineGroupIdGivenGroupName($groupname,$domainid){
            
            //obtain the grouptype id given a domain id
            $grouptype_id = $this->determineGrouptypeIdGivenDomainId($domainid);
            $criteria = new CDbCriteria();
            $criteria->select = 'id, name';
            $criteria->condition='name=:name and grouptype_id=:id';
            $criteria->params = array(':name'=>$groupname, ':id'=>$grouptype_id);
            $id= Group::model()->find($criteria);
            
            return $id['id'];
            
            
        }
        
        /**
         * This is the function to retrieve subgroup id given subgroup name
         */
        public function determineSubgroupIdGivenSubgroupName($subgroupname, $domainid){
            //determine the group for this subgroup            
            $criteria = new CDbCriteria();
            $criteria->select = 'id, name, group_id';
            $criteria->condition='name=:name';
            $criteria->params = array(':name'=>$subgroupname);
            $groups= SubGroup::model()->findAll($criteria);
            
            foreach($groups as $group){
                $groupdomainid = $this->determineDomainIdGivenGroupId($group['group_id']);
                if($groupdomainid == $domainid){
                    $criteria1 = new CDbCriteria();
                    $criteria1->select = 'id, name';
                    $criteria1->condition='name=:name';
                    $criteria1->params = array(':name'=>$subgroupname);
                    $id= SubGroup::model()->find($criteria1);
                    
                     return $id['id'];
                    
                }
                
                
            }
            
           
            
        }
        
        /**
         * This is the function that determines grouptype is given domain id
         */
        public function determineGrouptypeIdGivenDomainId($domainid){
            
            //determine domain name
            $domainname = $this->determineDomainNameGivenItId($domainid);
            //Determine grouptype id given domain name
            $grouptypeid = $this->determineGrouptypeIdGivenDomainName($domainname);
            
            return $grouptypeid;
            
        }
        
        
        /**
         * This is the function that determines domain id given group id
         */
        public function determineDomainIdGivenGroupId($groupid){
            //determine grouptype id given group id
            $grouptypeid = $this->determineGrouptypeIdGivenGroupId($groupid);
            //determine domain id given grouptype id
            $domainid = $this->determineDomainIdGivenGrouptypeId($grouptypeid);
            
            return $domainid;
            
            
        }
        
        /**
         * This is the function that determines the grouptypeid given group id
         */
        public function determineGrouptypeIdGivenGroupId($groupid){
            
            $criteria = new CDbCriteria();
            $criteria->select = 'id, name, grouptype_id';
            $criteria->condition='id=:id';
            $criteria->params = array(':id'=>$groupid);
            $type= Group::model()->find($criteria);
            
            return $type['grouptype_id'];
            
        }
        
        /**
         * This is the function that returns domain id given grouptype id
         */
        public function determineDomainIdGivenGrouptypeId($grouptypeid){
            
            //determine the grouptype name
            $typename = $this->determineGrouptypeNameGivenGrouptypeId($grouptypeid);
            
            $domainname = $this->determineDomainNameGivenGrouptypeName($typename);
           
            //determine domain id given its id
            $domainid = $this->determineDomainIdGivenItsName($domainname);
            
            return $domainid;
            
            
        }
        
        /**
         * This is the function that determines grouptype name given its id
         **/
        public function determineGrouptypeNameGivenGrouptypeId($typeid){
            
            $criteria = new CDbCriteria();
            $criteria->select = 'id, name';
            $criteria->condition='id=:id';
            $criteria->params = array(':id'=>$typeid);
            $type= GroupType::model()->find($criteria);
            
            return $type['name'];
            
        }
        
        /**
         * This is the function that determines domain name given grouptype name
         */
        public function determineDomainNameGivenGrouptypeName($typename){
            
            $criteria = new CDbCriteria();
            $criteria->select = 'id, name';
            $criteria->condition='name=:name';
            $criteria->params = array(':name'=>$typename);
            $domain= ResourcegroupCategory::model()->find($criteria);
            
            return $domain['name'];
            
        }
        
        /**
         * This is the function that obtains a toolbox name given its id 
         */
        public function determineToolboxNameGivenItsId($toolboxid){
            
            $criteria = new CDbCriteria();
            $criteria->select = 'id, name';
            $criteria->condition='id=:id';
            $criteria->params = array(':id'=>$toolboxid);
            $toolbox= Resourcegroup::model()->find($criteria);
            
            return $toolbox['name'];
            
        }
        
        
        /**
         * This is the function that obtains a toolbox id given its name
         */
        public function determineToolboxIdGivenItsName($toolboxname){
            
            $criteria = new CDbCriteria();
            $criteria->select = 'id, name';
            $criteria->condition='name=:name';
            $criteria->params = array(':name'=>$toolboxname);
            $toolbox= Resourcegroup::model()->find($criteria);
            
            return $toolbox['id'];
            
        }

	/**
         * This is the box that retrieves all neighbours permitted to request for boxes on this domain
         */
        public function actionretrieveTheNeighbourhoodsThatArePermittedToRequestForBoxes(){
            
            
            $_id = $_REQUEST['platform_setting_id'];
            //$_id = 1;
             
             //get the logged in user
             $user_id = Yii::app()->user->id;   
             //get logged in user domain
             //$domain_id = $this->determineAUserDomainIdGiven($user_id);
             
           
             $criteria = new CDbCriteria();
             $criteria->select = '*';
            // $criteria->condition='domain_id=:domainid';
            // $criteria->params = array(':domainid'=>$domain_id);
             $result = Neighbourhood::model()->findAll($criteria);   
           
             //get the selected neighbourhoods with permission to request for a domain box & folder
             $criteria2 = new CDbCriteria();
             $criteria2->select = '*';
            // $criteria2->condition='domain_policy_id=:id';
            // $criteria2->params = array(':id'=>$_id);
             $selected = NeighbourhoodForBoxesRequestOnPlatform::model()->findAll($criteria2);
            
           
                if($result===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                         "success" => mysql_errno() == 0,
                            "selected" => $selected,
                            "data" => $result,
                       ));
                       
                }
            
            
        }
        
        
        
        /**
         * This is the box that retrieves all neighbours permitted to request for boxes on this domain
         */
        public function actionretrieveTheClustersThatArePermittedToRequestForBoxes(){
            
            
            $_id = $_REQUEST['platform_setting_id'];
            //$_id = 1;
             
             //get the logged in user
             $user_id = Yii::app()->user->id;   
             //get logged in user domain
             //$domain_id = $this->determineAUserDomainIdGiven($user_id);
             
           
             $criteria = new CDbCriteria();
             $criteria->select = '*';
            // $criteria->condition='domain_id=:domainid';
            // $criteria->params = array(':domainid'=>$domain_id);
             $result = Cluster::model()->findAll($criteria);   
           
             //get the selected clusters with permission to request for a domain box & folder
             $criteria2 = new CDbCriteria();
             $criteria2->select = '*';
            // $criteria2->condition='domain_policy_id=:id';
            // $criteria2->params = array(':id'=>$_id);
             $selected = ClusterForBoxesRequestOnPlatform::model()->findAll($criteria2);
            
           
                if($result===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                         "success" => mysql_errno() == 0,
                            "selected" => $selected,
                            "data" => $result,
                       ));
                       
                }
            
            
        }
        
        
            /**
         * This is the function that retrieves the clusters that were permitted to capture documents
         */
        public function actionretrieveTheClustersThatArePermittedToCaptureDocuments(){
            
            $_id = $_REQUEST['platform_setting_id'];
            //$_id = 1;
             
             //get the logged in user
             $user_id = Yii::app()->user->id;   
             //get logged in user domain
             //$domain_id = $this->determineAUserDomainIdGiven($user_id);
             
           
             $criteria = new CDbCriteria();
             $criteria->select = '*';
            // $criteria->condition='domain_id=:domainid';
            // $criteria->params = array(':domainid'=>$domain_id);
             $result = Cluster::model()->findAll($criteria);   
           
             //get the selected clusters with permission to capture documents on the platform
             $criteria2 = new CDbCriteria();
             $criteria2->select = '*';
            // $criteria2->condition='domain_policy_id=:id';
            // $criteria2->params = array(':id'=>$_id);
             $selected = ClusterForDocumentCapturingOnPlatform::model()->findAll($criteria2);
            
           
                if($result===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                         "success" => mysql_errno() == 0,
                            "selected" => $selected,
                            "data" => $result,
                       ));
                       
                }
            
        }
        
        
        
        /**
         * This is the function that retrieves the document types that determines the batches & file to accept in a box & folder 
         */
        public function actionretrieveDocumentTpesThatDeterminesTheBatchToAcceptInABox(){
            
            $_id = $_REQUEST['platform_setting_id'];
            //$_id = 1;
             
             //get the logged in user
             $user_id = Yii::app()->user->id;   
             //get logged in user domain
             //$domain_id = $this->determineAUserDomainIdGiven($user_id);
             
           
             $criteria = new CDbCriteria();
             $criteria->select = '*';
            // $criteria->condition='domain_id=:domainid';
            // $criteria->params = array(':domainid'=>$domain_id);
             $result = Resourcetype::model()->findAll($criteria);   
           
             //get the selected document types that determines the batch & file to accept in a box & folder
             $criteria2 = new CDbCriteria();
             $criteria2->select = '*';
            // $criteria2->condition='domain_policy_id=:id';
            // $criteria2->params = array(':id'=>$_id);
             $selected = AcceptBatchesOfDoctypesOnPlatform::model()->findAll($criteria2);
            
           
                if($result===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                         "success" => mysql_errno() == 0,
                            "selected" => $selected,
                            "data" => $result,
                       ));
                       
                }
            
            
        }
        
        
        /**
         * This is the function that retrieves the document categories that determines the batches & file to accept in a box & folder 
         */
        public function actionretrieveDocumentCategoriesThatDeterminesTheBatchToAcceptInABox(){
            
            $_id = $_REQUEST['platform_setting_id'];
            //$_id = 1;
             
             //get the logged in user
             $user_id = Yii::app()->user->id;   
             //get logged in user domain
             //$domain_id = $this->determineAUserDomainIdGiven($user_id);
             
           
             $criteria = new CDbCriteria();
             $criteria->select = '*';
            // $criteria->condition='domain_id=:domainid';
            // $criteria->params = array(':domainid'=>$domain_id);
             $result = Products::model()->findAll($criteria);   
           
             //get the selected document categories that determines the batch & file to accept in a box & folder
             $criteria2 = new CDbCriteria();
             $criteria2->select = '*';
            // $criteria2->condition='domain_policy_id=:id';
            // $criteria2->params = array(':id'=>$_id);
             $selected = AcceptBatchesOfDoccategoriesOnPlatform::model()->findAll($criteria2);
            
           
                if($result===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                         "success" => mysql_errno() == 0,
                            "selected" => $selected,
                            "data" => $result,
                       ));
                       
                }
            
            
        }
        
        
        
        /**
         * This is the function that retrieves the neighbours that are permitted to consume boxes & files on the platform 
         */
        public function actionretrieveNeighbourhoodsWithThePermissionToConsumeBoxes(){
            
            $_id = $_REQUEST['platform_setting_id'];
            //$_id = 1;
             
             //get the logged in user
             $user_id = Yii::app()->user->id;   
             //get logged in user domain
             //$domain_id = $this->determineAUserDomainIdGiven($user_id);
             
           
             $criteria = new CDbCriteria();
             $criteria->select = '*';
            // $criteria->condition='domain_id=:domainid';
            // $criteria->params = array(':domainid'=>$domain_id);
             $result = Neighbourhood::model()->findAll($criteria);   
           
             //get the selected neighbourhoods with permission to request for a domain box & folder
             $criteria2 = new CDbCriteria();
             $criteria2->select = '*';
            // $criteria2->condition='domain_policy_id=:id';
            // $criteria2->params = array(':id'=>$_id);
             $selected = NeighbourhoodToConsumeBoxesOnPlatform::model()->findAll($criteria2);
            
           
                if($result===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                         "success" => mysql_errno() == 0,
                            "selected" => $selected,
                            "data" => $result,
                       ));
                       
                }
            
            
        }
        
        
        
        /**
         * This is the function that retrieves the clusters that are permitted to consume boxes & files on the platform 
         */
        public function actionretrieveClustersWithThePermissionToConsumeBoxes(){
            
            $_id = $_REQUEST['platform_setting_id'];
            //$_id = 1;
             
             //get the logged in user
             $user_id = Yii::app()->user->id;   
             //get logged in user domain
             //$domain_id = $this->determineAUserDomainIdGiven($user_id);
             
           
             $criteria = new CDbCriteria();
             $criteria->select = '*';
            // $criteria->condition='domain_id=:domainid';
            // $criteria->params = array(':domainid'=>$domain_id);
             $result = Cluster::model()->findAll($criteria);   
           
             //get the selected clusters with permission to consume boxes on a the platform
             $criteria2 = new CDbCriteria();
             $criteria2->select = '*';
            // $criteria2->condition='domain_policy_id=:id';
            // $criteria2->params = array(':id'=>$_id);
             $selected = ClusterToConsumeBoxesOnPlatform::model()->findAll($criteria2);
            
           
                if($result===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                         "success" => mysql_errno() == 0,
                            "selected" => $selected,
                            "data" => $result,
                       ));
                       
                }
            
            
        }
        
        /**
         * This is the function that retrieves all the document types that are available for exchange
         * 
         */
        public function actionretrieveTheDocumentTypesThatAreAvailableForExchange(){
            
            $_id = $_REQUEST['platform_setting_id'];
            //$_id = 1;
             
             //get the logged in user
             $user_id = Yii::app()->user->id;   
             //get logged in user domain
             //$domain_id = $this->determineAUserDomainIdGiven($user_id);
             
           
             $criteria = new CDbCriteria();
             $criteria->select = '*';
            // $criteria->condition='domain_id=:domainid';
            // $criteria->params = array(':domainid'=>$domain_id);
             $result = Resourcetype::model()->findAll($criteria);   
           
             //get the selected document types that are available for exchange
             $criteria2 = new CDbCriteria();
             $criteria2->select = '*';
            // $criteria2->condition='domain_policy_id=:id';
            // $criteria2->params = array(':id'=>$_id);
             $selected = DocumenttypesAvailableForExchangesOnPlatform::model()->findAll($criteria2);
            
           
                if($result===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                         "success" => mysql_errno() == 0,
                            "selected" => $selected,
                            "data" => $result,
                       ));
                       
                }
            
            
        }
        
        
         /**
         * This is the function that retrieves all the neighbourhoods that the document types will be restricted to at exchange 
         */
        public function actionretrieveTheNeighbourhoodsThatDocumentTypesAreRestrictedToOnExchange(){
            
            $_id = $_REQUEST['platform_setting_id'];
            //$_id = 1;
             
             //get the logged in user
             $user_id = Yii::app()->user->id;   
             //get logged in user domain
             //$domain_id = $this->determineAUserDomainIdGiven($user_id);
             
           
             $criteria = new CDbCriteria();
             $criteria->select = '*';
            // $criteria->condition='domain_id=:domainid';
            // $criteria->params = array(':domainid'=>$domain_id);
             $result = Neighbourhood::model()->findAll($criteria);   
           
             //get the selected neighbourhoods that will restrict document exchanges
             $criteria2 = new CDbCriteria();
             $criteria2->select = '*';
            // $criteria2->condition='domain_policy_id=:id';
            // $criteria2->params = array(':id'=>$_id);
             $selected = ExchangesRestrictedToNeighbourhoodsOnPlatform::model()->findAll($criteria2);
            
           
                if($result===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                         "success" => mysql_errno() == 0,
                            "selected" => $selected,
                            "data" => $result,
                       ));
                       
                }
            
            
        }
        
        
        /**
         * This is the function that retrieves all the clusters that the document types will be restricted to at exchange 
         */
        public function actionretrieveTheClustersThatDocumentTypesAreRestrictedToOnExchange(){
            
            $_id = $_REQUEST['platform_setting_id'];
            //$_id = 1;
             
             //get the logged in user
             $user_id = Yii::app()->user->id;   
             //get logged in user domain
             //$domain_id = $this->determineAUserDomainIdGiven($user_id);
             
           
             $criteria = new CDbCriteria();
             $criteria->select = '*';
            // $criteria->condition='domain_id=:domainid';
            // $criteria->params = array(':domainid'=>$domain_id);
             $result = Cluster::model()->findAll($criteria);   
           
             //get the selected clusters that will restrict document exchanges
             $criteria2 = new CDbCriteria();
             $criteria2->select = '*';
            // $criteria2->condition='domain_policy_id=:id';
            // $criteria2->params = array(':id'=>$_id);
             $selected = ExchangesRestrictedToClustersOnPlatform::model()->findAll($criteria2);
            
           
                if($result===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                         "success" => mysql_errno() == 0,
                            "selected" => $selected,
                            "data" => $result,
                       ));
                       
                }
            
            
            
            
        }
        
        
        /**
         * This is the function that retrieves all the neighbourhoods that the document types will be restricted to on sharing 
         */
        public function actionretrieveTheNeighbourhoodsThatDocumentTypesAreRestrictedToOnSharing(){
            
            $_id = $_REQUEST['platform_setting_id'];
            //$_id = 1;
             
             //get the logged in user
             $user_id = Yii::app()->user->id;   
             //get logged in user domain
             //$domain_id = $this->determineAUserDomainIdGiven($user_id);
             
             //get the domain of this domain policy
            // $domain_id = $this->getTheDomainOwnerOfThisPolicy($_id);
                      
       
             $criteria = new CDbCriteria();
             $criteria->select = '*';
            // $criteria->condition='domain_id=:domainid';
             //$criteria->params = array(':domainid'=>$domain_id);
             $result = Neighbourhood::model()->findAll($criteria);   
           
             //get the selected neighbourhoods that will restrict document sharing
             $criteria2 = new CDbCriteria();
             $criteria2->select = '*';
             $criteria2->condition='platform_setting_id=:id';
             $criteria2->params = array(':id'=>$_id);
             $selected = SharingRestrictedToNeighbourhoodsOnPlatform::model()->findAll($criteria2);
            
           
                if($result===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                         "success" => mysql_errno() == 0,
                            "selected" => $selected,
                            "data" => $result,
                       ));
                       
                }
            
            
        }
        
        
        
         /**
         * This is the function that retrieves all the clusters that the document types will be restricted to on sharing
         */
        public function actionretrieveTheClustersThatDocumentTypesAreRestrictedToOnSharing(){
            
            
            $_id = $_REQUEST['platform_setting_id'];
            //$_id = 1;
             
             //get the logged in user
             $user_id = Yii::app()->user->id;   
             //get logged in user domain
             //$domain_id = $this->determineAUserDomainIdGiven($user_id);
             
             //get the domain of this domain policy
            // $domain_id = $this->getTheDomainOwnerOfThisPolicy($_id);
                      
       
             $criteria = new CDbCriteria();
             $criteria->select = '*';
             //$criteria->condition='domain_id=:domainid';
             //$criteria->params = array(':domainid'=>$domain_id);
             $result = Cluster::model()->findAll($criteria);   
           
             //get the selected clusters with permission to request for a domain box & folder
             $criteria2 = new CDbCriteria();
             $criteria2->select = '*';
             $criteria2->condition='platform_setting_id=:id';
             $criteria2->params = array(':id'=>$_id);
             $selected = SharingRestrictedToClustersOnPlatform::model()->findAll($criteria2);
            
           
                if($result===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                         "success" => mysql_errno() == 0,
                            "selected" => $selected,
                            "data" => $result,
                       ));
                       
                }
            
            
        }
        
        
        /**
         * This is the function that retrieves all the document types that are available for exchange
         * 
         */
        public function actionretrieveTheDocumentTypesThatAreAvailableForSharing(){
            
             $_id = $_REQUEST['platform_setting_id'];
            //$_id = 1;
             
             //get the logged in user
             $user_id = Yii::app()->user->id;   
             //get logged in user domain
             //$domain_id = $this->determineAUserDomainIdGiven($user_id);
             
             //get the domain of this domain policy
            // $domain_id = $this->getTheDomainOwnerOfThisPolicy($_id);
                      
       
             $criteria = new CDbCriteria();
             $criteria->select = '*';
            // $criteria->condition='domain_id=:domainid';
            // $criteria->params = array(':domainid'=>$domain_id);
             $result = Resourcetype::model()->findAll($criteria);   
           
             //get the selected document types that are available for exchange
             $criteria2 = new CDbCriteria();
             $criteria2->select = '*';
             $criteria2->condition='platform_setting_id=:id';
             $criteria2->params = array(':id'=>$_id);
             $selected = DocumenttypesAvailableForSharingOnPlatform::model()->findAll($criteria2);
            
           
                if($result===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                         "success" => mysql_errno() == 0,
                            "selected" => $selected,
                            "data" => $result,
                       ));
                       
                }
            
        }
        
        
        
         //for transfers
         /**
         * This is the function that retrieves all the neighbourhoods that the document types will be restricted to on sharing 
         */
        public function actionretrieveTheNeighbourhoodsThatDocumentTypesAreRestrictedToOnTransfers(){
            
            $_id = $_REQUEST['platform_setting_id'];
            //$_id = 1;
             
             //get the logged in user
             $user_id = Yii::app()->user->id;   
             //get logged in user domain
             //$domain_id = $this->determineAUserDomainIdGiven($user_id);
             
             //get the domain of this domain policy
             //$domain_id = $this->getTheDomainOwnerOfThisPolicy($_id);
                      
       
             $criteria = new CDbCriteria();
             $criteria->select = '*';
            // $criteria->condition='domain_id=:domainid';
            // $criteria->params = array(':domainid'=>$domain_id);
             $result = Neighbourhood::model()->findAll($criteria);   
           
             //get the selected neighbourhoods that will restrict document transfer
             $criteria2 = new CDbCriteria();
             $criteria2->select = '*';
             $criteria2->condition='platform_setting_id=:id';
             $criteria2->params = array(':id'=>$_id);
             $selected = TransferRestrictedToNeighbourhoodsOnPlatform::model()->findAll($criteria2);
            
           
                if($result===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                         "success" => mysql_errno() == 0,
                            "selected" => $selected,
                            "data" => $result,
                       ));
                       
                }
            
            
        }
        
        
        
         /**
         * This is the function that retrieves all the clusters that the document types will be restricted to on sharing
         */
        public function actionretrieveTheClustersThatDocumentTypesAreRestrictedToOnTransfers(){
            
            
            $_id = $_REQUEST['platform_setting_id'];
            //$_id = 1;
             
             //get the logged in user
             $user_id = Yii::app()->user->id;   
             //get logged in user domain
             //$domain_id = $this->determineAUserDomainIdGiven($user_id);
             
             //get the domain of this domain policy
             //$domain_id = $this->getTheDomainOwnerOfThisPolicy($_id);
                      
       
             $criteria = new CDbCriteria();
             $criteria->select = '*';
             //$criteria->condition='domain_id=:domainid';
             //$criteria->params = array(':domainid'=>$domain_id);
             $result = Cluster::model()->findAll($criteria);   
           
             //get the selected cluster that will restrict document transfer
             $criteria2 = new CDbCriteria();
             $criteria2->select = '*';
             $criteria2->condition='platform_setting_id=:id';
             $criteria2->params = array(':id'=>$_id);
             $selected = TransferRestrictedToClustersOnPlatform::model()->findAll($criteria2);
            
           
                if($result===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                         "success" => mysql_errno() == 0,
                            "selected" => $selected,
                            "data" => $result,
                       ));
                       
                }
            
            
        }
        
        
        
        
         /**
         * This is the function that retrieves all the document types that are available for exchange
         * 
         */
        public function actionretrieveTheDocumentTypesThatAreAvailableOnTransfers(){
            
             $_id = $_REQUEST['platform_setting_id'];
            //$_id = 1;
             
             //get the logged in user
             $user_id = Yii::app()->user->id;   
             //get logged in user domain
             //$domain_id = $this->determineAUserDomainIdGiven($user_id);
             
             //get the domain of this domain policy
            // $domain_id = $this->getTheDomainOwnerOfThisPolicy($_id);
                      
       
             $criteria = new CDbCriteria();
             $criteria->select = '*';
            // $criteria->condition='domain_id=:domainid';
            // $criteria->params = array(':domainid'=>$domain_id);
             $result = Resourcetype::model()->findAll($criteria);   
           
             //get the selected document types that are available for transfer
             $criteria2 = new CDbCriteria();
             $criteria2->select = '*';
             $criteria2->condition='platform_setting_id=:id';
             $criteria2->params = array(':id'=>$_id);
             $selected = DocumenttypesAvailableForTransferOnPlatform::model()->findAll($criteria2);
            
           
                if($result===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                         "success" => mysql_errno() == 0,
                            "selected" => $selected,
                            "data" => $result,
                       ));
                       
                }
            
        }
        
        
        //for trading module
        
        /**
         * This is the function that retrieves all the document types that are available for exchange
         * 
         */
        public function actionretrieveTheDocumentTypesThatAreAvailableOnTrading(){
            
             $_id = $_REQUEST['platform_setting_id'];
            //$_id = 1;
             
             //get the logged in user
             $user_id = Yii::app()->user->id;   
             //get logged in user domain
             //$domain_id = $this->determineAUserDomainIdGiven($user_id);
             
             //get the domain of this domain policy
             //$domain_id = $this->getTheDomainOwnerOfThisPolicy($_id);
                      
       
             $criteria = new CDbCriteria();
             $criteria->select = '*';
            // $criteria->condition='domain_id=:domainid';
            // $criteria->params = array(':domainid'=>$domain_id);
             $result = Resourcetype::model()->findAll($criteria);   
           
             //get the selected document types that are available for trading
             $criteria2 = new CDbCriteria();
             $criteria2->select = '*';
             $criteria2->condition='platform_setting_id=:id';
             $criteria2->params = array(':id'=>$_id);
             $selected = DocumenttypesAvailableForTradingOnPlatform::model()->findAll($criteria2);
            
           
                if($result===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                         "success" => mysql_errno() == 0,
                            "selected" => $selected,
                            "data" => $result,
                       ));
                       
                }
            
        }
        
        
        
         /**
         * This is the function that retrieves all the neighbourhoods where trading of document types will be done on this platform 
         */
        public function actionretrieveTheNeighbourhoodsThatDocumentTypesAreRestrictedToOnTrading(){
            
            $_id = $_REQUEST['platform_setting_id'];
            //$_id = 1;
             
             //get the logged in user
             $user_id = Yii::app()->user->id;   
             //get logged in user domain
             //$domain_id = $this->determineAUserDomainIdGiven($user_id);
             
             //get the domain of this domain policy
             //$domain_id = $this->getTheDomainOwnerOfThisPolicy($_id);
                      
       
             $criteria = new CDbCriteria();
             $criteria->select = '*';
             //$criteria->condition='domain_id=:domainid';
             //$criteria->params = array(':domainid'=>$domain_id);
             $result = Neighbourhood::model()->findAll($criteria);   
           
             //get the selected neighbourhoods that will restrict document trading
             $criteria2 = new CDbCriteria();
             $criteria2->select = '*';
             $criteria2->condition='platform_setting_id=:id';
             $criteria2->params = array(':id'=>$_id);
             $selected = TradingRestrictedToNeighbourhoodsOnPlatform::model()->findAll($criteria2);
            
           
                if($result===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                         "success" => mysql_errno() == 0,
                            "selected" => $selected,
                            "data" => $result,
                       ));
                       
                }
            
            
        }
        
        /**
         * This is the function that retrieves all the neighbourhoods that will be permitted to trade on own domain private store 
         */
        public function actionallowTheseNeighbourhoodsToTradeOnOwnPrivateStoreOnTrading(){
            
            $_id = $_REQUEST['platform_setting_id'];
            //$_id = 1;
             
             //get the logged in user
             $user_id = Yii::app()->user->id;   
             //get logged in user domain
             //$domain_id = $this->determineAUserDomainIdGiven($user_id);
             
             //get the domain of this domain policy
            // $domain_id = $this->getTheDomainOwnerOfThisPolicy($_id);
                      
       
             $criteria = new CDbCriteria();
             $criteria->select = '*';
            // $criteria->condition='domain_id=:domainid';
             //$criteria->params = array(':domainid'=>$domain_id);
             $result = Neighbourhood::model()->findAll($criteria);   
           
             //get the selected neighbourhoods that will restrict document trading
             $criteria2 = new CDbCriteria();
             $criteria2->select = '*';
             $criteria2->condition='platform_setting_id=:id';
             $criteria2->params = array(':id'=>$_id);
             $selected = AllowNeighbourhoodsOnOwnStoresOnPlatform::model()->findAll($criteria2);
            
           
                if($result===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                         "success" => mysql_errno() == 0,
                            "selected" => $selected,
                            "data" => $result,
                       ));
                       
                }
            
            
        }
        
        
        /**
         * This is the function that retrieves all the clusters where trading of document types will be done on this domain 
         */
        public function actionretrieveTheClustersThatDocumentTypesAreRestrictedToOnTrading(){
            
            $_id = $_REQUEST['platform_setting_id'];
            //$_id = 1;
             
             //get the logged in user
             $user_id = Yii::app()->user->id;   
             //get logged in user domain
             //$domain_id = $this->determineAUserDomainIdGiven($user_id);
             
             //get the domain of this domain policy
            // $domain_id = $this->getTheDomainOwnerOfThisPolicy($_id);
                      
       
             $criteria = new CDbCriteria();
             $criteria->select = '*';
            // $criteria->condition='domain_id=:domainid';
             //$criteria->params = array(':domainid'=>$domain_id);
             $result = Cluster::model()->findAll($criteria);   
           
             //get the selected neighbourhoods that will restrict document trading
             $criteria2 = new CDbCriteria();
             $criteria2->select = '*';
             $criteria2->condition='platform_setting_id=:id';
             $criteria2->params = array(':id'=>$_id);
             $selected = TradingRestrictedToClustersOnPlatform::model()->findAll($criteria2);
            
           
                if($result===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                         "success" => mysql_errno() == 0,
                            "selected" => $selected,
                            "data" => $result,
                       ));
                       
                }
            
            
        }
        
        
        
        //this is the movement, reassignment and destruction module
        
        
         /**
         * This is the function that retrieves all the documents that cannot be moved 
         */
        public function actionretrieveAllTheDocumentsThatCannotBeMovedAtMovement(){
            
            $_id = $_REQUEST['platform_setting_id'];
            //$_id = 1;
             
             //get the logged in user
             $user_id = Yii::app()->user->id;   
             //get logged in user domain
             //$domain_id = $this->determineAUserDomainIdGiven($user_id);
             
             //get the domain of this domain policy
             //$domain_id = $this->getTheDomainOwnerOfThisPolicy($_id);
                      
       
             $criteria = new CDbCriteria();
             $criteria->select = '*';
            // $criteria->condition='domain_id=:domainid and parent_id is not null';
            // $criteria->params = array(':domainid'=>$domain_id);
             $result = Resources::model()->findAll($criteria);   
           
             //get the selected neighbourhoods that will restrict document trading
             $criteria2 = new CDbCriteria();
             $criteria2->select = '*';
             $criteria2->condition='platform_setting_id=:id';
             $criteria2->params = array(':id'=>$_id);
             $selected = ImmovableDocumentsOnPlatform::model()->findAll($criteria2);
            
           
                if($result===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                         "success" => mysql_errno() == 0,
                            "selected" => $selected,
                            "data" => $result,
                       ));
                       
                }
            
            
        }
        
        
           /**
         * This is the function that retrieves all the neighbourhoods where document movements are restricted to on this domain 
         */
        public function actionretrieveNeighbourhoodsThatDocumentMovementsHadBeenRestrictedToAtMovement(){
            
            $_id = $_REQUEST['platform_setting_id'];
            //$_id = 1;
             
             //get the logged in user
             $user_id = Yii::app()->user->id;   
             //get logged in user domain
             //$domain_id = $this->determineAUserDomainIdGiven($user_id);
             
             //get the domain of this domain policy
             //$domain_id = $this->getTheDomainOwnerOfThisPolicy($_id);
                      
       
             $criteria = new CDbCriteria();
             $criteria->select = '*';
             //$criteria->condition='domain_id=:domainid';
             //$criteria->params = array(':domainid'=>$domain_id);
             $result = Neighbourhood::model()->findAll($criteria);   
           
             //get the selected neighbourhoods that will restrict document trading
             $criteria2 = new CDbCriteria();
             $criteria2->select = '*';
             $criteria2->condition='platform_setting_id=:id';
             $criteria2->params = array(':id'=>$_id);
             $selected = RestrictedNeighbourhoodForDocumentMovementOnPlatform::model()->findAll($criteria2);
            
           
                if($result===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                         "success" => mysql_errno() == 0,
                            "selected" => $selected,
                            "data" => $result,
                       ));
                       
                }
            
            
        }
        
        
        
         /**
         * This is the function that retrieves all the documents that cannot be moved outside its domian
         */
        public function actionretrieveAllTheDocumentsThatCannotBeMovedOutsideOwnDomainAtMovement(){
            
            $_id = $_REQUEST['platform_setting_id'];
            //$_id = 1;
             
             //get the logged in user
             $user_id = Yii::app()->user->id;   
             //get logged in user domain
             //$domain_id = $this->determineAUserDomainIdGiven($user_id);
             
             //get the domain of this domain policy
           //  $domain_id = $this->getTheDomainOwnerOfThisPolicy($_id);
                      
       
             $criteria = new CDbCriteria();
             $criteria->select = '*';
             $criteria->condition='parent_id is not null';
             //$criteria->params = array(':domainid'=>$domain_id);
             $result = Resources::model()->findAll($criteria);   
           
             //get the selected neighbourhoods that will restrict document trading
             $criteria2 = new CDbCriteria();
             $criteria2->select = '*';
             $criteria2->condition='platform_setting_id=:id';
             $criteria2->params = array(':id'=>$_id);
             $selected = DocumentsNotMoveableOutsideOwnDomainOnPlatform::model()->findAll($criteria2);
            
           
                if($result===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                         "success" => mysql_errno() == 0,
                            "selected" => $selected,
                            "data" => $result,
                       ));
                       
                }
            
            
        }
        
        
        /**
         * This is the function that retrieves all the processors whose documents cannot be moved
         */
        public function actionretrieveAllProcessorsWhoseDocumentsCannotBeMovedAtMovement(){
            
            $_id = $_REQUEST['platform_setting_id'];
            //$_id = 1;
             
             //get the logged in user
             $user_id = Yii::app()->user->id;   
             //get logged in user domain
             //$domain_id = $this->determineAUserDomainIdGiven($user_id);
             
             //get the domain of this domain policy
            // $domain_id = $this->getTheDomainOwnerOfThisPolicy($_id);
                      
       
             $criteria = new CDbCriteria();
             $criteria->select = '*';
            // $criteria->condition='domain_id=:domainid';
            // $criteria->params = array(':domainid'=>$domain_id);
             $result = User::model()->findAll($criteria);   
           
             //get the selected neighbourhoods that will restrict document trading
             $criteria2 = new CDbCriteria();
             $criteria2->select = '*';
             $criteria2->condition='platform_setting_id=:id';
             $criteria2->params = array(':id'=>$_id);
             $selected = DocumentsByProcessorsNotMoveableOnPlatform::model()->findAll($criteria2);
            
           
                if($result===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                         "success" => mysql_errno() == 0,
                            "selected" => $selected,
                            "data" => $result,
                       ));
                       
                }
            
            
        }
        
        
        /**
         * This is the function that retrieves all the processors whose documents cannot be moved outside its domain
         */
        public function actionretrieveAllProcessorsWhoseDocumentsCannotBeMovedOutsideOwnDomainAtMovement(){
            
            $_id = $_REQUEST['platform_setting_id'];
            //$_id = 1;
             
             //get the logged in user
             $user_id = Yii::app()->user->id;   
             //get logged in user domain
             //$domain_id = $this->determineAUserDomainIdGiven($user_id);
             
             //get the domain of this domain policy
            // $domain_id = $this->getTheDomainOwnerOfThisPolicy($_id);
                      
       
             $criteria = new CDbCriteria();
             $criteria->select = '*';
             //$criteria->condition='domain_id=:domainid';
             //$criteria->params = array(':domainid'=>$domain_id);
             $result = User::model()->findAll($criteria);   
           
             //get the selected neighbourhoods that will restrict document trading
             $criteria2 = new CDbCriteria();
             $criteria2->select = '*';
             $criteria2->condition='platform_setting_id=:id';
             $criteria2->params = array(':id'=>$_id);
             $selected = RestrictedProcessorDocumentsMovementToDomainOnPlatform::model()->findAll($criteria2);
            
           
                if($result===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                         "success" => mysql_errno() == 0,
                            "selected" => $selected,
                            "data" => $result,
                       ));
                       
                }
            
            
        }
        
        
        
        /**
         * This is the function that retrieves all the batches that cannot be moved 
         */
        public function actionretrieveAllTheBatchesThatCannotBeMovedAtMovement(){
            
            $_id = $_REQUEST['platform_setting_id'];
            //$_id = 1;
             
             //get the logged in user
             $user_id = Yii::app()->user->id;   
             //get logged in user domain
             //$domain_id = $this->determineAUserDomainIdGiven($user_id);
             
             //get the domain of this domain policy
             //$domain_id = $this->getTheDomainOwnerOfThisPolicy($_id);
                      
       
             $criteria = new CDbCriteria();
             $criteria->select = '*';
             $criteria->condition='parent_id is null';
            // $criteria->params = array(':domainid'=>$domain_id);
             $result = Resources::model()->findAll($criteria);   
           
             //get the selected neighbourhoods that will restrict document trading
             $criteria2 = new CDbCriteria();
             $criteria2->select = '*';
             $criteria2->condition='platform_setting_id=:id';
             $criteria2->params = array(':id'=>$_id);
             $selected = ImmovableBatchesOnPlatform::model()->findAll($criteria2);
            
           
                if($result===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                         "success" => mysql_errno() == 0,
                            "selected" => $selected,
                            "data" => $result,
                       ));
                       
                }
            
            
        }
        
        
         /**
         * This is the function that retrieves all the neighbourhoods where batch movements are restricted to on this domain 
         */
        public function actionretrieveNeighbourhoodsThatBatchMovementsHadBeenRestrictedToAtMovement(){
            
            $_id = $_REQUEST['platform_setting_id'];
            //$_id = 1;
             
             //get the logged in user
             $user_id = Yii::app()->user->id;   
             //get logged in user domain
             //$domain_id = $this->determineAUserDomainIdGiven($user_id);
             
             //get the domain of this domain policy
             //$domain_id = $this->getTheDomainOwnerOfThisPolicy($_id);
                      
       
             $criteria = new CDbCriteria();
             $criteria->select = '*';
            // $criteria->condition='domain_id=:domainid';
             //$criteria->params = array(':domainid'=>$domain_id);
             $result = Neighbourhood::model()->findAll($criteria);   
           
             //get the selected neighbourhoods that will restrict document trading
             $criteria2 = new CDbCriteria();
             $criteria2->select = '*';
             $criteria2->condition='platform_setting_id=:id';
             $criteria2->params = array(':id'=>$_id);
             $selected = RestrictedNeighbourhoodForBatchMovementOnPlatform::model()->findAll($criteria2);
            
           
                if($result===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                         "success" => mysql_errno() == 0,
                            "selected" => $selected,
                            "data" => $result,
                       ));
                       
                }
            
            
        }
        
        
        /**
         * This is the function that retrieves all the batches that cannot be moved outside its domian
         */
        public function actionretrieveAllTheBatchesThatCannotBeMovedOutsideOwnDomainAtMovement(){
            
            $_id = $_REQUEST['platform_setting_id'];
            //$_id = 1;
             
             //get the logged in user
             $user_id = Yii::app()->user->id;   
             //get logged in user domain
             //$domain_id = $this->determineAUserDomainIdGiven($user_id);
             
             //get the domain of this domain policy
             //$domain_id = $this->getTheDomainOwnerOfThisPolicy($_id);
                      
       
             $criteria = new CDbCriteria();
             $criteria->select = '*';
             $criteria->condition='parent_id is null';
           //  $criteria->params = array(':domainid'=>$domain_id);
             $result = Resources::model()->findAll($criteria);   
           
             //get the selected neighbourhoods that will restrict document trading
             $criteria2 = new CDbCriteria();
             $criteria2->select = '*';
             $criteria2->condition='platform_setting_id=:id';
             $criteria2->params = array(':id'=>$_id);
             $selected = BatchesNotMoveableOutsideOwnDomainOnPlatform::model()->findAll($criteria2);
            
           
                if($result===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                         "success" => mysql_errno() == 0,
                            "selected" => $selected,
                            "data" => $result,
                       ));
                       
                }
            
            
        }
        
        
        
         /**
         * This is the function that retrieves all the boxes that cannot be moved 
         */
        public function actionretrieveAllTheBoxesThatCannotBeMovedAtMovement(){
            
            $_id = $_REQUEST['platform_setting_id'];
            //$_id = 1;
             
             //get the logged in user
             $user_id = Yii::app()->user->id;   
             //get logged in user domain
             //$domain_id = $this->determineAUserDomainIdGiven($user_id);
             
             //get the domain of this domain policy
             //$domain_id = $this->getTheDomainOwnerOfThisPolicy($_id);
                      
       
             $criteria = new CDbCriteria();
             $criteria->select = '*';
             //$criteria->condition='domain_id=:domainid';
            // $criteria->params = array(':domainid'=>$domain_id);
             $result = Resourcegroup::model()->findAll($criteria);   
           
             //get the selected neighbourhoods that will restrict document trading
             $criteria2 = new CDbCriteria();
             $criteria2->select = '*';
             $criteria2->condition='platform_setting_id=:id';
             $criteria2->params = array(':id'=>$_id);
             $selected = ImmovableBoxesOnPlatform::model()->findAll($criteria2);
            
           
                if($result===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                         "success" => mysql_errno() == 0,
                            "selected" => $selected,
                            "data" => $result,
                       ));
                       
                }
            
            
        }
        
        
         /**
         * This is the function that retrieves all the neighbourhoods where box & folder movements are restricted to on this domain 
         */
        public function actionretrieveNeighbourhoodsThatBoxMovementsHadBeenRestrictedToAtMovement(){
            
            $_id = $_REQUEST['platform_setting_id'];
            //$_id = 1;
             
             //get the logged in user
             $user_id = Yii::app()->user->id;   
             //get logged in user domain
             //$domain_id = $this->determineAUserDomainIdGiven($user_id);
             
             //get the domain of this domain policy
            // $domain_id = $this->getTheDomainOwnerOfThisPolicy($_id);
                      
       
             $criteria = new CDbCriteria();
             $criteria->select = '*';
             //$criteria->condition='domain_id=:domainid';
             //$criteria->params = array(':domainid'=>$domain_id);
             $result = Neighbourhood::model()->findAll($criteria);   
           
             //get the selected neighbourhoods that will restrict document trading
             $criteria2 = new CDbCriteria();
             $criteria2->select = '*';
             $criteria2->condition='platform_setting_id=:id';
             $criteria2->params = array(':id'=>$_id);
             $selected = RestrictedNeighbourhoodForBoxMovementOnPlatform::model()->findAll($criteria2);
            
           
                if($result===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                         "success" => mysql_errno() == 0,
                            "selected" => $selected,
                            "data" => $result,
                       ));
                       
                }
            
            
        }
        
        
        
         /**
         * This is the function that retrieves all the boxes & folders that cannot be moved outside its domian
         */
        public function actionretrieveAllTheBoxesThatCannotBeMovedOutsideOwnDomainAtMovement(){
            
            $_id = $_REQUEST['platform_setting_id'];
            //$_id = 1;
             
             //get the logged in user
             $user_id = Yii::app()->user->id;   
             //get logged in user domain
             //$domain_id = $this->determineAUserDomainIdGiven($user_id);
             
             //get the domain of this domain policy
             //$domain_id = $this->getTheDomainOwnerOfThisPolicy($_id);
                      
       
             $criteria = new CDbCriteria();
             $criteria->select = '*';
             //$criteria->condition='domain_id=:domainid';
             //$criteria->params = array(':domainid'=>$domain_id);
             $result = Resourcegroup::model()->findAll($criteria);   
           
             //get the selected neighbourhoods that will restrict document trading
             $criteria2 = new CDbCriteria();
             $criteria2->select = '*';
             $criteria2->condition='platform_setting_id=:id';
             $criteria2->params = array(':id'=>$_id);
             $selected = BoxesNotMoveableOutsideOwnDomainOnPlatform::model()->findAll($criteria2);
            
           
                if($result===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                         "success" => mysql_errno() == 0,
                            "selected" => $selected,
                            "data" => $result,
                       ));
                       
                }
            
            
        }
          /**
         * This is the function that gets the domain id of a domain policy owner
         */
        public function getTheDomainOwnerId($domain_policy_id){
            
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='id=:id';
            $criteria->params = array(':id'=>$domain_policy_id);
            $domain = DomainPolicy::model()->find($criteria); 
            
            return $domain['domain_id'];
        }
        
        
        /**
         * This is the function that retrieves all the documents that cannot be reassigned 
         */
        public function actionretrieveAllTheDocumentsThatCannotBeReassignedAtMovement(){
            
            $_id = $_REQUEST['platform_setting_id'];
            //$_id = 1;
             
             //get the logged in user
             $user_id = Yii::app()->user->id;   
             //get logged in user domain
             //$domain_id = $this->determineAUserDomainIdGiven($user_id);
             
             //get the domain of this domain policy
            // $domain_id = $this->getTheDomainOwnerOfThisPolicy($_id);
                      
       
             $criteria = new CDbCriteria();
             $criteria->select = '*';
             $criteria->condition='parent_id is not null';
             //$criteria->params = array(':domainid'=>$domain_id);
             $result = Resources::model()->findAll($criteria);   
           
             //get the selected documents that cannot be reassigned 
             $criteria2 = new CDbCriteria();
             $criteria2->select = '*';
             $criteria2->condition='platform_setting_id=:id';
             $criteria2->params = array(':id'=>$_id);
             $selected = NonreassignableDocumentsOnPlatform::model()->findAll($criteria2);
            
           
                if($result===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                         "success" => mysql_errno() == 0,
                            "selected" => $selected,
                            "data" => $result,
                       ));
                       
                }
            
            
        }
        
        
        
         /**
         * This is the function that retrieves all the batches that cannot be reassigned 
         */
        public function actionretrieveAllTheBatchesThatCannotBeReassignedAtMovement(){
            
            $_id = $_REQUEST['platform_setting_id'];
            //$_id = 1;
             
             //get the logged in user
             $user_id = Yii::app()->user->id;   
             //get logged in user domain
             //$domain_id = $this->determineAUserDomainIdGiven($user_id);
             
             //get the domain of this domain policy
             //$domain_id = $this->getTheDomainOwnerOfThisPolicy($_id);
                      
       
             $criteria = new CDbCriteria();
             $criteria->select = '*';
             $criteria->condition='parent_id is null';
             //$criteria->params = array(':domainid'=>$domain_id);
             $result = Resources::model()->findAll($criteria);   
           
             //get the selected documents that cannot be reassigned 
             $criteria2 = new CDbCriteria();
             $criteria2->select = '*';
             $criteria2->condition='platform_setting_id=:id';
             $criteria2->params = array(':id'=>$_id);
             $selected = NonreassignableBatchesOnPlatform::model()->findAll($criteria2);
            
           
                if($result===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                         "success" => mysql_errno() == 0,
                            "selected" => $selected,
                            "data" => $result,
                       ));
                       
                }
            
            
        }
        
        
        
        /**
         * This is the function that retrieves all the boxes & folders that cannot be reassigned 
         */
        public function actionretrieveAllTheBoxesThatCannotBeReassignedAtMovement(){
            
            $_id = $_REQUEST['platform_setting_id'];
            //$_id = 1;
             
             //get the logged in user
             $user_id = Yii::app()->user->id;   
             //get logged in user domain
             //$domain_id = $this->determineAUserDomainIdGiven($user_id);
             
             //get the domain of this domain policy
            // $domain_id = $this->getTheDomainOwnerOfThisPolicy($_id);
                      
       
             $criteria = new CDbCriteria();
             $criteria->select = '*';
            // $criteria->condition='domain_id=:domainid';
             //$criteria->params = array(':domainid'=>$domain_id);
             $result = Resourcegroup::model()->findAll($criteria);   
           
             //get the selected documents that cannot be reassigned 
             $criteria2 = new CDbCriteria();
             $criteria2->select = '*';
             $criteria2->condition='platform_setting_id=:id';
             $criteria2->params = array(':id'=>$_id);
             $selected = NonreassignableBoxesOnPlatform::model()->findAll($criteria2);
            
           
                if($result===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                         "success" => mysql_errno() == 0,
                            "selected" => $selected,
                            "data" => $result,
                       ));
                       
                }
            
            
        }
        
        
        
        /**
         * This is the function that retrieves all the neighbourhoods for document reassigned 
         */
        public function actionretrieveNeighbourhoodsThatDocumentReassignmentIsRestrictedToAtMovement(){
            
            $_id = $_REQUEST['platform_setting_id'];
            //$_id = 1;
             
             //get the logged in user
             $user_id = Yii::app()->user->id;   
             //get logged in user domain
             //$domain_id = $this->determineAUserDomainIdGiven($user_id);
             
             //get the domain of this domain policy
             //$domain_id = $this->getTheDomainOwnerOfThisPolicy($_id);
                      
       
             $criteria = new CDbCriteria();
             $criteria->select = '*';
             //$criteria->condition='domain_id=:domainid';
            // $criteria->params = array(':domainid'=>$domain_id);
             $result = Neighbourhood::model()->findAll($criteria);   
           
             //get the selected documents that cannot be reassigned 
             $criteria2 = new CDbCriteria();
             $criteria2->select = '*';
             $criteria2->condition='platform_setting_id=:id';
             $criteria2->params = array(':id'=>$_id);
             $selected = RestrictedNeighbourhoodForDocumentReassignmentOnPlatform::model()->findAll($criteria2);
            
           
                if($result===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                         "success" => mysql_errno() == 0,
                            "selected" => $selected,
                            "data" => $result,
                       ));
                       
                }
            
            
        }
        
        
        
        /**
         * This is the function that retrieves all the neighbourhoods for batch reassigned 
         */
        public function actionretrieveNeighbourhoodsThatBatchReassignmentIsRestrictedToAtMovement(){
            
            $_id = $_REQUEST['platform_setting_id'];
            //$_id = 1;
             
             //get the logged in user
             $user_id = Yii::app()->user->id;   
             //get logged in user domain
             //$domain_id = $this->determineAUserDomainIdGiven($user_id);
             
             //get the domain of this domain policy
            // $domain_id = $this->getTheDomainOwnerOfThisPolicy($_id);
                      
       
             $criteria = new CDbCriteria();
             $criteria->select = '*';
            // $criteria->condition='domain_id=:domainid';
             //$criteria->params = array(':domainid'=>$domain_id);
             $result = Neighbourhood::model()->findAll($criteria);   
           
             //get the selected documents that cannot be reassigned 
             $criteria2 = new CDbCriteria();
             $criteria2->select = '*';
             $criteria2->condition='platform_setting_id=:id';
             $criteria2->params = array(':id'=>$_id);
             $selected = RestrictedNeighbourhoodForBatchReassignmentOnPlatform::model()->findAll($criteria2);
            
           
                if($result===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                         "success" => mysql_errno() == 0,
                            "selected" => $selected,
                            "data" => $result,
                       ));
                       
                }
            
            
        }
        
        
        
        /**
         * This is the function that retrieves all the neighbourhoods for box & folder reassigned 
         */
        public function actionretrieveNeighbourhoodsThatBoxReassignmentIsRestrictedToAtMovement(){
            
            $_id = $_REQUEST['platform_setting_id'];
            //$_id = 1;
             
             //get the logged in user
             $user_id = Yii::app()->user->id;   
             //get logged in user domain
             //$domain_id = $this->determineAUserDomainIdGiven($user_id);
             
             //get the domain of this domain policy
            // $domain_id = $this->getTheDomainOwnerOfThisPolicy($_id);
                      
       
             $criteria = new CDbCriteria();
             $criteria->select = '*';
            // $criteria->condition='domain_id=:domainid';
            // $criteria->params = array(':domainid'=>$domain_id);
             $result = Neighbourhood::model()->findAll($criteria);   
           
             //get the selected documents that cannot be reassigned 
             $criteria2 = new CDbCriteria();
             $criteria2->select = '*';
             $criteria2->condition='platform_setting_id=:id';
             $criteria2->params = array(':id'=>$_id);
             $selected = RestrictedNeighbourhoodForBoxReassignmentOnPlatform::model()->findAll($criteria2);
            
           
                if($result===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                         "success" => mysql_errno() == 0,
                            "selected" => $selected,
                            "data" => $result,
                       ));
                       
                }
            
            
        }
        
        
        
        
        /**
         * This is the function that retrieves all the clusters for document reassigned 
         */
        public function actionretrieveClustersThatDocumentReassignmentIsRestrictedToAtMovement(){
            
            $_id = $_REQUEST['platform_setting_id'];
            //$_id = 1;
             
             //get the logged in user
             $user_id = Yii::app()->user->id;   
             //get logged in user domain
             //$domain_id = $this->determineAUserDomainIdGiven($user_id);
             
             //get the domain of this domain policy
            // $domain_id = $this->getTheDomainOwnerOfThisPolicy($_id);
                      
       
             $criteria = new CDbCriteria();
             $criteria->select = '*';
             //$criteria->condition='domain_id=:domainid';
             //$criteria->params = array(':domainid'=>$domain_id);
             $result = Cluster::model()->findAll($criteria);   
           
             //get the selected documents that cannot be reassigned 
             $criteria2 = new CDbCriteria();
             $criteria2->select = '*';
             $criteria2->condition='platform_setting_id=:id';
             $criteria2->params = array(':id'=>$_id);
             $selected = RestrictedClusterForDocumentReassignmentOnPlatform::model()->findAll($criteria2);
            
           
                if($result===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                         "success" => mysql_errno() == 0,
                            "selected" => $selected,
                            "data" => $result,
                       ));
                       
                }
            
            
        }
        
        
        /**
         * This is the function that retrieves all the clusters for batch reassigned 
         */
        public function actionretrieveClustersThatBatchReassignmentIsRestrictedToAtMovement(){
            
            $_id = $_REQUEST['platform_setting_id'];
            //$_id = 1;
             
             //get the logged in user
             $user_id = Yii::app()->user->id;   
             //get logged in user domain
             //$domain_id = $this->determineAUserDomainIdGiven($user_id);
             
             //get the domain of this domain policy
             //$domain_id = $this->getTheDomainOwnerOfThisPolicy($_id);
                      
       
             $criteria = new CDbCriteria();
             $criteria->select = '*';
             //$criteria->condition='domain_id=:domainid';
             //$criteria->params = array(':domainid'=>$domain_id);
             $result = Cluster::model()->findAll($criteria);   
           
             //get the selected documents that cannot be reassigned 
             $criteria2 = new CDbCriteria();
             $criteria2->select = '*';
             $criteria2->condition='platform_setting_id=:id';
             $criteria2->params = array(':id'=>$_id);
             $selected = RestrictedClusterForBatchReassignmentOnPlatform::model()->findAll($criteria2);
            
           
                if($result===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                         "success" => mysql_errno() == 0,
                            "selected" => $selected,
                            "data" => $result,
                       ));
                       
                }
            
            
        }
        
        
        
        
        /**
         * This is the function that retrieves all the clusters for box reassigned 
         */
        public function actionretrieveClustersThatBoxReassignmentIsRestrictedToAtMovement(){
            
            $_id = $_REQUEST['platform_setting_id'];
            //$_id = 1;
             
             //get the logged in user
             $user_id = Yii::app()->user->id;   
             //get logged in user domain
             //$domain_id = $this->determineAUserDomainIdGiven($user_id);
             
             //get the domain of this domain policy
             //$domain_id = $this->getTheDomainOwnerOfThisPolicy($_id);
                      
       
             $criteria = new CDbCriteria();
             $criteria->select = '*';
            // $criteria->condition='domain_id=:domainid';
           //  $criteria->params = array(':domainid'=>$domain_id);
             $result = Cluster::model()->findAll($criteria);   
           
             //get the selected documents that cannot be reassigned 
             $criteria2 = new CDbCriteria();
             $criteria2->select = '*';
             $criteria2->condition='platform_setting_id=:id';
             $criteria2->params = array(':id'=>$_id);
             $selected = RestrictedClusterForBoxReassignmentOnPlatform::model()->findAll($criteria2);
            
           
                if($result===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                         "success" => mysql_errno() == 0,
                            "selected" => $selected,
                            "data" => $result,
                       ));
                       
                }
            
            
        }
        
        
        
        /**
         * This is the function that retrieves all the neighbourhoods that were exempted from destruction 
         */
        public function actionretrieveNeighbourhoodsWhoseDocumentsCannotBeDestroyedAtDestruction(){
            
            $_id = $_REQUEST['platform_setting_id'];
            //$_id = 1;
             
             //get the logged in user
             $user_id = Yii::app()->user->id;   
             //get logged in user domain
             //$domain_id = $this->determineAUserDomainIdGiven($user_id);
             
             //get the domain of this domain policy
             //$domain_id = $this->getTheDomainOwnerOfThisPolicy($_id);
                      
       
             $criteria = new CDbCriteria();
             $criteria->select = '*';
             //$criteria->condition='domain_id=:domainid';
             //$criteria->params = array(':domainid'=>$domain_id);
             $result = Neighbourhood::model()->findAll($criteria);   
           
             //get the selected documents that cannot be reassigned 
             $criteria2 = new CDbCriteria();
             $criteria2->select = '*';
             $criteria2->condition='platform_setting_id=:id';
             $criteria2->params = array(':id'=>$_id);
             $selected = ExemptedNeighbourhoodForDestructionOnPlatform::model()->findAll($criteria2);
            
           
                if($result===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                         "success" => mysql_errno() == 0,
                            "selected" => $selected,
                            "data" => $result,
                       ));
                       
                }
            
            
        }
        
        
        
        
        /**
         * This is the function that retrieves all the clusters that were exempted from destruction 
         */
        public function actionretrieveClustersWhoseDocumentsCannotBeDestroyedAtDestruction(){
            
            $_id = $_REQUEST['platform_setting_id'];
            //$_id = 1;
             
             //get the logged in user
             $user_id = Yii::app()->user->id;   
             //get logged in user domain
             //$domain_id = $this->determineAUserDomainIdGiven($user_id);
             
             //get the domain of this domain policy
            // $domain_id = $this->getTheDomainOwnerOfThisPolicy($_id);
                      
       
             $criteria = new CDbCriteria();
             $criteria->select = '*';
             //$criteria->condition='domain_id=:domainid';
             //$criteria->params = array(':domainid'=>$domain_id);
             $result = Cluster::model()->findAll($criteria);   
           
             //get the selected documents that cannot be reassigned 
             $criteria2 = new CDbCriteria();
             $criteria2->select = '*';
             $criteria2->condition='platform_setting_id=:id';
             $criteria2->params = array(':id'=>$_id);
             $selected = ExemptedClusterForDestructionOnPlatform::model()->findAll($criteria2);
            
           
                if($result===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                         "success" => mysql_errno() == 0,
                            "selected" => $selected,
                            "data" => $result,
                       ));
                       
                }
            
            
        }
        
        
        /**
         * This is the function that retrieves all the processors whose documents were exempted from destruction 
         */
        public function actionretrieveProcessorsWhoseDocumentsCannotBeDestroyedAtDestruction(){
            
            $_id = $_REQUEST['platform_setting_id'];
            //$_id = 1;
             
             //get the logged in user
             $user_id = Yii::app()->user->id;   
             //get logged in user domain
             //$domain_id = $this->determineAUserDomainIdGiven($user_id);
             
             //get the domain of this domain policy
             //$domain_id = $this->getTheDomainOwnerOfThisPolicy($_id);
                      
       
             $criteria = new CDbCriteria();
             $criteria->select = '*';
            // $criteria->condition='domain_id=:domainid';
            // $criteria->params = array(':domainid'=>$domain_id);
             $result = User::model()->findAll($criteria);   
           
             //get the selected documents that cannot be reassigned 
             $criteria2 = new CDbCriteria();
             $criteria2->select = '*';
             $criteria2->condition='platform_setting_id=:id';
             $criteria2->params = array(':id'=>$_id);
             $selected = ExemptedProcessorForDestructionOnPlatform::model()->findAll($criteria2);
            
           
                if($result===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                         "success" => mysql_errno() == 0,
                            "selected" => $selected,
                            "data" => $result,
                       ));
                       
                }
            
            
        }
        
        
        
        /**
         * This is the function that retrieves all the document types whose documents were exempted from destruction 
         */
        public function actionretrieveTypesWhoseDocumentsCannotBeDestroyedAtDestruction(){
            
            $_id = $_REQUEST['platform_setting_id'];
            //$_id = 1;
             
             //get the logged in user
             $user_id = Yii::app()->user->id;   
             //get logged in user domain
             //$domain_id = $this->determineAUserDomainIdGiven($user_id);
             
             //get the domain of this domain policy
             //$domain_id = $this->getTheDomainOwnerOfThisPolicy($_id);
                      
       
             $criteria = new CDbCriteria();
             $criteria->select = '*';
            // $criteria->condition='domain_id=:domainid';
            // $criteria->params = array(':domainid'=>$domain_id);
             $result = Resourcetype::model()->findAll($criteria);   
           
             //get the selected documents that cannot be reassigned 
             $criteria2 = new CDbCriteria();
             $criteria2->select = '*';
             $criteria2->condition='platform_setting_id=:id';
             $criteria2->params = array(':id'=>$_id);
             $selected = ExemptedTypeForDestructionOnPlatform::model()->findAll($criteria2);
            
           
                if($result===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                         "success" => mysql_errno() == 0,
                            "selected" => $selected,
                            "data" => $result,
                       ));
                       
                }
            
            
        }
        
        
        
        /**
         * This is the function that retrieves all the destroyed documents that were retained at destruction 
         */
        public function actionretrieveRetainedDestroyedDocumentsAtDestruction(){
            
            $_id = $_REQUEST['platform_setting_id'];
            //$_id = 1;
             
             //get the logged in user
             $user_id = Yii::app()->user->id;   
             //get logged in user domain
             //$domain_id = $this->determineAUserDomainIdGiven($user_id);
             
             //get the domain of this domain policy
             //$domain_id = $this->getTheDomainOwnerOfThisPolicy($_id);
                      
       
             $criteria = new CDbCriteria();
             $criteria->select = '*';
             $criteria->condition='parent_id is not null';
            // $criteria->params = array(':domainid'=>$domain_id);
             $result = Resources::model()->findAll($criteria);   
           
             //get the selected documents that cannot be reassigned 
             $criteria2 = new CDbCriteria();
             $criteria2->select = '*';
             $criteria2->condition='platform_setting_id=:id';
             $criteria2->params = array(':id'=>$_id);
             $selected = RetainedDestroyedDocumentsOnPlatform::model()->findAll($criteria2);
            
           
                if($result===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                         "success" => mysql_errno() == 0,
                            "selected" => $selected,
                            "data" => $result,
                       ));
                       
                }
            
            
        }
        
        
        
         /**
         * This is the function that retrieves all the batches that must be moved or reassigned as a whole at movement 
         */
        public function actionretrieveBatchesThatCanOnlyBeReassignedOrMovedAsAWholeAtMovement(){
            
            $_id = $_REQUEST['platform_setting_id'];
            //$_id = 1;
             
             //get the logged in user
             $user_id = Yii::app()->user->id;   
             //get logged in user domain
             //$domain_id = $this->determineAUserDomainIdGiven($user_id);
             
             //get the domain of this domain policy
             //$domain_id = $this->getTheDomainOwnerOfThisPolicy($_id);
                      
       
             $criteria = new CDbCriteria();
             $criteria->select = '*';
             $criteria->condition='parent_id is null';
             //$criteria->params = array(':domainid'=>$domain_id);
             $result = Resources::model()->findAll($criteria);   
           
             //get the selected documents that cannot be reassigned 
             $criteria2 = new CDbCriteria();
             $criteria2->select = '*';
             $criteria2->condition='platform_setting_id=:id';
             $criteria2->params = array(':id'=>$_id);
             $selected = BatchesToBeMovedAsWholeOnPlatform::model()->findAll($criteria2);
            
           
                if($result===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                         "success" => mysql_errno() == 0,
                            "selected" => $selected,
                            "data" => $result,
                       ));
                       
                }
            
            
        }
        
        
        
        /**
         * This is the function that retrieves all the boxes & folders that must be moved or reassigned as a whole at movement 
         */
        public function actionretrieveBoxesThatCanOnlyBeReassignedOrMovedAsAWholeAtMovement(){
            
            $_id = $_REQUEST['platform_setting_id'];
            //$_id = 1;
             
             //get the logged in user
             $user_id = Yii::app()->user->id;   
             //get logged in user domain
             //$domain_id = $this->determineAUserDomainIdGiven($user_id);
             
             //get the domain of this domain policy
             //$domain_id = $this->getTheDomainOwnerOfThisPolicy($_id);
                      
       
             $criteria = new CDbCriteria();
             $criteria->select = '*';
           //  $criteria->condition='domain_id=:domainid';
             //$criteria->params = array(':domainid'=>$domain_id);
             $result = Resourcegroup::model()->findAll($criteria);   
           
             //get the selected documents that cannot be reassigned 
             $criteria2 = new CDbCriteria();
             $criteria2->select = '*';
             $criteria2->condition='platform_setting_id=:id';
             $criteria2->params = array(':id'=>$_id);
             $selected = BoxesToBeMovedAsWholeOnPlatform::model()->findAll($criteria2);
            
           
                if($result===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                         "success" => mysql_errno() == 0,
                            "selected" => $selected,
                            "data" => $result,
                       ));
                       
                }
            
            
        }
        
        
         /**
         * This is the function that retrieves all the document categories whose documents were exempted from destruction 
         */
        public function actionretrieveCategoriesWhoseDocumentsCannotBeDestroyedAtDestruction(){
            
            $_id = $_REQUEST['platform_setting_id'];
            //$_id = 1;
             
             //get the logged in user
             $user_id = Yii::app()->user->id;   
             //get logged in user domain
             //$domain_id = $this->determineAUserDomainIdGiven($user_id);
             
             //get the domain of this domain policy
             //$domain_id = $this->getTheDomainOwnerOfThisPolicy($_id);
                      
       
             $criteria = new CDbCriteria();
             $criteria->select = '*';
            // $criteria->condition='domain_id=:domainid';
            // $criteria->params = array(':domainid'=>$domain_id);
             $result = Products::model()->findAll($criteria);   
           
             //get the selected documents that cannot be reassigned 
             $criteria2 = new CDbCriteria();
             $criteria2->select = '*';
             $criteria2->condition='platform_setting_id=:id';
             $criteria2->params = array(':id'=>$_id);
             $selected = ExemptedCategoryForDestructionOnPlatform::model()->findAll($criteria2);
            
           
                if($result===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                         "success" => mysql_errno() == 0,
                            "selected" => $selected,
                            "data" => $result,
                       ));
                       
                }
            
            
        }
        
        
        
        /**
         * This is the function that retrieves all the document types whose electronic copy were to be retained after destruction 
         */
        public function actionretrieveTypesWhoseElectronicCopyBeRetainedAfterDestructionAtDestruction(){
            
            $_id = $_REQUEST['platform_setting_id'];
            //$_id = 1;
             
             //get the logged in user
             $user_id = Yii::app()->user->id;   
             //get logged in user domain
             //$domain_id = $this->determineAUserDomainIdGiven($user_id);
             
             //get the domain of this domain policy
             //$domain_id = $this->getTheDomainOwnerOfThisPolicy($_id);
                      
       
             $criteria = new CDbCriteria();
             $criteria->select = '*';
            // $criteria->condition='domain_id=:domainid';
            // $criteria->params = array(':domainid'=>$domain_id);
             $result = Resourcetype::model()->findAll($criteria);   
           
             //get the selected documents that cannot be reassigned 
             $criteria2 = new CDbCriteria();
             $criteria2->select = '*';
             $criteria2->condition='platform_setting_id=:id';
             $criteria2->params = array(':id'=>$_id);
             $selected = RetainElectronicTypeAfterDestructionOnPlatform::model()->findAll($criteria2);
            
           
                if($result===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                         "success" => mysql_errno() == 0,
                            "selected" => $selected,
                            "data" => $result,
                       ));
                       
                }
            
            
        }
        
        
         /**
         * This is the function that retrieves all the document categories whose electronic copy were to be retained after destruction 
         */
        public function actionretrieveCategoriesWhoseElectronicCopyBeRetainedAfterDestructionAtDestruction(){
            
            $_id = $_REQUEST['platform_setting_id'];
            //$_id = 1;
             
             //get the logged in user
             $user_id = Yii::app()->user->id;   
             //get logged in user domain
             //$domain_id = $this->determineAUserDomainIdGiven($user_id);
             
             //get the domain of this domain policy
             //$domain_id = $this->getTheDomainOwnerOfThisPolicy($_id);
                      
       
             $criteria = new CDbCriteria();
             $criteria->select = '*';
            // $criteria->condition='domain_id=:domainid';
            // $criteria->params = array(':domainid'=>$domain_id);
             $result = Products::model()->findAll($criteria);   
           
             //get the selected documents that cannot be reassigned 
             $criteria2 = new CDbCriteria();
             $criteria2->select = '*';
             $criteria2->condition='platform_setting_id=:id';
             $criteria2->params = array(':id'=>$_id);
             $selected = RetainElectronicCategoryAfterDestructionOnPlatform::model()->findAll($criteria2);
            
           
                if($result===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                         "success" => mysql_errno() == 0,
                            "selected" => $selected,
                            "data" => $result,
                       ));
                       
                }
            
            
        }
        
        
        /**
         * This is the function that retrieves all the document types that were exempted from global search after document destruction 
         */
        public function actionretrieveTypesWhoseDestroyedTypesWillHaveNoGlobalRequestAtDestruction(){
            
            $_id = $_REQUEST['platform_setting_id'];
            //$_id = 1;
             
             //get the logged in user
             $user_id = Yii::app()->user->id;   
             //get logged in user domain
             //$domain_id = $this->determineAUserDomainIdGiven($user_id);
             
             //get the domain of this domain policy
             //$domain_id = $this->getTheDomainOwnerOfThisPolicy($_id);
                      
       
             $criteria = new CDbCriteria();
             $criteria->select = '*';
            // $criteria->condition='domain_id=:domainid';
            // $criteria->params = array(':domainid'=>$domain_id);
             $result = Resourcetype::model()->findAll($criteria);   
           
             //get the selected documents that cannot be reassigned 
             $criteria2 = new CDbCriteria();
             $criteria2->select = '*';
             $criteria2->condition='platform_setting_id=:id';
             $criteria2->params = array(':id'=>$_id);
             $selected = ExemptedTypeFromGlobalRequestAfterDestructionOnPlatform::model()->findAll($criteria2);
            
           
                if($result===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                         "success" => mysql_errno() == 0,
                            "selected" => $selected,
                            "data" => $result,
                       ));
                       
                }
            
            
        }
        
        
        
        /**
         * This is the function that retrieves all the destroyed documents that cannot be accessed by all     */
        public function actionretrieveAllTheDestroyedDocumentsThatCannotBeAccessedByAllAtDestruction(){
            
            $_id = $_REQUEST['platform_setting_id'];
            //$_id = 1;
             
             //get the logged in user
             $user_id = Yii::app()->user->id;   
             //get logged in user domain
             //$domain_id = $this->determineAUserDomainIdGiven($user_id);
             
             //get the domain of this domain policy
             //$domain_id = $this->getTheDomainOwnerOfThisPolicy($_id);
                      
       
             $criteria = new CDbCriteria();
             $criteria->select = '*';
             $criteria->condition='parent_id is not null';
             //$criteria->params = array(':domainid'=>$domain_id);
             $result = Resources::model()->findAll($criteria);   
           
             //get the selected documents that cannot be reassigned 
             $criteria2 = new CDbCriteria();
             $criteria2->select = '*';
             $criteria2->condition='platform_setting_id=:id';
             $criteria2->params = array(':id'=>$_id);
             $selected = InaccessibleDestroyedDocumentsOnPlatform::model()->findAll($criteria2);
            
           
                if($result===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                         "success" => mysql_errno() == 0,
                            "selected" => $selected,
                            "data" => $result,
                       ));
                       
                }
            
            
        }
        
        
        
        
        /**
         * This is the function that retrieves all the neighbourhoods that could access destroyed documents on this domain 
         */
        public function actionretrieveNeighbourhoodsThatCouldAccessAllDestroyedDocumentAtDestruction(){
            
            $_id = $_REQUEST['platform_setting_id'];
            //$_id = 1;
             
             //get the logged in user
             $user_id = Yii::app()->user->id;   
             //get logged in user domain
             //$domain_id = $this->determineAUserDomainIdGiven($user_id);
             
             //get the domain of this domain policy
             //$domain_id = $this->getTheDomainOwnerOfThisPolicy($_id);
                      
       
             $criteria = new CDbCriteria();
             $criteria->select = '*';
             //$criteria->condition='domain_id=:domainid';
            // $criteria->params = array(':domainid'=>$domain_id);
             $result = Neighbourhood::model()->findAll($criteria);   
           
             //get the selected documents that cannot be reassigned 
             $criteria2 = new CDbCriteria();
             $criteria2->select = '*';
             $criteria2->condition='platform_setting_id=:id';
             $criteria2->params = array(':id'=>$_id);
             $selected = HoodPermittedToAccessDestroyedDocumentsOnPlatform::model()->findAll($criteria2);
            
           
                if($result===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                         "success" => mysql_errno() == 0,
                            "selected" => $selected,
                            "data" => $result,
                       ));
                       
                }
            
            
        }
        
        
        /**
         * This is the function that retrieves all the clusters that could access destroyed documents on this domain 
         */
        public function actionretrieveClustersThatCouldAccessAllDestroyedDocumentAtDestruction(){
            
            $_id = $_REQUEST['platform_setting_id'];
            //$_id = 1;
             
             //get the logged in user
             $user_id = Yii::app()->user->id;   
             //get logged in user domain
             //$domain_id = $this->determineAUserDomainIdGiven($user_id);
             
             //get the domain of this domain policy
            // $domain_id = $this->getTheDomainOwnerOfThisPolicy($_id);
                      
       
             $criteria = new CDbCriteria();
             $criteria->select = '*';
             //$criteria->condition='domain_id=:domainid';
             //$criteria->params = array(':domainid'=>$domain_id);
             $result = Cluster::model()->findAll($criteria);   
           
             //get the selected documents that cannot be reassigned 
             $criteria2 = new CDbCriteria();
             $criteria2->select = '*';
             $criteria2->condition='platform_setting_id=:id';
             $criteria2->params = array(':id'=>$_id);
             $selected = ClusterPermittedToAccessDestroyedDocumentsOnPlatform::model()->findAll($criteria2);
            
           
                if($result===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                         "success" => mysql_errno() == 0,
                            "selected" => $selected,
                            "data" => $result,
                       ));
                       
                }
            
            
        }
        
        
        
        /**
         * This is the function that retrieves all the blacklist applicable on the platform
         */
public function actionretrieveTheBlacklistsApplicableAtExchange(){
    
         $_id = $_REQUEST['platform_setting_id'];
            //$_id = 1;
             
             //get the logged in user
             $user_id = Yii::app()->user->id;   
             //get logged in user domain
             //$domain_id = $this->determineAUserDomainIdGiven($user_id);
             
             //get the domain of this domain policy
            // $domain_id = $this->getTheDomainOwnerOfThisPolicy($_id);
                      
       
             $criteria = new CDbCriteria();
             $criteria->select = '*';
             //$criteria->condition='domain_id=:domainid';
             //$criteria->params = array(':domainid'=>$domain_id);
             $result = Blacklist::model()->findAll($criteria);   
           
             //get the selected neighbourhoods with permission to add batches to this box
             $criteria2 = new CDbCriteria();
             $criteria2->select = '*';
             $criteria2->condition='platform_setting_id=:id';
             $criteria2->params = array(':id'=>$_id);
             $selected = BlacklistAtExchangeOnPlatform::model()->findAll($criteria2);
            
           
                if($result===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                         "success" => mysql_errno() == 0,
                            "selected" => $selected,
                            "data" => $result,
                       ));
                       
                }
    
}



 /**
         * This is the function that retrieves all the whitelist applicable on the platform
         */
public function actionretrieveTheWhitelistsApplicableAtExchange(){
    
         $_id = $_REQUEST['platform_setting_id'];
            //$_id = 1;
             
             //get the logged in user
             $user_id = Yii::app()->user->id;   
             //get logged in user domain
             //$domain_id = $this->determineAUserDomainIdGiven($user_id);
             
             //get the domain of this domain policy
            // $domain_id = $this->getTheDomainOwnerOfThisPolicy($_id);
                      
       
             $criteria = new CDbCriteria();
             $criteria->select = '*';
             //$criteria->condition='domain_id=:domainid';
             //$criteria->params = array(':domainid'=>$domain_id);
             $result = Whitelist::model()->findAll($criteria);   
           
             //get the selected neighbourhoods with permission to add batches to this box
             $criteria2 = new CDbCriteria();
             $criteria2->select = '*';
             $criteria2->condition='platform_setting_id=:id';
             $criteria2->params = array(':id'=>$_id);
             $selected = WhitelistAtExchangeOnPlatform::model()->findAll($criteria2);
            
           
                if($result===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                         "success" => mysql_errno() == 0,
                            "selected" => $selected,
                            "data" => $result,
                       ));
                       
                }
    
}


  //for document sharing blacklist and whitelist
 /**
         * This is the function that retrieves all the blacklist applicable on this domain during sharing
         */
public function actionretrieveTheBlacklistsApplicableAtSharing(){
    
         $_id = $_REQUEST['platform_setting_id'];
            //$_id = 1;
             
             //get the logged in user
             $user_id = Yii::app()->user->id;   
             //get logged in user domain
             //$domain_id = $this->determineAUserDomainIdGiven($user_id);
             
             //get the domain of this domain policy
             //$domain_id = $this->getTheDomainOwnerOfThisPolicy($_id);
                      
       
             $criteria = new CDbCriteria();
             $criteria->select = '*';
            // $criteria->condition='domain_id=:domainid';
            // $criteria->params = array(':domainid'=>$domain_id);
             $result = Blacklist::model()->findAll($criteria);   
           
             //get the selected neighbourhoods with permission to add batches to this box
             $criteria2 = new CDbCriteria();
             $criteria2->select = '*';
             $criteria2->condition='platform_setting_id=:id';
             $criteria2->params = array(':id'=>$_id);
             $selected = BlacklistAtSharingOnPlatform::model()->findAll($criteria2);
            
           
                if($result===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                         "success" => mysql_errno() == 0,
                            "selected" => $selected,
                            "data" => $result,
                       ));
                       
                }
    
}


 /**
         * This is the function that retrieves all the whitelist applicable on this domain during sharing
         */
public function actionretrieveTheWhitelistsApplicableAtSharing(){
    
         $_id = $_REQUEST['platform_setting_id'];
            //$_id = 1;
             
             //get the logged in user
             $user_id = Yii::app()->user->id;   
             //get logged in user domain
             //$domain_id = $this->determineAUserDomainIdGiven($user_id);
             
             //get the domain of this domain policy
             //$domain_id = $this->getTheDomainOwnerOfThisPolicy($_id);
                      
       
             $criteria = new CDbCriteria();
             $criteria->select = '*';
             //$criteria->condition='domain_id=:domainid';
             //$criteria->params = array(':domainid'=>$domain_id);
             $result = Whitelist::model()->findAll($criteria);   
           
             //get the selected neighbourhoods with permission to add batches to this box
             $criteria2 = new CDbCriteria();
             $criteria2->select = '*';
             $criteria2->condition='platform_setting_id=:id';
             $criteria2->params = array(':id'=>$_id);
             $selected = WhitelistAtSharingOnPlatform::model()->findAll($criteria2);
            
           
                if($result===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                         "success" => mysql_errno() == 0,
                            "selected" => $selected,
                            "data" => $result,
                       ));
                       
                }
    
}
        

//blacklist and whitelist at transfers


/**
         * This is the function that retrieves all the blacklist applicable on this domain during transfers
         */
public function actionretrieveTheBlacklistsApplicableAtTransfers(){
    
         $_id = $_REQUEST['platform_setting_id'];
            //$_id = 1;
             
             //get the logged in user
             $user_id = Yii::app()->user->id;   
             //get logged in user domain
             //$domain_id = $this->determineAUserDomainIdGiven($user_id);
             
             //get the domain of this domain policy
             //$domain_id = $this->getTheDomainOwnerOfThisPolicy($_id);
                      
       
             $criteria = new CDbCriteria();
             $criteria->select = '*';
             //$criteria->condition='domain_id=:domainid';
             //$criteria->params = array(':domainid'=>$domain_id);
             $result = Blacklist::model()->findAll($criteria);   
           
             //get the selected neighbourhoods with permission to add batches to this box
             $criteria2 = new CDbCriteria();
             $criteria2->select = '*';
             $criteria2->condition='platform_setting_id=:id';
             $criteria2->params = array(':id'=>$_id);
             $selected = BlacklistAtTransferOnPlatform::model()->findAll($criteria2);
            
           
                if($result===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                         "success" => mysql_errno() == 0,
                            "selected" => $selected,
                            "data" => $result,
                       ));
                       
                }
    
}


 /**
         * This is the function that retrieves all the whitelist applicable on this domain during transfers
         */
public function actionretrieveTheWhitelistsApplicableAtTransfers(){
    
         $_id = $_REQUEST['platform_setting_id'];
            //$_id = 1;
             
             //get the logged in user
             $user_id = Yii::app()->user->id;   
             //get logged in user domain
             //$domain_id = $this->determineAUserDomainIdGiven($user_id);
             
             //get the domain of this domain policy
            // $domain_id = $this->getTheDomainOwnerOfThisPolicy($_id);
                      
       
             $criteria = new CDbCriteria();
             $criteria->select = '*';
             //$criteria->condition='domain_id=:domainid';
            // $criteria->params = array(':domainid'=>$domain_id);
             $result = Whitelist::model()->findAll($criteria);   
           
             //get the selected neighbourhoods with permission to add batches to this box
             $criteria2 = new CDbCriteria();
             $criteria2->select = '*';
             $criteria2->condition='platform_setting_id=:id';
             $criteria2->params = array(':id'=>$_id);
             $selected = WhitelistAtTransferOnPlatform::model()->findAll($criteria2);
            
           
                if($result===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                         "success" => mysql_errno() == 0,
                            "selected" => $selected,
                            "data" => $result,
                       ));
                       
                }
    
}



//blacklist and whitelist at trading

/**
         * This is the function that retrieves all the blacklist applicable on this domain during tradings
         */
public function actionretrieveTheBlacklistsApplicableAtTradings(){
    
         $_id = $_REQUEST['platform_setting_id'];
            //$_id = 1;
             
             //get the logged in user
             $user_id = Yii::app()->user->id;   
             //get logged in user domain
             //$domain_id = $this->determineAUserDomainIdGiven($user_id);
             
             //get the domain of this domain policy
            // $domain_id = $this->getTheDomainOwnerOfThisPolicy($_id);
                      
       
             $criteria = new CDbCriteria();
             $criteria->select = '*';
             //$criteria->condition='domain_id=:domainid';
             //$criteria->params = array(':domainid'=>$domain_id);
             $result = Blacklist::model()->findAll($criteria);   
           
             //get the selected neighbourhoods with permission to add batches to this box
             $criteria2 = new CDbCriteria();
             $criteria2->select = '*';
             $criteria2->condition='platform_setting_id=:id';
             $criteria2->params = array(':id'=>$_id);
             $selected = BlacklistAtTradingOnPlatform::model()->findAll($criteria2);
            
           
                if($result===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                         "success" => mysql_errno() == 0,
                            "selected" => $selected,
                            "data" => $result,
                       ));
                       
                }
    
}


 /**
         * This is the function that retrieves all the whitelist applicable on this domain during tradings
         */
public function actionretrieveTheWhitelistsApplicableAtTradings(){
    
         $_id = $_REQUEST['platform_setting_id'];
            //$_id = 1;
             
             //get the logged in user
             $user_id = Yii::app()->user->id;   
             //get logged in user domain
             //$domain_id = $this->determineAUserDomainIdGiven($user_id);
             
             //get the domain of this domain policy
             //$domain_id = $this->getTheDomainOwnerOfThisPolicy($_id);
                      
       
             $criteria = new CDbCriteria();
             $criteria->select = '*';
           //  $criteria->condition='domain_id=:domainid';
            // $criteria->params = array(':domainid'=>$domain_id);
             $result = Whitelist::model()->findAll($criteria);   
           
             //get the selected neighbourhoods with permission to add batches to this box
             $criteria2 = new CDbCriteria();
             $criteria2->select = '*';
             $criteria2->condition='platform_setting_id=:id';
             $criteria2->params = array(':id'=>$_id);
             $selected = WhitelistAtTradingOnPlatform::model()->findAll($criteria2);
            
           
                if($result===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                         "success" => mysql_errno() == 0,
                            "selected" => $selected,
                            "data" => $result,
                       ));
                       
                }
    
}


//blacklist and whitelist at request


/**
         * This is the function that retrieves all the blacklist applicable on this domain during request
         */
public function actionretrieveTheBlacklistsApplicableAtRequest(){
    
         $_id = $_REQUEST['platform_setting_id'];
            //$_id = 1;
             
             //get the logged in user
             $user_id = Yii::app()->user->id;   
             //get logged in user domain
             //$domain_id = $this->determineAUserDomainIdGiven($user_id);
             
             //get the domain of this domain policy
            // $domain_id = $this->getTheDomainOwnerOfThisPolicy($_id);
                      
       
             $criteria = new CDbCriteria();
             $criteria->select = '*';
            // $criteria->condition='domain_id=:domainid';
           //  $criteria->params = array(':domainid'=>$domain_id);
             $result = Blacklist::model()->findAll($criteria);   
           
             //get the selected neighbourhoods with permission to add batches to this box
             $criteria2 = new CDbCriteria();
             $criteria2->select = '*';
             $criteria2->condition='platform_setting_id=:id';
             $criteria2->params = array(':id'=>$_id);
             $selected = BlacklistAtRequestOnPlatform::model()->findAll($criteria2);
            
           
                if($result===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                         "success" => mysql_errno() == 0,
                            "selected" => $selected,
                            "data" => $result,
                       ));
                       
                }
    
}


 /**
         * This is the function that retrieves all the whitelist applicable on this domain during request
         */
public function actionretrieveTheWhitelistsApplicableAtRequest(){
    
         $_id = $_REQUEST['platform_setting_id'];
            //$_id = 1;
             
             //get the logged in user
             $user_id = Yii::app()->user->id;   
             //get logged in user domain
             //$domain_id = $this->determineAUserDomainIdGiven($user_id);
             
             //get the domain of this domain policy
            // $domain_id = $this->getTheDomainOwnerOfThisPolicy($_id);
                      
       
             $criteria = new CDbCriteria();
             $criteria->select = '*';
            // $criteria->condition='domain_id=:domainid';
            // $criteria->params = array(':domainid'=>$domain_id);
             $result = Whitelist::model()->findAll($criteria);   
           
             //get the selected neighbourhoods with permission to add batches to this box
             $criteria2 = new CDbCriteria();
             $criteria2->select = '*';
             $criteria2->condition='platform_setting_id=:id';
             $criteria2->params = array(':id'=>$_id);
             $selected = WhitelistAtRequestOnPlatform::model()->findAll($criteria2);
            
           
                if($result===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                         "success" => mysql_errno() == 0,
                            "selected" => $selected,
                            "data" => $result,
                       ));
                       
                }
    
}



//blacklist and whitelist at consumption


/**
         * This is the function that retrieves all the blacklist applicable on this domain during consumption
         */
public function actionretrieveTheBlacklistsApplicableAtConsumption(){
    
         $_id = $_REQUEST['platform_setting_id'];
            //$_id = 1;
             
             //get the logged in user
             $user_id = Yii::app()->user->id;   
             //get logged in user domain
             //$domain_id = $this->determineAUserDomainIdGiven($user_id);
             
             //get the domain of this domain policy
             //$domain_id = $this->getTheDomainOwnerOfThisPolicy($_id);
                      
       
             $criteria = new CDbCriteria();
             $criteria->select = '*';
             //$criteria->condition='domain_id=:domainid';
             //$criteria->params = array(':domainid'=>$domain_id);
             $result = Blacklist::model()->findAll($criteria);   
           
             //get the selected neighbourhoods with permission to add batches to this box
             $criteria2 = new CDbCriteria();
             $criteria2->select = '*';
             $criteria2->condition='platform_setting_id=:id';
             $criteria2->params = array(':id'=>$_id);
             $selected = BlacklistAtConsumptionOnPlatform::model()->findAll($criteria2);
            
           
                if($result===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                         "success" => mysql_errno() == 0,
                            "selected" => $selected,
                            "data" => $result,
                       ));
                       
                }
    
}


 /**
         * This is the function that retrieves all the whitelist applicable on this domain during consumption
         */
public function actionretrieveTheWhitelistsApplicableAtConsumption(){
    
         $_id = $_REQUEST['platform_setting_id'];
            //$_id = 1;
             
             //get the logged in user
             $user_id = Yii::app()->user->id;   
             //get logged in user domain
             //$domain_id = $this->determineAUserDomainIdGiven($user_id);
             
             //get the domain of this domain policy
             //$domain_id = $this->getTheDomainOwnerOfThisPolicy($_id);
                      
       
             $criteria = new CDbCriteria();
             $criteria->select = '*';
            // $criteria->condition='domain_id=:domainid';
            // $criteria->params = array(':domainid'=>$domain_id);
             $result = Whitelist::model()->findAll($criteria);   
           
             //get the selected neighbourhoods with permission to add batches to this box
             $criteria2 = new CDbCriteria();
             $criteria2->select = '*';
             $criteria2->condition='platform_setting_id=:id';
             $criteria2->params = array(':id'=>$_id);
             $selected = WhitelistAtConsumptionOnPlatform::model()->findAll($criteria2);
            
           
                if($result===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                         "success" => mysql_errno() == 0,
                            "selected" => $selected,
                            "data" => $result,
                       ));
                       
                }
    
}


//blacklist and whitelist at movement


/**
         * This is the function that retrieves all the blacklist applicable on this domain during movement
         */
public function actionretrieveTheBlacklistsApplicableAtMovement(){
    
         $_id = $_REQUEST['platform_setting_id'];
            //$_id = 1;
             
             //get the logged in user
             $user_id = Yii::app()->user->id;   
             //get logged in user domain
             //$domain_id = $this->determineAUserDomainIdGiven($user_id);
             
             //get the domain of this domain policy
             //$domain_id = $this->getTheDomainOwnerOfThisPolicy($_id);
                      
       
             $criteria = new CDbCriteria();
             $criteria->select = '*';
             //$criteria->condition='domain_id=:domainid';
             //$criteria->params = array(':domainid'=>$domain_id);
             $result = Blacklist::model()->findAll($criteria);   
           
             //get the selected neighbourhoods with permission to add batches to this box
             $criteria2 = new CDbCriteria();
             $criteria2->select = '*';
             $criteria2->condition='platform_setting_id=:id';
             $criteria2->params = array(':id'=>$_id);
             $selected = BlacklistAtMovementOnPlatform::model()->findAll($criteria2);
            
           
                if($result===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                         "success" => mysql_errno() == 0,
                            "selected" => $selected,
                            "data" => $result,
                       ));
                       
                }
    
}


 /**
         * This is the function that retrieves all the whitelist applicable on this domain during movement
         */
public function actionretrieveTheWhitelistsApplicableAtMovement(){
    
         $_id = $_REQUEST['platform_setting_id'];
            //$_id = 1;
             
             //get the logged in user
             $user_id = Yii::app()->user->id;   
             //get logged in user domain
             //$domain_id = $this->determineAUserDomainIdGiven($user_id);
             
             //get the domain of this domain policy
             //$domain_id = $this->getTheDomainOwnerOfThisPolicy($_id);
                      
       
             $criteria = new CDbCriteria();
             $criteria->select = '*';
             //$criteria->condition='domain_id=:domainid';
             //$criteria->params = array(':domainid'=>$domain_id);
             $result = Whitelist::model()->findAll($criteria);   
           
             //get the selected neighbourhoods with permission to add batches to this box
             $criteria2 = new CDbCriteria();
             $criteria2->select = '*';
             $criteria2->condition='platform_setting_id=:id';
             $criteria2->params = array(':id'=>$_id);
             $selected = WhitelistAtMovementOnPlatform::model()->findAll($criteria2);
            
           
                if($result===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                         "success" => mysql_errno() == 0,
                            "selected" => $selected,
                            "data" => $result,
                       ));
                       
                }
    
}


//blacklist amd whitelist at destruction


/**
         * This is the function that retrieves all the blacklist applicable on this domain during destruction
         */
public function actionretrieveTheBlacklistsApplicableAtDestruction(){
    
         $_id = $_REQUEST['platform_setting_id'];
            //$_id = 1;
             
             //get the logged in user
             $user_id = Yii::app()->user->id;   
             //get logged in user domain
             //$domain_id = $this->determineAUserDomainIdGiven($user_id);
             
             //get the domain of this domain policy
            // $domain_id = $this->getTheDomainOwnerOfThisPolicy($_id);
                      
       
             $criteria = new CDbCriteria();
             $criteria->select = '*';
             //$criteria->condition='domain_id=:domainid';
            // $criteria->params = array(':domainid'=>$domain_id);
             $result = Blacklist::model()->findAll($criteria);   
           
             //get the selected neighbourhoods with permission to add batches to this box
             $criteria2 = new CDbCriteria();
             $criteria2->select = '*';
             $criteria2->condition='platform_setting_id=:id';
             $criteria2->params = array(':id'=>$_id);
             $selected = BlacklistAtDestructionOnPlatform::model()->findAll($criteria2);
            
           
                if($result===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                         "success" => mysql_errno() == 0,
                            "selected" => $selected,
                            "data" => $result,
                       ));
                       
                }
    
}


 /**
         * This is the function that retrieves all the whitelist applicable on this domain during destruction
         */
public function actionretrieveTheWhitelistsApplicableAtDestruction(){
    
         $_id = $_REQUEST['platform_setting_id'];
            //$_id = 1;
             
             //get the logged in user
             $user_id = Yii::app()->user->id;   
             //get logged in user domain
             //$domain_id = $this->determineAUserDomainIdGiven($user_id);
             
             //get the domain of this domain policy
             //$domain_id = $this->getTheDomainOwnerOfThisPolicy($_id);
                      
       
             $criteria = new CDbCriteria();
             $criteria->select = '*';
           //  $criteria->condition='domain_id=:domainid';
          //   $criteria->params = array(':domainid'=>$domain_id);
             $result = Whitelist::model()->findAll($criteria);   
           
             //get the selected neighbourhoods with permission to add batches to this box
             $criteria2 = new CDbCriteria();
             $criteria2->select = '*';
             $criteria2->condition='platform_setting_id=:id';
             $criteria2->params = array(':id'=>$_id);
             $selected = WhitelistAtDestructionOnPlatform::model()->findAll($criteria2);
            
           
                if($result===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                         "success" => mysql_errno() == 0,
                            "selected" => $selected,
                            "data" => $result,
                       ));
                       
                }
    
}


        
        
        
        /**
         * This is the function that selects the neighbourhoods permitted for platform box request
         * 
         */
        
        
        public function actionAddPermittedNeighbourhoodsForBoxesOnPlatform(){
            
            //get the domain policy id
            
            $platform_setting_id = $_POST['id'];
            
                      
            //delete all the infomation about this domain policy on the lookup table
           $cmd =Yii::app()->db->createCommand();  
           $cmd->delete('neighbourhood_for_boxes_request_on_platform', 'platform_setting_id=:id', array(':id'=>$platform_setting_id));
           
           //insert the new selected neighbourhood values
           
           $counter = 0;
           if(isset($_POST['hood'])){
               foreach($_POST['hood'] as $hood){
                 $cmd =Yii::app()->db->createCommand();  
                $cmd->insert('neighbourhood_for_boxes_request_on_platform',
                	array('platform_setting_id'=>$platform_setting_id,
				'hood_id'=>$hood,
				 'create_time'=>new CDbExpression('NOW()'),
                                 'update_time'=>new CDbExpression('NOW()'),
                                  'created_by'=>Yii::app()->user->id,
                                    'updated_by'=>Yii::app()->user->id,
					
					
			));
                
             $counter = $counter + 1;
            }
           $msg = "Members of the selected neighbourhood(s) will be permitted to request for boxes & folders on this platform";
              header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                           "msg"=>$msg
                       ));
            
               
           }else{
               $msg = "There will be no selected neighbourhood(s) will only be permitted to request for boxes & folders on this platform";
              header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                           "msg"=>$msg
                       ));
               
           }
            
            
        }
        
        
        
               
        
        /**
         * This is the function that selects the clusters permitted for platform box request
         * 
         */
        
        
        public function actionAddPermittedClustersForBoxesOnPlatform(){
            
            //get the domain policy id
            
            $platform_setting_id = $_POST['id'];
            
                      
            //delete all the infomation about this domain policy on the lookup table
           $cmd =Yii::app()->db->createCommand();  
           $cmd->delete('cluster_for_boxes_request_on_platform', 'platform_setting_id=:id', array(':id'=>$platform_setting_id));
           
           //insert the new selected cluster values
           
           $counter = 0;
           if(isset($_POST['cluster'])){
               foreach($_POST['cluster'] as $cluster){
                 $cmd =Yii::app()->db->createCommand();  
                $cmd->insert('cluster_for_boxes_request_on_platform',
                	array('platform_setting_id'=>$platform_setting_id,
				'cluster_id'=>$cluster,
				 'create_time'=>new CDbExpression('NOW()'),
                                 'update_time'=>new CDbExpression('NOW()'),
                                  'created_by'=>Yii::app()->user->id,
                                    'updated_by'=>Yii::app()->user->id,
					
					
			));
                
             $counter = $counter + 1;
            }
           $msg = "Members of the selected cluster(s) will be permitted to request for all boxes & folders on this platform";
              header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                           "msg"=>$msg
                       ));
               
           }else{
                $msg = "There wil be no selected cluster(s) will only be permitted to request for all boxes & folders on this platform";
              header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                           "msg"=>$msg
                       ));
               
           }
            
            
            
        }
        
    
        
        
        /**
         * This is the function that enrols the clusters permitted for document capturing 
         */
        public function actionAddPermittedClustersForDocumentCaputuringOnPlatform(){
            
             //get the domain policy id
            
            $platform_setting_id = $_POST['id'];
            
                      
            //delete all the infomation about this domain policy on the lookup table
           $cmd =Yii::app()->db->createCommand();  
           $cmd->delete('cluster_for_document_capturing_on_platform', 'platform_setting_id=:id', array(':id'=>$platform_setting_id));
           
           //insert the new selected cluster values
           
           $counter = 0;
           if(isset($_POST['cluster'])){
               foreach($_POST['cluster'] as $cluster){
                 $cmd =Yii::app()->db->createCommand();  
                $cmd->insert('cluster_for_document_capturing_on_platform',
                	array('platform_setting_id'=>$platform_setting_id,
				'cluster_id'=>$cluster,
				 'create_time'=>new CDbExpression('NOW()'),
                                 'update_time'=>new CDbExpression('NOW()'),
                                  'created_by'=>Yii::app()->user->id,
                                    'updated_by'=>Yii::app()->user->id,
					
					
			));
                
             $counter = $counter + 1;
            }
           $msg = "Members of the selected cluster(s) will be permitted to capture documents on this platform";
              header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                           "msg"=>$msg
                       ));
               
           }else{
               
               $msg = "There are no selected cluster(s) that will only be permitted to capture documents on this platform";
              header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                           "msg"=>$msg
                       ));
               
           }
            
            
        }
        
        
        /**
         * This is the function that adds the document types that will determine the batches & files taht could be acceptable in a box & folder
         */
        public function actionAddDocumentTypesThatAreAcceptableToBatchesInBoxesOnPlatform(){
            
             //get the domain policy id
            
            $platform_setting_id = $_POST['id'];
            
                      
            //delete all the infomation about this domain policy on the lookup table
           $cmd =Yii::app()->db->createCommand();  
           $cmd->delete('accept_batches_of_doctypes_on_platform', 'platform_setting_id=:id', array(':id'=>$platform_setting_id));
           
           //insert the new selected document types values
           
           $counter = 0;
           if(isset($_POST['types'])){
               foreach($_POST['types'] as $type){
                 $cmd =Yii::app()->db->createCommand();  
                $cmd->insert('accept_batches_of_doctypes_on_platform',
                	array('platform_setting_id'=>$platform_setting_id,
				'type_id'=>$type,
				 'create_time'=>new CDbExpression('NOW()'),
                                 'update_time'=>new CDbExpression('NOW()'),
                                  'created_by'=>Yii::app()->user->id,
                                    'updated_by'=>Yii::app()->user->id,
					
					
			));
                
             $counter = $counter + 1;
            }
           $msg = "These document types will determine the batches & files that will be accepted in a box on this platform";
              header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                           "msg"=>$msg
                       ));
               
               
           }else{
               
               $msg = "There are no document types that will determine the batches & files that will be accepted in a box on this platform";
              header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                           "msg"=>$msg
                       ));
               
           }
            
            
        }
        
        
         /**
         * This is the function that adds the document categories that will determine the batches & files taht could be acceptable in a box & folder
         */
        public function actionAddDocumentCategoriesThatAreAcceptableToBatchesInBoxesOnPlatform(){
            
             //get the domain policy id
            
            $platform_setting_id = $_POST['id'];
            
                      
            //delete all the infomation about this domain policy on the lookup table
           $cmd =Yii::app()->db->createCommand();  
           $cmd->delete('accept_batches_of_doccategories_on_platform', 'platform_setting_id=:id', array(':id'=>$platform_setting_id));
           
           //insert the new selected document category values
           
           $counter = 0;
            if(isset($_POST['categories'])){
                
                foreach($_POST['categories'] as $category){
                 $cmd =Yii::app()->db->createCommand();  
                $cmd->insert('accept_batches_of_doccategories_on_platform',
                	array('platform_setting_id'=>$platform_setting_id,
				'category_id'=>$category,
				 'create_time'=>new CDbExpression('NOW()'),
                                 'update_time'=>new CDbExpression('NOW()'),
                                  'created_by'=>Yii::app()->user->id,
                                    'updated_by'=>Yii::app()->user->id,
					
					
			));
                
             $counter = $counter + 1;
            }
           $msg = "These document categories will determine the batches & files that will be accepted in a box on this platform";
              header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                           "msg"=>$msg
                       ));
                
            }else{
                $msg = "There are no document categories to determine the batches & files that will be accepted in a box on this platform";
              header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                           "msg"=>$msg
                       ));
                
            }
            
        }
        
        
        /**
         * This is the function that adds the neighbourhoods with the permission to collect boxes & folders on request
         */
        public function actionAddNeighbourhoodsWithPermissionToCollectBoxesOnPlatform(){
            
            //get the domain policy id
            
            $platform_setting_id = $_POST['id'];
            
                      
            //delete all the infomation about this domain policy on the lookup table
           $cmd =Yii::app()->db->createCommand();  
           $cmd->delete('neighbourhood_to_consume_boxes_on_platform', 'platform_setting_id=:id', array(':id'=>$platform_setting_id));
           
           //insert the new selected neighbourhood values
           
           $counter = 0;
           if(isset($_POST['hoods'])){
               foreach($_POST['hoods'] as $hood){
                 $cmd =Yii::app()->db->createCommand();  
                $cmd->insert('neighbourhood_to_consume_boxes_on_platform',
                	array('platform_setting_id'=>$platform_setting_id,
				'hood_id'=>$hood,
				 'create_time'=>new CDbExpression('NOW()'),
                                 'update_time'=>new CDbExpression('NOW()'),
                                  'created_by'=>Yii::app()->user->id,
                                    'updated_by'=>Yii::app()->user->id,
					
					
			));
                
             $counter = $counter + 1;
            }
           $msg = "The members of these neighbourhoods are permitted to consume boxes & folders belonging to this platform";
              header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                           "msg"=>$msg
                       ));
               
           }else{
               $msg = "There are no neighbourhods that are permitted to consume boxes & folders belonging to this platform";
              header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                           "msg"=>$msg
                       ));
               
           }
            
            
            
        }
        
        
        
        
         /**
         * This is the function that adds the clusters with the permission to collect boxes & folders on request
         */
        public function actionAddClustersWithPermissionToCollectBoxesOnPlatform(){
            
            //get the domain policy id
            
            $platform_setting_id = $_POST['id'];
            
                      
            //delete all the infomation about this domain policy on the lookup table
           $cmd =Yii::app()->db->createCommand();  
           $cmd->delete('cluster_to_consume_boxes_on_platform', 'platform_setting_id=:id', array(':id'=>$platform_setting_id));
           
           //insert the new selected cluster values
           
           $counter = 0;
           if(isset($_POST['clusters'])){
               foreach($_POST['clusters'] as $cluster){
                 $cmd =Yii::app()->db->createCommand();  
                $cmd->insert('cluster_to_consume_boxes_on_platform',
                	array('platform_setting_id'=>$platform_setting_id,
				'cluster_id'=>$cluster,
				 'create_time'=>new CDbExpression('NOW()'),
                                 'update_time'=>new CDbExpression('NOW()'),
                                  'created_by'=>Yii::app()->user->id,
                                    'updated_by'=>Yii::app()->user->id,
					
					
			));
                
             $counter = $counter + 1;
            }
           $msg = "The members of these cluster(s) are  permitted to consume boxes & folders belonging to this platform";
              header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                           "msg"=>$msg
                       ));
               
           }else{
               
              $msg = "There are no clusters that are permitted to consume boxes & folders belonging to this platform";
              header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                           "msg"=>$msg
                       ));
               
           }
            
            
            
        }
        
        
         /**
         * This is the function that adds document types that are available for exchange
          * 
          */
        public function actionAddDocumentTypesThatAreAvailableForExchangeOnPlatform(){
            
            //get the domain policy id
            
            $platform_setting_id = $_POST['id'];
            
                      
            //delete all the infomation about this domain policy on the lookup table
           $cmd =Yii::app()->db->createCommand();  
           $cmd->delete('documenttypes_available_for_exchanges_on_platform', 'platform_setting_id=:id', array(':id'=>$platform_setting_id));
           
           //insert the new selected document types values
           
           $counter = 0;
           if(isset($_POST['types'])){
               foreach($_POST['types'] as $type){
                 $cmd =Yii::app()->db->createCommand();  
                $cmd->insert('documenttypes_available_for_exchanges_on_platform',
                	array('platform_setting_id'=>$platform_setting_id,
				'type_id'=>$type,
				 'create_time'=>new CDbExpression('NOW()'),
                                 'update_time'=>new CDbExpression('NOW()'),
                                  'created_by'=>Yii::app()->user->id,
                                    'updated_by'=>Yii::app()->user->id,
					
					
			));
                
             $counter = $counter + 1;
            }
           $msg = "These document types will be available for exchange on this platform";
              header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                           "msg"=>$msg
                       ));
               
               
           }else{
               
               $msg = "There are no document types available for exchange on the platform";
              header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                           "msg"=>$msg
                       ));
               
           }
            
        }
        
        
        /**
         * This is the function that adds the neighbourhoods that restrict document type exchange
         */
        public function actionAddDocumentTypesRestrictedToNeighbourhoodsAtExchangeOnPlatform(){
            
            //get the domain policy id
            
            $platform_setting_id = $_POST['id'];
            
                      
            //delete all the infomation about this domain policy on the lookup table
           $cmd =Yii::app()->db->createCommand();  
           $cmd->delete('exchanges_restricted_to_neighbourhoods_on_platform', 'platform_setting_id=:id', array(':id'=>$platform_setting_id));
           
           //insert the new selected neighbourhood values
           
           $counter = 0;
           if(isset($_POST['hoods'])){
               foreach($_POST['hoods'] as $hood){
                 $cmd =Yii::app()->db->createCommand();  
                $cmd->insert('exchanges_restricted_to_neighbourhoods_on_platform',
                	array('platform_setting_id'=>$platform_setting_id,
				'hood_id'=>$hood,
				 'create_time'=>new CDbExpression('NOW()'),
                                 'update_time'=>new CDbExpression('NOW()'),
                                  'created_by'=>Yii::app()->user->id,
                                    'updated_by'=>Yii::app()->user->id,
					
					
			));
                
             $counter = $counter + 1;
            }
           $msg = "Exchange of documents are restricted to these selected neighbourhoods on this platform";
              header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                           "msg"=>$msg
                       ));
               
           }else{
               $msg = "There are no neighbourhoods that restricts the exchange of documents on this platform";
              header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                           "msg"=>$msg
                       ));
               
           }
            
        }
        
 /**
  * This is the function that restricts the exchange of documents to clusters
  */
        public function actionAddDocumentTypesRestrictedToClustersAtExchangeOnPlatform(){
            
            //get the domain policy id
            
            $platform_setting_id = $_POST['id'];
            
                      
            //delete all the infomation about this domain policy on the lookup table
           $cmd =Yii::app()->db->createCommand();  
           $cmd->delete('exchanges_restricted_to_clusters_on_platform', 'platform_setting_id=:id', array(':id'=>$platform_setting_id));
           
           //insert the new selected cluster values
           
           $counter = 0;
           if(isset($_POST['clusters'])){
               foreach($_POST['clusters'] as $cluster){
                 $cmd =Yii::app()->db->createCommand();  
                $cmd->insert('exchanges_restricted_to_clusters_on_platform',
                	array('platform_setting_id'=>$platform_setting_id,
				'cluster_id'=>$cluster,
				 'create_time'=>new CDbExpression('NOW()'),
                                 'update_time'=>new CDbExpression('NOW()'),
                                  'created_by'=>Yii::app()->user->id,
                                    'updated_by'=>Yii::app()->user->id,
					
					
			));
                
             $counter = $counter + 1;
            }
           $msg = "Exchange of documents are restricted to these selected clusters on this platform";
              header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                           "msg"=>$msg
                       ));
               
           }else{
               
              $msg = "There are no clusters that restricts the exchange of documents on this platform";
              header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                           "msg"=>$msg
                       ));
               
           }
            
            
        }
        
        
      //docunent sharing policy module
        
         /**
 * This is the function that restricts the sharing of documents to neighbourhoods
 */
 public function actionAddDocumentTypeRestrictedToNeighbourhoodsAtSharingOnPlatform(){
     
      //get the domain policy id
            
            $platform_setting_id = $_POST['id'];
            
                      
            //delete all the infomation about this domain policy on the lookup table
           $cmd =Yii::app()->db->createCommand();  
           $cmd->delete('sharing_restricted_to_neighbourhoods_on_platform', 'platform_setting_id=:id', array(':id'=>$platform_setting_id));
           
           //insert the new selected neighbourhood values
           
           $counter = 0;
           if(isset($_POST['hoods'])){
               foreach($_POST['hoods'] as $hood){
                 $cmd =Yii::app()->db->createCommand();  
                $cmd->insert('sharing_restricted_to_neighbourhoods_on_platform',
                	array('platform_setting_id'=>$platform_setting_id,
				'hood_id'=>$hood,
				 'create_time'=>new CDbExpression('NOW()'),
                                 'update_time'=>new CDbExpression('NOW()'),
                                  'created_by'=>Yii::app()->user->id,
                                    'updated_by'=>Yii::app()->user->id,
					
					
			));
                
             $counter = $counter + 1;
            }
           $msg = "Sharing of documents are restricted to these selected neighbourhoods on this platform";
              header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                           "msg"=>$msg
                       ));
               
           }else{
               
                $msg = "There are no neighbourhoods that restricts the sharing of documents on this platform";
              header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                           "msg"=>$msg
                       ));
               
           }
            
 }   
 
 
 
 
 /**
  * This is the function that restricts the sharing of documents to clusters
  */
 public function actionAddDocumentTypeRestrictedToClustersAtSharingOnPlatform(){
     
     //get the domain policy id
            
            $platform_setting_id = $_POST['id'];
            
                      
            //delete all the infomation about this domain policy on the lookup table
           $cmd =Yii::app()->db->createCommand();  
           $cmd->delete('sharing_restricted_to_clusters_on_platform', 'platform_setting_id=:id', array(':id'=>$platform_setting_id));
           
           //insert the new selected neighbourhood values
           
           $counter = 0;
            if(isset($_POST['clusters'])){
                foreach($_POST['clusters'] as $cluster){
                 $cmd =Yii::app()->db->createCommand();  
                $cmd->insert('sharing_restricted_to_clusters_on_platform',
                	array('platform_setting_id'=>$platform_setting_id,
				'cluster_id'=>$cluster,
				 'create_time'=>new CDbExpression('NOW()'),
                                 'update_time'=>new CDbExpression('NOW()'),
                                  'created_by'=>Yii::app()->user->id,
                                    'updated_by'=>Yii::app()->user->id,
					
					
			));
                
             $counter = $counter + 1;
            }
           $msg = "Sharing of documents are restricted to these selected clusters on this platform";
              header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                           "msg"=>$msg
                       ));
                
            }else{
              $msg = "There are no clusters that restricts the sharing of documents on this platform";
              header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                           "msg"=>$msg
                       ));
                
            }
     
 }
 
 
 
 
  /**
         * This is the function that adds document types that are available for exchange
         */
        public function actionAddDocumentTypesThatAreAvailableForSharingOnPlatform(){
            
             //get the domain policy id
            
            $platform_setting_id = $_POST['id'];
            
                      
            //delete all the infomation about this domain policy on the lookup table
           $cmd =Yii::app()->db->createCommand();  
           $cmd->delete('documenttypes_available_for_sharing_on_platform', 'platform_setting_id=:id', array(':id'=>$platform_setting_id));
           
           //insert the new selected neighbourhood values
           
           $counter = 0;
           if(isset($_POST['types'])){
                foreach($_POST['types'] as $type){
                 $cmd =Yii::app()->db->createCommand();  
                $cmd->insert('documenttypes_available_for_sharing_on_platform',
                	array('platform_setting_id'=>$platform_setting_id,
				'type_id'=>$type,
				 'create_time'=>new CDbExpression('NOW()'),
                                 'update_time'=>new CDbExpression('NOW()'),
                                  'created_by'=>Yii::app()->user->id,
                                    'updated_by'=>Yii::app()->user->id,
					
					
			));
                
             $counter = $counter + 1;
            }
           $msg = "These document types will be available for sharing on this platform";
              header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                           "msg"=>$msg
                       ));
               
           }else{
               
                $msg = "There will be no document types available for sharing on this platform";
              header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                           "msg"=>$msg
                       ));
           }
            
            
        }
        
        
       //for transfers policy module
        
         /**
 * This is the function that restricts the transfers of documents to neighbourhoods
 */
 public function actionAddDocumentTypesThatAreRestrictedToNeighbourhoodsAtTransfersOnPlatform(){
     
      //get the domain policy id
            
            $platform_setting_id = $_POST['id'];
            
                      
            //delete all the infomation about this domain policy on the lookup table
           $cmd =Yii::app()->db->createCommand();  
           $cmd->delete('transfer_restricted_to_neighbourhoods_on_platform', 'platform_setting_id=:id', array(':id'=>$platform_setting_id));
           
           //insert the new selected neighbourhood values
           
           $counter = 0;
           if(isset($_POST['hoods'])){
               foreach($_POST['hoods'] as $hood){
                 $cmd =Yii::app()->db->createCommand();  
                $cmd->insert('transfer_restricted_to_neighbourhoods_on_platform',
                	array('platform_setting_id'=>$platform_setting_id,
				'hood_id'=>$hood,
				 'create_time'=>new CDbExpression('NOW()'),
                                 'update_time'=>new CDbExpression('NOW()'),
                                  'created_by'=>Yii::app()->user->id,
                                    'updated_by'=>Yii::app()->user->id,
					
					
			));
                
             $counter = $counter + 1;
            }
           $msg = "Transfer of documents are restricted to these selected neighbourhoods on this platform";
              header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                           "msg"=>$msg
                       ));
               
           }else{
               
                $msg = "There are no neighbourhoods that restricts the transfer of documents on this platform";
              header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                           "msg"=>$msg
                       ));
               
           }
            
 }   
 
 
 
 
 /**
  * This is the function that restricts the sharing of documents to clusters
  */
 public function actionAddDocumentTypesThatAreRestrictedToClustersAtTransfersOnPlatform(){
     
     //get the domain policy id
            
            $platform_setting_id = $_POST['id'];
            
                      
            //delete all the infomation about this domain policy on the lookup table
           $cmd =Yii::app()->db->createCommand();  
           $cmd->delete('transfer_restricted_to_clusters_on_platform', 'platform_setting_id=:id', array(':id'=>$platform_setting_id));
           
           //insert the new selected neighbourhood values
           
           $counter = 0;
            if(isset($_POST['clusters'])){
                foreach($_POST['clusters'] as $cluster){
                 $cmd =Yii::app()->db->createCommand();  
                $cmd->insert('transfer_restricted_to_clusters_on_platform',
                	array('platform_setting_id'=>$platform_setting_id,
				'cluster_id'=>$cluster,
				 'create_time'=>new CDbExpression('NOW()'),
                                 'update_time'=>new CDbExpression('NOW()'),
                                  'created_by'=>Yii::app()->user->id,
                                    'updated_by'=>Yii::app()->user->id,
					
					
			));
                
             $counter = $counter + 1;
            }
           $msg = "Transfer of documents are restricted to these selected clusters on this platform";
              header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                           "msg"=>$msg
                       ));
                
            }else{
              $msg = "There are no clusters that restricts the transfer of documents on this platform";
              header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                           "msg"=>$msg
                       ));
                
            }
     
 }
 
 
 
 
  /**
         * This is the function that adds document types that are available for transfers
         */
        public function actionAddDocumentTypesThatAreAvailableAtTransfersOnPlatform(){
            
             //get the domain policy id
            
            $platform_setting_id = $_POST['id'];
            
                      
            //delete all the infomation about this domain policy on the lookup table
           $cmd =Yii::app()->db->createCommand();  
           $cmd->delete('documenttypes_available_for_transfer_on_platform', 'platform_setting_id=:id', array(':id'=>$platform_setting_id));
           
           //insert the new selected neighbourhood values
           
           $counter = 0;
           if(isset($_POST['types'])){
                foreach($_POST['types'] as $type){
                 $cmd =Yii::app()->db->createCommand();  
                $cmd->insert('documenttypes_available_for_transfer_on_platform',
                	array('platform_setting_id'=>$platform_setting_id,
				'type_id'=>$type,
				 'create_time'=>new CDbExpression('NOW()'),
                                 'update_time'=>new CDbExpression('NOW()'),
                                  'created_by'=>Yii::app()->user->id,
                                    'updated_by'=>Yii::app()->user->id,
					
					
			));
                
             $counter = $counter + 1;
            }
           $msg = "These document types will be available for transfers on this platform";
              header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                           "msg"=>$msg
                       ));
               
           }else{
               
                $msg = "There will be no document types available for transfers on this platform";
              header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                           "msg"=>$msg
                       ));
           }
            
            
        }
        
        
        
        
        //for trading module
        
        /**
         * This is the function that adds document types that are available for trading
         */
        public function actionAddDocumentTypesThatAreAvailableAtTradingOnPlatform(){
            
             //get the domain policy id
            
            $platform_setting_id = $_POST['id'];
            
                      
            //delete all the infomation about this domain policy on the lookup table
           $cmd =Yii::app()->db->createCommand();  
           $cmd->delete('documenttypes_available_for_trading_on_platform', 'platform_setting_id=:id', array(':id'=>$platform_setting_id));
           
           //insert the new selected neighbourhood values
           
           $counter = 0;
           if(isset($_POST['types'])){
                foreach($_POST['types'] as $type){
                 $cmd =Yii::app()->db->createCommand();  
                $cmd->insert('documenttypes_available_for_trading_on_platform',
                	array('platform_setting_id'=>$platform_setting_id,
				'type_id'=>$type,
				 'create_time'=>new CDbExpression('NOW()'),
                                 'update_time'=>new CDbExpression('NOW()'),
                                  'created_by'=>Yii::app()->user->id,
                                    'updated_by'=>Yii::app()->user->id,
					
					
			));
                
             $counter = $counter + 1;
            }
           $msg = "These document types will be available for trading on this platform";
              header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                           "msg"=>$msg
                       ));
               
           }else{
               
                $msg = "There will be no document types available for trading on this platform";
              header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                           "msg"=>$msg
                       ));
           }
            
            
        }
        
        
        /**
 * This is the function that restricts the trading of document types to neighbourhoods
 */
 public function actionAddDocumentTypesThatAreRestrictedToNeighbourhoodsAtTradingOnPlatform(){
     
      //get the domain policy id
            
            $platform_setting_id = $_POST['id'];
            
                      
            //delete all the infomation about this domain policy on the lookup table
           $cmd =Yii::app()->db->createCommand();  
           $cmd->delete('trading_restricted_to_neighbourhoods_on_platform', 'platform_setting_id=:id', array(':id'=>$platform_setting_id));
           
           //insert the new selected neighbourhood values
           
           $counter = 0;
           if(isset($_POST['hoods'])){
               foreach($_POST['hoods'] as $hood){
                 $cmd =Yii::app()->db->createCommand();  
                $cmd->insert('trading_restricted_to_neighbourhoods_on_platform',
                	array('platform_setting_id'=>$platform_setting_id,
				'hood_id'=>$hood,
				 'create_time'=>new CDbExpression('NOW()'),
                                 'update_time'=>new CDbExpression('NOW()'),
                                  'created_by'=>Yii::app()->user->id,
                                    'updated_by'=>Yii::app()->user->id,
					
					
			));
                
             $counter = $counter + 1;
            }
           $msg = "Trading of documents are restricted to these selected neighbourhoods on this platform";
              header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                           "msg"=>$msg
                       ));
               
           }else{
               
                $msg = "There are no neighbourhoods that restricts the trading of documents on this platform";
              header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                           "msg"=>$msg
                       ));
               
           }
            
 }  
 
 
 /**
  * This is the function that restricts the trading of documents to clusters
  */
 public function actionAddDocumentTypesThatAreRestrictedToClustersAtTradingOnPlatform(){
     
     //get the platform setting id
            
            $platform_setting_id = $_POST['id'];
            
                      
            //delete all the infomation about this domain policy on the lookup table
           $cmd =Yii::app()->db->createCommand();  
           $cmd->delete('trading_restricted_to_clusters_on_platform', 'platform_setting_id=:id', array(':id'=>$platform_setting_id));
           
           //insert the new selected neighbourhood values
           
           $counter = 0;
            if(isset($_POST['clusters'])){
                foreach($_POST['clusters'] as $cluster){
                 $cmd =Yii::app()->db->createCommand();  
                $cmd->insert('trading_restricted_to_clusters_on_platform',
                	array('platform_setting_id'=>$platform_setting_id,
				'cluster_id'=>$cluster,
				 'create_time'=>new CDbExpression('NOW()'),
                                 'update_time'=>new CDbExpression('NOW()'),
                                  'created_by'=>Yii::app()->user->id,
                                    'updated_by'=>Yii::app()->user->id,
					
					
			));
                
             $counter = $counter + 1;
            }
           $msg = "Trading of documents are restricted to these selected clusters on this platform";
              header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                           "msg"=>$msg
                       ));
                
            }else{
              $msg = "There are no clusters that restricts the trading of documents on this platform";
              header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                           "msg"=>$msg
                       ));
                
            }
     
 }
 
 
 /**
 * This is the function that allows members of a neighbourhoods to trade on own domain store
 */
 public function actionAddAllowTheseNeighbourhoodsToTradeOnOwnStoreAtTradingOnPlatform(){
     
      //get the domain policy id
            
            $platform_setting_id = $_POST['id'];
            
                      
            //delete all the infomation about this domain policy on the lookup table
           $cmd =Yii::app()->db->createCommand();  
           $cmd->delete('allow_neighbourhoods_on_own_stores_on_platform', 'platform_setting_id=:id', array(':id'=>$platform_setting_id));
           
           //insert the new selected neighbourhood values
           
           $counter = 0;
           if(isset($_POST['hoods'])){
               foreach($_POST['hoods'] as $hood){
                 $cmd =Yii::app()->db->createCommand();  
                $cmd->insert('allow_neighbourhoods_on_own_stores_on_platform',
                	array('platform_setting_id'=>$platform_setting_id,
				'hood_id'=>$hood,
				 'create_time'=>new CDbExpression('NOW()'),
                                 'update_time'=>new CDbExpression('NOW()'),
                                  'created_by'=>Yii::app()->user->id,
                                    'updated_by'=>Yii::app()->user->id,
					
					
			));
                
             $counter = $counter + 1;
            }
           $msg = "These neighnourhoods are allowed to trade on private store";
              header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                           "msg"=>$msg
                       ));
               
           }else{
               
                $msg = "There are no neighbourhoods that is given permission to trade on private store";
              header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                           "msg"=>$msg
                       ));
               
           }
            
 } 
 
 
 
  //for security, movements and destruction policies  
 
       /**
 *  This is the function that adds documents that cannot be moved on domain
 */
 public function actionAddDocumentsThatCannotBeMovedOnPlatform(){
     
      //get the domain policy id
            
            $platform_setting_id = $_POST['id'];
            
                      
            //delete all the infomation about this domain policy on the lookup table
           $cmd =Yii::app()->db->createCommand();  
           $cmd->delete('immovable_documents_on_platform', 'platform_setting_id=:id', array(':id'=>$platform_setting_id));
           
           //insert the new selected neighbourhood values
           
           $counter = 0;
           if(isset($_POST['documents'])){
               foreach($_POST['documents'] as $document){
                 $cmd =Yii::app()->db->createCommand();  
                $cmd->insert('immovable_documents_on_platform',
                	array('platform_setting_id'=>$platform_setting_id,
				'document_id'=>$document,
				 'create_time'=>new CDbExpression('NOW()'),
                                 'update_time'=>new CDbExpression('NOW()'),
                                  'created_by'=>Yii::app()->user->id,
                                    'updated_by'=>Yii::app()->user->id,
					
					
			));
                
             $counter = $counter + 1;
            }
           $msg = "These documents cannot be moved on this platform";
              header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                           "msg"=>$msg
                       ));
               
           }else{
               
                $msg = "There are no document that cannot be moved on this platform";
              header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                           "msg"=>$msg
                       ));
               
           }
            
 }  
 
 
 
 /**
 * This is the function that allows document movements to be restricted to these neighbourhoods on this domain
 */
 public function actionAddNeighbourhoodsForRestrictedDocumentMovementsOnPlatform(){
     
      //get the domain policy id
            
            $platform_setting_id = $_POST['id'];
            
                      
            //delete all the infomation about this domain policy on the lookup table
           $cmd =Yii::app()->db->createCommand();  
           $cmd->delete('restricted_neighbourhood_for_document_movement_on_platform', 'platform_setting_id=:id', array(':id'=>$platform_setting_id));
           
           //insert the new selected neighbourhood values
           
           $counter = 0;
           if(isset($_POST['hoods'])){
               foreach($_POST['hoods'] as $hood){
                 $cmd =Yii::app()->db->createCommand();  
                $cmd->insert('restricted_neighbourhood_for_document_movement_on_platform',
                	array('platform_setting_id'=>$platform_setting_id,
				'hood_id'=>$hood,
				 'create_time'=>new CDbExpression('NOW()'),
                                 'update_time'=>new CDbExpression('NOW()'),
                                  'created_by'=>Yii::app()->user->id,
                                    'updated_by'=>Yii::app()->user->id,
					
					
			));
                
             $counter = $counter + 1;
            }
           $msg = "Document movements are restricted to this neighnourhoods on this platform";
              header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                           "msg"=>$msg
                       ));
               
           }else{
               
                $msg = "There are no neighbourhoods that restrict document movements on this platform";
              header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                           "msg"=>$msg
                       ));
               
           }
            
 } 
 
 
 
      /**
 * This is the function that adds documents that cannot be moved outside own domain 
 */
 public function actionAddDocumentsThatCannotBeMovedOutsideOwnDomainOnPlatform(){
     
      //get the domain policy id
            
            $platform_setting_id = $_POST['id'];
            
                      
            //delete all the infomation about this domain policy on the lookup table
           $cmd =Yii::app()->db->createCommand();  
           $cmd->delete('documents_not_moveable_outside_own_domain_on_platform', 'platform_setting_id=:id', array(':id'=>$platform_setting_id));
           
           //insert the new selected neighbourhood values
           
           $counter = 0;
           if(isset($_POST['documents'])){
               foreach($_POST['documents'] as $document){
                 $cmd =Yii::app()->db->createCommand();  
                $cmd->insert('documents_not_moveable_outside_own_domain_on_platform',
                	array('platform_setting_id'=>$platform_setting_id,
				'document_id'=>$document,
				 'create_time'=>new CDbExpression('NOW()'),
                                 'update_time'=>new CDbExpression('NOW()'),
                                  'created_by'=>Yii::app()->user->id,
                                    'updated_by'=>Yii::app()->user->id,
					
					
			));
                
             $counter = $counter + 1;
            }
           $msg = "These documents cannot be moved outside their own domain on this platform ";
              header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                           "msg"=>$msg
                       ));
               
           }else{
               
                $msg = "There are no document that cannot be moved outside of their own domain on this platform";
              header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                           "msg"=>$msg
                       ));
               
           }
            
 }  
 
 
 
     /**
 * This is the function that adds processors whose documents cannot be moved on the domain 
 */
 public function actionAddDocumentsByTheseProcessorsCannotBeMovedOnPlatform(){
     
      //get the domain policy id
            
            $platform_setting_id = $_POST['id'];
            
                      
            //delete all the infomation about this domain policy on the lookup table
           $cmd =Yii::app()->db->createCommand();  
           $cmd->delete('documents_by_processors_not_moveable_on_platform', 'platform_setting_id=:id', array(':id'=>$platform_setting_id));
           
           //insert the new selected neighbourhood values
           
           $counter = 0;
           if(isset($_POST['processors'])){
               foreach($_POST['processors'] as $processor){
                 $cmd =Yii::app()->db->createCommand();  
                $cmd->insert('documents_by_processors_not_moveable_on_platform',
                	array('platform_setting_id'=>$platform_setting_id,
				'processor_id'=>$processor,
				 'create_time'=>new CDbExpression('NOW()'),
                                 'update_time'=>new CDbExpression('NOW()'),
                                  'created_by'=>Yii::app()->user->id,
                                    'updated_by'=>Yii::app()->user->id,
					
					
			));
                
             $counter = $counter + 1;
            }
           $msg = "These processors' initiated documents cannot be moved on this platform ";
              header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                           "msg"=>$msg
                       ));
               
           }else{
               
                $msg = "There are no processor initiated document that cannot be moved on this platform";
              header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                           "msg"=>$msg
                       ));
               
           }
            
 }  
 
 
 
     /**
 * This is the function that adds processors whose documents cannot be moved outside own domain on the domain 
 */
 public function actionAddProcessorsWhoseDocumentsAreMoveableOnlyWithinOwnDomainOnPlatform(){
     
      //get the domain policy id
            
            $platform_setting_id = $_POST['id'];
            
                      
            //delete all the infomation about this domain policy on the lookup table
           $cmd =Yii::app()->db->createCommand();  
           $cmd->delete('restricted_processor_documents_movement_to_domain_on_platform', 'platform_setting_id=:id', array(':id'=>$platform_setting_id));
           
           //insert the new selected processors values
           
           $counter = 0;
           if(isset($_POST['processors'])){
               foreach($_POST['processors'] as $processor){
                 $cmd =Yii::app()->db->createCommand();  
                $cmd->insert('restricted_processor_documents_movement_to_domain_on_platform',
                	array('platform_setting_id'=>$platform_setting_id,
				'processor_id'=>$processor,
				 'create_time'=>new CDbExpression('NOW()'),
                                 'update_time'=>new CDbExpression('NOW()'),
                                  'created_by'=>Yii::app()->user->id,
                                    'updated_by'=>Yii::app()->user->id,
					
					
			));
                
             $counter = $counter + 1;
            }
           $msg = "These processors' initiated documents cannot be moved outside own domain on this platform ";
              header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                           "msg"=>$msg
                       ));
               
           }else{
               
                $msg = "There are no processor initiated document that cannot be moved outside own domain on this platform";
              header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                           "msg"=>$msg
                       ));
               
           }
            
 } 
 
 
 
      /**
 * This is the function that adds batches & files that cannot be moved on domain
 */
 public function actionAddBatchesThatCannotBeMovedOnPlatform(){
     
      //get the domain policy id
            
            $platform_setting_id = $_POST['id'];
            
                      
            //delete all the infomation about this domain policy on the lookup table
           $cmd =Yii::app()->db->createCommand();  
           $cmd->delete('immovable_batches_on_platform', 'platform_setting_id=:id', array(':id'=>$platform_setting_id));
           
           //insert the new selected batch values
           
           $counter = 0;
           if(isset($_POST['batches'])){
               foreach($_POST['batches'] as $batch){
                 $cmd =Yii::app()->db->createCommand();  
                $cmd->insert('immovable_batches_on_platform',
                	array('platform_setting_id'=>$platform_setting_id,
				'batch_id'=>$batch,
				 'create_time'=>new CDbExpression('NOW()'),
                                 'update_time'=>new CDbExpression('NOW()'),
                                  'created_by'=>Yii::app()->user->id,
                                    'updated_by'=>Yii::app()->user->id,
					
					
			));
                
             $counter = $counter + 1;
            }
           $msg = "These batches & files cannot be moved on this platform";
              header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                           "msg"=>$msg
                       ));
               
           }else{
               
                $msg = "There are no batch & file that cannot be moved on this platform";
              header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                           "msg"=>$msg
                       ));
               
           }
            
 }  
 
 
  /**
 * This is the function that allows batches & files movements to be restricted to these neighbourhoods on this domain
 */
 public function actionAddNeighboursForRestrictedBatchMovementOnPlatform(){
     
      //get the domain policy id
            
            $platform_setting_id = $_POST['id'];
            
                      
            //delete all the infomation about this domain policy on the lookup table
           $cmd =Yii::app()->db->createCommand();  
           $cmd->delete('restricted_neighbourhood_for_batch_movement_on_platform', 'platform_setting_id=:id', array(':id'=>$platform_setting_id));
           
           //insert the new selected neighbourhood values
           
           $counter = 0;
           if(isset($_POST['hoods'])){
               foreach($_POST['hoods'] as $hood){
                 $cmd =Yii::app()->db->createCommand();  
                $cmd->insert('restricted_neighbourhood_for_batch_movement_on_platform',
                	array('platform_setting_id'=>$platform_setting_id,
				'hood_id'=>$hood,
				 'create_time'=>new CDbExpression('NOW()'),
                                 'update_time'=>new CDbExpression('NOW()'),
                                  'created_by'=>Yii::app()->user->id,
                                    'updated_by'=>Yii::app()->user->id,
					
					
			));
                
             $counter = $counter + 1;
            }
           $msg = "Batch & file movements are restricted to this neighnourhoods on this platform";
              header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                           "msg"=>$msg
                       ));
               
           }else{
               
                $msg = "There are no neighbourhoods that restrict batch & file movements on this platform";
              header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                           "msg"=>$msg
                       ));
               
           }
            
 } 
 
 
      /**
 * This is the function that adds batches & files that cannot be moved outside own domain on this platform
 */
 public function actionAddBatchesThatCannotBeMovedOutsideOwnDomainOnPlatform(){
     
      //get the domain policy id
            
            $platform_setting_id = $_POST['id'];
            
                      
            //delete all the infomation about this domain policy on the lookup table
           $cmd =Yii::app()->db->createCommand();  
           $cmd->delete('batches_not_moveable_outside_own_domain_on_platform', 'platform_setting_id=:id', array(':id'=>$platform_setting_id));
           
           //insert the new selected neighbourhood values
           
           $counter = 0;
           if(isset($_POST['batches'])){
               foreach($_POST['batches'] as $batch){
                 $cmd =Yii::app()->db->createCommand();  
                $cmd->insert('batches_not_moveable_outside_own_domain_on_platform',
                	array('platform_setting_id'=>$platform_setting_id,
				'batch_id'=>$batch,
				 'create_time'=>new CDbExpression('NOW()'),
                                 'update_time'=>new CDbExpression('NOW()'),
                                  'created_by'=>Yii::app()->user->id,
                                    'updated_by'=>Yii::app()->user->id,
					
					
			));
                
             $counter = $counter + 1;
            }
           $msg = "These batches & files cannot be moved outside their own domain on this platform ";
              header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                           "msg"=>$msg
                       ));
               
           }else{
               
                $msg = "There are no batch & file that cannot be moved outside of their own domain on this platform";
              header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                           "msg"=>$msg
                       ));
               
           }
            
 }  
 
 
 
     /**
 * This is the function that adds boxes & folders that cannot be moved on this platform
 */
 public function actionAddBoxesThatCannotBeMovedOnPlatform(){
     
      //get the platform setting id
            
            $platform_setting_id = $_POST['id'];
            
                      
            //delete all the infomation about this domain policy on the lookup table
           $cmd =Yii::app()->db->createCommand();  
           $cmd->delete('immovable_boxes_on_platform', 'platform_setting_id=:id', array(':id'=>$platform_setting_id));
           
           //insert the new selected batch values
           
           $counter = 0;
           if(isset($_POST['boxes'])){
               foreach($_POST['boxes'] as $box){
                 $cmd =Yii::app()->db->createCommand();  
                $cmd->insert('immovable_boxes_on_platform',
                	array('platform_setting_id'=>$platform_setting_id,
				'box_id'=>$box,
				 'create_time'=>new CDbExpression('NOW()'),
                                 'update_time'=>new CDbExpression('NOW()'),
                                  'created_by'=>Yii::app()->user->id,
                                    'updated_by'=>Yii::app()->user->id,
					
					
			));
                
             $counter = $counter + 1;
            }
           $msg = "These boxes & folders cannot be moved on this platform";
              header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                           "msg"=>$msg
                       ));
               
           }else{
               
                $msg = "There are no box & folder that cannot be moved on this platform";
              header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                           "msg"=>$msg
                       ));
               
           }
            
 }  
 
 
 
  /**
 * This is the function that allows boxes & folders movements to be restricted to these neighbourhoods on this platform
 */
 public function actionAddNeighbourhoodsForRestrictedBoxMovementsOnPlatform(){
     
      //get the platform_setting_id
            
            $platform_setting_id = $_POST['id'];
            
                      
            //delete all the infomation about this domain policy on the lookup table
           $cmd =Yii::app()->db->createCommand();  
           $cmd->delete('restricted_neighbourhood_for_box_movement_on_platform', 'platform_setting_id=:id', array(':id'=>$platform_setting_id));
           
           //insert the new selected neighbourhood values
           
           $counter = 0;
           if(isset($_POST['hoods'])){
               foreach($_POST['hoods'] as $hood){
                 $cmd =Yii::app()->db->createCommand();  
                $cmd->insert('restricted_neighbourhood_for_box_movement_on_platform',
                	array('platform_setting_id'=>$platform_setting_id,
				'hood_id'=>$hood,
				 'create_time'=>new CDbExpression('NOW()'),
                                 'update_time'=>new CDbExpression('NOW()'),
                                  'created_by'=>Yii::app()->user->id,
                                    'updated_by'=>Yii::app()->user->id,
					
					
			));
                
             $counter = $counter + 1;
            }
           $msg = "Boxes & folders movements are restricted to this neighnourhoods on this platform";
              header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                           "msg"=>$msg
                       ));
               
           }else{
               
                $msg = "There are no neighbourhoods that restrict box & folder movements on this platform";
              header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                           "msg"=>$msg
                       ));
               
           }
            
 } 
 
 
 
     /**
 * This is the function that adds boxes & folders that cannot be moved outside own domain on this platform
 */
 public function actionAddBoxesThatCannotBeMovedOutsideOwnDomainsOnPlatform(){
     
      //get the platform_setting_id
            
            $platform_setting_id = $_POST['id'];
            
                      
            //delete all the infomation about this domain policy on the lookup table
           $cmd =Yii::app()->db->createCommand();  
           $cmd->delete('boxes_not_moveable_outside_own_domain_on_platform', 'platform_setting_id=:id', array(':id'=>$platform_setting_id));
           
           //insert the new selected batch values
           
           $counter = 0;
           if(isset($_POST['boxes'])){
               foreach($_POST['boxes'] as $box){
                 $cmd =Yii::app()->db->createCommand();  
                $cmd->insert('boxes_not_moveable_outside_own_domain_on_platform',
                	array('platform_setting_id'=>$platform_setting_id,
				'box_id'=>$box,
				 'create_time'=>new CDbExpression('NOW()'),
                                 'update_time'=>new CDbExpression('NOW()'),
                                  'created_by'=>Yii::app()->user->id,
                                    'updated_by'=>Yii::app()->user->id,
					
					
			));
                
             $counter = $counter + 1;
            }
           $msg = "These boxes & folders cannot be moved outside own domain on this platform";
              header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                           "msg"=>$msg
                       ));
               
           }else{
               
                $msg = "There are no box & folder that cannot be moved outside own domain on this platform";
              header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                           "msg"=>$msg
                       ));
               
           }
            
 }  
 
 
       /**
 *  This is the function that adds documents that cannot be reassigned on domain
 */
 public function actionAddDocumentsThatAreNotReassignableOnPlatform(){
     
      //get the domain policy id
            
            $platform_setting_id = $_POST['id'];
            
                      
            //delete all the infomation about this domain policy on the lookup table
           $cmd =Yii::app()->db->createCommand();  
           $cmd->delete('nonreassignable_documents_on_platform', 'platform_setting_id=:id', array(':id'=>$platform_setting_id));
           
           //insert the new selected neighbourhood values
           
           $counter = 0;
           if(isset($_POST['documents'])){
               foreach($_POST['documents'] as $document){
                 $cmd =Yii::app()->db->createCommand();  
                $cmd->insert('nonreassignable_documents_on_platform',
                	array('platform_setting_id'=>$platform_setting_id,
				'document_id'=>$document,
				 'create_time'=>new CDbExpression('NOW()'),
                                 'update_time'=>new CDbExpression('NOW()'),
                                  'created_by'=>Yii::app()->user->id,
                                    'updated_by'=>Yii::app()->user->id,
					
					
			));
                
             $counter = $counter + 1;
            }
           $msg = "These documents cannot be reassigned on this platform";
              header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                           "msg"=>$msg
                       ));
               
           }else{
               
                $msg = "There are no document that cannot be reassigned on this platform";
              header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                           "msg"=>$msg
                       ));
               
           }
            
 }  
 
 
 
        /**
 *  This is the function that adds batches & files  that cannot be reassigned on this platform
 */
 public function actionAddBatchesThatAreNotReassignableOnPlatform(){
     
      //get the domain policy id
            
            $platform_setting_id = $_POST['id'];
            
                      
            //delete all the infomation about this platform settings on the lookup table
           $cmd =Yii::app()->db->createCommand();  
           $cmd->delete('nonreassignable_batches_on_platform', 'platform_setting_id=:id', array(':id'=>$platform_setting_id));
           
           //insert the new selected neighbourhood values
           
           $counter = 0;
           if(isset($_POST['batches'])){
               foreach($_POST['batches'] as $batch){
                 $cmd =Yii::app()->db->createCommand();  
                $cmd->insert('nonreassignable_batches_on_platform',
                	array('platform_setting_id'=>$platform_setting_id,
				'batch_id'=>$batch,
				 'create_time'=>new CDbExpression('NOW()'),
                                 'update_time'=>new CDbExpression('NOW()'),
                                  'created_by'=>Yii::app()->user->id,
                                    'updated_by'=>Yii::app()->user->id,
					
					
			));
                
             $counter = $counter + 1;
            }
           $msg = "These batches & files cannot be reassigned on this platform";
              header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                           "msg"=>$msg
                       ));
               
           }else{
               
                $msg = "There are no batch & file that cannot be reassigned on this platform";
              header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                           "msg"=>$msg
                       ));
               
           }
            
 }  
 
 
    /**
 *  This is the function that adds boxes & folders  that cannot be reassigned on domain
 */
 public function actionAddBoxesThatAreNotReassignableOnPlatform(){
     
      //get the platform_setting_id
            
            $platform_setting_id = $_POST['id'];
            
                      
            //delete all the infomation about this domain policy on the lookup table
           $cmd =Yii::app()->db->createCommand();  
           $cmd->delete('nonreassignable_boxes_on_platform', 'platform_setting_id=:id', array(':id'=>$platform_setting_id));
           
           //insert the new selected batch values
           
           $counter = 0;
           if(isset($_POST['boxes'])){
               foreach($_POST['boxes'] as $box){
                 $cmd =Yii::app()->db->createCommand();  
                $cmd->insert('nonreassignable_boxes_on_platform',
                	array('platform_setting_id'=>$platform_setting_id,
				'box_id'=>$box,
				 'create_time'=>new CDbExpression('NOW()'),
                                 'update_time'=>new CDbExpression('NOW()'),
                                  'created_by'=>Yii::app()->user->id,
                                    'updated_by'=>Yii::app()->user->id,
					
					
			));
                
             $counter = $counter + 1;
            }
           $msg = "These boxes & folders cannot be reassigned on this platform";
              header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                           "msg"=>$msg
                       ));
               
           }else{
               
                $msg = "There are no box & folder that cannot be reassigned on this platform";
              header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                           "msg"=>$msg
                       ));
               
           }
            
 }  
 
 
 
 
  /**
 * This is the function that add neighbourhoods so as to restrict documents reassignments
 */
 public function actionAddNeighbourhoodsForRestrictedDocumentsReassignmentOnPlatform(){
     
      //get the platform_setting_id
            
            $platform_setting_id = $_POST['id'];
            
                      
            //delete all the infomation on this lookup table
           $cmd =Yii::app()->db->createCommand();  
           $cmd->delete('restricted_neighbourhood_for_document_reassignment_on_platform', 'platform_setting_id=:id', array(':id'=>$platform_setting_id));
           
           //insert the new selected neighbourhood values
           
           $counter = 0;
           if(isset($_POST['hoods'])){
               foreach($_POST['hoods'] as $hood){
                 $cmd =Yii::app()->db->createCommand();  
                $cmd->insert('restricted_neighbourhood_for_document_reassignment_on_platform',
                	array('platform_setting_id'=>$platform_setting_id,
				'hood_id'=>$hood,
				 'create_time'=>new CDbExpression('NOW()'),
                                 'update_time'=>new CDbExpression('NOW()'),
                                  'created_by'=>Yii::app()->user->id,
                                    'updated_by'=>Yii::app()->user->id,
					
					
			));
                
             $counter = $counter + 1;
            }
           $msg = "Reassignments of documents are restricted  to these selected neighnourhoods on this platform";
              header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                           "msg"=>$msg
                       ));
               
           }else{
               
                $msg = "There are no neighbourhoods that restrict the reassignment of documents on this platform";
              header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                           "msg"=>$msg
                       ));
               
           }
            
 } 
 
 
 
  /**
 * This is the function that add neighbourhoods so as to restrict batches & files on  reassignments
 */
 public function actionAddNeighbourhoodsForRestrictedBatchReassignmentOnPlatform(){
     
      //get the domain policy id
            
            $platform_setting_id = $_POST['id'];
            
                      
            //delete all the infomation about this domain policy on the lookup table
           $cmd =Yii::app()->db->createCommand();  
           $cmd->delete('restricted_neighbourhood_for_batch_reassignment_on_platform', 'platform_setting_id=:id', array(':id'=>$platform_setting_id));
           
           //insert the new selected neighbourhood values
           
           $counter = 0;
           if(isset($_POST['hoods'])){
               foreach($_POST['hoods'] as $hood){
                 $cmd =Yii::app()->db->createCommand();  
                $cmd->insert('restricted_neighbourhood_for_batch_reassignment_on_platform',
                	array('platform_setting_id'=>$platform_setting_id,
				'hood_id'=>$hood,
				 'create_time'=>new CDbExpression('NOW()'),
                                 'update_time'=>new CDbExpression('NOW()'),
                                  'created_by'=>Yii::app()->user->id,
                                    'updated_by'=>Yii::app()->user->id,
					
					
			));
                
             $counter = $counter + 1;
            }
           $msg = "Reassignments of batches & files are restricted  to these selected neighnourhoods on this platform";
              header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                           "msg"=>$msg
                       ));
               
           }else{
               
                $msg = "There are no neighbourhoods that restrict the reassignment of batches & files on this platform";
              header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                           "msg"=>$msg
                       ));
               
           }
            
 } 
 
 
 
 
 /**
 * This is the function that add neighbourhoods so as to restrict boxes & folders on  reassignments
 */
 public function actionAddNeighbourhoodsForRestrictedBoxReassignmentOnPlatform(){
     
      //get the domain policy id
            
            $platform_setting_id = $_POST['id'];
            
                      
            //delete all the infomation about this domain policy on the lookup table
           $cmd =Yii::app()->db->createCommand();  
           $cmd->delete('restricted_neighbourhood_for_box_reassignment_on_platform', 'platform_setting_id=:id', array(':id'=>$platform_setting_id));
           
           //insert the new selected neighbourhood values
           
           $counter = 0;
           if(isset($_POST['hoods'])){
               foreach($_POST['hoods'] as $hood){
                 $cmd =Yii::app()->db->createCommand();  
                $cmd->insert('restricted_neighbourhood_for_box_reassignment_on_platform',
                	array('platform_setting_id'=>$platform_setting_id,
				'hood_id'=>$hood,
				 'create_time'=>new CDbExpression('NOW()'),
                                 'update_time'=>new CDbExpression('NOW()'),
                                  'created_by'=>Yii::app()->user->id,
                                    'updated_by'=>Yii::app()->user->id,
					
					
			));
                
             $counter = $counter + 1;
            }
           $msg = "Reassignments of boxes & folder are restricted  to these selected neighnourhoods on this platform";
              header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                           "msg"=>$msg
                       ));
               
           }else{
               
                $msg = "There are no neighbourhoods that restrict the reassignment of boxes & folder on this platform";
              header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                           "msg"=>$msg
                       ));
               
           }
            
 } 
 
 
 
 /**
  * This is the function that add clusters so as to restrict documents on  reassignments
  */
 public function actionAddClustersForRestrictedDocumentsReassignmentOnPlatform(){
     
     //get the domain policy id
            
            $platform_setting_id = $_POST['id'];
            
                      
            //delete all the infomation about this domain policy on the lookup table
           $cmd =Yii::app()->db->createCommand();  
           $cmd->delete('restricted_cluster_for_document_reassignment_on_platform', 'platform_setting_id=:id', array(':id'=>$platform_setting_id));
           
           //insert the new selected cluster values
           
           $counter = 0;
            if(isset($_POST['clusters'])){
                foreach($_POST['clusters'] as $cluster){
                 $cmd =Yii::app()->db->createCommand();  
                $cmd->insert('restricted_cluster_for_document_reassignment_on_platform',
                	array('platform_setting_id'=>$platform_setting_id,
				'cluster_id'=>$cluster,
				 'create_time'=>new CDbExpression('NOW()'),
                                 'update_time'=>new CDbExpression('NOW()'),
                                  'created_by'=>Yii::app()->user->id,
                                    'updated_by'=>Yii::app()->user->id,
					
					
			));
                
             $counter = $counter + 1;
            }
           $msg = "Reassignments of documents are restricted  to these selected clusters on this platform";
              header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                           "msg"=>$msg
                       ));
                
            }else{
              $msg = "There are no clusters that restrict the reassignment of documents on this platform";
              header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                           "msg"=>$msg
                       ));
                
            }
     
 }
 
 
 
 
 /**
  * This is the function that add clusters so as to restrict batches & files on  reassignments
  */
 public function actionAddClustersForRestrictedBatchReassignmentOnPlatform(){
     
     //get the domain policy id
            
            $platform_setting_id = $_POST['id'];
            
                      
            //delete all the infomation about this domain policy on the lookup table
           $cmd =Yii::app()->db->createCommand();  
           $cmd->delete('restricted_cluster_for_batch_reassignment_on_platform', 'platform_setting_id=:id', array(':id'=>$platform_setting_id));
           
           //insert the new selected cluster values
           
           $counter = 0;
            if(isset($_POST['clusters'])){
                foreach($_POST['clusters'] as $cluster){
                 $cmd =Yii::app()->db->createCommand();  
                $cmd->insert('restricted_cluster_for_batch_reassignment_on_platform',
                	array('platform_setting_id'=>$platform_setting_id,
				'cluster_id'=>$cluster,
				 'create_time'=>new CDbExpression('NOW()'),
                                 'update_time'=>new CDbExpression('NOW()'),
                                  'created_by'=>Yii::app()->user->id,
                                    'updated_by'=>Yii::app()->user->id,
					
					
			));
                
             $counter = $counter + 1;
            }
           $msg = "Reassignments of batches & files are restricted  to these selected clusters on this platform";
              header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                           "msg"=>$msg
                       ));
                
            }else{
              $msg = "There are no clusters that restrict the reassignment of batches & files on this platform";
              header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                           "msg"=>$msg
                       ));
                
            }
     
 }
 
 
 
 
 /**
  * This is the function that add clusters so as to restrict boxes & folders on  reassignments
  */
 public function actionAddClustersForRestrictedBoxReassignmentOnPlatform(){
     
     //get the domain policy id
            
            $platform_setting_id = $_POST['id'];
            
                      
            //delete all the infomation about this domain policy on the lookup table
           $cmd =Yii::app()->db->createCommand();  
           $cmd->delete('restricted_cluster_for_box_reassignment_on_platform', 'platform_setting_id=:id', array(':id'=>$platform_setting_id));
           
           //insert the new selected cluster values
           
           $counter = 0;
            if(isset($_POST['clusters'])){
                foreach($_POST['clusters'] as $cluster){
                 $cmd =Yii::app()->db->createCommand();  
                $cmd->insert('restricted_cluster_for_box_reassignment_on_platform',
                	array('platform_setting_id'=>$platform_setting_id,
				'cluster_id'=>$cluster,
				 'create_time'=>new CDbExpression('NOW()'),
                                 'update_time'=>new CDbExpression('NOW()'),
                                  'created_by'=>Yii::app()->user->id,
                                    'updated_by'=>Yii::app()->user->id,
					
					
			));
                
             $counter = $counter + 1;
            }
           $msg = "Reassignments of boxes & folders are restricted  to these selected clusters on this platform";
              header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                           "msg"=>$msg
                       ));
                
            }else{
              $msg = "There are no clusters that restrict the reassignment of boxes & folders on this platform";
              header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                           "msg"=>$msg
                       ));
                
            }
     
 }
 
 
 
  /**
 * This is the function that add neighbourhoods   whose documents ae exempted from destruction on this domain
 */
 public function actionAddNeighbourhoodsWhereDocumentsCannotBeDestroyedOnPlatform(){
     
      //get the domain policy id
            
            $platform_setting_id = $_POST['id'];
            
                      
            //delete all the infomation about this domain policy on the lookup table
           $cmd =Yii::app()->db->createCommand();  
           $cmd->delete('exempted_neighbourhood_for_destruction_on_platform', 'platform_setting_id=:id', array(':id'=>$platform_setting_id));
           
           //insert the new selected neighbourhood values
           
           $counter = 0;
           if(isset($_POST['hoods'])){
               foreach($_POST['hoods'] as $hood){
                 $cmd =Yii::app()->db->createCommand();  
                $cmd->insert('exempted_neighbourhood_for_destruction_on_platform',
                	array('platform_setting_id'=>$platform_setting_id,
				'hood_id'=>$hood,
				 'create_time'=>new CDbExpression('NOW()'),
                                 'update_time'=>new CDbExpression('NOW()'),
                                  'created_by'=>Yii::app()->user->id,
                                    'updated_by'=>Yii::app()->user->id,
					
					
			));
                
             $counter = $counter + 1;
            }
           $msg = "The documents of these selected neighbourhoods are exempted from destruction on this platform";
              header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                           "msg"=>$msg
                       ));
               
           }else{
               
                $msg = "There are no neighbourhoods whose documents are exempted from destruction on this platform";
              header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                           "msg"=>$msg
                       ));
               
           }
            
 } 
 
 
 
 
 /**
  * This is the function that add clusters whose documents are exempted from destruction on this domain
  */
 public function actionAddClustersWhereDocumentsCannotBeDestroyedOnPlatform(){
     
     //get the domain policy id
            
            $platform_setting_id = $_POST['id'];
            
                      
            //delete all the infomation about this domain policy on the lookup table
           $cmd =Yii::app()->db->createCommand();  
           $cmd->delete('exempted_cluster_for_destruction_on_platform', 'platform_setting_id=:id', array(':id'=>$platform_setting_id));
           
           //insert the new selected cluster values
           
           $counter = 0;
            if(isset($_POST['clusters'])){
                foreach($_POST['clusters'] as $cluster){
                 $cmd =Yii::app()->db->createCommand();  
                $cmd->insert('exempted_cluster_for_destruction_on_platform',
                	array('platform_setting_id'=>$platform_setting_id,
				'cluster_id'=>$cluster,
				 'create_time'=>new CDbExpression('NOW()'),
                                 'update_time'=>new CDbExpression('NOW()'),
                                  'created_by'=>Yii::app()->user->id,
                                    'updated_by'=>Yii::app()->user->id,
					
					
			));
                
             $counter = $counter + 1;
            }
           $msg = "The documents of these selected clusters are exempted from destruction on this platform";
              header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                           "msg"=>$msg
                       ));
                
            }else{
              $msg = "There are no clusters whose documents are exempted from destruction on this platform";
              header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                           "msg"=>$msg
                       ));
                
            }
     
 }
 
 
 
 
 
 /**
  * This is the function that add processors whose documents are exempted from destruction on this domain
  */
 public function actionAddProcessorsWhoseDocumentsCannotBeDestroyedOnPlatform(){
     
     //get the domain policy id
            
            $platform_setting_id = $_POST['id'];
            
                      
            //delete all the infomation about this domain policy on the lookup table
           $cmd =Yii::app()->db->createCommand();  
           $cmd->delete('exempted_processor_for_destruction_on_platform', 'platform_setting_id=:id', array(':id'=>$platform_setting_id));
           
           //insert the new selected cluster values
           
           $counter = 0;
            if(isset($_POST['processors'])){
                foreach($_POST['processors'] as $processor){
                 $cmd =Yii::app()->db->createCommand();  
                $cmd->insert('exempted_processor_for_destruction_on_platform',
                	array('platform_setting_id'=>$platform_setting_id,
				'processor_id'=>$processor,
				 'create_time'=>new CDbExpression('NOW()'),
                                 'update_time'=>new CDbExpression('NOW()'),
                                  'created_by'=>Yii::app()->user->id,
                                    'updated_by'=>Yii::app()->user->id,
					
					
			));
                
             $counter = $counter + 1;
            }
           $msg = "The documents initiated by these selected processors are exempted from destruction on this platform";
              header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                           "msg"=>$msg
                       ));
                
            }else{
              $msg = "There are no processors whose documents are exempted from destruction on this platform";
              header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                           "msg"=>$msg
                       ));
                
            }
     
 }
 
 
 
 /**
  * This is the function that add document types that are exempted from destruction on this platform
  */
 public function actionAddDocumentTypesCannotBeDestroyedOnPlatform(){
     
     //get the domain policy id
            
            $platform_setting_id = $_POST['id'];
            
                      
            //delete all the infomation about this domain policy on the lookup table
           $cmd =Yii::app()->db->createCommand();  
           $cmd->delete('exempted_type_for_destruction_on_platform', 'platform_setting_id=:id', array(':id'=>$platform_setting_id));
           
           //insert the new selected cluster values
           
           $counter = 0;
            if(isset($_POST['types'])){
                foreach($_POST['types'] as $type){
                 $cmd =Yii::app()->db->createCommand();  
                $cmd->insert('exempted_type_for_destruction_on_platform',
                	array('platform_setting_id'=>$platform_setting_id,
				'type_id'=>$type,
				 'create_time'=>new CDbExpression('NOW()'),
                                 'update_time'=>new CDbExpression('NOW()'),
                                  'created_by'=>Yii::app()->user->id,
                                    'updated_by'=>Yii::app()->user->id,
					
					
			));
                
             $counter = $counter + 1;
            }
           $msg = "These selected document types are exempted from destruction on this platform";
              header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                           "msg"=>$msg
                       ));
                
            }else{
              $msg = "There are no document types exempted from destruction on this platform";
              header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                           "msg"=>$msg
                       ));
                
            }
     
 }
 
 
 
 /**
  * This is the function that add document categories that are exempted from destruction on this domain
  */
 public function actionAddDocumentCategoriesCannotBeDestroyedOnPlatform(){
     
     //get the domain policy id
            
            $platform_setting_id = $_POST['id'];
            
                      
            //delete all the infomation about this domain policy on the lookup table
           $cmd =Yii::app()->db->createCommand();  
           $cmd->delete('exempted_category_for_destruction_on_platform', 'platform_setting_id=:id', array(':id'=>$platform_setting_id));
           
           //insert the new selected cluster values
           
           $counter = 0;
            if(isset($_POST['categories'])){
                foreach($_POST['categories'] as $category){
                 $cmd =Yii::app()->db->createCommand();  
                $cmd->insert('exempted_category_for_destruction_on_platform',
                	array('platform_setting_id'=>$platform_setting_id,
				'category_id'=>$category,
				 'create_time'=>new CDbExpression('NOW()'),
                                 'update_time'=>new CDbExpression('NOW()'),
                                  'created_by'=>Yii::app()->user->id,
                                    'updated_by'=>Yii::app()->user->id,
					
					
			));
                
             $counter = $counter + 1;
            }
           $msg = "These selected document categories are exempted from destruction on this platform";
              header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                           "msg"=>$msg
                       ));
                
            }else{
              $msg = "There are no document categories exempted from destruction on this platform";
              header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                           "msg"=>$msg
                       ));
                
            }
     
 }
 
 
 
 
 /**
  * This is the function that add document types to be retained after destruction on this domain
  */
 public function actionAddDocumentTypesOfElectronicCopyToRetainAfterDestructionOnPlatform(){
     
     //get the domain policy id
            
            $platform_setting_id = $_POST['id'];
            
                      
            //delete all the infomation about this domain policy on the lookup table
           $cmd =Yii::app()->db->createCommand();  
           $cmd->delete('retain_electronic_type_after_destruction_on_platform', 'platform_setting_id=:id', array(':id'=>$platform_setting_id));
           
           //insert the new selected cluster values
           
           $counter = 0;
            if(isset($_POST['types'])){
                foreach($_POST['types'] as $type){
                 $cmd =Yii::app()->db->createCommand();  
                $cmd->insert('retain_electronic_type_after_destruction_on_platform',
                	array('platform_setting_id'=>$platform_setting_id,
				'type_id'=>$type,
				 'create_time'=>new CDbExpression('NOW()'),
                                 'update_time'=>new CDbExpression('NOW()'),
                                  'created_by'=>Yii::app()->user->id,
                                    'updated_by'=>Yii::app()->user->id,
					
					
			));
                
             $counter = $counter + 1;
            }
           $msg = "These selected document types are to be retained after destruction on this platform";
              header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                           "msg"=>$msg
                       ));
                
            }else{
              $msg = "There are no document types whose document will be retained after destruction on this platform";
              header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                           "msg"=>$msg
                       ));
                
            }
     
 }
 
 
 
 
 /**
  * This is the function that add document categories to be retained after destruction on this domain
  */
 public function actionAddDocumentCategoriesOfElectronicCopyToRetainAfterDestructionOnPlatform(){
     
     //get the domain policy id
            
            $platform_setting_id = $_POST['id'];
            
                      
            //delete all the infomation about this domain policy on the lookup table
           $cmd =Yii::app()->db->createCommand();  
           $cmd->delete('retain_electronic_category_after_destruction_on_platform', 'platform_setting_id=:id', array(':id'=>$platform_setting_id));
           
           //insert the new selected cluster values
           
           $counter = 0;
            if(isset($_POST['categories'])){
                foreach($_POST['categories'] as $category){
                 $cmd =Yii::app()->db->createCommand();  
                $cmd->insert('retain_electronic_category_after_destruction_on_platform',
                	array('platform_setting_id'=>$platform_setting_id,
				'category_id'=>$category,
				 'create_time'=>new CDbExpression('NOW()'),
                                 'update_time'=>new CDbExpression('NOW()'),
                                  'created_by'=>Yii::app()->user->id,
                                    'updated_by'=>Yii::app()->user->id,
					
					
			));
                
             $counter = $counter + 1;
            }
           $msg = "These selected document categories are to be retained after destruction on this platform";
              header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                           "msg"=>$msg
                       ));
                
            }else{
              $msg = "There are no document categories whose document will be retained after destruction on this platform";
              header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                           "msg"=>$msg
                       ));
                
            }
     
 }
 
 
 
 
 /**
  * This is the function that add document types that are exempted from global request after destruction on this platform
  */
 public function actionAddDocumentTypeWithNoGlobalRequestAfterDestructionOnPlatform(){
     
     //get the domain policy id
            
            $platform_setting_id = $_POST['id'];
            
                      
            //delete all the infomation about this domain policy on the lookup table
           $cmd =Yii::app()->db->createCommand();  
           $cmd->delete('exempted_type_from_global_request_after_destruction_on_platform', 'platform_setting_id=:id', array(':id'=>$platform_setting_id));
           
           //insert the new selected cluster values
           
           $counter = 0;
            if(isset($_POST['types'])){
                foreach($_POST['types'] as $type){
                 $cmd =Yii::app()->db->createCommand();  
                $cmd->insert('exempted_type_from_global_request_after_destruction_on_platform',
                	array('platform_setting_id'=>$platform_setting_id,
				'type_id'=>$type,
				 'create_time'=>new CDbExpression('NOW()'),
                                 'update_time'=>new CDbExpression('NOW()'),
                                  'created_by'=>Yii::app()->user->id,
                                    'updated_by'=>Yii::app()->user->id,
					
					
			));
                
             $counter = $counter + 1;
            }
           $msg = "These selected document types are exempted from global request after destruction on this platform";
              header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                           "msg"=>$msg
                       ));
                
            }else{
              $msg = "There are no document types whose document will be exempted from global request after destruction on this platform";
              header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                           "msg"=>$msg
                       ));
                
            }
     
 }
 
 
 
 
  /**
  * This is the function that add destroyed documents that cannot be accessed on this platform
  */
 public function actionAddDestroyedDocumentsThatCannotBeAccessedOnPlatform(){
     
     //get the domain policy id
            
            $platform_setting_id = $_POST['id'];
            
                      
            //delete all the infomation about this domain policy on the lookup table
           $cmd =Yii::app()->db->createCommand();  
           $cmd->delete('inaccessible_destroyed_documents_on_platform', 'platform_setting_id=:id', array(':id'=>$platform_setting_id));
           
           //insert the new selected cluster values
           
           $counter = 0;
            if(isset($_POST['documents'])){
                foreach($_POST['documents'] as $document){
                 $cmd =Yii::app()->db->createCommand();  
                $cmd->insert('inaccessible_destroyed_documents_on_platform',
                	array('platform_setting_id'=>$platform_setting_id,
				'document_id'=>$document,
				 'create_time'=>new CDbExpression('NOW()'),
                                 'update_time'=>new CDbExpression('NOW()'),
                                  'created_by'=>Yii::app()->user->id,
                                    'updated_by'=>Yii::app()->user->id,
					
					
			));
                
             $counter = $counter + 1;
            }
           $msg = "These selected destroyed documents are not accessible on this platform";
              header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                           "msg"=>$msg
                       ));
                
            }else{
              $msg = "There are no destroyed document that is not accessible on this platform";
              header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                           "msg"=>$msg
                       ));
                
            }
     
 }
 
 
 
 /**
 * This is the function that add neighbourhoods  that could access destroyed documents on this platform
 */
 public function actionAddNeighbourhoodsThatCouldAccessDestroyedDocumentsOnPlatform(){
     
      //get the domain policy id
            
            $platform_setting_id = $_POST['id'];
            
                      
            //delete all the infomation about this domain policy on the lookup table
           $cmd =Yii::app()->db->createCommand();  
           $cmd->delete('Hood_permitted_to_access_destroyed_documents_on_platform', 'platform_setting_id=:id', array(':id'=>$platform_setting_id));
           
           //insert the new selected neighbourhood values
           
           $counter = 0;
           if(isset($_POST['hoods'])){
               foreach($_POST['hoods'] as $hood){
                 $cmd =Yii::app()->db->createCommand();  
                $cmd->insert('Hood_permitted_to_access_destroyed_documents_on_platform',
                	array('platform_setting_id'=>$platform_setting_id,
				'hood_id'=>$hood,
				 'create_time'=>new CDbExpression('NOW()'),
                                 'update_time'=>new CDbExpression('NOW()'),
                                  'created_by'=>Yii::app()->user->id,
                                    'updated_by'=>Yii::app()->user->id,
					
					
			));
                
             $counter = $counter + 1;
            }
           $msg = "These selected neighbourhoods are permitted to access destroyed documents on this platform";
              header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                           "msg"=>$msg
                       ));
               
           }else{
               
                $msg = "There are no neighbourhoods that are permitted  to access destroyed documents on this platform";
              header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                           "msg"=>$msg
                       ));
               
           }
            
 } 
 
 
 
 
 /**
 * This is the function that add clusters that could access destroyed documents on this platform
 */
 public function actionAddClustersThatCouldAccessDestroyedDocumentsOnPlatform(){
     
      //get the platform_setting_id
            
            $platform_setting_id = $_POST['id'];
            
                      
            //delete all the infomation about this domain policy on the lookup table
           $cmd =Yii::app()->db->createCommand();  
           $cmd->delete('cluster_permitted_to_access_destroyed_documents_on_platform', 'platform_setting_id=:id', array(':id'=>$platform_setting_id));
           
           //insert the new selected neighbourhood values
           
           $counter = 0;
           if(isset($_POST['clusters'])){
               foreach($_POST['clusters'] as $cluster){
                 $cmd =Yii::app()->db->createCommand();  
                $cmd->insert('cluster_permitted_to_access_destroyed_documents_on_platform',
                	array('platform_setting_id'=>$platform_setting_id,
				'cluster_id'=>$cluster,
				 'create_time'=>new CDbExpression('NOW()'),
                                 'update_time'=>new CDbExpression('NOW()'),
                                  'created_by'=>Yii::app()->user->id,
                                    'updated_by'=>Yii::app()->user->id,
					
					
			));
                
             $counter = $counter + 1;
            }
           $msg = "These selected clusters are permitted to access destroyed documents on this platform";
              header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                           "msg"=>$msg
                       ));
               
           }else{
               
                $msg = "There are no clusters that are permitted  to access destroyed documents on this platform";
              header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                           "msg"=>$msg
                       ));
               
           }
            
 } 
 
 
 
 
 /**
 * This is the function that add batches & files that could be moved as a whole on this platform
 */
 public function actionAddBatchesThatMustBeMovedAsAWholeOnPlatform(){
     
      //get the platform_setting_id
            
            $platform_setting_id = $_POST['id'];
            
                      
            //delete all the infomation about this domain policy on the lookup table
           $cmd =Yii::app()->db->createCommand();  
           $cmd->delete('batches_to_be_moved_as_whole_on_platform', 'platform_setting_id=:id', array(':id'=>$platform_setting_id));
           
           //insert the new selected neighbourhood values
           
           $counter = 0;
           if(isset($_POST['batches'])){
               foreach($_POST['batches'] as $batch){
                 $cmd =Yii::app()->db->createCommand();  
                $cmd->insert('batches_to_be_moved_as_whole_on_platform',
                	array('platform_setting_id'=>$platform_setting_id,
				'batch_id'=>$batch,
				 'create_time'=>new CDbExpression('NOW()'),
                                 'update_time'=>new CDbExpression('NOW()'),
                                  'created_by'=>Yii::app()->user->id,
                                    'updated_by'=>Yii::app()->user->id,
					
					
			));
                
             $counter = $counter + 1;
            }
           $msg = "These selected batches & files will be moved or reassigned as a whole on this platform";
              header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                           "msg"=>$msg
                       ));
               
           }else{
               
                $msg = "There are no batches &  files that will be moved or reassigned as a whole on this platform";
              header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                           "msg"=>$msg
                       ));
               
           }
            
 } 
 
 
 
 
 
  /**
 * This is the function that add boxes & folders that could be moved as a whole on this platform
 */
 public function actionAddBoxesThatMustBeMovedAsAWholeOnPlatform(){
     
      //get the domain policy id
            
            $platform_setting_id = $_POST['id'];
            
                      
            //delete all the infomation about this domain policy on the lookup table
           $cmd =Yii::app()->db->createCommand();  
           $cmd->delete('boxes_to_be_moved_as_whole_on_platform', 'platform_setting_id=:id', array(':id'=>$platform_setting_id));
           
           //insert the new selected boxes & folders values
           
           $counter = 0;
           if(isset($_POST['boxes'])){
               foreach($_POST['boxes'] as $box){
                 $cmd =Yii::app()->db->createCommand();  
                $cmd->insert('boxes_to_be_moved_as_whole_on_platform',
                	array('platform_setting_id'=>$platform_setting_id,
				'box_id'=>$box,
				 'create_time'=>new CDbExpression('NOW()'),
                                 'update_time'=>new CDbExpression('NOW()'),
                                  'created_by'=>Yii::app()->user->id,
                                    'updated_by'=>Yii::app()->user->id,
					
					
			));
                
             $counter = $counter + 1;
            }
           $msg = "These selected boxes & folders will be moved or reassigned as a whole on this platform";
              header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                           "msg"=>$msg
                       ));
               
           }else{
               
                $msg = "There are no boxes &  folders that will be moved or reassigned as a whole on this platform";
              header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                           "msg"=>$msg
                       ));
               
           }
            
 } 
 
 
 
 /**
  * This is the function that add destroyed documents that could be retained on this domain
  */
 public function actionAddDocumentsThatWillBeRetainedAfterDestructionOnPlatform(){
     
     //get the domain policy id
            
            $platform_setting_id = $_POST['id'];
            
                      
            //delete all the infomation about this domain policy on the lookup table
           $cmd =Yii::app()->db->createCommand();  
           $cmd->delete('retained_destroyed_documents_on_platform', 'platform_setting_id=:id', array(':id'=>$platform_setting_id));
           
           //insert the new selected cluster values
           
           $counter = 0;
            if(isset($_POST['documents'])){
                foreach($_POST['documents'] as $document){
                 $cmd =Yii::app()->db->createCommand();  
                $cmd->insert('retained_destroyed_documents_on_platform',
                	array('platform_setting_id'=>$platform_setting_id,
				'document_id'=>$document,
				 'create_time'=>new CDbExpression('NOW()'),
                                 'update_time'=>new CDbExpression('NOW()'),
                                  'created_by'=>Yii::app()->user->id,
                                    'updated_by'=>Yii::app()->user->id,
					
					
			));
                
             $counter = $counter + 1;
            }
           $msg = "These selected destroyed documents are to be retained on this platform";
              header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                           "msg"=>$msg
                       ));
                
            }else{
              $msg = "There are no destroyed document that  will be retained on this platform";
              header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                           "msg"=>$msg
                       ));
                
            }
     
 }
 
 
 //blacklist and whitelist for exchanges
 
 
 
 /**
         * This is the function that adds the balcklists that will be applicable on a box & folder 
         */
        public function actionAddApplicableBlacklistAtExchangeOnPlatform(){
            
             //get the platform_setting_id
            
            $platform_setting_id = $_POST['id'];
            
                      
            //delete all the infomation about this domain policy on the lookup table
           $cmd =Yii::app()->db->createCommand();  
           $cmd->delete('blacklist_at_exchange_on_platform', 'platform_setting_id=:id', array(':id'=>$platform_setting_id));
           
           //insert the new selected cluster values
           
           $counter = 0;
            if(isset($_POST['blacklists'])){
                foreach($_POST['blacklists'] as $blacklist){
                 $cmd =Yii::app()->db->createCommand();  
                $cmd->insert('blacklist_at_exchange_on_platform',
                	array('platform_setting_id'=>$platform_setting_id,
				'blacklist_id'=>$blacklist,
				 'create_time'=>new CDbExpression('NOW()'),
                                 'update_time'=>new CDbExpression('NOW()'),
                                  'created_by'=>Yii::app()->user->id,
                                    'updated_by'=>Yii::app()->user->id,
					
					
			));
                
             $counter = $counter + 1;
            }
           $msg = "The selected blacklist(s) will be applicable on this platform at exchange ";
              header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                           "msg"=>$msg
                       ));
                
            }else{
              $msg = "There are no blacklist that will be applicable on this platform at exchange ";
              header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                           "msg"=>$msg
                       ));
                
            }
            
            
            
            
        }
        
        
        
         /**
         * This is the function that adds the whitelists that will be applicable on a box & folder 
         */
        public function actionAddApplicableWhitelistAtExchangeOnPlatform(){
            
             //get the platform_setting_i
            
            $platform_setting_id = $_POST['id'];
            
                      
            //delete all the infomation about this domain policy on the lookup table
           $cmd =Yii::app()->db->createCommand();  
           $cmd->delete('whitelist_at_exchange_on_platform', 'platform_setting_id=:id', array(':id'=>$platform_setting_id));
           
           //insert the new selected cluster values
           
           $counter = 0;
            if(isset($_POST['whitelists'])){
                foreach($_POST['whitelists'] as $whitelist){
                 $cmd =Yii::app()->db->createCommand();  
                $cmd->insert('whitelist_at_exchange_on_platform',
                	array('platform_setting_id'=>$platform_setting_id,
				'whitelist_id'=>$whitelist,
				 'create_time'=>new CDbExpression('NOW()'),
                                 'update_time'=>new CDbExpression('NOW()'),
                                  'created_by'=>Yii::app()->user->id,
                                    'updated_by'=>Yii::app()->user->id,
					
					
			));
                
             $counter = $counter + 1;
            }
           $msg = "The selected whitelist(s) will be applicable on this platform at exchange ";
              header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                           "msg"=>$msg
                       ));
                
            }else{
              $msg = "There are no whitelist that will be applicable on this platform at exchange";
              header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                           "msg"=>$msg
                       ));
                
            }
            
            
            
            
        }
        
        
         //adding blacklist and whitelist during sharing
        
        
        /**
         * This is the function that adds the balcklists that will be applicable on the platform during sharing 
         */
        public function actionAddApplicableBlacklistAtSharingOnPlatform(){
            
             //get the platform_setting_id
            
            $platform_setting_id = $_POST['id'];
            
                      
            //delete all the infomation about this domain policy on the lookup table
           $cmd =Yii::app()->db->createCommand();  
           $cmd->delete('blacklist_at_sharing_on_platform', 'platform_setting_id=:id', array(':id'=>$platform_setting_id));
           
           //insert the new selected blacklist id
           
           $counter = 0;
            if(isset($_POST['blacklists'])){
                foreach($_POST['blacklists'] as $blacklist){
                 $cmd =Yii::app()->db->createCommand();  
                $cmd->insert('blacklist_at_sharing_on_platform',
                	array('platform_setting_id'=>$platform_setting_id,
				'blacklist_id'=>$blacklist,
				 'create_time'=>new CDbExpression('NOW()'),
                                 'update_time'=>new CDbExpression('NOW()'),
                                  'created_by'=>Yii::app()->user->id,
                                    'updated_by'=>Yii::app()->user->id,
					
					
			));
                
             $counter = $counter + 1;
            }
           $msg = "The selected blacklist(s) will be applicable on this platform at sharing ";
              header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                           "msg"=>$msg
                       ));
                
            }else{
              $msg = "There are no blacklist that will be applicable on this platform at sharing ";
              header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                           "msg"=>$msg
                       ));
                
            }
            
            
            
            
        }
        
        
        
         /**
         * This is the function that adds the whitelists that will be applicable on the platform at sharing
         */
        public function actionAddApplicableWhitelistAtSharingOnPlatform(){
            
             //get the platform_setting_id
            
            $platform_setting_id = $_POST['id'];
            
                      
            //delete all the infomation about this platform_setting on the lookup table
           $cmd =Yii::app()->db->createCommand();  
           $cmd->delete('whitelist_at_sharing_on_platform', 'platform_setting_id=:id', array(':id'=>$platform_setting_id));
           
           //insert the new selected whitelists
           
           $counter = 0;
            if(isset($_POST['whitelists'])){
                foreach($_POST['whitelists'] as $whitelist){
                 $cmd =Yii::app()->db->createCommand();  
                $cmd->insert('whitelist_at_sharing_on_platform',
                	array('platform_setting_id'=>$platform_setting_id,
				'whitelist_id'=>$whitelist,
				 'create_time'=>new CDbExpression('NOW()'),
                                 'update_time'=>new CDbExpression('NOW()'),
                                  'created_by'=>Yii::app()->user->id,
                                    'updated_by'=>Yii::app()->user->id,
					
					
			));
                
             $counter = $counter + 1;
            }
           $msg = "The selected whitelist(s) will be applicable on this platform at sharing ";
              header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                           "msg"=>$msg
                       ));
                
            }else{
              $msg = "There are no whitelist that will be applicable on this platform at sharing";
              header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                           "msg"=>$msg
                       ));
                
            }
            
            
            
            
        }
        
        
        
        
        //adding blacklist and whitelist at transfers
        
        
        /**
         * This is the function that adds the balcklists that will be applicable on the platform during transfer 
         */
        public function actionAddApplicableBlacklistsAtTransfersOnPlatform(){
            
             //get the platform_setting_id
            
            $platform_setting_id = $_POST['id'];
            
                      
            //delete all the infomation about this platform_settings on the lookup table
           $cmd =Yii::app()->db->createCommand();  
           $cmd->delete('blacklist_at_transfer_on_platform', 'platform_setting_id=:id', array(':id'=>$platform_setting_id));
           
           //insert the new selected blacklist id
           
           $counter = 0;
            if(isset($_POST['blacklists'])){
                foreach($_POST['blacklists'] as $blacklist){
                 $cmd =Yii::app()->db->createCommand();  
                $cmd->insert('blacklist_at_transfer_on_platform',
                	array('platform_setting_id'=>$platform_setting_id,
				'blacklist_id'=>$blacklist,
				 'create_time'=>new CDbExpression('NOW()'),
                                 'update_time'=>new CDbExpression('NOW()'),
                                  'created_by'=>Yii::app()->user->id,
                                    'updated_by'=>Yii::app()->user->id,
					
					
			));
                
             $counter = $counter + 1;
            }
           $msg = "The selected blacklist(s) will be applicable on this platform at transfers ";
              header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                           "msg"=>$msg
                       ));
                
            }else{
              $msg = "There are no blacklist that will be applicable on this platform at transfers ";
              header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                           "msg"=>$msg
                       ));
                
            }
            
            
            
            
        }
        
        
        
         /**
         * This is the function that adds the whitelists that will be applicable on the platform at transfers
         */
        public function actionAddApplicableWhitelistsAtTransfersOnPlatform(){
            
             //get the platform_setting_id
            
            $platform_setting_id = $_POST['id'];
            
                      
            //delete all the infomation about this platform_setting on the lookup table
           $cmd =Yii::app()->db->createCommand();  
           $cmd->delete('whitelist_at_transfer_on_platform', 'platform_setting_id=:id', array(':id'=>$platform_setting_id));
           
           //insert the new selected whitelists          
           $counter = 0;
            if(isset($_POST['whitelists'])){
                foreach($_POST['whitelists'] as $whitelist){
                 $cmd =Yii::app()->db->createCommand();  
                $cmd->insert('whitelist_at_transfer_on_platform',
                	array('platform_setting_id'=>$platform_setting_id,
				'whitelist_id'=>$whitelist,
				 'create_time'=>new CDbExpression('NOW()'),
                                 'update_time'=>new CDbExpression('NOW()'),
                                  'created_by'=>Yii::app()->user->id,
                                    'updated_by'=>Yii::app()->user->id,
					
					
			));
                
             $counter = $counter + 1;
            }
           $msg = "The selected whitelist(s) will be applicable on this platform at transfer ";
              header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                           "msg"=>$msg
                       ));
                
            }else{
              $msg = "There are no whitelist that will be applicable on this platform at transfer";
              header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                           "msg"=>$msg
                       ));
                
            }
            
            
            
            
        }
        
        
        
        
         //adding blacklist and whitelist at tradings
        
        
        /**
         * This is the function that adds the balcklists that will be applicable on a domian during tradings 
         */
        public function actionAddApplicableBlacklistAtTradingOnPlatform(){
            
             //get the platform_setting_id
            
            $platform_setting_id = $_POST['id'];
            
                      
            //delete all the infomation about this domain policy on the lookup table
           $cmd =Yii::app()->db->createCommand();  
           $cmd->delete('blacklist_at_trading_on_platform', 'platform_setting_id=:id', array(':id'=>$platform_setting_id));
           
           //insert the new selected blacklist id
           
           $counter = 0;
            if(isset($_POST['blacklists'])){
                foreach($_POST['blacklists'] as $blacklist){
                 $cmd =Yii::app()->db->createCommand();  
                $cmd->insert('blacklist_at_trading_on_platform',
                	array('platform_setting_id'=>$platform_setting_id,
				'blacklist_id'=>$blacklist,
				 'create_time'=>new CDbExpression('NOW()'),
                                 'update_time'=>new CDbExpression('NOW()'),
                                  'created_by'=>Yii::app()->user->id,
                                    'updated_by'=>Yii::app()->user->id,
					
					
			));
                
             $counter = $counter + 1;
            }
           $msg = "The selected blacklist(s) will be applicable on this platform at tradings ";
              header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                           "msg"=>$msg
                       ));
                
            }else{
              $msg = "There are no blacklist that will be applicable on this platform at tradings ";
              header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                           "msg"=>$msg
                       ));
                
            }
            
            
            
            
        }
        
        
        
         /**
         * This is the function that adds the whitelists that will be applicable on a domain at tradings
         */
        public function actionAddApplicableWhitelistAtTradingOnPlatform(){
            
             //get the platform_setting_id
            
            $platform_setting_id = $_POST['id'];
            
                      
            //delete all the infomation about this platform_settings on the lookup table
           $cmd =Yii::app()->db->createCommand();  
           $cmd->delete('whitelist_at_trading_on_platform', 'platform_setting_id=:id', array(':id'=>$platform_setting_id));
           
           //insert the new selected whitelists
           
           $counter = 0;
            if(isset($_POST['whitelists'])){
                foreach($_POST['whitelists'] as $whitelist){
                 $cmd =Yii::app()->db->createCommand();  
                $cmd->insert('whitelist_at_trading_on_platform',
                	array('platform_setting_id'=>$platform_setting_id,
				'whitelist_id'=>$whitelist,
				 'create_time'=>new CDbExpression('NOW()'),
                                 'update_time'=>new CDbExpression('NOW()'),
                                  'created_by'=>Yii::app()->user->id,
                                    'updated_by'=>Yii::app()->user->id,
					
					
			));
                
             $counter = $counter + 1;
            }
           $msg = "The selected whitelist(s) will be applicable on this platform at tradings ";
              header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                           "msg"=>$msg
                       ));
                
            }else{
              $msg = "There are no whitelist that will be applicable on this platform at tradings";
              header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                           "msg"=>$msg
                       ));
                
            }
            
            
            
            
        }
        
        
        
        
        //adding blacklist and whitelist at request
        
        
        /**
         * This is the function that adds the balcklists that will be applicable on the platform during request 
         */
        public function actionAddApplicableBlacklistAtRequestOnPlatform(){
            
             //get the platform_setting
            
            $platform_setting_id = $_POST['id'];
            
                      
            //delete all the infomation about this platform_settings on the lookup table
           $cmd =Yii::app()->db->createCommand();  
           $cmd->delete('blacklist_at_request_on_platform', 'platform_setting_id=:id', array(':id'=>$platform_setting_id));
           
           //insert the new selected blacklist id
           
           $counter = 0;
            if(isset($_POST['blacklists'])){
                foreach($_POST['blacklists'] as $blacklist){
                 $cmd =Yii::app()->db->createCommand();  
                $cmd->insert('blacklist_at_request_on_platform',
                	array('platform_setting_id'=>$platform_setting_id,
				'blacklist_id'=>$blacklist,
				 'create_time'=>new CDbExpression('NOW()'),
                                 'update_time'=>new CDbExpression('NOW()'),
                                  'created_by'=>Yii::app()->user->id,
                                    'updated_by'=>Yii::app()->user->id,
					
					
			));
                
             $counter = $counter + 1;
            }
           $msg = "The selected blacklist(s) will be applicable on this platform at request ";
              header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                           "msg"=>$msg
                       ));
                
            }else{
              $msg = "There are no blacklist that will be applicable on this platform at request ";
              header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                           "msg"=>$msg
                       ));
                
            }
            
            
            
            
        }
        
        
        
         /**
         * This is the function that adds the whitelists that will be applicable on a domain at request
         */
        public function actionAddApplicableWhitelistAtRequestOnPlatform(){
            
             //get the platform_setting
            
            $platform_setting_id = $_POST['id'];
            
                      
            //delete all the infomation about this platform_setting on the lookup table
           $cmd =Yii::app()->db->createCommand();  
           $cmd->delete('whitelist_at_request_on_platform', 'platform_setting_id=:id', array(':id'=>$platform_setting_id));
           
           //insert the new selected whitelists
           
           $counter = 0;
            if(isset($_POST['whitelists'])){
                foreach($_POST['whitelists'] as $whitelist){
                 $cmd =Yii::app()->db->createCommand();  
                $cmd->insert('whitelist_at_request_on_platform',
                	array('platform_setting_id'=>$platform_setting_id,
				'whitelist_id'=>$whitelist,
				 'create_time'=>new CDbExpression('NOW()'),
                                 'update_time'=>new CDbExpression('NOW()'),
                                  'created_by'=>Yii::app()->user->id,
                                    'updated_by'=>Yii::app()->user->id,
					
					
			));
                
             $counter = $counter + 1;
            }
           $msg = "The selected whitelist(s) will be applicable on this platform at request ";
              header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                           "msg"=>$msg
                       ));
                
            }else{
              $msg = "There are no whitelist that will be applicable on this platform at request";
              header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                           "msg"=>$msg
                       ));
                
            }
            
            
            
            
        }
 
        
        
        //adding blacklist and whitelist at consumption
        
        
        /**
         * This is the function that adds the balcklists that will be applicable on the platform during consumption 
         */
        public function actionAddApplicableBlacklistAtConsumptionOnPlatform(){
            
             //get the platform_setting
            
            $platform_setting_id = $_POST['id'];
            
                      
            //delete all the infomation about this domain policy on the lookup table
           $cmd =Yii::app()->db->createCommand();  
           $cmd->delete('blacklist_at_consumption_on_platform', 'platform_setting_id=:id', array(':id'=>$platform_setting_id));
           
           //insert the new selected blacklist id
           
           $counter = 0;
            if(isset($_POST['blacklists'])){
                foreach($_POST['blacklists'] as $blacklist){
                 $cmd =Yii::app()->db->createCommand();  
                $cmd->insert('blacklist_at_consumption_on_platform',
                	array('platform_setting_id'=>$platform_setting_id,
				'blacklist_id'=>$blacklist,
				 'create_time'=>new CDbExpression('NOW()'),
                                 'update_time'=>new CDbExpression('NOW()'),
                                  'created_by'=>Yii::app()->user->id,
                                    'updated_by'=>Yii::app()->user->id,
					
					
			));
                
             $counter = $counter + 1;
            }
           $msg = "The selected blacklist(s) will be applicable on this platform at consumption ";
              header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                           "msg"=>$msg
                       ));
                
            }else{
              $msg = "There are no blacklist that will be applicable on this platform at consumption ";
              header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                           "msg"=>$msg
                       ));
                
            }
            
            
            
            
        }
        
        
        
         /**
         * This is the function that adds the whitelists that will be applicable on the platform at consumption
         */
        public function actionAddApplicableWhitelistAtConsumptionOnPlatform(){
            
             //get the platform_setting_id
            
            $platform_setting_id = $_POST['id'];
            
                      
            //delete all the infomation about this platform_settings on the lookup table
           $cmd =Yii::app()->db->createCommand();  
           $cmd->delete('whitelist_at_consumption_on_platform', 'platform_setting_id=:id', array(':id'=>$platform_setting_id));
           
           //insert the new selected whitelists
           
           $counter = 0;
            if(isset($_POST['whitelists'])){
                foreach($_POST['whitelists'] as $whitelist){
                 $cmd =Yii::app()->db->createCommand();  
                $cmd->insert('whitelist_at_consumption_on_platform',
                	array('platform_setting_id'=>$platform_setting_id,
				'whitelist_id'=>$whitelist,
				 'create_time'=>new CDbExpression('NOW()'),
                                 'update_time'=>new CDbExpression('NOW()'),
                                  'created_by'=>Yii::app()->user->id,
                                    'updated_by'=>Yii::app()->user->id,
					
					
			));
                
             $counter = $counter + 1;
            }
           $msg = "The selected whitelist(s) will be applicable on this platform at consumption ";
              header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                           "msg"=>$msg
                       ));
                
            }else{
              $msg = "There are no whitelist that will be applicable on this platform at consumption";
              header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                           "msg"=>$msg
                       ));
                
            }
            
            
            
            
        }
        
        
        
        //adding blacklist and whitelist at movement
        
        
        /**
         * This is the function that adds the balcklists that will be applicable on a domian during movement 
         */
        public function actionAddApplicableBlacklistAtMovementOnPlatform(){
            
             //get the platform_setting_id
            
            $platform_setting_id = $_POST['id'];
            
                      
            //delete all the infomation about this platform_settings on the lookup table
           $cmd =Yii::app()->db->createCommand();  
           $cmd->delete('blacklist_at_movement_on_platform', 'platform_setting_id=:id', array(':id'=>$platform_setting_id));
           
           //insert the new selected blacklist id
           
           $counter = 0;
            if(isset($_POST['blacklists'])){
                foreach($_POST['blacklists'] as $blacklist){
                 $cmd =Yii::app()->db->createCommand();  
                $cmd->insert('blacklist_at_movement_on_platform',
                	array('platform_setting_id'=>$platform_setting_id,
				'blacklist_id'=>$blacklist,
				 'create_time'=>new CDbExpression('NOW()'),
                                 'update_time'=>new CDbExpression('NOW()'),
                                  'created_by'=>Yii::app()->user->id,
                                    'updated_by'=>Yii::app()->user->id,
					
					
			));
                
             $counter = $counter + 1;
            }
           $msg = "The selected blacklist(s) will be applicable on this platform at movement ";
              header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                           "msg"=>$msg
                       ));
                
            }else{
              $msg = "There are no blacklist that will be applicable on this platform at movement ";
              header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                           "msg"=>$msg
                       ));
                
            }
            
            
            
            
        }
        
        
        
         /**
         * This is the function that adds the whitelists that will be applicable on the platform at movement
         */
        public function actionAddApplicableWhitelistAtMovementOnPlatform(){
            
             //get the platform_setting_id
            
            $platform_setting_id = $_POST['id'];
            
                      
            //delete all the infomation about this platform_settings on the lookup table
           $cmd =Yii::app()->db->createCommand();  
           $cmd->delete('whitelist_at_movement_on_platform', 'platform_setting_id=:id', array(':id'=>$platform_setting_id));
           
           //insert the new selected whitelists
           
           $counter = 0;
            if(isset($_POST['whitelists'])){
                foreach($_POST['whitelists'] as $whitelist){
                 $cmd =Yii::app()->db->createCommand();  
                $cmd->insert('whitelist_at_movement_on_platform',
                	array('platform_setting_id'=>$platform_setting_id,
				'whitelist_id'=>$whitelist,
				 'create_time'=>new CDbExpression('NOW()'),
                                 'update_time'=>new CDbExpression('NOW()'),
                                  'created_by'=>Yii::app()->user->id,
                                    'updated_by'=>Yii::app()->user->id,
					
					
			));
                
             $counter = $counter + 1;
            }
           $msg = "The selected whitelist(s) will be applicable on this platform at movement ";
              header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                           "msg"=>$msg
                       ));
                
            }else{
              $msg = "There are no whitelist that will be applicable on this platform at movement";
              header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                           "msg"=>$msg
                       ));
                
            }
            
            
            
            
        }
        
        
        
        
         //adding blacklist and whitelist at destruction
        
        
        /**
         * This is the function that adds the balcklists that will be applicable on the pltaform during destruction 
         */
        public function actionAddApplicableBlacklistAtDestructionOnPlatform(){
            
             //get the platform_setting_id
            
            $platform_setting_id = $_POST['id'];
            
                      
            //delete all the infomation about this platform_settings on the lookup table
           $cmd =Yii::app()->db->createCommand();  
           $cmd->delete('blacklist_at_destruction_on_platform', 'platform_setting_id=:id', array(':id'=>$platform_setting_id));
           
           //insert the new selected blacklist id
           
           $counter = 0;
            if(isset($_POST['blacklists'])){
                foreach($_POST['blacklists'] as $blacklist){
                 $cmd =Yii::app()->db->createCommand();  
                $cmd->insert('blacklist_at_destruction_on_platform',
                	array('platform_setting_id'=>$platform_setting_id,
				'blacklist_id'=>$blacklist,
				 'create_time'=>new CDbExpression('NOW()'),
                                 'update_time'=>new CDbExpression('NOW()'),
                                  'created_by'=>Yii::app()->user->id,
                                    'updated_by'=>Yii::app()->user->id,
					
					
			));
                
             $counter = $counter + 1;
            }
           $msg = "The selected blacklist(s) will be applicable on this platform at destruction ";
              header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                           "msg"=>$msg
                       ));
                
            }else{
              $msg = "There are no blacklist that will be applicable on this platform at destruction ";
              header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                           "msg"=>$msg
                       ));
                
            }
            
            
            
            
        }
        
        
        
         /**
         * This is the function that adds the whitelists that will be applicable on the platform at destruction
         */
        public function actionAddApplicableWhitelistAtDestructionOnPlatform(){
            
             //get the platform_setting_id
            
            $platform_setting_id = $_POST['id'];
            
                      
            //delete all the infomation about this platform_settings on the lookup table
           $cmd =Yii::app()->db->createCommand();  
           $cmd->delete('whitelist_at_destruction_on_platform', 'platform_setting_id=:id', array(':id'=>$platform_setting_id));
           
           //insert the new selected whitelist values
           
           $counter = 0;
            if(isset($_POST['whitelists'])){
                foreach($_POST['whitelists'] as $whitelist){
                 $cmd =Yii::app()->db->createCommand();  
                $cmd->insert('whitelist_at_destruction_on_platform',
                	array('platform_setting_id'=>$platform_setting_id,
				'whitelist_id'=>$whitelist,
				 'create_time'=>new CDbExpression('NOW()'),
                                 'update_time'=>new CDbExpression('NOW()'),
                                  'created_by'=>Yii::app()->user->id,
                                    'updated_by'=>Yii::app()->user->id,
					
					
			));
                
             $counter = $counter + 1;
            }
           $msg = "The selected whitelist(s) will be applicable on this platform at destruction ";
              header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                           "msg"=>$msg
                       ));
                
            }else{
              $msg = "There are no whitelist that will be applicable on this platform at destruction";
              header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                           "msg"=>$msg
                       ));
                
            }
            
            
            
            
        }
        
        //lifespan for document types
        /**
         * this is the function that retrieves the lifespan from document type on a platform
         */
        public function actionretrieveTheLifespanOfThisDocumentType(){
            
            $platform_setting_id = $_POST['id'];
            
            $document_type_id = $_POST['document_type_id'];
            
             $criteria2 = new CDbCriteria();
             $criteria2->select = '*';
             $criteria2->condition='platform_setting_id=:setting and document_type_id=:type';
             $criteria2->params = array(':setting'=>$platform_setting_id,':type'=>$document_type_id);
             $lifespan = DocumenttypeApprovedLifespanOnPlatform::model()->find($criteria2);
             
              header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                           "lifespan"=>$lifespan['lifespan']
                       ));
             
            
        }
        
        
        
         /**
         * This is the function that adds the lifespan to document types on platform
         */
        public function actionAssignThisLifespanToThisDocumentTypeOnPlatform(){
            
             //get the domain policy id
            
            $platform_setting_id = $_POST['id'];
            $document_type_id = $_POST['document_type_id'];
            
                      
            //delete this current lifespan assigbment from the table
           $cmd =Yii::app()->db->createCommand();  
           $cmd->delete('documenttype_approved_lifespan_on_platform', '(platform_setting_id=:id and document_type_id=:type)', array(':id'=>$platform_setting_id, ':type'=>$document_type_id));
           
           //insert the new record into the table
              $cmd =Yii::app()->db->createCommand();  
                $result = $cmd->insert('documenttype_approved_lifespan_on_platform',
                	array('platform_setting_id'=>$platform_setting_id,
				'document_type_id'=>$document_type_id,
                                'lifespan'=>$_POST['lifespan'],
				 'create_time'=>new CDbExpression('NOW()'),
                                 'update_time'=>new CDbExpression('NOW()'),
                                  'created_by'=>Yii::app()->user->id,
                                    'updated_by'=>Yii::app()->user->id,
					
					
			));
                
                
              $msg = " A new lifespan had been given to that document type on the platform ";
              header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                           "msg"=>$msg
                       ));
               
             
                
            }
            
            
            /**
             * Remove lifespan from a document type
             */
            public function actionRemoveLifespanFromDocumentType(){
                
                //get the platform_setting_id
            
            $platform_setting_id = $_POST['id'];
            $document_type_id = $_POST['document_type_id'];
            
                      
            //delete this current lifespan assigbment from the table
           $cmd =Yii::app()->db->createCommand();  
           $result = $cmd->delete('documenttype_approved_lifespan_on_platform', '(platform_setting_id=:id and document_type_id=:type)', array(':id'=>$platform_setting_id, ':type'=>$document_type_id));
           
           if($result>0){
              $msg = " The existing lifespan had been removed from the document type ";
              header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                           "msg"=>$msg
                       ));
               
           }else{
               $msg = " The removal of the existing lifespan from the document type was not successful or there was no lifespan assigned to the document type ";
               header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                           "msg"=>$msg
                       ));
           }
                
                
            }
            
            
            //lifespan for document category
            
            /**
         * this is the function that retrieves the lifespan from document type on a platform
         */
        public function actionretrieveTheLifespanOfThisDocumentCategory(){
            
            $platform_setting_id = $_POST['id'];
            
            $document_category_id = $_POST['document_category_id'];
            
             $criteria2 = new CDbCriteria();
             $criteria2->select = '*';
             $criteria2->condition='platform_setting_id=:setting and document_category_id=:category';
             $criteria2->params = array(':setting'=>$platform_setting_id,':category'=>$document_category_id);
             $lifespan = DocumentcategoriesApprovedLifespanOnPlatform::model()->find($criteria2);
             
              header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                           "lifespan"=>$lifespan['lifespan']
                       ));
             
            
        }
        
        
        
         /**
         * This is the function that adds the lifespan to document types on platform
         */
        public function actionAssignThisLifespanToThisDocumentCategoryOnPlatform(){
            
             //get the domain policy id
            
            $platform_setting_id = $_POST['id'];
            $document_category_id = $_POST['document_category_id'];
            
                      
            //delete this current lifespan assigbment from the table
           $cmd =Yii::app()->db->createCommand();  
           $cmd->delete('documentcategories_approved_lifespan_on_platform', '(platform_setting_id=:id and document_category_id=:category)', array(':id'=>$platform_setting_id, ':category'=>$document_category_id));
           
           //insert the new record into the table
              $cmd =Yii::app()->db->createCommand();  
                $result = $cmd->insert('documentcategories_approved_lifespan_on_platform',
                	array('platform_setting_id'=>$platform_setting_id,
				'document_category_id'=>$document_category_id,
                                'lifespan'=>$_POST['lifespan'],
				 'create_time'=>new CDbExpression('NOW()'),
                                 'update_time'=>new CDbExpression('NOW()'),
                                  'created_by'=>Yii::app()->user->id,
                                    'updated_by'=>Yii::app()->user->id,
					
					
			));
                
                
              $msg = " A new lifespan had been assigned to that document category on the platform ";
              header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                           "msg"=>$msg
                       ));
               
             
                
            }
            
            
            /**
             * Remove lifespan from a document category
             */
            public function actionRemoveLifespanFromDocumentCategory(){
                
                //get the platform_setting_id
            
            $platform_setting_id = $_POST['id'];
            $document_category_id = $_POST['document_category_id'];
            
                      
            //delete this current lifespan assigbment from the table
           $cmd =Yii::app()->db->createCommand();  
           $result = $cmd->delete('documentcategories_approved_lifespan_on_platform', '(platform_setting_id=:id and document_category_id=:category)', array(':id'=>$platform_setting_id, ':category'=>$document_category_id));
           
           if($result>0){
              $msg = " The existing lifespan had been removed from the document category ";
              header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                           "msg"=>$msg
                       ));
               
           }else{
               $msg = " The removal of the existing lifespan from the document category was not successful or there was no existing lifespan assigned to the document category ";
               header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                           "msg"=>$msg
                       ));
           }
                
                
            }
 
}
