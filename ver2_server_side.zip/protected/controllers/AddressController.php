<?php

class AddressController extends Controller
{
	/**
	 * @var string the default layout for the views. Defaults to '//layouts/column2', meaning
	 * using two-column layout. See 'protected/views/layouts/column2.php'.
	 */
	public $layout='//layouts/column2';

	/**
	 * @return array action filters
	 */
	public function filters()
	{
		return array(
			'accessControl', // perform access control for CRUD operations
			'postOnly + delete', // we only allow deletion via POST request
		);
	}

	/**
	 * Specifies the access control rules.
	 * This method is used by the 'accessControl' filter.
	 * @return array access control rules
	 */
	public function accessRules()
	{
		return array(
			array('allow',  // allow all users to perform 'index' and 'view' actions
				'actions'=>array('index','view'),
				'users'=>array('*'),
			),
			array('allow', // allow authenticated user to perform 'create' and 'update' actions
				'actions'=>array('create','update','addanewaddress','deleteaddress','retrieveextraaddressinfo','updateaddress','listAllAddresses',
                                    'listAlladdressforthisstreet','searchingforanaddress','addanewstreetaddress','requestforaddressverification',
                                    'preverifyinganaddress','verifyingthisverificationtionrequest'),
				'users'=>array('@'),
			),
			array('allow', // allow admin user to perform 'admin' and 'delete' actions
				'actions'=>array('admin','delete'),
				'users'=>array('admin'),
			),
			array('deny',  // deny all users
				'users'=>array('*'),
			),
		);
	}

	/**
         * This is the function that adds new streets
         */
        public function actionaddanewaddress(){
            
            $model=new Address;

                $model->house_number = $_POST['house_number'];
                $model->street_id = $_POST['streetname'];
                 if(isset($_POST['structure_type'])){
                   $model->structure_type = $_POST['structure_type']; 
                }
                 if(isset($_POST['premises_layout'])){
                   $model->premises_layout = $_POST['premises_layout']; 
                }
                  if(isset($_POST['building_colour'])){
                   $model->building_colour = $_POST['building_colour']; 
                }
                if(isset($_POST['building_room_layout'])){
                   $model->building_room_layout = $_POST['building_room_layout']; 
                }
                 if(isset($_POST['building_purpose'])){
                   $model->building_purpose = $_POST['building_purpose']; 
                }
                 if(isset($_POST['is_compound_gated'])){
                   $model->is_compound_gated = $_POST['is_compound_gated']; 
                }
                 if(isset($_POST['compound_gate_colour'])){
                   $model->compound_gate_colour = $_POST['compound_gate_colour']; 
                }
                 if(isset($_POST['nearest_busstop'])){
                   $model->nearest_busstop = $_POST['nearest_busstop']; 
                }
                  if(isset($_POST['first_landmark'])){
                   $model->first_landmark = $_POST['first_landmark']; 
                }
                if(isset($_POST['second_landmark'])){
                   $model->second_landmark = $_POST['second_landmark']; 
                }
                if(isset($_POST['other_landmark'])){
                   $model->other_landmark = $_POST['other_landmark']; 
                }
                 if(isset($_POST['building_condition'])){
                   $model->building_condition = $_POST['building_condition']; 
                }
                 if(isset($_POST['building_fence_status'])){
                   $model->building_fence_status = $_POST['building_fence_status']; 
                }
                 if(isset($_POST['electricity_metering_type'])){
                   $model->electricity_metering_type = $_POST['electricity_metering_type']; 
                }
                  if(isset($_POST['compound_has_active_security_person'])){
                   $model->compound_has_active_security_person = $_POST['compound_has_active_security_person']; 
                }
                $model->create_time = new CDbExpression('NOW()');
                $model->create_user_id = Yii::app()->user->id;
               if($model->save()){
                         // $result['success'] = 'true';
                          $msg = 'New Address Successfully Created';
                          header('Content-Type: application/json');
                          echo CJSON::encode(array(
                                    "success" => mysql_errno() == 0,
                                        "msg" => $msg)
                           );
                 }else {
                         //$result['success'] = 'false';
                         $msg = 'Creation of a new address was unsuccessful';
                         header('Content-Type: application/json');
                         echo CJSON::encode(array(
                                    "success" => mysql_errno() != 0,
                                        "msg" => $msg)
                           );
                  }  
            
            
            
        }
        
        
        
         /**
         * This is the function that updates street information
         */
        public function actionupdateaddress(){
            
           //get the city id
            $street = $_POST['streetname'];
          
            
            $_id = $_POST['id'];
            $model=  Address::model()->findByPk($_id);
          if(is_numeric($street)) {
                $model->street_id = $street;
                
            }else{
                              
                $model->street_id = $_POST['street_id'];
                
                
            }
          
             $model->house_number = $_POST['house_number'];
                if(isset($_POST['structure_type'])){
                   $model->structure_type = $_POST['structure_type']; 
                }
                 if(isset($_POST['premises_layout'])){
                   $model->premises_layout = $_POST['premises_layout']; 
                }
                  if(isset($_POST['building_colour'])){
                   $model->building_colour = $_POST['building_colour']; 
                }
                if(isset($_POST['building_room_layout'])){
                   $model->building_room_layout = $_POST['building_room_layout']; 
                }
                 if(isset($_POST['building_purpose'])){
                   $model->building_purpose = $_POST['building_purpose']; 
                }
                 if(isset($_POST['is_compound_gated'])){
                   $model->is_compound_gated = $_POST['is_compound_gated']; 
                }
                 if(isset($_POST['compound_gate_colour'])){
                   $model->compound_gate_colour = $_POST['compound_gate_colour']; 
                }
                 if(isset($_POST['nearest_busstop'])){
                   $model->nearest_busstop = $_POST['nearest_busstop']; 
                }
                  if(isset($_POST['first_landmark'])){
                   $model->first_landmark = $_POST['first_landmark']; 
                }
                if(isset($_POST['second_landmark'])){
                   $model->second_landmark = $_POST['second_landmark']; 
                }
                if(isset($_POST['other_landmark'])){
                   $model->other_landmark = $_POST['other_landmark']; 
                }
                 if(isset($_POST['building_condition'])){
                   $model->building_condition = $_POST['building_condition']; 
                }
                 if(isset($_POST['building_fence_status'])){
                   $model->building_fence_status = $_POST['building_fence_status']; 
                }
                 if(isset($_POST['electricity_metering_type'])){
                   $model->electricity_metering_type = $_POST['electricity_metering_type']; 
                }
                  if(isset($_POST['compound_has_active_security_person'])){
                   $model->compound_has_active_security_person = $_POST['compound_has_active_security_person']; 
                }
               
                $model->update_time = new CDbExpression('NOW()');
                $model->update_user_id = Yii::app()->user->id;
               if($model->save()){
                         // $result['success'] = 'true';
                          $msg = 'Address information was updated successfully';
                          header('Content-Type: application/json');
                          echo CJSON::encode(array(
                                    "success" => mysql_errno() == 0,
                                        "msg" => $msg)
                           );
                 }else {
                         //$result['success'] = 'false';
                         $msg = 'The update of this address information was not successful';
                         header('Content-Type: application/json');
                         echo CJSON::encode(array(
                                    "success" => mysql_errno() != 0,
                                        "msg" => $msg)
                           );
                  } 
            
            
            
        }
        
        
         /**
         * This is the function that deletes an address
         */
        public function actiondeleteaddress(){
            
            $_id = $_POST['id'];
            $model=Address::model()->findByPk($_id);
           
                $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition='id=:id';
                $criteria->params = array(':id'=>$_id);
                $address= Address::model()->find($criteria);
                
                $addressnumber = $address['house_number'];
                
                $streetname = $this->getTheNameOfThisStreet($address['street_id']);
            
            
            if($model === null){
                $data['success'] = 'undefined';
                $data['msg'] = 'No such record exist';
                header('Content-Type: application/json');
                echo CJSON::encode($data);
                                      
            }else if($model->delete()){
                    $data['success'] = 'true';
                    $data['msg'] = "Number '$addressnumber'  of '$streetname is successfully deleted";
                     header('Content-Type: application/json');
                    echo CJSON::encode($data);
            } else {
                    $data['success'] = 'false';
                    $data['msg'] = "Attempt to delete '$addressnumber'  of '$streetname wss  not successful";
                     header('Content-Type: application/json');
                    echo CJSON::encode($data);
                            
                }
            
        }
        
        
        
         /**
         * This is the function that gets a street name
         */
        public function getTheNameOfThisStreet($id){
            $model = new Street;
            return $model->getTheNameOfThisStreet($id);
        }
        
        
        
         /**
         * This is the function that list all addresses
         */
        public function actionlistAllAddresses(){
            
            $address = Address::model()->findAll();
                if($address===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            "address" => $address)
                       );
                       
                }
        }
        
        
        
        /**
         * This is the function that retrieves extra info for an address
         */
        public function actionretrieveextraaddressinfo(){
            
            $model = new State;
            $street_id = $_REQUEST['street_id'];
            
            //get the name of the 
             $criteria = new CDbCriteria();
             $criteria->select = '*';
             $criteria->condition='id=:id';
             $criteria->params = array(':id'=>$street_id);
             $street= Street::model()->find($criteria);
             
             
             //get the city details
             
             $criteria = new CDbCriteria();
             $criteria->select = '*';
             $criteria->condition='id=:id';
             $criteria->params = array(':id'=>$street['city_id']);
             $city= City::model()->find($criteria);
             
             $countryname = $model->getTheCountryOfThisState($city['state_id']);
             
             $countryname = $model->getTheCountryOfThisState($city['state_id']);
             
             $statename = $model->getTheNameOfThisState($city['state_id']);
             
             $cityname = $city['name'];
             
             $streetname = $street['name'];
             
             if($street===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            "statename" => $statename,
                           "countryname"=>$countryname,
                           "cityname"=>$cityname,
                           "streetname"=>$streetname)
                       );
                       
                }
            
            
        }
        
        
        /**
         * This is the function that list all address for a street
         */
        public function actionlistAlladdressforthisstreet(){
            
            $street_id = $_REQUEST['street_id'];
            
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='street_id=:id';
            $criteria->params = array(':id'=>$street_id);
            $address= Address::model()->findAll($criteria);
            
            if($address===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            "address" => $address)
                       );
                       
                }
        }
        
        
        /**
         * This is the function that searches for a street address
         */
        public function actionsearchingforanaddress(){
            
            $model = new AddressVerificationConsumptionRequest;
            
            $user_id = Yii::app()->user->id;
            
            $domain_id = $this->determineAUserDomainIdGiven($user_id);
            
                        
            $street_id = $_REQUEST['street_id'];
            $address_id = $_REQUEST['address_id'];
            $city_id = $_REQUEST['city_id'];
            $state_id = $_REQUEST['state_id'];
            
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='id=:id';
            $criteria->params = array(':id'=>$state_id);
            $state= State::model()->find($criteria);
            
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='id=:id';
            $criteria->params = array(':id'=>$city_id);
            $city= City::model()->find($criteria);
            
            
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='id=:id';
            $criteria->params = array(':id'=>$street_id);
            $street= Street::model()->find($criteria);
            
            
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='id=:id';
            $criteria->params = array(':id'=>$address_id);
            $address= Address::model()->find($criteria);
            
            if($model->isTheConsumptionOfThisVerificationRequestASuccess($user_id,$address_id,$domain_id,$address['is_verified'])){
                 header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            "address" => $address,
                           "city"=>$city,
                            "state"=>$state,
                           "street"=>$street)
                       );
                
                
            }else{
                
                //$result['success'] = 'false';
                         $msg = 'It appears you are having some challenges trying to execute this request. Please kindly contact customer service for assistance';
                         header('Content-Type: application/json');
                         echo CJSON::encode(array(
                                    "success" => mysql_errno() != 0,
                                        "msg" => $msg)
                           );
            }
            
           
        }
        
        /**
         * This is the function that adds a new street address
         */
        public function actionaddanewstreetaddress(){
            
            $model = new Address;
            $street_id = $_REQUEST['street_id'];
            $house_number = $_REQUEST['house_number'];
            
            if($model->isHouseNumberAlreadyAvailable($street_id,$house_number) == false){
                $model->house_number =$house_number;
                $model->street_id = $street_id;
                $model->create_time = new CDbExpression('NOW()');
                $model->create_user_id = Yii::app()->user->id;
               if($model->save()){
                         // $result['success'] = 'true';
                          $msg = 'New Aaddress number is successfully added';
                          header('Content-Type: application/json');
                          echo CJSON::encode(array(
                                    "success" => mysql_errno() == 0,
                                        "msg" => $msg)
                           );
                 }else {
                         //$result['success'] = 'false';
                         $msg = 'The attempt to add this number to this street was not successful';
                         header('Content-Type: application/json');
                         echo CJSON::encode(array(
                                    "success" => mysql_errno() != 0,
                                        "msg" => $msg)
                           );
                  }  
                
                
            }else{
                
                 header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                            "msg" => "This house number is already available for this street. Please kindly select it and continue searching"
                         )
                       );
            }
            
        }
        
        
       /**
         * This is the function that retrieves domain id of a user
         */
        public function determineAUserDomainIdGiven($user_id){
            $model = new User;
            return $model->determineAUserDomainIdGiven($user_id);
        }
       
        
        
        /**
         * This is the function that preverifies an address
         */
        public function actionpreverifyinganaddress(){
            
             $model = new Address;
            $id = $_REQUEST['id'];
            if($model->isTheVerificationOfThisAddressASuccess($id)){
                 header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            "msg" =>"This address verification request is successful"
            
                       ));
            }else{
                 header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                            "msg" =>"The attempt to verify this address is not successfully. Please contact customer service for assistance"
            
                       ));
            }
        }
        
        
        /**
         * This is the function that verifies an address request
         */
        public function actionverifyingthisverificationtionrequest(){
            
            //get the city id
            $verification_id = $_POST['id'];
          
            
            $_id = $_POST['address_id'];
            $model=  Address::model()->findByPk($_id);
         /** if(is_numeric($street)) {
                $model->street_id = $street;
                
            }else{
                              
                $model->street_id = $_POST['street_id'];
                
                
            }
          * 
          */
          
             $model->house_number = $_POST['address'];
                if(isset($_POST['structure_type'])){
                   $model->structure_type = $_POST['structure_type']; 
                }
                 if(isset($_POST['premises_layout'])){
                   $model->premises_layout = $_POST['premises_layout']; 
                }
                  if(isset($_POST['building_colour'])){
                   $model->building_colour = $_POST['building_colour']; 
                }
                if(isset($_POST['building_room_layout'])){
                   $model->building_room_layout = $_POST['building_room_layout']; 
                }
                 if(isset($_POST['building_purpose'])){
                   $model->building_purpose = $_POST['building_purpose']; 
                }
                 if(isset($_POST['is_compound_gated'])){
                   $model->is_compound_gated = $_POST['is_compound_gated']; 
                }
                 if(isset($_POST['compound_gate_colour'])){
                   $model->compound_gate_colour = $_POST['compound_gate_colour']; 
                }
                 if(isset($_POST['nearest_busstop'])){
                   $model->nearest_busstop = $_POST['nearest_busstop']; 
                }
                  if(isset($_POST['first_landmark'])){
                   $model->first_landmark = $_POST['first_landmark']; 
                }
                if(isset($_POST['second_landmark'])){
                   $model->second_landmark = $_POST['second_landmark']; 
                }
                if(isset($_POST['other_landmark'])){
                   $model->other_landmark = $_POST['other_landmark']; 
                }
                 if(isset($_POST['building_condition'])){
                   $model->building_condition = $_POST['building_condition']; 
                }
                 if(isset($_POST['building_fence_status'])){
                   $model->building_fence_status = $_POST['building_fence_status']; 
                }
                 if(isset($_POST['electricity_metering_type'])){
                   $model->electricity_metering_type = $_POST['electricity_metering_type']; 
                }
                  if(isset($_POST['compound_has_active_security_person'])){
                   $model->compound_has_active_security_person = $_POST['compound_has_active_security_person']; 
                }
                if($_REQUEST['type'] == "fresh"){
                    $model->verification_owner_type = "offus";
                    $model->verification_owner_domain_id = $_REQUEST['requestor_domain_id'];
                }
               $model->verified_by = Yii::app()->user->id;
               $model->is_verified = 1;
               $model->date_verified = new CDbExpression('NOW()');
               if($model->save()){
                   if($this->isTheVerificationRequestUpdateSuccessfully($verification_id)){
                         // $result['success'] = 'true';
                          $msg = 'Address information was updated and verified successfully';
                          header('Content-Type: application/json');
                          echo CJSON::encode(array(
                                    "success" => mysql_errno() == 0,
                                        "msg" => $msg)
                           );
                       
               }else{
                   // $result['success'] = 'true';
                          $msg = 'Address information was updated successfully but the verification update was not updated. Please report this to the customer service desk';
                          header('Content-Type: application/json');
                          echo CJSON::encode(array(
                                    "success" => mysql_errno() == 0,
                                        "msg" => $msg)
                           );
                       
               }
                       
                 }else {
                         //$result['success'] = 'false';
                         $msg = 'The verification update of this address information was not successful';
                         header('Content-Type: application/json');
                         echo CJSON::encode(array(
                                    "success" => mysql_errno() != 0,
                                        "msg" => $msg)
                           );
                  } 
            
        }
        
        
        /**
         * This is the function that updates the verification request table
         */
        public function isTheVerificationRequestUpdateSuccessfully($verification_id){
            $model = new AddressVerificationRequest;
            return $model->isTheVerificationOfThisRequestASuccess($verification_id);
        }
}
