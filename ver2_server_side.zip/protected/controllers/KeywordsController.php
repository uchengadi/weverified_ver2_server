<?php

class KeywordsController extends Controller
{
	/**
	 * @var string the default layout for the views. Defaults to '//layouts/column2', meaning
	 * using two-column layout. See 'protected/views/layouts/column2.php'.
	 */
	public $layout='//layouts/column2';

	/**
	 * @return array action filters
	 */
	public function filters()
	{
		return array(
			'accessControl', // perform access control for CRUD operations
			'postOnly + delete', // we only allow deletion via POST request
		);
	}

	/**
	 * Specifies the access control rules.
	 * This method is used by the 'accessControl' filter.
	 * @return array access control rules
	 */
	public function accessRules()
	{
		return array(
			array('allow',  // allow all users to perform 'index' and 'view' actions
				'actions'=>array('index','view','ListAllKeywordsInThePlatform'),
				'users'=>array('*'),
			),
			array('allow', // allow authenticated user to perform 'create' and 'update' actions
				'actions'=>array('create','update','ListAllTheKeywordsInThisDomain','AddNewKeyword','UpdateKeyword','DeleteOneKeyword',
                                    'ListAllKeywordsInThePlatform','ListAllSubscribedOtherDomainMediaKeywordsInThisDomain'),
				'users'=>array('@'),
			),
			array('allow', // allow admin user to perform 'admin' and 'delete' actions
				'actions'=>array('admin','delete'),
				'users'=>array('admin'),
			),
			array('deny',  // deny all users
				'users'=>array('*'),
			),
		);
	}

        /**
         * This is the function that adds new keyword for a domain
         */
        public function actionAddNewKeyword(){
            
            $model=new Keywords;
            
            //logged in user id is
            $userid = Yii::app()->user->id;
            
            $domainid = $this->determineAUserDomainIdGiven($userid);
            
            $model->keyword = $_POST['keyword'];
           
            $model->domain_id = $domainid;
            $model->create_user_id=$userid;
            $model->create_time = new CDbExpression('NOW()');
            
             if($model->save()) {
                        // $result['success'] = 'true';
                         $msg = "'$model->keyword' keyword/phrase was succesfully created by this Domain";
                         header('Content-Type: application/json');
                         echo CJSON::encode(array(
                           "success" => mysql_errno() == 0,
                             "msg" => $msg)
                       );
                         
                     }else {
                         //$result['success'] = 'false';
                         $msg = "Error Creating keyword/phrase '$model->keyword' for this domain";
                         header('Content-Type: application/json');
                         echo CJSON::encode(array(
                                    "success" => mysql_errno() != 0,
                                        "msg" => $msg)
                           );
                         
                         
                     }
        }
        
        
        /**
         * This is the function that updates keyword information
         */
        public function actionUpdateKeyword(){
            
              //obtain the id of the logged in user
            $userid = Yii::app()->user->id;
            
            $domainid = $this->determineAUserDomainIdGiven($userid);
            
            $_id = $_POST['id'];
            $model=Keywords::model()->findByPk($_id);
            
            $model->keyword = $_POST['keyword'];
           
            $model->domain_id = $domainid;
            $model->update_user_id=$userid;
            $model->update_time = new CDbExpression('NOW()');
            
             if($model->save()) {
                        // $result['success'] = 'true';
                         $msg = "'$model->keyword' Keyword/phrase is succesfully updated by this Domain";
                         header('Content-Type: application/json');
                         echo CJSON::encode(array(
                           "success" => mysql_errno() == 0,
                             "msg" => $msg)
                       );
                         
                     }else {
                         //$result['success'] = 'false';
                         $msg = "Error Updating keyword/phrase '$model->keyword' by this domain";
                         header('Content-Type: application/json');
                         echo CJSON::encode(array(
                                    "success" => mysql_errno() != 0,
                                        "msg" => $msg)
                           );
                         
                         
                     }
            
        }
        
        
        /**
         * This is the function that deletes one keyword from a domain
         * 
         */
        public function actionDeleteOneKeyword(){
            
            $_id = $_POST['id'];
            //get the name of this designation
            $keyword = $this->getThisKeywordName($_id);
            $model=Keywords::model()->findByPk($_id);
            if($model === null){
                 $msg = 'No Such Record Exist'; 
                    header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            //"selected" => $selected,
                            "msg" => $msg
                            //"category" =>$category,
                           
                           
                          
                       ));
                                      
            }else if($model->delete()){
                    $msg = "'$keyword' Designation was Successfully Deleted"; 
                    header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            //"selected" => $selected,
                            "msg" => $msg
                            //"category" =>$category,
                           
                           
                          
                       ));
                       
            } else {
                    $msg = "'$keyword' Designation was Not Deleted"; 
                    header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                            //"selected" => $selected,
                            "msg" => $msg
                            //"category" =>$category,
                           
                           
                          
                       ));
                            
                }
            
        }
        
        
        
        /**
         * This is the function that list all keywords in a domain
         */
        public function actionListAllTheKeywordsInThisDomain(){
            
             //obtain the id of the logged in user
            $userid = Yii::app()->user->id;
            
            $domainid = $this->determineAUserDomainIdGiven($userid);
            
           if($this->determineIfAUserHasThisPrivilegeAssigned($userid, "platformAdmin")){
               
               $criteria = new CDbCriteria();
               $criteria->select = '*';
               //$criteria->condition='domain_id!=:domainid';
               //$criteria->params = array(':domainid'=>$domainid);
               $keywords = Keywords::model()->findAll($criteria);
                 
            if($keywords===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            "keyword" => $keywords
            
                       ));
                       
                }
               
           }else{
               
               $criteria = new CDbCriteria();
               $criteria->select = '*';
               $criteria->condition='domain_id!=:domainid';
               $criteria->params = array(':domainid'=>$domainid);
               $keywords = Keywords::model()->findAll($criteria);
                 
            if($keywords===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            "keyword" => $keywords
                          
                           
                           
                          
                       ));
                       
                }
           } 
            
        }
        
        
        /**
         * This is the function that list all the keywords in the platform
         */
        public function actionListAllKeywordsInThePlatform(){
            
            $criteria = new CDbCriteria();
               $criteria->select = '*';
               //$criteria->condition='domain_id!=:domainid';
               //$criteria->params = array(':domainid'=>$domainid);
               $keywords = Keywords::model()->findAll($criteria);
                 
            if($keywords===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            "keyword" => $keywords
            
                       ));
                       
                }
            
        }
        
         /**
         * This is the function that gets the name of a designation
         */
        public function getThisKeywordName($id){
            
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='id=:id';
            $criteria->params = array(':id'=>$id);
            $keyword = Keywords::model()->find($criteria);   
            
            return $keyword['keyword'];
        }

        
         /**
         * Determine a domain id of a user given his user id 
         */
        public function determineAUserDomainIdGiven($userid){
            
            $criteria1 = new CDbCriteria();
            $criteria1->select = '*';
            $criteria1->condition='id=:id';
            $criteria1->params = array(':id'=>$userid);
            $user= User::model()->find($criteria1);
            
            return $user['domain_id'];
        }
        
        
         /**
         * This is a function that determines if a user has a particular privilege assigned to him
         */
        public function determineIfAUserHasThisPrivilegeAssigned($userid, $privilegename){
            
             $allprivileges = [];
            //spool all the privileges assigned to a user
                $criteria7 = new CDbCriteria();
                $criteria7->select = 'itemname, userid';
                $criteria7->condition='userid=:userid';
                $criteria7->params = array(':userid'=>$userid);
                $priv= AuthAssignment::model()->find($criteria7);
                
                //retrieve all the children of the role
                
                $criteria = new CDbCriteria();
                $criteria->select = 'child';
                $criteria->condition='parent=:parent';
                $criteria->params = array(':parent'=>$priv['itemname']);
                $allprivs= Authitemchild::model()->findAll($criteria);
                 
                //check to see if this privilege exist for this user
                foreach($allprivs as $pris){
                    if($this->privilegeType($pris['child'])== 0){
                        $allprivileges[] = $pris['child'];
                        
                    }elseif($this->privilegeType($pris['child'])== 1){
                        
                       $allprivileges[] = $this->retrieveAllTaskPrivileges($pris['child']); 
                    }elseif($this->privilegeType($pris['child'])== 2){
                        
                        $allprivileges[] = $this->retrieveAllRolePrivileges($pris['child']);
                    }
                    
                    
                    
                    
                }
               
                
                if(in_array($privilegename, $allprivileges)){
                    
                    return true;
                     
                }else{
                    
                    return false;
                     
                }
                
                
                
                
                
           
           
            
           
        }
        
        
        /**
         * This is the function that returns all member privileges of a task
         */
        public function retrieveAllTaskPrivileges($task){
            
            $member = [];
            
                $criteria = new CDbCriteria();
                $criteria->select = 'child';
                $criteria->condition='parent=:parent';
                $criteria->params = array(':parent'=>$task);
                $allprivs= Authitemchild::model()->findAll($criteria);
                
                foreach($allprivs as $privs){
                    if($this->privilegeType($privs['child'])== 0){
                         $member[] = $privs['child'];
                        
                    }elseif($this->privilegeType($privs['child'])== 1){
                        
                        $member[] = $this->retrieveAllTaskPrivileges($privs['child']); 
                    }
                   
                    
                }
              return $member;
               
            
        }
        
        /**
         * This is the function that returns all members in a role
         */
        public function retrieveAllRolePrivileges($role){
            
            $member = [];
            
                $criteria = new CDbCriteria();
                $criteria->select = 'child';
                $criteria->condition='parent=:parent';
                $criteria->params = array(':parent'=>$role);
                $allprivs= Authitemchild::model()->findAll($criteria);
                
                foreach($allprivs as $privs){
                    if($this->privilegeType($privs['child'])== 0){
                         $member[] = $privs['child'];
                        
                    }elseif($this->privilegeType($privs['child'])== 1){
                        
                        $member[] = $this->retrieveAllTaskPrivileges($privs['child']); 
                    }elseif($this->privilegeType($privs['child'])== 2){
                        
                        $member[] = $this->retrieveAllRolePrivileges($privs['child']); 
                    }
                   
                    
                }
              return $member;
                
            
        }
        
        
       
        
        /**
         * This is the function that determines a privilege type
         */
        public function privilegeType($privname){
            
            $criteria7 = new CDbCriteria();
                $criteria7->select = 'name, type';
                $criteria7->condition='name=:name';
                $criteria7->params = array(':name'=>$privname);
                $privs= Authitem::model()->find($criteria7);
                
                return $privs['type'];
                
                
        }
        
        
        
        /**
         * This is the function that will list all other domain keywords in this domain
         */
        public function actionListAllSubscribedOtherDomainMediaKeywordsInThisDomain(){
            
            //get the logged in user
            $user_id = Yii::app()->user->id;
            
            //get the logged in user domain
            $domain_id = $this->determineAUserDomainIdGiven($user_id);
            
            //$domain_id = 2;
            
            //get all other domain program & event subscribed to by this domain
            $all_other_domain_programs = $this->getTheListOfOtherDomainsProgramsAndEventsConsumedByThisDomain($domain_id);
            
            //get the domain of these programs
            $all_program_domains = [];
            foreach($all_other_domain_programs as $program){
                $all_program_domains[] = $this->getTheDomainOfThisProgram($program);
            }
            
            //get the keywords for each of this domain
            
            $all_keywords = [];
            foreach($all_program_domains as $domain){
               
                $all_keywords[] = $this->getTheKeywordsInThisDomain($domain);
            }
            
            //get the one dimensional array of this keywords
            $serialized_keywords = $this->getOneDimensionalArrayOfThisKeywordArray($all_keywords);
            //get all the details of the keywords        
            $all_other_domain_keywords = [];
            foreach($serialized_keywords as $keyword){
               $criteria = new CDbCriteria();
               $criteria->select = '*';
               $criteria->condition='id=:id';
               $criteria->params = array(':id'=>$keyword);
               $keywords = Keywords::model()->find($criteria);
               $all_other_domain_keywords[] = $keywords;
                
            }
            if($all_other_domain_keywords===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            "keyword" => $all_other_domain_keywords,
                           "domain_keywords"=>$all_keywords,
                           "serialized_keyword"=>$serialized_keywords
                               
        
                       ));
                       
                }
        }
        
        
        /**
         * This is the function that gets the list of other domain program & events consumed by this domain
         */
        public function getTheListOfOtherDomainsProgramsAndEventsConsumedByThisDomain($domain_id){
            
            $all_media = [];
                    $criteria1 = new CDbCriteria();
                    $criteria1->select = '*';
                    $criteria1->condition='category_id=:id';
                    $criteria1->params = array(':id'=>$domain_id);
                    $items= ResourcegroupHasResourcegroupcategory::model()->findAll($criteria1);
                      
                      foreach($items as $item){
                        if($this->isThisDomainTheOwnerOfThisProgramAndEvent($item['resourcegroup_id'],$domain_id) === false){
                             //if($this->isMediaItemWithinTheDateRange(strtotime($item['max_date']),$start_date,$end_date)){
                              $all_media[] = $item['resourcegroup_id'];
                         // }
                       }
                          
                      }
                      
                       //get the unigue sessions in this program
                                            
                      return array_unique($all_media);
        }
        
        
        /**
             * This is the function that confirms if a program belongs to a domain
             */
            public function isThisDomainTheOwnerOfThisProgramAndEvent($toolbox_id,$domain_id){
                
              $cmd =Yii::app()->db->createCommand();
                $cmd->select('COUNT(*)')
                    ->from('resourcegroup')
                    ->where("domain_id = $domain_id && id =$toolbox_id");
                $result = $cmd->queryScalar();
                
                if($result >0){
                    return true;
                }else{
                    return false;
                }
                
            }
            
            
             /**
             * This is the function that gets only the unique sessions
             */
            public function getOneDimensionalArrayOfThisKeywordArray($keywords){
                
                $all_keyword = [];
                if(is_array($keywords)){
                    foreach($keywords as $keyword){
                        if(is_array($keyword)){
                            foreach($keyword as $key){
                               $all_keyword[] =  $key;
                            }
                        }else{
                           $all_keyword[] = $keyword; 
                        }
                    }
                    return array_unique($all_keyword);
                }else{
                    return $keywords;
                }
            }
            
           /**
            * This is the function that gets the domain of this program
            */ 
            public function getTheDomainOfThisProgram($program_id){
                
                    $criteria1 = new CDbCriteria();
                    $criteria1->select = '*';
                    $criteria1->condition='id=:id';
                    $criteria1->params = array(':id'=>$program_id);
                    $domain= Resourcegroup::model()->find($criteria1);
                    
                    return $domain['domain_id'];
                
            }
        
        
            /**
             * This is the function that gets the keywords in a domain
             */
            public function getTheKeywordsInThisDomain($domain_id){
                
                    $criteria1 = new CDbCriteria();
                    $criteria1->select = '*';
                    $criteria1->condition='domain_id=:id';
                    $criteria1->params = array(':id'=>$domain_id);
                    $keywords= Keywords::model()->findAll($criteria1);
                    
                    $all_domain_keywords = [];
                    foreach($keywords as $keyword){
                        $all_domain_keywords[] = $keyword['id'];
                    }
                    
                    return $all_domain_keywords;
                
            }
        
	/**
	 * Returns the data model based on the primary key given in the GET variable.
	 * If the data model is not found, an HTTP exception will be raised.
	 * @param integer $id the ID of the model to be loaded
	 * @return Keywords the loaded model
	 * @throws CHttpException
	 */
	public function loadModel($id)
	{
		$model=Keywords::model()->findByPk($id);
		if($model===null)
			throw new CHttpException(404,'The requested page does not exist.');
		return $model;
	}

	/**
	 * Performs the AJAX validation.
	 * @param Keywords $model the model to be validated
	 */
	protected function performAjaxValidation($model)
	{
		if(isset($_POST['ajax']) && $_POST['ajax']==='keywords-form')
		{
			echo CActiveForm::validate($model);
			Yii::app()->end();
		}
	}
}
