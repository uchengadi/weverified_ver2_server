<?php

class OrderController extends Controller
{
	/**
	 * @var string the default layout for the views. Defaults to '//layouts/column2', meaning
	 * using two-column layout. See 'protected/views/layouts/column2.php'.
	 */
	public $layout='//layouts/column2';

	/**
	 * @return array action filters
	 */
	public function filters()
	{
		return array(
			'accessControl', // perform access control for CRUD operations
			'postOnly + delete', // we only allow deletion via POST request
		);
	}

	/**
	 * Specifies the access control rules.
	 * This method is used by the 'accessControl' filter.
	 * @return array access control rules
	 */
	public function accessRules()
	{
		return array(
			array('allow',  // allow all users to perform 'index' and 'view' actions
				'actions'=>array('index','view','getAUserCartDetailInformation','getToolboxDetailInformation',
                                    'getToolboxDetailInformation','ListAllPlatformOrders'),
				'users'=>array('*'),
			),
			array('allow', // allow authenticated user to perform 'create' and 'update' actions
				'actions'=>array('create','update','ListAllDomainOrders','ListSingleOrderItemsInCart',
                                    'retrieveThisOrderdetailinfo','retrieveToolboxForRenewalInfoOnThatDomain','retrieveTheNameOfThisUser','effectSubscriberChangeAndNewValuesForRenewal',
                                    'retrieveSoonToExpireToolboxes','retrieveTheEndDateForThisToolboxInThisDomain',
                                    'ListAllToolboxesForRenewal','retrieveSoonToExpireToolboxes','retrieveTheEndDateForThisToolboxInThisDomain',
                                    'ListSingleOrderItemsInCart'.'retrieveDomainDueRemittance','retrieveToolboxForRenewalInfoOnThatDomain',
                                    'isEndOfDateDeclaredForThisServiceToThisDomain','isThisToolboxServiceToThisDomainAlreadyExpired',
                                    'generateTheRandomNumber','generateTheInvoiceNumberForPayment','generateTheNeededOrderNumber','renewThisToolboxForThisDomain',
                                    'renewThisToolboxForThisDomain','obtainTheVatForThisPurchase','isPayeeDomainVatLegibleOnThisPurchase',
                                    'retrieveOrderForRenewalInfoOnThatDomain','makePaymentForThisOrderForThisDomain','getToolboxForRenewalInfoOnThatDomain',
                                    'isPurchaseOnMultipleStore','generateTheInvoiceNumberForThisOrder','addThisItemToCart','RemoveAnItemFromCart','retrieveToolboxName','modifyThisItemInCart',
                                    'getToolboxDetailInformation','getTheGrossAmountForThisToolboxPerDomain','addNewItemToCart','getAUserCartDetailInformation','getTheNumberOfItemsInUserCart',
                                    'determineIfAUserCartIsEmpty','getTheUsersOpenOrder','getTheCurrencyCodeOfThisCountry','effectSubscriberChangeAndNewValuesForRenewal',
                                    'updateTheDomainSubscriberBaseToThisToolbox','AssignResourcegroupToCategory','AssignNewSingleResourcegroupToCategory',
                                    'AssignSingleResourcegroupToCategory','DeleteOneAssignedResourcegroupToCategory','ListAllPlatformOrders','getTheDiscountAmountForThisToolbox','getTheDiscountApplicableToThisTool',
                                    'getTheDomainStatedMinToolUserNumberForDiscount','isDomainMinDiscountableNumberOfToolUsersMet','isDiscountApplicableToThisToolTransaction',
                                    'effectThePaymentOfThisPurchase','getTheActualToolboxPrice','getTheNumberOfItemsInCart','ConfirmIfBoxAndFolderIsAlreadyInTheRequestList','AddThisBatchOrFileToExistingBoxInTheRequestList',
                                    'AddThisBatchOrFileToNewBoxInTheRequestList','RemoveThisBatchOrFileFromAnExistingBoxInTheRequestList','ModifyRequestForThisVirtualBox'),
				'users'=>array('@'),
			),
			array('allow', // allow admin user to perform 'admin' and 'delete' actions
				'actions'=>array('admin','delete'),
				'users'=>array('admin'),
			),
			array('deny',  // deny all users
				'users'=>array('*'),
			),
		);
	}

	/**
         * This is the function that retrieves all orders in a domains acart
         */
        public function actionListAllDomainOrders(){
            
            //get the logged in user
            
            $userid = Yii::app()->user->id;
            
            //get the logged in user domain
            $order_domain_id = $this->determineAUserDomainIdGiven($userid);
            if($this->determineIfAUserHasThisPrivilegeAssigned($userid, "platformAdmin")|| $this->determineIfAUserHasThisPrivilegeAssigned($userid, "platformOrdersSupport")){
                //retrieve all the orders made by this user
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            //$criteria->condition='order_domain_id=:id';
            //$criteria->params = array(':id'=>$order_domain_id);
            $orders= Order::model()->findAll($criteria);
            
            if($orders===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            "order" =>$orders
                          
                           
                           
                          
                       ));
                } 
                
            }else{
                //retrieve all the orders made by this user
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='order_domain_id=:id';
            $criteria->params = array(':id'=>$order_domain_id);
            $orders= Order::model()->findAll($criteria);
            
            if($orders===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            "order" =>$orders
                          
                           
                           
                          
                       ));
                } 
                
            }
            
            
            
            
        }
        
        
        
        
        
        /**
         * This is the function that retrieves all orders in a domains acart
         */
        public function actionListAllPlatformOrders(){
            
            //get the logged in user
            
            $userid = Yii::app()->user->id;
            
            //get the logged in user domain
            //$order_domain_id = $this->determineAUserDomainIdGiven($userid);
            //retrieve all the orders made by this user
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            //$criteria->condition='order_domain_id=:id';
            //$criteria->params = array(':id'=>$order_domain_id);
            $orders= Order::model()->findAll($criteria);
            
            if($orders===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            "order" =>$orders
                          
                           
                           
                          
                       ));
                } 
                
            
                
                        
            
            
            
        }
        
        
        /**
         * This is the function that retrieves  an order's detail info
         */
        public function actionRetrieveThisOrderdetailinfo(){
            
            $order_id = $_REQUEST['order_id'];
            
             //$order_id = 2;

            $userid = Yii::app()->user->id;
            
            //get the logged in user domain
            $domain_id = $this->determineAUserDomainIdGiven($userid);
            
            
                           
                //get the order status
                $order_status = $this->getTheOrderStatus($order_id);
                //get the order beneficiary
                $order_beneficiary = $this->determineDomainNameGivenItId($domain_id);
                //get the total toolboxes in this order
                $order_toolboxes = $this->getTheTotalNumberOfToolboxesInThisOrder($order_id);
                
                //get the total number of tools in all this toolboxes
                $order_tools = $this->getTotalNumberOfToolsInToolboxes($order_id);
                //get the total number of tasks in the toolboxes
                $order_task = $this->getTotalNumberOfTasksInToolboxes($order_id);
                //get the total number of users subscribed to these toolboxes in this order
                $order_users =$this->getTheTotalNumberOfConsumingUsers($order_id);
                
                //get the number of years for subscription
               // $number_of_years = $this->getTheNumberOfYearsForSubscription($order_id);
                
              //get the user that initiated the order
                $order_initiator = $this->getTheInitiatorOfThisOrder($order_id);
                
                //get the gross amount for this order
                $order_gross = $this->getTheGrossAmountForThisOrder($order_id);
                
                //get the applicable discount for this order
                $order_discount = $this->getTheApplicableDiscountForThisOrder($order_id,$domain_id);
                
                //get the net payment for this order
                $order_net = $order_gross - $order_discount;
                
                //get the order number
                $order_number = $this->getTheOrderNumber($order_id);
                
                //get all the toolboxes in this order
                //$order_items = $this->getAllThisOrderItems($order_id);
            
                //retreive all the toolboxes in this order
                    $criteria = new CDbCriteria();
                    $criteria->select = '*';
                    $criteria->condition='order_id=:id';
                    $criteria->params = array(':id'=>$order_id);
                    $order_items= OrderHasToolboxes::model()->findAll($criteria);
                 
           
                if($order_id===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                }else{
                    header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            "order_status" => $order_status,
                            "order_number" => $order_number,
                            "order_beneficiary" => $order_beneficiary,
                            "order_toolboxes" => $order_toolboxes,
                            "order_tools" => $order_tools,
                            "order_tasks" => $order_task,
                           "order_users" => $order_users,
                           "order_initiator" => $order_initiator,
                           "order_gross_amount" => $order_gross,
                           "order_discount_granted" => $order_discount,
                           "order_net_payment" => $order_net,
                           "items" =>$order_items
                          
                       
                       ));
                    
                }
            
        }

        
       
        
        /**
         * This is the function that retrieves the information about the toolboxes that is due for renewal
         */
        public function actionretrieveToolboxForRenewalInfoOnThatDomain(){
            
             $toolbox_id = $_REQUEST['id'];
             
              //$toolbox_id = 1;
           
            $userid = Yii::app()->user->id;
            
            //get the logged in user domain
            $domain_id = $this->determineAUserDomainIdGiven($userid);
            
            
                           
                //get the toolbox name
                $toolbox_name = $this->getTheToolboxName($toolbox_id);
                
                //get the toolbox name
                $toolbox_expiry = $this->getTheToolboxExpiryDate($toolbox_id,$domain_id);
                //get the order beneficiary
                $toolbox_beneficiary = $this->determineDomainNameGivenItId($domain_id);
                
                //get the total number of tools in this toolbox
                $tools_in_toolbox = $this->getTheTotalNumberOfToolsInThisToolbox($toolbox_id);
                //get the total number of tasks in this toolbox
                $tasks_in_toolbox = $this->getTotalNumberOfTasksInThisToolbox($toolbox_id);
                //get the total number of current users subscribed to these toolbox in this domain
                $toolbox_users =$this->getTheTotalNumberOfToolboxUsers($toolbox_id,$domain_id);
                
                //get the number of years for subscription
                $years_of_subscription = $this->getTheNumberOfYearsOfSubscription($toolbox_id,$domain_id);
                
                //get the user that initiated the renewal
                $renewal_initiator = $this->retrieveTheNameOfThisUser($userid);
                
                //get the gross amount for this order
                $toolbox_gross = $this->getTheGrossAmountForThisToolboxPerDomain($toolbox_id, $domain_id,$toolbox_users);
                
                //get the applicable discount for this toolbox by this domain
                $toolbox_discount = $this->getTheApplicableDiscountForThisToolbox($toolbox_id,$domain_id,$toolbox_users);
                
                //get the net payment for this toolbox by this domain
                $toolbox_net = $toolbox_gross - $toolbox_discount;
             
                if($toolbox_id===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                }else{
                    header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            "toolboxname" => $toolbox_name,
                            "toolbox_expiry" => $toolbox_expiry,
                            "toolbox_beneficiary" => $toolbox_beneficiary,
                            "toolbox_tools" => $tools_in_toolbox,
                            "toolbox_tasks" => $tasks_in_toolbox,
                            "toolbox_users" => $toolbox_users,
                           "renewal_initiator" => $renewal_initiator,
                           "toolbox_gross_amount" => $toolbox_gross,
                           "toolbox_discount_granted" => $toolbox_discount,
                           "toolbox_net_payment" => $toolbox_net,
                           "subscription_years"=> $years_of_subscription
                         
                          
                       
                       ));
                    
                }
            
        }
        
        
         /**
         * This is the function that is called when subscriber number is alterred during renewal
         */
        public function actioneffectSubscriberChangeAndNewValuesForRenewal(){
            
           $toolbox_id = $_REQUEST['id'];
           $subscriber_number =$_REQUEST['subscribers'];
            if(isset($_REQUEST['number_of_years']) || $_REQUEST['number_of_years'] !== NULL){
                $number_of_years = $_REQUEST['number_of_years'];
           }else{
               $number_of_years = "";
           }
          
          
                          //$toolbox_id = 1;
           
            $userid = Yii::app()->user->id;
            
            //get the logged in user domain
            $domain_id = $this->determineAUserDomainIdGiven($userid);
            
            //update the subscriber number on the database
            if($number_of_years === ""){
                $result = $this->updateTheDomainSubscriberBaseToThisToolbox($domain_id,$toolbox_id,$subscriber_number);
            }else{
                $result = $this->updateTheDomainSubscriptionBaseAndNumberOfYearsOfThisToolbox($domain_id,$toolbox_id,$subscriber_number,$number_of_years);
            }
            
            
              if($result >= 0){
                  //get the toolbox name
                $toolbox_name = $this->getTheToolboxName($toolbox_id);
                
               //get the toolbox name
                $toolbox_expiry = $this->getTheToolboxExpiryDate($toolbox_id,$domain_id);
                //get the order beneficiary
                $toolbox_beneficiary = $this->determineDomainNameGivenItId($domain_id);
                
                //get the total number of tools in this toolbox
                $tools_in_toolbox = $this->getTheTotalNumberOfToolsInThisToolbox($toolbox_id);
                //get the total number of tasks in this toolbox
                $tasks_in_toolbox = $this->getTotalNumberOfTasksInThisToolbox($toolbox_id);
                //get the total number of current users subscribed to these toolbox in this domain
                $toolbox_users =$this->getTheTotalNumberOfToolboxUsers($toolbox_id,$domain_id);
                
                //get the number of years for subscription
                $years_of_subscription = $this->getTheNumberOfYearsOfSubscription($toolbox_id,$domain_id);
                
                //get the user that initiated the renewal
                $renewal_initiator = $this->retrieveTheNameOfThisUser($userid);
                
                //get the gross amount for this order
                $toolbox_gross = $this->getTheGrossAmountForThisToolboxPerDomain($toolbox_id, $domain_id,$toolbox_users);
                
                //get the applicable discount for this toolbox by this domain
                $toolbox_discount = $this->getTheApplicableDiscountForThisToolbox($toolbox_id,$domain_id,$toolbox_users);
                
                //get the net payment for this toolbox by this domain
                $toolbox_net = $toolbox_gross - $toolbox_discount;
                 
                
             
                if($toolbox_id===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                }else{
                    header('Content-Type: application/json');
                       echo CJSON::encode(array(
                             "success" => mysql_errno() == 0,
                            "toolboxname" => $toolbox_name,
                         
                            "toolbox_expiry" => $toolbox_expiry,
                            "toolbox_beneficiary" => $toolbox_beneficiary,
                            "toolbox_tools" => $tools_in_toolbox,
                            "toolbox_tasks" => $tasks_in_toolbox,
                            "toolbox_users" => $toolbox_users,
                           "renewal_initiator" => $renewal_initiator,
                           "toolbox_gross_amount" => $toolbox_gross,
                           "toolbox_discount_granted" => $toolbox_discount,
                           "toolbox_net_payment" => $toolbox_net,
                           "subscription_years"=>$years_of_subscription
                             
                             
                         
                          
                       
                       ));
                    
                }
                  
              }
              
                
                    
        }
        
        
        /**
         * This is the function to update the subscriber number
         */
        public function updateTheDomainSubscriberBaseToThisToolbox($domain_id,$toolbox_id,$subscriber_number){
            
            $cmd =Yii::app()->db->createCommand();
             $result = $cmd->update('resourcegroup_has_resourcegroupcategory',
                                  array(
                                    'no_of_subscribers'=>$subscriber_number
                                   
                               
		
                            ),
                     ("category_id=$domain_id and resourcegroup_id=$toolbox_id"));
            
            return $result;
             
            
        }
        
        /**
         * This is the function that will update both number of subscribers and the year of subscription
         */
        public function updateTheDomainSubscriptionBaseAndNumberOfYearsOfThisToolbox($domain_id,$toolbox_id,$subscriber_number,$number_of_years){
            
             $cmd =Yii::app()->db->createCommand();
             $result = $cmd->update('resourcegroup_has_resourcegroupcategory',
                                  array(
                                    'no_of_subscribers'=>$subscriber_number,
                                      'number_of_years'=>$number_of_years
                                   
                               
		
                            ),
                     ("category_id=$domain_id and resourcegroup_id=$toolbox_id"));
            
            return $result;
            
        }
        
        
        /**
         * This is the function that retrieves that status of an order
         */
        public function getTheOrderStatus($order_id){
                    $criteria = new CDbCriteria();
                    $criteria->select = '*';
                    $criteria->condition='id=:id';
                    $criteria->params = array(':id'=>$order_id);
                    $order= Order::model()->find($criteria);
                    
                    return $order['status'];
        }
        
        /**
         * This is the function that retrieves the initiator of this order
         */
        public function getTheInitiatorOfThisOrder($order_id){
            
                    $criteria = new CDbCriteria();
                    $criteria->select = '*';
                    $criteria->condition='id=:id';
                    $criteria->params = array(':id'=>$order_id);
                    $order= Order::model()->find($criteria);
                    
                    $name = $this->retrieveTheNameOfThisUser($order['order_initiated_by']);
                    
                    return $name;
        }
        
        /**
         * This is the function that provides a users name given his id
         */
        public function retrieveTheNameOfThisUser($user_id){
            
                    $criteria = new CDbCriteria();
                    $criteria->select = '*';
                    $criteria->condition='id=:id';
                    $criteria->params = array(':id'=>$user_id);
                    $user= User::model()->find($criteria);
                    
                    return ($user['firstname'] . ' '. $user['middlename'] . ' '. $user['lastname']);
                   
            
        }
        
        /**
         * This is the function that gets the order number
         */
        public function getTheOrderNumber($order_id){
            
                    $criteria = new CDbCriteria();
                    $criteria->select = '*';
                    $criteria->condition='id=:id';
                    $criteria->params = array(':id'=>$order_id);
                    $order= Order::model()->find($criteria);
                    
                    return $order['order_number'];
            
        }
        
        /**
         * This is the function that retrieves all the toobox ids in an order
         */
        public function getAllThisOrderItems($order_id){
            
                    $criteria = new CDbCriteria();
                    $criteria->select = '*';
                    $criteria->condition='order_id=:id';
                    $criteria->params = array(':id'=>$order_id);
                    $orders= OrderHasToolboxes::model()->findAll($criteria);
                    
                   $allitems = [];
                   foreach($orders as $item){
                       
                       $allitems[] = $item['toolbox_id'];
                   }
                   return $allitems;
        }
        
        /**
         * This is the function that will get the total number of toolboxes in an order 
         */
        public function getTheTotalNumberOfToolboxesInThisOrder($order_id){
            
            $cmd =Yii::app()->db->createCommand();
                $cmd->select('COUNT(*)')
                    ->from('order_has_toolboxes')
                    ->where("order_id = $order_id");
                $result = $cmd->queryScalar();
                
                return $result;
        }
        
        /**
         * This is the function that gets the total number of tools in an order with many toolboxes
         */
        public function getTotalNumberOfToolsInToolboxes($order_id){
            //retrieve all the toolboxes in this order
            $toolboxes = $this->getAllThisOrderItems($order_id);
            
            //get the tools in each toolbox
            $sum_tools = 0;
            foreach($toolboxes as $toolbox){
                //get the tools in each of this toolbox
                $sum_tools  = $sum_tools + $this->getTheTotalNumberOfToolsInThisToolbox($toolbox);
                
            }
            return $sum_tools;
            
        }
        
        /**
         * This is the function that get the total number of tools in this toolbox
         */
        public function getTheTotalNumberOfToolsInThisToolbox($toolbox_id){
            
            $cmd =Yii::app()->db->createCommand();
                $cmd->select('COUNT(*)')
                    ->from('resource_has_resourcegroups')
                    ->where("resourcegroup_id = $toolbox_id");
                $result = $cmd->queryScalar();
                
                return $result;
            
        }
        
        /**
         * This is the function that gets the total number of task in a toolbox
         */
        public function getTotalNumberOfTasksInToolboxes($order_id){
            //retrieve all the toolboxes in this order
            $toolboxes = $this->getAllThisOrderItems($order_id);
            $sum_tasks = 0;
            foreach($toolboxes as $toolbox){
                
                //retrieve all the tools in each toolbox
                $tools = $this->getAllTheToolsInThisToolbox($toolbox);
                foreach($tools as $tool){
                    $sum_tasks = $sum_tasks + $this->getTheTotalNumberOfTaskInThisTool($tool);
                }
            }
            return $sum_tasks;
            
        }
        
        /**
         * This is the function that retrieves all the tools in a toolbox
         */
        public function getAllTheToolsInThisToolbox($toolbox_id){
            
                    $criteria = new CDbCriteria();
                    $criteria->select = '*';
                    $criteria->condition='resourcegroup_id=:id';
                    $criteria->params = array(':id'=>$toolbox_id);
                    $tools= ResourceHasResourcegroups::model()->findAll($criteria);
                    
                   $alltools = [];
                   foreach($tools as $tool){
                       
                       $alltools[] = $tool['resource_id'];
                   }
                   return $alltools;
            
        }
        
        /**
         * This is the function that get the total number of task in a tool
         */
        public function getTheTotalNumberOfTaskInThisTool($tool_id){
            
            $cmd =Yii::app()->db->createCommand();
                $cmd->select('COUNT(*)')
                    ->from('resources')
                    ->where("parent_id = $tool_id");
                $result = $cmd->queryScalar();
                
                return $result;
            
            
        }
        
        /**
         * This is the function that gets the total number of users subscribing to the toolbox items in the cart
         */
        public function getTheTotalNumberOfConsumingUsers($order_id){
            
            //retrieve all the toolboxes in this order
            $toolboxes = $this->getAllThisOrderItems($order_id);
            
            $users = 0;
            
            foreach($toolboxes as $toolbox){
                $users = $users + $this->getTheNumberOfUsersSubscribedToThisToolbox($toolbox,$order_id);
            }
            return $users;
        }
        
        /**
         * This is the function that retrieves the number subscribed to this toolbox 
         */
        public function getTheNumberOfUsersSubscribedToThisToolbox($toolbox_id,$order_id){
            
                    $criteria = new CDbCriteria();
                    $criteria->select = '*';
                    $criteria->condition='order_id=:orderid and toolbox_id=:toolboxid';
                    $criteria->params = array(':orderid'=>$order_id,':toolboxid'=>$toolbox_id);
                    $order= OrderHasToolboxes::model()->find($criteria);
                    
                    return $order['number_of_users'];
            
        }
        
        
        /**
         * This is the function that gets the number of years for this subscription
         */
        public function getTheNumberOfYearsForThisSubscription($toolbox_id,$order_id){
            
                    $criteria = new CDbCriteria();
                    $criteria->select = '*';
                    $criteria->condition='order_id=:orderid and toolbox_id=:toolboxid';
                    $criteria->params = array(':orderid'=>$order_id,':toolboxid'=>$toolbox_id);
                    $order= OrderHasToolboxes::model()->find($criteria);
                    
                    return $order['number_of_years'];
            
        }
        
        
        /**
         * This is the function that retrieves the gross amount for an order
         */
        public function getTheGrossAmountForThisOrder($order_id){
            
            //get the domain of this order
            $domain_id = $this->getTheDomainOfThisOrder($order_id);

            //retrieve all the toolboxes in this order
            $toolboxes = $this->getAllThisOrderItems($order_id);
            
            //retrieve the price per user for this toolboxes
            $total_amount = 0.00;
            foreach($toolboxes as $toolbox){
                if($this->isToolboxNotPrivateToThisDomain($toolbox, $domain_id)){
                    $total_amount = $total_amount + ($this->getThisToolboxAmount($toolbox) * $this->getTheNumberOfUsersSubscribedToThisToolbox($toolbox,$order_id) * $this->getTheNumberOfYearsForThisSubscription($toolbox,$order_id));
                }else{
                    if($this->isPrivateToolboxNotInvolveInSpaceCalculations()){
                       if($this->getTheNumberOfUsersSubscribedToThisToolbox($toolbox,$order_id)>=$this->getTheMinRequiredPrivateToolboxSubscribersInThePlatform()){
                       $total_amount = $total_amount + ($this->getThisPlatformPrivateToolboxAmount() * $this->getTheNumberOfUsersSubscribedToThisToolbox($toolbox,$order_id) * $this->getTheNumberOfYearsForThisSubscription($toolbox,$order_id)* $this->getTheTotalNumberOfToolsInThisToolbox($toolbox));
                        }else{
                       $total_amount = $total_amount + ($this->getThisPlatformPrivateToolboxAmount() * $this->getTheMinRequiredPrivateToolboxSubscribersInThePlatform() * $this->getTheNumberOfYearsForThisSubscription($toolbox,$order_id)* $this->getTheTotalNumberOfToolsInThisToolbox($toolbox));
                        } 
                    }else{
                        $total_amount = $total_amount + 0.00;
                    }
                   
                }
                
            }
            return $total_amount;
            
        }
        
        
        /**
         * This is the function that determines if private toolboxes are involve in space calculation
         */
        public function isPrivateToolboxNotInvolveInSpaceCalculations(){
            
                    $criteria = new CDbCriteria();
                    $criteria->select = '*';
                    //$criteria->condition='domain_id=:id';
                    //$criteria->params = array(':id'=>$domain_id);
                    $space= PlatformSettings::model()->find($criteria);
                    
                    if($space['include_private_toolboxes_in_space_calculation'] == 1){
                        return false;
                    }else{
                        return true;
                    }
            
            
        }
        
        /**
         * This is the function that gets the domain that initiated an order
         */
        public function getTheDomainOfThisOrder($order_id){
            
                    $criteria = new CDbCriteria();
                    $criteria->select = '*';
                    $criteria->condition='id=:id';
                    $criteria->params = array(':id'=>$order_id);
                    $order= Order::model()->find($criteria);
                    
                    return $order['order_domain_id'];
            
        }
        
        
        /**
         * This is the function that gets the domain's private toolbox amount
         */
        public function getThisDomainPrivateToolboxAmount($domain_id){
            
                    $criteria = new CDbCriteria();
                    $criteria->select = '*';
                    $criteria->condition='domain_id=:id';
                    $criteria->params = array(':id'=>$domain_id);
                    $subscribers= DomainPolicy::model()->find($criteria);
                    
                    return $subscribers['private_toolboxes_price_per_task'];
            
        }
        
        
        /**
         * This is the function that gets the platform private toolbox amount
         */
        public function getThisPlatformPrivateToolboxAmount(){
            
                    $criteria = new CDbCriteria();
                    $criteria->select = '*';
                    //$criteria->condition='domain_id=:id';
                    //$criteria->params = array(':id'=>$domain_id);
                    $subscribers= PlatformSettings::model()->find($criteria);
                    
                    return $subscribers['private_toolboxes_price_per_task'];
            
        }
        
        /**
         * This is the function that retrieves the minimum required subscribers for a private toolbox
         */
        public function getTheMinRequiredPrivateToolboxSubscribersForThisDomain($domain_id){
            
                    $criteria = new CDbCriteria();
                    $criteria->select = '*';
                    $criteria->condition='domain_id=:id and status=:status';
                    $criteria->params = array(':id'=>$domain_id,':status'=>'active');
                    $subscribers= DomainPolicy::model()->find($criteria);
                    
                    return $subscribers['private_toolbox_min_subscription_no'];
            
        }
        
        
        /**
         * This is the function that retrieves the minimum required subscribers for a private toolbox in the platform
         */
        public function getTheMinRequiredPrivateToolboxSubscribersInThePlatform(){
            
                    $criteria = new CDbCriteria();
                    $criteria->select = '*';
                   // $criteria->condition='domain_id=:id and status=:status';
                    //$criteria->params = array(':id'=>$domain_id,':status'=>'active');
                    $subscribers= PlatformSettings::model()->find($criteria);
                    
                    return $subscribers['private_toolbox_min_subscription_no'];
            
        }
       
        /**
         * This is the function that gets the toolbox actual amount
         */
        public function getThisToolboxAmount($toolbox_id){
           if($this->isToolboxVisibilityNotPrivate($toolbox_id)){
               if($this->isPricePreferenceChecked($toolbox_id)){
                if($this->isStatedPriceHigherThanDerivedPrice($toolbox_id)){
                    $price = $this->getTheToolboxStatedPrice($toolbox_id);
                    return $price;
                }else{
                    if($this->isToolboxPricingDerivable($toolbox_id)){
                        $price = $this->getTheDerivePriceForThisToolbox($toolbox_id);
                        return $price;
                    }else{
                       $price = $this->getTheToolboxStatedPrice($toolbox_id);
                       return $price; 
                    }
                    
                    
                }
            }else{
              if($this->isToolboxPricingDerivable($toolbox_id)){
                        $price = $this->getTheDerivePriceForThisToolbox($toolbox_id);
                        return $price;
                    }else{
                       $price = $this->getTheToolboxStatedPrice($toolbox_id);
                       return $price; 
                    }
            }
           }else{
               if($this->isPrivateToolboxNotInvolveInSpaceCalculations()){
                   return $this->getThisPlatformPrivateToolboxAmount();
               }else{
                   return 0.00;
               }
           } 
            
            
        }
        
        
        /**
         * This is the function that determines if a toolbox visibility is not private
         */
        public function isToolboxVisibilityNotPrivate($toolbox_id){
            
                    $criteria = new CDbCriteria();
                    $criteria->select = '*';
                    $criteria->condition='id=:id';
                    $criteria->params = array(':id'=>$toolbox_id);
                    $toolbox= ResourceGroup::model()->find($criteria);
                    
                    if($toolbox['visibility'] == 'private'){
                        return false;
                    }else{
                        return true;
                    }
        }
        
        /**
         * This is the function that determines if toolbox pring should be derived from its component
         */
        public function isToolboxPricingDerivable($toolbox_id){
            
                    $criteria = new CDbCriteria();
                    $criteria->select = '*';
                    $criteria->condition='id=:id';
                    $criteria->params = array(':id'=>$toolbox_id);
                    $toolbox= ResourceGroup::model()->find($criteria);
                    
                    if($toolbox['cumulative_component_price']== 1){
                        return true;
                    }else{
                        return false;
                    }
            
        }
        
        /**
         * This is the function that verifies if a toolbox price preference is checked or not
         */
        public function isPricePreferenceChecked($toolbox_id){
                    $criteria = new CDbCriteria();
                    $criteria->select = '*';
                    $criteria->condition='id=:id';
                    $criteria->params = array(':id'=>$toolbox_id);
                    $toolbox= ResourceGroup::model()->find($criteria);
                    
                    if($toolbox['price_preference']== 1){
                        return true;
                    }else{
                        return false;
                    }
            
        }
        
        /**
         * This is the function that retrieve the stated price of a toolbox
         */
        public function getTheToolboxStatedPrice($toolbox_id){
                    $criteria = new CDbCriteria();
                    $criteria->select = '*';
                    $criteria->condition='id=:id';
                    $criteria->params = array(':id'=>$toolbox_id);
                    $toolbox= ResourceGroup::model()->find($criteria);
                    
                    return $toolbox['price'];
            
        }
        
        /**
         * This is the function that determines if a toolbox stated price is higher than the derived price
         */
        public function isStatedPriceHigherThanDerivedPrice($toolbox_id){
            
            if($this->getTheToolboxStatedPrice($toolbox_id) >= $this->getTheDerivePriceForThisToolbox($toolbox_id)){
                return true;
            }else{
                return false;
            }
            
        }
        
        /**
         * This is the function that gets the derived price of a toolbox
         */
        public function getTheDerivePriceForThisToolbox($toolbox_id){
            
            //get all the tools in this toolbox
            $tools = $this->getAllTheToolsInThisToolbox($toolbox_id);
            $sum = 0;
            foreach($tools as $tool){
                $sum = $sum + $this->getThePriceAssignedToThisTool($tool);
                
            }
            return $sum;
        }
        
        /**
         * This is the function that obtains the price assigned to this tool
         */
        public function getThePriceAssignedToThisTool($tool_id){
            
            //confirm if tool price preference is checked
            if($this->isToolPricePreferenceChecked($tool_id)){
                if($this->isToolStatedPriceHigherThanDerivedPrice($tool_id)){
                    $price = $this->getTheToolStatedPrice($tool_id);
                    return $price;
                }else{
                    if($this->isToolPricingDerivable($tool_id)){
                        $price = $this->getTheDerivePriceForThisTool($tool_id);
                        return $price;
                }else{
                    $price = $this->getTheToolStatedPrice($tool_id);
                    return $price;
                }
                    
                }
            }else{
                
                 if($this->isToolPricingDerivable($tool_id)){
                        $price = $this->getTheDerivePriceForThisTool($tool_id);
                        return $price;
                }else{
                    $price = $this->getTheToolStatedPrice($tool_id);
                    return $price;
                }
            }
     
        }
        
        
        /**
         * This is the function that determines if a tool pricing is derivable from its components 
         */
        public function isToolPricingDerivable($tool_id){
            
                    $criteria = new CDbCriteria();
                    $criteria->select = '*';
                    $criteria->condition='id=:id';
                    $criteria->params = array(':id'=>$tool_id);
                    $tool= Resources::model()->find($criteria);
                    
                    if($tool['cumulative_component_price']== 1){
                        return true;
                    }else{
                        return false;
                    }
            
        }
  /**
   * This is the function that confirms if tools price preference is checked or not
   */      
        public function isToolPricePreferenceChecked($tool_id){
            
                    $criteria = new CDbCriteria();
                    $criteria->select = '*';
                    $criteria->condition='id=:id';
                    $criteria->params = array(':id'=>$tool_id);
                    $tool= Resources::model()->find($criteria);
                    
                    if($tool['price_preference']== 1){
                        return true;
                    }else{
                        return false;
                    }
        }
        
        /**
         * This is the function that determines if the stated price is higher than the derived price
         */
        public function isToolStatedPriceHigherThanDerivedPrice($tool_id){
            
            if($this->getTheToolStatedPrice($tool_id) > $this->getTheDerivePriceForThisTool($tool_id)){
                return true;
            }else{
                return false;
            }
            
        }
        
        /**
         * This is the function that retrieves the tool's stated price
         */
        public function getTheToolStatedPrice($tool_id){
            
                    $criteria = new CDbCriteria();
                    $criteria->select = '*';
                    $criteria->condition='id=:id';
                    $criteria->params = array(':id'=>$tool_id);
                    $tool= Resources::model()->find($criteria);
                    
                    return $tool['price'];
        }
        
        /**
         * This is the function that gets the derived price for a tool
         */
        public function getTheDerivePriceForThisTool($tool_id){
            
            //get all the task in this tool
            $tasks = $this->getTheTasksInThisTool($tool_id);
            $sum = 0.00;
            foreach($tasks as $task){
                $sum = $sum + (DOUBLE)$this->getThePriceForThisTask($task);
            }
            return $sum;
        }
        
        /**
         * This is the function that gets the price for this task
         */
        public function getThePriceForThisTask($task_id){
            
                    $criteria = new CDbCriteria();
                    $criteria->select = '*';
                    $criteria->condition='id=:id';
                    $criteria->params = array(':id'=>$task_id);
                    $task= Resources::model()->find($criteria);
                    
                    return $task['price'];
         }
         
         /**
          * This is the function that gets all tasks in a tool
          */
         public function getTheTasksInThisTool($tool_id){
             
                    $criteria = new CDbCriteria();
                    $criteria->select = '*';
                    $criteria->condition='parent_id=:id';
                    $criteria->params = array(':id'=>$tool_id);
                    $tasks= Resources::model()->findAll($criteria);
                    
                    $alltasks = [];
                    foreach($tasks as $task){
                        $alltasks[] = $task['id'];
                    }
                    return $alltasks;
             
         }
         
         /**
          * This is the function that gets the applicable discounts for an order
          */
         public function getTheApplicableDiscountForThisOrder($order_id,$domain_id){
             //retrieve all the toolboxes in this order
            $toolboxes = $this->getAllThisOrderItems($order_id);
            
           $discount_sum = 0.00;
            foreach($toolboxes as $toolbox){
                //get the number of subscribers to this toolbox in this order 
                    $subscribers = $this->getTheNumberOfUsersSubscribedToThisToolbox($toolbox,$order_id);
                //confirm if this toolbox is not privately visible to this domain
                if($this->isToolboxNotPrivateToThisDomain($toolbox,$domain_id)){
                    
                    //get the applicable discount
                    $discount_sum  = $discount_sum  + ($this->getTheDiscountAmountForThisToolbox($toolbox,$domain_id,$subscribers) * $this->getTheNumberOfYearsForThisSubscription($toolbox,$order_id));
                }else{
                   
                    //get the applicable discount
                    $discount_sum  = $discount_sum  + ($this->getThisDomainDiscountForPrivateToolboxes($toolbox,$domain_id,$subscribers) * $this->getTheNumberOfYearsForThisSubscription($toolbox,$order_id)); 
                }
                
            }
             return $discount_sum;
             
         }
         
         /**
          * This is the function that determines if a given toolbox is private to a domain
          */
         public function isToolboxNotPrivateToThisDomain($toolbox_id,$domain_id){
             
                   $criteria = new CDbCriteria();
                   $criteria->select = '*';
                   $criteria->condition='id=:id and domain_id=:domainid';
                   $criteria->params = array(':id'=>$toolbox_id,':domainid'=>$domain_id);
                   $toolbox= Resourcegroup::model()->find($criteria);
                    
                   if($toolbox['visibility'] =='private' || $toolbox['visibility']=='private & public'){
                       return false;
                   }else{
                       return true;
                   }
                    
                    
             
         }
         
         /**
          * This is the function that calculates the minimum discount applicable to a private toolbox
          */
         public function getThisDomainDiscountForPrivateToolboxes($toolbox,$domain_id,$subscribers){
             
            return 0.0;
         }
         
         /**
          * This is the function that gets the actual discount amount
          */
         public function getTheDiscountAmountForThisToolbox($toolbox_id, $domain_id,$subscribers){
             //confirm if domains minimun discount applicable number is met
             //if($this->isDomainMinDiscountableNumberOfToolboxUsersMet($domain_id,$subscribers)){
             if($this->isDiscountApplicableToThisToolboxTransaction($toolbox_id,$domain_id,$subscribers)){
                 //determine if off this toolbox discount is applicable
                 if($this->isOffThisToolboxDiscountNotAppicable($toolbox_id)){
                     //retrieve the toolbox discount value
                     $discount_rate = $this->getTheStatedDiscountRate($toolbox_id);
                     $aggregate_discount = $discount_rate * $this->getThisToolboxAmount($toolbox_id);
                     // multiply this by the number of subscribers
                     $aggregate_discount = $aggregate_discount * $subscribers;
                     return $aggregate_discount;
                     
                 }else{
                     //get the tools in this toolbox
                     $tools = $this->getAllTheToolsInThisToolbox($toolbox_id);
                     $discount_sum = 0.00;
                     foreach($tools as $tool){
                         $discount_sum = $discount_sum + $this->getTheDiscountApplicableToThisTool($tool,$toolbox_id,$domain_id,$subscribers);
                                 
                     }
                     return $discount_sum;
                    
                 }
             }else{
                 return 0.00;
             }
             
         }
         
         /**
          * This is a function that will determine if discount is applicable to a transaction
          */
         public function isDiscountApplicableToThisToolboxTransaction($toolbox_id,$domain_id,$subscribers){
             
             $toolbox_domain_id = $this->getTheDomainIdOfThisToolbox($toolbox_id);
             if($this->isEnforceTheToolboxMinimumNumberOfDiscount($toolbox_id)){
                 if($subscribers >= $this->getTheToolboxMinDiscoutableValue($toolbox_id)){
                     return true;
                 }else{
                     return false;
                 }
             }else if($this->isEnforceThisDomainToolboxDiscountableNumber($toolbox_domain_id)){
                 if($this->isDomainMinDiscountableNumberOfToolboxUsersMet($toolbox_domain_id,$subscribers)){
                     return true;
                 }else{
                     return false;
                 }
                 
             }else{
                
                 return false;
             }
             
         }
         
         /**
          * This is the function that determines the domain owner of a toolbox
          */
         public function getTheDomainIdOfThisToolbox($toolbox_id){
             
                    $criteria = new CDbCriteria();
                    $criteria->select = '*';
                    $criteria->condition='id=:id';
                    $criteria->params = array(':id'=>$toolbox_id);
                    $domain= ResourceGroup::model()->find($criteria);
                    
                    return $domain['domain_id'];
             
         }
         
         /**
          * This is the function that verifies the possibility of enforcing a toolbox's minimum discountable value
          */
         public function isEnforceTheToolboxMinimumNumberOfDiscount($toolbox_id){
             
                    $criteria = new CDbCriteria();
                    $criteria->select = '*';
                    $criteria->condition='id=:id';
                    $criteria->params = array(':id'=>$toolbox_id);
                    $discount= ResourceGroup::model()->find($criteria);
                    
                    if($discount['enforce_min_discountable_number'] == 1){
                        return true;
                    }else{
                        return false;
                    }
             
         }
         
         /**
          * This is the function that verifies if a domain toolbox minimum discountable value is in force
          */
         public function isEnforceThisDomainToolboxDiscountableNumber($domain_id){
                    $criteria = new CDbCriteria();
                    $criteria->select = '*';
                    $criteria->condition='domain_id=:id and status=:status';
                    $criteria->params = array(':id'=>$domain_id,':status'=>'active');
                    $discount= DomainPolicy::model()->find($criteria);
                    
                    if($discount['enforce_min_discountable_number'] == 1){
                            return true;
                    }else{
                        return false;
                    }
             
         }
         
         /**
          * This is the function that verifies if a domain tool minimum discountable number is in force
          */
        
         public function isEnforceThisDomainToolDiscountableNumber($domain_id){
                   return ($this->isEnforceThisDomainToolboxDiscountableNumber($domain_id));
             
         }
         
         /**
          * This is the function that gets the toolbox minimum number of subscribers required to effect discount
          */
         public function getTheToolboxMinDiscoutableValue($toolbox_id){
             
                    $criteria = new CDbCriteria();
                    $criteria->select = '*';
                    $criteria->condition='id=:id';
                    $criteria->params = array(':id'=>$toolbox_id);
                    $discount= ResourceGroup::model()->find($criteria);
                    
                    return $discount['min_discountable_number'];
             
         }
         
         /**
          * This is the function that gets the discount value associated to a tool
          */
         public function getTheDiscountApplicableToThisTool($tool_id,$toolbox_id,$domain_id,$subscribers){
             
            ///get the tools domain
            $tool_domain_id = $this->getTheDomainOwnerOfThisTool($tool_id);
             //confirm if the minimum discountable number of users for tools in this domain is met
            if($this->isDiscountApplicableToThisToolTransaction($tool_id,$tool_domain_id,$subscribers)){
                 //determine if off this tool discount is applicable
                 if($this->isOffThisToolDiscountNotAppicable($tool_id)){
                     //retrieve the tool discount value
                     $discount_rate = $this->getTheStatedDiscountRateForThisTool($tool_id);
                     $aggregate_discount = $discount_rate * $this->getThePriceAssignedToThisTool($tool_id);
                     // multiply this by the number of subscribers
                     $aggregate_discount = $aggregate_discount * $subscribers;
                     return $aggregate_discount;
                     
                 }else{
                     //get the tasks in this tool
                     $tasks = $this->getTheTasksInThisTool($tool_id);
                     $discount_sum = 0.00;
                     foreach($tasks as $task){
                         $discount_sum = $discount_sum + $this->getTheDiscountApplicableToThisTask($task,$toolbox_id,$domain_id,$subscribers);
                                 
                     }
                     return $discount_sum;
                    
                 }
             }else{
                 return 0.00;
                 
             }
         }
         
         
        /**
         * This is the function that determines the domain owner of a tool
         */
         public function getTheDomainOwnerOfThisTool($tool_id){
             
                    $criteria = new CDbCriteria();
                    $criteria->select = '*';
                    $criteria->condition='id=:id';
                    $criteria->params = array(':id'=>$tool_id);
                    $domain= Resources::model()->find($criteria);
                    
                    return $domain['domain_id'];
         }
         
        /**
         * This is the function that determines if discount is applicable to a tool  
         */
         public function isDiscountApplicableToThisToolTransaction($tool_id,$domain_id,$subscribers){
             
            if($this->isEnforceThisDomainToolDiscountableNumber($domain_id)){
                 if($this->isDomainMinDiscountableNumberOfToolUsersMet($domain_id,$subscribers)){
                     return true;
                     
                 }else{
                     return false;
                    
                 }
                 
             }else{
                
                return false;
                 
             }
             
         }
         
                  
         
         /**
          * This is the function that gets the discount applicable to this task
          */
         public function getTheDiscountApplicableToThisTask($task_id,$toolbox_id,$domain_id,$subscribers){
             
             //get the domain id of this task
             $task_domain_id = $this->getTheDomainOfThisTask($task_id);
             
             if($this->isDiscountApplicableToThisTaskTransaction($task_id,$task_domain_id,$subscribers)){
                 //determine if off this tool discount is applicable
                 if($this->isOffThisTaskDiscountNotAppicable($task_id)){
                     
                     //retrieve the task discount value
                    $discount_rate = $this->getTheStatedDiscountRateForThisTask($task_id);
                    $aggregate_discount = $discount_rate * $this->getThePriceForThisTask($task_id);
                    // multiply this by the number of subscribers
                    $aggregate_discount = $aggregate_discount * $subscribers;
                    return $aggregate_discount;
                 }else{
                     
                    return 0.00;
                 }
                 
                 
             }else{
                 return 0.00;
             }
            
         }
         
         
         /**
         * This is the function that determines if discount is applicable to a task  
         */
         public function isDiscountApplicableToThisTaskTransaction($task_id,$domain_id,$subscribers){
             
            if($this->isEnforceThisDomainTaskDiscountableNumber($domain_id)){
                 if($this->isDomainMinDiscountableNumberOfTaskUsersMet($domain_id,$subscribers)){
                     return true;
                 }else{
                     return false;
                 }
                 
             }else{
                
                 return false;
             }
             
         }
         
         
         /**
          * This is the function that verifies if a domain task minimum discountable number is in force
          */
        
         public function isEnforceThisDomainTaskDiscountableNumber($domain_id){
                   return $this->isEnforceThisDomainToolboxDiscountableNumber($domain_id);
         }
         
         
         /**
          * This is the function that gets the domain owner of a task
          */
         public function getTheDomainOfThisTask($task_id){
             
                    $criteria = new CDbCriteria();
                    $criteria->select = '*';
                    $criteria->condition='id=:id';
                    $criteria->params = array(':id'=>$task_id);
                    $domain= Resources::model()->find($criteria);
                    
                    return $domain['domain_id'];
             
         }
         
         /**
          * This is the function that determines if the discount should be applied to the toolbox based on the number of subscribed users
          */
         public function isDomainMinDiscountableNumberOfToolboxUsersMet($domain_id,$subscribers){
             
                 if($subscribers>=$this->getTheDomainStatedMinToolboxUserNumberForDiscount($domain_id)){
                     return true;
                 }else{
                     return false;
                 }
         }
         
         /**
          * This is th function that determines if the discount shoule be applied to the tool base on the number of subscribers
          */
         public function isDomainMinDiscountableNumberOfToolUsersMet($domain_id,$subscribers){
             
             if($subscribers>=$this->getTheDomainStatedMinToolUserNumberForDiscount($domain_id)){
                     return true;
                 
                 }else{
                    return false;
                    
                 }
         }
         
         
         /**
          * This is the function that determines if discount should apply to the task base on the number of subscribers
          */
         public function isDomainMinDiscountableNumberOfTaskUsersMet($domain_id,$subscribers){
             
             if($subscribers>=$this->getTheDomainStatedMinTaskUserNumberForDiscount($domain_id)){
                     return true;
                 }else{
                     return false;
                 }
         }
         /**
          * This is the function that gets the domain's minimum value before discount is applicable to a toolbox
          */
         public function getTheDomainStatedMinToolboxUserNumberForDiscount($domain_id){
                    $criteria = new CDbCriteria();
                    $criteria->select = '*';
                    $criteria->condition='domain_id=:id and status=:status';
                    $criteria->params = array(':id'=>$domain_id,':status'=>'active');
                    $users= DomainPolicy::model()->find($criteria);
                    
                    if($users['minimum_toolbox_discountable_number'] !== NULL || $users['minimum_toolbox_discountable_number']>=0 ){
                        return $users['minimum_toolbox_discountable_number'];
                    }else{
                        return ($this->platformDiscountApplicableNumber($domain_id));
                    }
                    
            
         }
         
         /**
          * This is the function that gets the domain's minimum value before discount is applicable to a tool
          */
         public function getTheDomainStatedMinToolUserNumberForDiscount($domain_id){
                    $criteria = new CDbCriteria();
                    $criteria->select = '*';
                    $criteria->condition='domain_id=:id and status=:status';
                    $criteria->params = array(':id'=>$domain_id,':status'=>'active');
                    $users= DomainPolicy::model()->find($criteria);
                    
                    if($users['minimum_tool_discountable_number'] !== NULL || $users['minimum_tool_discountable_number']>=0){
                       return $users['minimum_tool_discountable_number'];
                       
                    }else{
                        return ($this->platformDiscountApplicableNumber($domain_id));
                       
                    }
                    
            
         }
         
         /**
          * This is the function that gets the domain's minimum value before discount is applicable to a task
          */
         public function getTheDomainStatedMinTaskUserNumberForDiscount($domain_id){
                    $criteria = new CDbCriteria();
                    $criteria->select = '*';
                    $criteria->condition='domain_id=:id and status=:status';
                    $criteria->params = array(':id'=>$domain_id,':status'=>'active');
                    $users= DomainPolicy::model()->find($criteria);
                    
                    if($users['minimum_task_discountable_number'] !== NULL || $users['minimum_task_discountable_number']>=0){
                        return $users['minimum_task_discountable_number'];
                    }else{
                        return ($this->platformDiscountApplicableNumber($domain_id));
                    }
                    
            
         }
         
         /**
          * This is the function that calculates the platform allowable discount number base on a domain
          */
         public function platformDiscountApplicableNumber($domain_id){
             
             $discountable_number = ($this->platformDefaultMinDiscoutableNumber() * $this->totalNumberOfDomainPlatformSubscribers($domain_id))*1000;
             
             return $discountable_number;
             
         }
         
         /**
          * This is the function that retrieves the platforms defaults discountable number
          */
         public function platformDefaultMinDiscoutableNumber(){
             
                    $criteria = new CDbCriteria();
                    $criteria->select = '*';
                   // $criteria->condition='id=:id';
                    //$criteria->params = array(':id'=>$domain_id);
                    $settings= PlatformSettings::model()->find($criteria);
                    
                    return $settings['default_min_discount_settings'];
             
         }
         
         /**
          * This is the function retrieves the total domain subscriber base
          */
         public function totalNumberOfDomainPlatformSubscribers($domain_id){
             
                  $cmd =Yii::app()->db->createCommand();
                $cmd->select('COUNT(*)')
                    ->from('user')
                    ->where("domain_id = $domain_id");
                $result = $cmd->queryScalar();
                
                return $result; 
         }
         
         /**
          * This is the function that will determine if off this toolbox discount should apply
          */
         public function isOffThisToolboxDiscountNotAppicable($toolbox_id){
             
                    $criteria = new CDbCriteria();
                    $criteria->select = '*';
                    $criteria->condition='id=:id';
                    $criteria->params = array(':id'=>$toolbox_id);
                    $discount= ResourceGroup::model()->find($criteria);
                    
                    if($discount['discount_proof'] == 1){
                        return true;
                    }else{
                        return false;
                    }
             
         }
         
         /**
          * This is the value that gets the actual stated discount value for this toolbox
          */
         public function getTheStatedDiscountRate($toolbox_id){
             
                    $criteria = new CDbCriteria();
                    $criteria->select = '*';
                    $criteria->condition='id=:id';
                    $criteria->params = array(':id'=>$toolbox_id);
                    $discount= ResourceGroup::model()->find($criteria);
                    
                    return ($discount['discount_rate']/100);
         }
         
         /**
          * This is the function that will determine if tool is discount proof
          */
         public function isOffThisToolDiscountNotAppicable($tool_id){
                    $criteria = new CDbCriteria();
                    $criteria->select = '*';
                    $criteria->condition='id=:id';
                    $criteria->params = array(':id'=>$tool_id);
                    $discount= Resources::model()->find($criteria);
                    
                    if($discount['discount_proof'] == 1){
                        return true;
                    }else{
                        return false;
                    }
         }
         
         
          /**
          * This is the function that will determine if a task is discount proof
          */
         public function isOffThisTaskDiscountNotAppicable($task_id){
                    $criteria = new CDbCriteria();
                    $criteria->select = '*';
                    $criteria->condition='id=:id';
                    $criteria->params = array(':id'=>$task_id);
                    $discount= Resources::model()->find($criteria);
                    
                    if($discount['discount_proof'] == 1){
                        return true;
                    }else{
                        return false;
                    }
         }
         
         /**
          * This is the function that retrieves the discount rate for a tool
          */
         public function getTheStatedDiscountRateForThisTool($tool_id){
             
                    $criteria = new CDbCriteria();
                    $criteria->select = '*';
                    $criteria->condition='id=:id';
                    $criteria->params = array(':id'=>$tool_id);
                    $discount= Resources::model()->find($criteria);
                    
                    return ($discount['discount_rate']/100);
         }
         
         /**
          * This is the function that retrieves the discount rate for this task
          */
         public function getTheStatedDiscountRateForThisTask($task_id){
             
                    $criteria = new CDbCriteria();
                    $criteria->select = '*';
                    $criteria->condition='id=:id';
                    $criteria->params = array(':id'=>$task_id);
                    $discount= Resources::model()->find($criteria);
                    
                    return ($discount['discount_rate']/100);
         }
         
         
         /**
          * This is the function that retrieves the toolbox name
          */
         public function getTheToolboxName($toolbox_id){
                    $criteria = new CDbCriteria();
                    $criteria->select = '*';
                    $criteria->condition='id=:id';
                    $criteria->params = array(':id'=>$toolbox_id);
                    $name= ResourceGroup::model()->find($criteria);
                    
                    return $name['name'];
             
         }
         
         /**
          * This is the function that retrieves the expiray date of this toolbox in this domain
          */
         public function getTheToolboxExpiryDate($toolbox_id,$domain_id){
             
                    $criteria = new CDbCriteria();
                    $criteria->select = '*';
                    $criteria->condition='category_id=:categoryid and resourcegroup_id=:toolboxid';
                    $criteria->params = array(':categoryid'=>$domain_id,':toolboxid'=>$toolbox_id);
                    $expiry= ResourcegroupHasResourcegroupcategory::model()->find($criteria);
                    
                    return $expiry['end_date'];
             
         }
         
         
         /**
          * This is the function that gets the total number of tasks in a toolbox
          */
         public function getTotalNumberOfTasksInThisToolbox($toolbox_id){
             
             //retrieve the tools in this toolbox
             $tools = $this->getAllTheToolsInThisToolbox($toolbox_id);
             $sum_tasks = 0;
             foreach($tools as $tool){
                    $sum_tasks = $sum_tasks + $this->getTheTotalNumberOfTaskInThisTool($tool);
                }
             return $sum_tasks;
         }
        /**
         * Determine a domain id of a user given his user id 
         */
        public function determineAUserDomainIdGiven_old($userid){
            
            //determine the usertype id of the user
            $typeid = $this->determineAUserUsertypeId($userid);
            //determine the usertype name of this usertypeid
            $typename = $this->determineUserTypeName($typeid);
            
            //determine the domain id given usertype name
            $domainid = $this->determineDomainIdGiveUsertypeName($typename);
            
            //determine the domain name given its id
            $name = $this->determineDomainNameGivenItId($domainid);
            //determine the domain id given its name
            $domainname = $this->determineDomainIdGivenItsName($name);
            
            return $domainname;
            
            
        }
        
        
         /**
         * Determine a domain id of a user given his user id 
         */
        public function determineAUserDomainIdGiven($userid){
            
            $criteria1 = new CDbCriteria();
            $criteria1->select = '*';
            $criteria1->condition='id=:id';
            $criteria1->params = array(':id'=>$userid);
            $user= User::model()->find($criteria1);
            
            return $user['domain_id'];
        }
        
        
              
        /**
         * this is the function that retrieves the grouptype id given domain name
         */
        public function determineGrouptypeIdGivenDomainName($domainname){
            
            $criteria = new CDbCriteria();
            $criteria->select = 'id, name';
            $criteria->condition='name=:name';
            $criteria->params = array(':name'=>$domainname);
            $grouptypeid= GroupType::model()->find($criteria);
            
            return $grouptypeid['id'];
            
            
        }
           
        /**
         * Determine a users usertype_id
         */
        public function determineAUserUsertypeId($userid){
            
            $criteria = new CDbCriteria();
            $criteria->select = 'id, usertype_id';
            $criteria->condition='id=:id';
            $criteria->params = array(':id'=>$userid);
            $usertype= User::model()->find($criteria);
            
            return $usertype['usertype_id'];
            
            
        }
        
        /*
         * Determine a usertype name given its id
         */
        public function determineUserTypeName($usertypeid){
            $criteria1 = new CDbCriteria();
            $criteria1->select = 'id, name';
            $criteria1->condition='id=:id';
            $criteria1->params = array(':id'=>$usertypeid);
            $name= UserType::model()->find($criteria1);
            
            return $name['name'];
            
        }
        
        /*
         *  determine a usertype id given its name
         */
        public function determineUsertypeNameGiveId($usertypename){
            $criteria1 = new CDbCriteria();
            $criteria1->select = 'id, name';
            $criteria1->condition='name=:name';
            $criteria1->params = array(':name'=>$usertypename);
            $id= UserType::model()->find($criteria1);
            
            return $id['id'];
        }
        
        /*
         * Determine a domain name given a usetypername
         */
        public function determineDomainNameGiveUsertypeName($usertypename){
            
            $criteria1 = new CDbCriteria();
            $criteria1->select = 'id, name';
            $criteria1->condition='name=:name';
            $criteria1->params = array(':name'=>$usertypename);
            $name= ResourcegroupCategory::model()->find($criteria1);
            
            return $name['name'];
            
        }
        
        /*
         * Determine a domain id given a usetypername
         */
        public function determineDomainIdGiveUsertypeName($usertypename){
            
            $criteria1 = new CDbCriteria();
            $criteria1->select = 'id, name';
            $criteria1->condition='name=:name';
            $criteria1->params = array(':name'=>$usertypename);
            $id= ResourcegroupCategory::model()->find($criteria1);
            
            return $id['id'];
            
        }
        
        
        /**
         * Determine a domain id given its name
         */
        public function determineDomainIdGivenItsName($name){
            $criteria1 = new CDbCriteria();
            $criteria1->select = 'id, name';
            $criteria1->condition='name=:name';
            $criteria1->params = array(':name'=>$name);
            $id= ResourcegroupCategory::model()->find($criteria1);
            
            return $id['id'];
            
        }
        
        /**
         * Determine a domain name given its id
         */
        public function determineDomainNameGivenItId($domainid){
            $criteria1 = new CDbCriteria();
            $criteria1->select = 'id, name';
            $criteria1->condition='id=:id';
            $criteria1->params = array(':id'=>$domainid);
            $name= ResourcegroupCategory::model()->find($criteria1);
            
            return $name['name'];
            
            
        }
        
        /**
         * This is the function that retrieves a resource/tool id given its name
         */
        public function determineResourceOrToolId($toolname){
            
            $criteria1 = new CDbCriteria();
            $criteria1->select = 'id, name';
            $criteria1->condition='name=:name';
            $criteria1->params = array(':name'=>$toolname);
            $id= Resources::model()->find($criteria1);
            
            return $id['id'];
            
        }
        
        
        /**
         * This is the function that retrieves a resource/tool name given its id
         */
        public function determineResourceOrToolName($toolid){
            
            $criteria1 = new CDbCriteria();
            $criteria1->select = 'id, name';
            $criteria1->condition='id=:id';
            $criteria1->params = array(':id'=>$toolid);
            $name= Resources::model()->find($criteria1);
            
            return $name['name'];
            
        }
        
        /**
         * This is the function that retrieves a resource/tool name given its id
         */
        public function determineGrouptypeGivenDomainId($domainid){
            
            $criteria1 = new CDbCriteria();
            $criteria1->select = 'id, name';
            $criteria1->condition='id=:id';
            $criteria1->params = array(':id'=>$domainid);
            $name= GroupType::model()->find($criteria1);
            
            return $name['name'];
            
        }
        
        /**
         * This is the function the retrieves a group id given the group name
         */
        public function determineGroupIdGivenGroupName($groupname,$domainid){
            
            //obtain the grouptype id given a domain id
            $grouptype_id = $this->determineGrouptypeIdGivenDomainId($domainid);
            $criteria = new CDbCriteria();
            $criteria->select = 'id, name';
            $criteria->condition='name=:name and grouptype_id=:id';
            $criteria->params = array(':name'=>$groupname, ':id'=>$grouptype_id);
            $id= Group::model()->find($criteria);
            
            return $id['id'];
            
            
        }
        
        /**
         * This is the function to retrieve subgroup id given subgroup name
         */
        public function determineSubgroupIdGivenSubgroupName($subgroupname, $domainid){
            //determine the group for this subgroup            
            $criteria = new CDbCriteria();
            $criteria->select = 'id, name, group_id';
            $criteria->condition='name=:name';
            $criteria->params = array(':name'=>$subgroupname);
            $groups= SubGroup::model()->findAll($criteria);
            
            foreach($groups as $group){
                $groupdomainid = $this->determineDomainIdGivenGroupId($group['group_id']);
                if($groupdomainid == $domainid){
                    $criteria1 = new CDbCriteria();
                    $criteria1->select = 'id, name';
                    $criteria1->condition='name=:name';
                    $criteria1->params = array(':name'=>$subgroupname);
                    $id= SubGroup::model()->find($criteria1);
                    
                     return $id['id'];
                    
                }
                
                
            }
            
           
            
        }
        
        /**
         * This is the function that determines grouptype is given domain id
         */
        public function determineGrouptypeIdGivenDomainId($domainid){
            
            //determine domain name
            $domainname = $this->determineDomainNameGivenItId($domainid);
            //Determine grouptype id given domain name
            $grouptypeid = $this->determineGrouptypeIdGivenDomainName($domainname);
            
            return $grouptypeid;
            
        }
        
        
        /**
         * This is the function that determines domain id given group id
         */
        public function determineDomainIdGivenGroupId($groupid){
            //determine grouptype id given group id
            $grouptypeid = $this->determineGrouptypeIdGivenGroupId($groupid);
            //determine domain id given grouptype id
            $domainid = $this->determineDomainIdGivenGrouptypeId($grouptypeid);
            
            return $domainid;
            
            
        }
        
        /**
         * This is the function that determines the grouptypeid given group id
         */
        public function determineGrouptypeIdGivenGroupId($groupid){
            
            $criteria = new CDbCriteria();
            $criteria->select = 'id, name, grouptype_id';
            $criteria->condition='id=:id';
            $criteria->params = array(':id'=>$groupid);
            $type= Group::model()->find($criteria);
            
            return $type['grouptype_id'];
            
        }
        
        /**
         * This is the function that returns domain id given grouptype id
         */
        public function determineDomainIdGivenGrouptypeId($grouptypeid){
            
            //determine the grouptype name
            $typename = $this->determineGrouptypeNameGivenGrouptypeId($grouptypeid);
            
            $domainname = $this->determineDomainNameGivenGrouptypeName($typename);
           
            //determine domain id given its id
            $domainid = $this->determineDomainIdGivenItsName($domainname);
            
            return $domainid;
            
            
        }
        
        /**
         * This is the function that determines grouptype name given its id
         **/
        public function determineGrouptypeNameGivenGrouptypeId($typeid){
            
            $criteria = new CDbCriteria();
            $criteria->select = 'id, name';
            $criteria->condition='id=:id';
            $criteria->params = array(':id'=>$typeid);
            $type= GroupType::model()->find($criteria);
            
            return $type['name'];
            
        }
        
        /**
         * This is the function that determines domain name given grouptype name
         */
        public function determineDomainNameGivenGrouptypeName($typename){
            
            $criteria = new CDbCriteria();
            $criteria->select = 'id, name';
            $criteria->condition='name=:name';
            $criteria->params = array(':name'=>$typename);
            $domain= ResourcegroupCategory::model()->find($criteria);
            
            return $domain['name'];
            
        }
        
        /**
         * This is the function that obtains a toolbox name given its id 
         */
        public function determineToolboxNameGivenItsId($toolboxid){
            
            $criteria = new CDbCriteria();
            $criteria->select = 'id, name';
            $criteria->condition='id=:id';
            $criteria->params = array(':id'=>$toolboxid);
            $toolbox= Resourcegroup::model()->find($criteria);
            
            return $toolbox['name'];
            
        }
        
        
        /**
         * This is the function that obtains a toolbox id given its name
         */
        public function determineToolboxIdGivenItsName($toolboxname){
            
            $criteria = new CDbCriteria();
            $criteria->select = 'id, name';
            $criteria->condition='name=:name';
            $criteria->params = array(':name'=>$toolboxname);
            $toolbox= Resourcegroup::model()->find($criteria);
            
            return $toolbox['id'];
            
        }
        
        /**
         * This is the function that will retrieve the items in the cart for an order
         */
        public function actionListSingleOrderItemsInCart(){
            
            //get the order id
            $order_id = $_REQUEST['order_id'];
                       
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='order_id=:orderid';
            $criteria->params = array(':orderid'=>$order_id);
            $orders = OrderHasToolboxes::model()->findAll($criteria);
                 
            if($orders===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            "items" =>$orders
                          
                           
                           
                          
                       ));
                       
                }
        }
        
        /**
         * This is the function that gets the total number of this toolbox users in a domain
         */
        public function getTheTotalNumberOfToolboxUsers($toolbox_id,$domain_id){
            
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='resourcegroup_id=:id and category_id=:categoryid';
            $criteria->params = array(':id'=>$toolbox_id,':categoryid'=>$domain_id);
            $users = ResourcegroupHasResourcegroupcategory::model()->find($criteria);
                 
            return $users['no_of_subscribers'];
        }
        
        
        /**
         * This is the function that gets the year of subscription
         */
        public function getTheNumberOfYearsOfSubscription($toolbox_id,$domain_id){
            
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='resourcegroup_id=:id and category_id=:categoryid';
            $criteria->params = array(':id'=>$toolbox_id,':categoryid'=>$domain_id);
            $users = ResourcegroupHasResourcegroupcategory::model()->find($criteria);
                 
            return $users['number_of_years'];
            
        }
        
               
        /**
         * This is the function that computes the gross amount for a toolbox in a domain
         */
        public function getTheGrossAmountForThisToolboxPerDomain($toolbox_id, $domain_id,$subscribers){
            
             $toolbox_amount = $this->getThisToolboxAmount($toolbox_id) * $subscribers * $this->getTheNumberOfYearsOfSubscription($toolbox_id, $domain_id);
         
            return $toolbox_amount; 
              
        }
        
        /**
         * This is the function that gets the applicable discount of a toolbox to a domain
         */
        public function getTheApplicableDiscountForThisToolbox($toolbox_id,$domain_id,$subscribers){
          
               //get the applicable discount
                $discount_sum  = $this->getTheDiscountAmountForThisToolbox($toolbox_id,$domain_id,$subscribers)*$this->getTheNumberOfYearsOfSubscription($toolbox_id, $domain_id);
            return $discount_sum;
             
        }
        
        
        /**
         * This is the function that retrieves the current detail of a remittance due to a domain
         */
        public function actionretrieveDomainDueRemittance(){
            
             //$toolbox_id = $_REQUEST['id'];
           
            $userid = Yii::app()->user->id;
            
            //get the logged in user domain
            $domain_id = $this->determineAUserDomainIdGiven($userid);
            
            
                           
                //get the accraubles from own toolboxes in user by other domains
                $toolbox_accruables = $this->getAllTheAccruableAmountsFromOwnToolboxesInUserByOtherDomains($domain_id);
                
                //get the accruables from own tools used outside own toolbox by other domains
                $standalone_tool_accruable = $this->getTheAccruableAmountsFromOwnToolsConsumedByOtherDomains($domain_id);
                
                //get the accruables from own tasks used outside own toolbox by other domains
                $standalone_task_accruable = $this->getTheAccruableAmountsFromOwnTasksConsumedByOtherDomains($domain_id);
                
                //get the total discount offered to other domains within this remittance period
                $total_discount_offerred = $this->getTheTotalDiscountOfferredToOtherDomainsWithinRemittancePeriod($domain_id);
               
                //get the total number of current users consuming own products
                $toolbox_users =$this->getTheTotalNumberOfOtherDomainUsersConsumingOwnToolboxes($domain_id);
                
                //get the total vat applicable to a domain from current remittance
                $vat = $this->getTheTotalVatApplicableToDomainInThisRemittance($domain_id);
                
                //get the estimated remittance date
                $remittance_date = $this->getTheEstimatedRemittanceDate($domain_id);
                
                //get the applicable remittance currency
                $remittance_currency = $this->getTheApplicableRemittanceCurrency($domain_id);
                
                //get the remittance mode
                $remittance_mode = $this->getTheRemittanceMode();
                
                //calculate the amount that will be remitted to this domain
                 $remittance_amount = $this->getTheRemittanceAmountForThisDomain($domain_id);
                
                //get the domain domiciled bank name
                $bank_name = $this->getTheDomainBankName($domain_id);
                
                //get the domain account title
                $account_title = $this->getTheDomainAccountTitle($domain_id);
                
                //get the domain account type
                $account_type = $this->getTheDomainAccountType($domain_id);
                
                //get the domain account number
                $account_number = $this->getTheDomainAccountNumber($domain_id);
                
                
             
                if($domain_id===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                }else{
                    header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            "toolbox_accruable" => $toolbox_accruables,
                            "tools_accruable" => $standalone_tool_accruable,
                            "tasks_accruable" => $standalone_task_accruable,
                            "total_users" => $toolbox_users,
                            "total_discount_granted" => $total_discount_offerred,
                            "vat" => $vat,
                           "remittance_date" => $remittance_date,
                           "remittance_currency" => $remittance_currency,
                           "remittance_mode"=>$remittance_mode,
                           "remittance_amount" => $remittance_amount,
                           "bank_name" => $bank_name,
                           "account_title" => $account_title,
                           "account_type" => $account_type,
                           "account_number" => $account_number,
                         
                          
                       
                       ));
                    
                }
            
        }
        
        /**
         * This is the function for renewal payments
         */
        public function actiongetToolboxForRenewalInfoOnThatDomain(){
            
             $userid = Yii::app()->user->id;
            
            //get the logged in user domain
            $domain_id = $this->determineAUserDomainIdGiven($userid);
            
            
            $toolbox_id = $_REQUEST['toolbox_id'];
            //$toolbox_id = 10;
            
            
            //get the payment mode
            $payment_mode = $this->getThePlatformApprovedPaymentMode($domain_id);
            
            //get the account name
            
            $account_title = $this->getThePlatformAccountName($domain_id);
            
            //get the account number
            $account_number = $this->getThePlatformAccountNumber($domain_id);
            
            //get the Swift Code
            $swift_code = $this->getThePlatformSwiftCode($domain_id);
            
            //get the account type 
            $account_type = $this->getThePlatformAccountType($domain_id);
            
            //get the bank name
            $bank_name = $this->getThePlatformAccountBankName($domain_id);
            
            //generate the renewal order number
            $order_number=$this->generateRenewalOrderNumber($toolbox_id,$domain_id);
            
            if($toolbox_id===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                }else{
                    header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                           "payment_mode" => $payment_mode,
                           "account_number" => $account_number,
                           "swift_code"=>$swift_code,
                           "account_type" => $account_type,
                           "order_number" =>  $order_number,
                           "account_name" => $account_title,
                           "bank_name" => $bank_name,
                          
                         
                          
                       
                       ));
                    
                }
            
        }
        
        
        
        /**
         * This is the function for new order payment
         */
        public function actionretrieveOrderForRenewalInfoOnThatDomain(){
            
             $userid = Yii::app()->user->id;
            
            //get the logged in user domain
            $domain_id = $this->determineAUserDomainIdGiven($userid);
            
            
            //$order_id = $_REQUEST['order_id'];
            //$toolbox_id = 10;
            
            //the store id
            
           if(isset($_REQUEST['store_id'])){
               $store_id = $_REQUEST['store_id'];
           }
            if(isset($_REQUEST['order_id'])){
                 $order_id = $_REQUEST['order_id'];
                 
                 $order_number = $this->getThisOrderNumber($order_id);
            }else{
                $order_number = "";
            }
            
       
            //get the payment mode
            $payment_mode = $this->getThePlatformApprovedPaymentMode($domain_id);
            
            //get the account name
            
            $account_title = $this->getThePlatformAccountName($domain_id);
            
            //get the account number
            $account_number = $this->getThePlatformAccountNumber($domain_id);
            
            //get the Swift Code
            $swift_code = $this->getThePlatformSwiftCode($domain_id);
            
            //get the account type 
            $account_type = $this->getThePlatformAccountType($domain_id);
            
            //get the bank name
            $bank_name = $this->getThePlatformAccountBankName($domain_id);
            
            //get the store currency code
            $currency_code = $this->getTheRelevantCurrencyCodeForThisStore($store_id);
            
            //retrieve the pre request order number 
            //$order_number=$this->getThePreRequestNumber($toolbox_id,$domain_id);
            
            //get the total number of own physical documents on request
            $own_physical_document = $this->getOwnPhysicalDocumentOnRequest($userid,$domain_id);
            
            //get the total number of own physical batches on request
            $own_physical_batch = $this->getOwnPhysicalBatchOnRequest($userid,$domain_id);
            
             //get the total number of own physical boxes on request
            $own_physical_box = $this->getOwnPhysicalBoxOnRequest($userid,$domain_id);
            
             //get the total number of own virtual documents on request
            $own_virtual_document = $this->getOwnVirtualDocumentOnRequest($userid,$domain_id);
            
             //get the total number of own virtual batches on request
            $own_virtual_batch = $this->getOwnVirtualBatchOnRequest($userid,$domain_id);
            
            //get the total number of own virtual box on request
            $own_virtual_box = $this->getOwnVirtualBoxOnRequest($userid,$domain_id);
            
            //get the total number of other domain physical documents on request
            $other_physical_document = $this->getOtherDomainPhysicalDocumentOnRequest($userid,$domain_id);
            
             //get the total number of other domain physical batches on request
            $other_physical_batch = $this->getOtherDomainPhysicalBatchOnRequest($userid,  $domain_id);
            
             //get the total number of other domain physical boxes on request
            $other_physical_box = $this->getOtherDomainPhysicalBoxOnRequest($userid,$domain_id);
            
            //get the total number of other domain virtual documents on request
            $other_virtual_document = $this->getOtherDomainVirtualDocumentOnRequest($userid,$domain_id);
            
            //get the total number of other domain virtual batches on request
            $other_virtual_batch = $this->getOtherDomainVirtualBatchOnRequest($userid,$domain_id);
            
            //get the total number of other domain virtual boxes on request
            $other_virtual_box = $this->getOtherDomainVirtualBoxOnRequest($userid,$domain_id);
            
            if($domain_id===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                }else{
                    header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                           "payment_mode" => $payment_mode,
                           "account_number" => $account_number,
                           "swift_code"=>$swift_code,
                           "account_type" => $account_type,
                           "order_number" =>  $order_number,
                           "account_name" => $account_title,
                           "bank_name" => $bank_name,
                           "currency_code"=>$currency_code,
                           "number_of_physical_documents"=>$own_physical_document,
                           "number_of_physical_batches"=>$own_physical_batch,
                           "number_of_physical_boxes"=>$own_physical_box,
                           "number_of_other_physical_documents"=>$other_physical_document,
                           "number_of_other_physical_batches"=>$other_physical_batch,
                           "number_of_other_physical_boxes"=>$other_physical_box,
                           "number_of_virtual_documents"=> $own_virtual_document,
                           "number_of_virtual_batches"=>$own_virtual_batch,
                           "number_of_virtual_boxes"=>$own_virtual_box,
                           "number_of_other_virtual_documents"=>$other_virtual_document,
                           "number_of_other_virtual_batches"=>$other_virtual_batch,
                           "number_of_other_virtual_boxes"=>$other_virtual_box
                          
                         
                          
                       
                       ));
                    
                }
            
        }
        
        
        /**
         * This is the function that retrieves an order number of a particular order
         */
        public function getThisOrderNumber($order_id){
            
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='id=:orderid';
            $criteria->params = array(':orderid'=>$order_id);
            $order = Order::model()->find($criteria);
            
            return $order['order_number'];
        }
        
        /**
         * This is the function that gets own physical document on request
         */
        public function getOwnPhysicalDocumentOnRequest($user_id,$domain_id){
           //get all own physical document with initiated request status 
            $documents_on_request = $this->getAllSelfInitiatedDocumentsUndergoingRequest($user_id);
            $counter = 0;
            
            foreach($documents_on_request as $doc){
                if($this->isThisInstrumentAnOwnDomainDocument($doc,$domain_id)){
                    $counter = $counter + 1;
                }
            }
            return $counter;
        }
        
        
        /**
         * This is the function that confirms if a document belongs to a domain
         */
        public function isThisInstrumentAnOwnDomainDocument($doc,$domain_id){
            
              $cmd =Yii::app()->db->createCommand();
                $cmd->select('COUNT(*)')
                    ->from('resources')
                    ->where("domain_id = $domain_id and id =$doc");
                $result = $cmd->queryScalar();
                
                if($result >0){
                    return true;
                }else{
                    return false;
                } 
        }
        
        /**
         * This is the function that spools all self initiated documents on request
         */
        public function getAllSelfInitiatedDocumentsUndergoingRequest($user_id){
            
             $criteria6 = new CDbCriteria();
             $criteria6->select = '*';
             $criteria6->condition='(request_initiated_by=:userid and is_request_cancelled=:cancelled) and (is_sent=:sent and is_requested=:requested)';
             $criteria6->params = array(':userid'=>$user_id,':sent'=>false,':requested'=>false,':cancelled'=>false);
             $requests = PhysicalDocumentRequest::model()->findAll($criteria6);  
             
             $documents = [];
            foreach($requests as $request){
                $documents[] = $request['document_id'];
            }
            return $documents;
            
        }
        
        
        
         /**
         * This is the function that gets other domain physical document on request
         */
        public function getOtherDomainPhysicalDocumentOnRequest($user_id,$domain_id){
           //get all own physical document with initiated request status 
            $documents_on_request = $this->getAllSelfInitiatedDocumentsUndergoingRequest($user_id);
            $counter = 0;
            
            foreach($documents_on_request as $doc){
                if($this->isThisInstrumentAnOwnDomainDocument($doc,$domain_id)== false){
                    $counter = $counter + 1;
                }
            }
            return $counter;
        }
        
        
        /**
         * This is the function that confirms if a document belongs to a domain
         */
        public function isThisInstrumentAnOwnDomainBatch($batch,$domain_id){
            
              $cmd =Yii::app()->db->createCommand();
                $cmd->select('COUNT(*)')
                    ->from('resources')
                    ->where("domain_id = $domain_id and id =$batch");
                $result = $cmd->queryScalar();
                
                if($result >0){
                    return true;
                }else{
                    return false;
                } 
        }
        
        
        
        /**
         * This is the function that gets own physical batch on request
         */
        public function getOwnPhysicalBatchOnRequest($user_id,$domain_id){
            
            //get all own physical batch & file with initiated request status 
            $batches_on_request = $this->getAllSelfInitiatedBatchesUndergoingRequest($user_id);
            $counter = 0;
            
            foreach($batches_on_request as $batch){
                if($this->isThisInstrumentAnOwnDomainBatch($batch,$domain_id)){
                    $counter = $counter + 1;
                }
            }
            return $counter;
            
        }
        
         /**
         * This is the function that spools all self initiated batches & file on request
         */
        public function getAllSelfInitiatedBatchesUndergoingRequest($user_id){
            
             $criteria6 = new CDbCriteria();
             $criteria6->select = '*';
             $criteria6->condition='(request_initiated_by=:userid and is_request_cancelled=:cancelled) and (is_sent=:sent and is_requested=:requested)';
             $criteria6->params = array(':userid'=>$user_id,':sent'=>false,':requested'=>false,':cancelled'=>false);
             $requests = PhysicalBatchRequest::model()->findAll($criteria6);  
             
             $batches = [];
            foreach($requests as $request){
                $batches[] = $request['batch_id'];
            }
            return $batches;
            
        }
        
        
        /**
         * This is the function that gets own physical batch on request
         */
        public function getOtherDomainPhysicalBatchOnRequest($user_id,$domain_id){
            
            //get all own physical batch & file with initiated request status 
            $batches_on_request = $this->getAllSelfInitiatedBatchesUndergoingRequest($user_id);
            $counter = 0;
            
            foreach($batches_on_request as $batch){
                if($this->isThisInstrumentAnOwnDomainBatch($batch,$domain_id) == false){
                    $counter = $counter + 1;
                }
            }
            return $counter;
            
        }
        
        
        /**
         * This is the function that gets own physical box & folder on request
         */
        public function getOwnPhysicalBoxOnRequest($user_id,$domain_id){
            
            //get all own physical box & folder with initiated request status 
            $boxes_on_request = $this->getAllSelfInitiatedBoxesUndergoingRequest($user_id);
            $counter = 0;
            
            foreach($boxes_on_request as $box){
                if($this->isThisInstrumentAnOwnDomainBox($box,$domain_id)){
                    $counter = $counter + 1;
                }
            }
            return $counter;
        }
        
        
        /**
         * This is the function that spools all self initiated batches & file on request
         */
        public function getAllSelfInitiatedBoxesUndergoingRequest($user_id){
            
             $criteria6 = new CDbCriteria();
             $criteria6->select = '*';
             $criteria6->condition='(request_initiated_by=:userid and is_request_cancelled=:cancelled) and (is_sent=:sent and is_requested=:requested)';
             $criteria6->params = array(':userid'=>$user_id,':sent'=>false,':requested'=>false,':cancelled'=>false);
             $requests = PhysicalBoxRequest::model()->findAll($criteria6);  
             
             $boxes = [];
            foreach($requests as $request){
                $boxes[] = $request['box_id'];
            }
            return $boxes;
            
        }
        
        
        /**
         * This is the function that confirms if a document belongs to a domain
         */
        public function isThisInstrumentAnOwnDomainBox($box,$domain_id){
            
              $cmd =Yii::app()->db->createCommand();
                $cmd->select('COUNT(*)')
                    ->from('resourcegroup')
                    ->where("domain_id = $domain_id and id =$box");
                $result = $cmd->queryScalar();
                
                if($result >0){
                    return true;
                }else{
                    return false;
                } 
        }
        
        
        /**
         * This is the function that gets own physical box & folder on request
         */
        public function getOtherDomainPhysicalBoxOnRequest($user_id,$domain_id){
            
            //get all other physical box & folder with initiated request status 
            $boxes_on_request = $this->getAllSelfInitiatedBoxesUndergoingRequest($user_id);
            $counter = 0;
            
            foreach($boxes_on_request as $box){
                if($this->isThisInstrumentAnOwnDomainBox($box,$domain_id) == false){
                    $counter = $counter + 1;
                }
            }
            return $counter;
        }
        
        
        /**
         * This is the function that gets own virtual document on request
         */
        public function getOwnVirtualDocumentOnRequest($user_id,$domain_id){
            
            //get all own virtual document with initiated request status 
            $documents_on_request = $this->getAllSelfInitiatedVirtualDocumentsUndergoingRequest($user_id);
            $counter = 0;
            
            foreach($documents_on_request as $doc){
                if($this->isThisInstrumentAnOwnDomainDocument($doc,$domain_id)){
                    $counter = $counter + 1;
                }
            }
            return $counter;
            
        }
        
        
        /**
         * This is the function that gets the id of a virtual document request
         */
        public function getAllSelfInitiatedVirtualDocumentsUndergoingRequest($user_id){
            
             $criteria6 = new CDbCriteria();
             $criteria6->select = '*';
             $criteria6->condition='(virtual_request_initiated_by=:userid) and (status=:status and virtual_is_requested=:requested)';
             $criteria6->params = array(':userid'=>$user_id,':status'=>"inactive",':requested'=>false);
             $requests = VirtualDocumentRequest::model()->findAll($criteria6);  
             
             $documents = [];
             foreach($requests  as $request){
                 $documents[] = $request['virtual_document_id'];
             }
             return $documents;
            
        }
        
        /**
         * This is the function that gets own virtual batch on request
         */
        public function getOwnVirtualBatchOnRequest($user_id,$domain_id){
            
            //get all own virtual batch & file with initiated request status 
            $batches_on_request = $this->getAllSelfInitiatedVirtualBatchesUndergoingRequest($user_id);
            $counter = 0;
            
            foreach($batches_on_request as $batch){
                if($this->isThisInstrumentAnOwnDomainBatch($batch,$domain_id)){
                    $counter = $counter + 1;
                }
            }
            return $counter;
            
        }
        
         /**
         * This is the function that gets the id of a virtual batch request
         */
        public function getAllSelfInitiatedVirtualBatchesUndergoingRequest($user_id){
            
             $criteria6 = new CDbCriteria();
             $criteria6->select = '*';
             $criteria6->condition='(virtual_request_initiated_by=:userid) and (status=:status and virtual_is_requested=:requested)';
             $criteria6->params = array(':userid'=>$user_id,':status'=>"inactive",':requested'=>false);
             $requests = VirtualBatchRequest::model()->findAll($criteria6);  
             
             $batches = [];
             foreach($requests  as $request){
                 $batches[] = $request['virtual_batch_id'];
             }
             return $batches;
            
        }
        
        /**
         * This is the function that gets own virtual box & folder on request
         */
        public function getOwnVirtualBoxOnRequest($user_id,$domain_id){
            
             //get all own virtual box & folder with initiated request status 
            $boxes_on_request = $this->getAllSelfInitiatedVirtualBoxesUndergoingRequest($user_id);
            $counter = 0;
            
            foreach($boxes_on_request as $box){
                if($this->isThisInstrumentAnOwnDomainBox($box,$domain_id)){
                    $counter = $counter + 1;
                }
            }
            return $counter;
            
        }
        
        
        /**
         * This is the function that gets the id of a virtual batch request
         */
        public function getAllSelfInitiatedVirtualBoxesUndergoingRequest($user_id){
            
             $criteria6 = new CDbCriteria();
             $criteria6->select = '*';
             $criteria6->condition='(virtual_request_initiated_by=:userid) and (status=:status and virtual_is_requested=:requested)';
             $criteria6->params = array(':userid'=>$user_id,':status'=>"inactive",':requested'=>false);
             $requests = VirtualBoxRequest::model()->findAll($criteria6);  
             
             $boxes = [];
             foreach($requests  as $request){
                 $boxes[] = $request['virtual_box_id'];
             }
             return $boxes;
            
        }
        
        
        /**
         * This is the function that gets other domains virtual documents on request
         */
        public function getOtherDomainVirtualDocumentOnRequest($user_id,$domain_id){
            
            //get all other virtual document with initiated request status 
            $documents_on_request = $this->getAllSelfInitiatedVirtualDocumentsUndergoingRequest($user_id);
            $counter = 0;
            
            foreach($documents_on_request as $doc){
                if($this->isThisInstrumentAnOwnDomainDocument($doc,$domain_id) == false){
                    $counter = $counter + 1;
                }
            }
            return $counter;
            
        }
        
        
        /**
         * This is the function that gets the other domain virtual batches & files on request
         */
        public function getOtherDomainVirtualBatchOnRequest($user_id,$domain_id){
            
            //get all own virtual batch & file with initiated request status 
            $batches_on_request = $this->getAllSelfInitiatedVirtualBatchesUndergoingRequest($user_id);
            $counter = 0;
            
            foreach($batches_on_request as $batch){
                if($this->isThisInstrumentAnOwnDomainBatch($batch,$domain_id)== false){
                    $counter = $counter + 1;
                }
            }
            return $counter;
            
            
        }
        
        
        /**
         * This is the function that gets the other domain virtual boxes & folder on request 
         */
        public function getOtherDomainVirtualBoxOnRequest($user_id,$domain_id){
            
            //get all other virtual box & folder with initiated request status 
            $boxes_on_request = $this->getAllSelfInitiatedVirtualBoxesUndergoingRequest($user_id);
            $counter = 0;
            
            foreach($boxes_on_request as $box){
                if($this->isThisInstrumentAnOwnDomainBox($box,$domain_id) == false){
                    $counter = $counter + 1;
                }
            }
            return $counter;
            
        }
        

        /**
         * This is the function that gets the platform payment mode
         */
        public function getThePlatformApprovedPaymentMode($domain_id){
            //get the country of this domain
            $country_id = $this->getTheCountryIdOfThisDomain($domain_id);
            
            if($this->isAnyAccountApprovedAndActiveForThisCountry($country_id)){
                //get the payment of the said account to this country
                $payment_mode = $this->getTheApprovedPaymentMode($country_id);
                return $payment_mode;
            }else{
                //get the default account payment mode
                $default_payment_mode = $this->getTheDefaultAccountPaymentMode();
                return $default_payment_mode;
            }
            
                 
        }
        
        
        /**
         * This is the function that confirms if a country has an approved and active account assigned to it
         */
        public function isAnyAccountApprovedAndActiveForThisCountry($country_id){
            
            $cmd =Yii::app()->db->createCommand();
                $cmd->select('COUNT(*)')
                    ->from('bank_collect_for_country')
                    ->where("country_id = $country_id and status='active'");
                $result = $cmd->queryScalar();
                
                if($result > 0){
                    return true;
                }else{
                    return false;
                }
        }
        
        /**
         * This is the function that gets the payment mode for an active and approved account
         */
        public function getTheApprovedPaymentMode($country_id){
            
               $criteria = new CDbCriteria();
               $criteria->select = '*';
               $criteria->condition='(country_id=:id and (status=:status and approved=:approved))';
               $criteria->params = array(':id'=>$country_id,':status'=>'active',':approved'=>1);
               $account =  BankCollectForCountry::model()->find($criteria);
               
               return $account['payment_mode'];
            
        }
        
        
        /**
         * This is the function that returns default account payment mode
         */
        public function getTheDefaultAccountPaymentMode(){
            
               $criteria = new CDbCriteria();
               $criteria->select = '*';
               $criteria->condition='default_bank=:default';
               $criteria->params = array(':default'=>1);
               $accounts =Banker::model()->find($criteria);
               
               return $accounts['payment_mode'];
        }
        
        /**
         * This is the function that gets the platform banks account title
         */
        public function getThePlatformAccountName($domain_id){
            
           //get the country of this domain
            $country_id = $this->getTheCountryIdOfThisDomain($domain_id);
            
            if($this->isAnyAccountApprovedAndActiveForThisCountry($country_id)){
                //get the payment of the said account to this country
                $account_name = $this->getTheApprovedAccountName($country_id);
                return $account_name;
            }else{
                //get the default account payment mode
                $default_account_name = $this->getTheDefaultAccountName();
                return $default_account_name;
            }
        }
        
        /**
         * This is the function that gets the approved account name for  a country
         */
        public function getTheApprovedAccountName($country_id){
               $criteria = new CDbCriteria();
               $criteria->select = '*';
               $criteria->condition='(country_id=:id and (status=:status and approved=:approved))';
               $criteria->params = array(':id'=>$country_id,':status'=>'active',':approved'=>1);
               $account =  BankCollectForCountry::model()->find($criteria);
               
               //get the account name
               
               $account_name = $this->getThisAccountName($account['bank_id']);
               
               return $account_name;
            
        }
        
        /**
         * This is the function that gets an acount name given its id
         */
        public function getThisAccountName($id){
               $criteria = new CDbCriteria();
               $criteria->select = '*';
               $criteria->condition='id=:id';
               $criteria->params = array(':id'=>$id);
               $accounts =Banker::model()->find($criteria);
               
               return $accounts['account_name'];
            
        }
        
        /**
         * This is the function that gets the defaults account name
         */
        public function getTheDefaultAccountName(){
           
               $criteria = new CDbCriteria();
               $criteria->select = '*';
               $criteria->condition='default_bank=:default';
               $criteria->params = array(':default'=>1);
               $accounts =Banker::model()->find($criteria);
               
               return $accounts['account_name'];
            
        }
        
        /**
         * This is the function that gets the platforms account numbrr
         */
        public function getThePlatformAccountNumber($domain_id){
            
            //get the country of this domain
            $country_id = $this->getTheCountryIdOfThisDomain($domain_id);
            
            if($this->isAnyAccountApprovedAndActiveForThisCountry($country_id)){
                //get the payment of the said account to this country
                $account_number = $this->getTheApprovedAccountNumber($country_id);
                return $account_number;
            }else{
                //get the default account payment mode
                $default_account_number = $this->getTheDefaultAccountNumber();
                return $default_account_number;
            }
        }
        
        /**
         * This is the function that gets the account number of an account approved and activated for a country 
         */
        public function getTheApprovedAccountNumber($country_id){
            
               $criteria = new CDbCriteria();
               $criteria->select = '*';
               $criteria->condition='(country_id=:id and (status=:status and approved=:approved))';
               $criteria->params = array(':id'=>$country_id,':status'=>'active',':approved'=>1);
               $account =  BankCollectForCountry::model()->find($criteria);
               
               //get the account name
               
               $account_name = $this->getThisAccountNumber($account['bank_id']);
               
               return $account_name;
        }
        
        /**
         * This is the function that gets the default account number
         */
        public function getTheDefaultAccountNumber(){
            
               $criteria = new CDbCriteria();
               $criteria->select = '*';
               $criteria->condition='default_bank=:default';
               $criteria->params = array(':default'=>1);
               $accounts =Banker::model()->find($criteria);
               
               return $accounts['account_number'];
        }
        
        /**
         * This is the function that gets the approved and active account number for a country
         */
        public function getThisAccountNumber($id){
            
            $criteria = new CDbCriteria();
               $criteria->select = '*';
               $criteria->condition='id=:id';
               $criteria->params = array(':id'=>$id);
               $accounts =Banker::model()->find($criteria);
               
               return $accounts['account_number'];
     
        }
        
        /**
         * This is the function that gets the platforms swift code
         */
        public function getThePlatformSwiftCode($domain_id){
            
           //get the country of this domain
            $country_id = $this->getTheCountryIdOfThisDomain($domain_id);
            
            if($this->isAnyAccountApprovedAndActiveForThisCountry($country_id)){
                //get the payment of the said account to this country
                $account_swift_code = $this->getTheApprovedAccountSwiftCode($country_id);
                return $account_swift_code;
            }else{
                //get the default account payment mode
                $default_account_number = $this->getTheDefaultAccountSwiftCode();
                return $default_account_number;
            }
        }
        
        
        /**
         * This is the function that gets the approved and active accounts swift code
         */
        public function getTheApprovedAccountSwiftCode($country_id){
            
               $criteria = new CDbCriteria();
               $criteria->select = '*';
               $criteria->condition='(country_id=:id and (status=:status and approved=:approved))';
               $criteria->params = array(':id'=>$country_id,':status'=>'active',':approved'=>1);
               $account =  BankCollectForCountry::model()->find($criteria);
               
               //get the account name
               
               $account_name = $this->getThisAccountSwiftCode($account['bank_id']);
               
               return $account_name;
            
        }
        
        
        
        /**
         * This is the function that gets the swift code of the approved and active account of a country
         */
        public function getThisAccountSwiftCode($id){
            
               $criteria = new CDbCriteria();
               $criteria->select = '*';
               $criteria->condition='id=:id';
               $criteria->params = array(':id'=>$id);
               $accounts =Banker::model()->find($criteria);
               
               return $accounts['swift_code'];
            
        }
        
        
        /**
         * This is the function that gets the default account swift code on the platform
         */
        public function getTheDefaultAccountSwiftCode(){
            
               $criteria = new CDbCriteria();
               $criteria->select = '*';
               $criteria->condition='default_bank=:default';
               $criteria->params = array(':default'=>1);
               $accounts =Banker::model()->find($criteria);
               
               return $accounts['swift_code'];
            
        }
        /**
         * This is the function that gets the platform account type
         */
        public function getThePlatformAccountType($domain_id){
            
            //get the country of this domain
            $country_id = $this->getTheCountryIdOfThisDomain($domain_id);
            
            if($this->isAnyAccountApprovedAndActiveForThisCountry($country_id)){
                //get the payment of the said account to this country
                $account_type = $this->getTheApprovedAccountType($country_id);
                return $account_type;
            }else{
                //get the default account payment mode
                $default_account_type = $this->getTheDefaultAccountType();
                return $default_account_type;
            }
        }
        
        
        /**
         * This is the function that gets the account type of the approved and active country account
         */
        public function getTheApprovedAccountType($country_id){
            
               $criteria = new CDbCriteria();
               $criteria->select = '*';
               $criteria->condition='(country_id=:id and (status=:status and approved=:approved))';
               $criteria->params = array(':id'=>$country_id,':status'=>'active',':approved'=>1);
               $account =  BankCollectForCountry::model()->find($criteria);
               
               //get the account name
               
               $account_name = $this->getThisAccountType($account['bank_id']);
               
               return $account_name;
            
        }
        
        
        /**
         * This is the function that gets the approved and active account type of a country
         */
        public function getThisAccountType($id){
            
               $criteria = new CDbCriteria();
               $criteria->select = '*';
               $criteria->condition='id=:id';
               $criteria->params = array(':id'=>$id);
               $accounts =Banker::model()->find($criteria);
               
               return $accounts['type'];
        }
        
        
        /**
         * This is the function that gets the default account type on the platform
         */
        public function getTheDefaultAccountType(){
            
               $criteria = new CDbCriteria();
               $criteria->select = '*';
               $criteria->condition='default_bank=:default';
               $criteria->params = array(':default'=>1);
               $accounts =Banker::model()->find($criteria);
               
               return $accounts['type'];
        }
        
        /**
         * This is the function that gets the platforms banker
         */
        public function getThePlatformAccountBankName($domain_id){
            //get the country of this domain
            $country_id = $this->getTheCountryIdOfThisDomain($domain_id);
            
            if($this->isAnyAccountApprovedAndActiveForThisCountry($country_id)){
                //get the payment of the said account to this country
                $account_bank = $this->getTheApprovedAccountBank($country_id);
                return $account_bank;
            }else{
                //get the default account payment mode
                $default_account_bank = $this->getTheDefaultAccountBank();
                return $default_account_bank;
            }
        }
        
        
        /**
         * This is the function that gets the approved and active account bank name of a country
         */
        public function getTheApprovedAccountBank($country_id){
            
               $criteria = new CDbCriteria();
               $criteria->select = '*';
               $criteria->condition='(country_id=:id and (status=:status and approved=:approved))';
               $criteria->params = array(':id'=>$country_id,':status'=>'active',':approved'=>1);
               $account =  BankCollectForCountry::model()->find($criteria);
               
               //get the account name
               
               $account_name = $this->getThisAccountBankName($account['bank_id']);
               
               return $account_name;
            
        }
        
        
        
        /**
         * This is the function that gets the bank name
         */
        public function getThisAccountBankName($id){
            
               $criteria = new CDbCriteria();
               $criteria->select = '*';
               $criteria->condition='id=:id';
               $criteria->params = array(':id'=>$id);
               $accounts =Banker::model()->find($criteria);
               
               return $accounts['bank_name'];
            
        }
        
        
        /**
         * This is the function that gets the default account bank name
         */
        public function getTheDefaultAccountBank(){
           
               $criteria = new CDbCriteria();
               $criteria->select = '*';
               $criteria->condition='default_bank=:default';
               $criteria->params = array(':default'=>1);
               $accounts =Banker::model()->find($criteria);
               
               return $accounts['bank_name'];
            
        }
        
        
        /**
         * This is the function that generates renewal order number
         */
        public function generateRenewalOrderNumber($toolbox_id,$domain_id){
            //generate the order number
          $order_number = $this->generateTheNeededOrderNumber($toolbox_id,$domain_id);
          if($this->isThisOrderAlreadyRegistered($order_number)){
             if($this->registerTheOrder($order_number)){
                 return $order_number;
             } 
          }else{
             return $order_number;
          }
           
            
        }
        
        /**
         * This is the function that performs the actual payment renewal for a toolbox
         */
        public function actionrenewThisToolboxForThisDomain(){
            $toolbox_id = $_POST['toolbox_id'];
            
            $gross_amount = $_POST['gross_amount_for_payment'];
            
            $discount_amount = $_POST['discount_amount_for_payment'];
            
            $net_amount = $_POST['net_amount_for_payment'];
            
            $subscribers = $_POST['no_of_subscribers'];
            
            $order_number = $_POST['renewal_order_number'];
            
            $payment_mode = strtolower($_POST['renewal_payment_mode']);
            
            $payment_status = strtolower('unconfirmed');
            
          
            //gert the user is
            $userid = Yii::app()->user->id;
            $domain_id = $this->determineAUserDomainIdGiven($userid);
            
             //get the existing number of years for this subscription
            
            $number_of_years = $this->getTheNumberOfYearsOfSubscription($toolbox_id, $domain_id);
            
            //get the order id for this renewal
            $order_id = $this->getTheOrderIdOfThisRenewalPurchase($order_number,$toolbox_id,$domain_id);
            //confirm if the payee domain is legible to pay vat on that item
            
            //if($_POST['net_amount_for_payment']=$_POST['no_of_subscribers']=$_POST['gross_amount_for_payment'] == 0){
            if($this->isThisOrderNotAvailableInTheCart($order_id)){    
                           $msg ="Your cart is empty. Kindly add some Folder item(s) into it before effecting renewal";
                                header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysql_errno() != 0,
                                     "msg" => $msg,
                                    
                               
                            ));
            }else{
            if($this->isPayeeDomainVatLegibleOnThisPurchase($domain_id,$toolbox_id)){
                $vat = $this->obtainTheVatForThisPurchase($toolbox_id,$domain_id,$net_amount);
            }
            
            $store_id = $this->getTheStoreIdUsedInTheInitialPurchaseOfThisServicebyThisDomain($toolbox_id,$domain_id);
            //generate the order number of this purchase/renewal
            $invoice_number = $this->generateTheInvoiceNumberForPayment($order_number,$domain_id,$toolbox_id,$store_id);
            
                        
            if($order_id>0){
                //write the payment information to the payment table
                $result = $this->effectThePaymentOfThisPurchase($gross_amount,$discount_amount,$net_amount,$order_id,$invoice_number,$vat,$payment_mode,$payment_status,$toolbox_id,$subscribers);
                if($result>0){
                    //confirm the expiry status of this toolbox to this domain
                    if($this->isThisToolboxServiceToThisDomainAlreadyExpired($toolbox_id,$domain_id, $_POST['expiry_date'])){
                        //extend the end date of the service to this domain
                       if($this->ExtendThisServiceToThisDomain($toolbox_id,$domain_id,$subscribers,$number_of_years)){
                           //return to the client with both the order number and the invoice number for actual transfer
                             $msg ="For easy Payment verification and service activation use the order number:'$order_number' and invoice number '$invoice_number' in effecting payment";
                                header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysql_errno() == 0,
                                     "msg" => $msg,
                                    
                               
                            ));
                    
                
                       }else{
                           $message = "Payment made but expired service could not be extended automatically";
                           $this->sendThisPaymentIssueToTheRenewalTeamForResolution($toolbox_id,$domain_id,$order_id,$invoice_number,$_POST['expiry_date'],$message);
                           $msg ="Payment with order number '$order_number' and invoice number '$invoice_number is effected:You can effect the Bank Transfer while the Renewal Center manually extends the service period to you";
                                header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysql_errno() != 0,
                                     "msg" => $msg,
                                    
                               
                            ));
                       } 
                        
                    }else{
                       if($this->ExtendThisServiceToThisDomain($toolbox_id,$domain_id,$subscribers,$number_of_years)){
                            //return to the client with both the order number and the invoice number for actual transfer
                             $msg ="For easy Payment verification use the order number:'$order_number' and invoice number '$invoice_number' in effecting payment";
                                header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysql_errno() == 0,
                                     "msg" => $msg,
                                    
                               
                            ));
                    
                
                       }else{
                           $message = "Payment made but this soon-to-expire service could not be extended automatically";
                           $this->sendThisPaymentIssueToTheRenewalTeamForResolution($toolbox_id,$domain_id,$order_id,$invoice_number,$_POST['expiry_date'],$message);
                           $msg ="Payment with order number '$order_number' and invoice number '$invoice_number is effected:You can effect the Bank Transfer while the Renewal Center manually extends the service period to you";
                                header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysql_errno() != 0,
                                     "msg" => $msg,
                                    
                               
                            ));
                       } 
                        }
                    }else{
                        $message = "Payment could not be effected automatically by the client";
                        $this->sendThisPaymentIssueToTheRenewalTeamForResolution($toolbox_id,$domain_id,$order_id,$invoice_number,$_POST['expiry_date'],$message);
                           $msg ="Payment with order number '$order_number' and invoice number '$invoice_number could not be effected, Please contcat the Renewal Center for assistance";
                                header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysql_errno() != 0,
                                     "msg" => $msg,
                                    
                               
                            ));
                    }
                    
                    
                }else{
                    $message = "This order was not initiated successfully by the client";
                        $this->sendThisPaymentIssueToTheRenewalTeamForResolution($toolbox_id,$domain_id,$order_id,$invoice_number,$_POST['expiry_date'],$message);
                           $msg ="Could not initiate this order with order number '$order_number' and invoice number '$invoice_number. Contact the Renewal Center for assistance";
                                header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysql_errno() != 0,
                                     "msg" => $msg,
                                    
                               
                            ));
                }
                
                
            }
                
            }
            
            
             /**
         * This is the function that performs the actual new order payment
         */
        public function actionmakePaymentForThisOrderForThisDomain(){
            $order_id = $_POST['order_id'];
            
            $order_number = $_POST['payment_order_number'];
                        
            $payment_mode = strtolower($_POST['payment_payment_mode']);
            
            $payment_status = strtolower('unconfirmed');
            
            $toolbox_status = strtolower('inactive');
             
            //gert the user is
            $userid = Yii::app()->user->id;
            $domain_id = $this->determineAUserDomainIdGiven($userid);
          // if($_POST['net_amount_for_payment']=$_POST['no_of_subscribers']=$_POST['gross_amount_for_payment'] == 0){
           if($this->isThisOrderNotAvailableInTheCart($order_id)){     
                           $msg ="Your cart is empty. Kindly add some Folder item(s) into it before consummating request";
                                header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysql_errno() != 0,
                                     "msg" => $msg,
                                    
                               
                            ));
            }else{ 
            //spool all the items in the cart
            $toolboxes = $this->getAllToolboxItemsInTheCart($order_id);
           //generate the invoice number
            $invoice_number = $this->generateTheInvoiceNumberForThisOrder($order_number,$domain_id,$order_id);
            $effecting_payment = 0;
            $assigning_toolboxes = 0;
            $extending_toolboxes = 0;
            
           foreach($toolboxes as $toolbox_id){
               
                //get the subscribers to this toolbox
                 $subscribers = $this->getTheSubscribersToThisToolboxForThisOrder($toolbox_id,$order_id);
                 
                 //get the number of years for this subscription
                 $number_of_years = $this->getTheNumberOfYearsForThisSubscription($toolbox_id, $order_id);
                
                //get the gross amount for this order
                $toolbox_gross = $this->getTheGrossAmountForThisToolboxInThisOrder($toolbox_id,$subscribers,$order_id);
                
                //get the applicable discount for this toolbox by this domain
                $toolbox_discount = $this->getTheApplicableDiscountForThisToolboxInThisOrder($toolbox_id,$domain_id,$subscribers,$order_id);
                
                //get the net payment for this toolbox by this domain
                $toolbox_net = $toolbox_gross - $toolbox_discount;
                
                 
               //confirm if the payee domain is legible to pay vat on that item
                  
                if($this->isPayeeDomainVatLegibleOnThisPurchase($domain_id,$toolbox_id)){
                    $vat = $this->obtainTheVatForThisPurchase($toolbox_id,$domain_id,$toolbox_net);
                }else{
                   $vat = 0.00; 
                }
           
            $result = $this->effectThePaymentOfThisPurchase($toolbox_gross,$toolbox_discount,$toolbox_net,$order_id,$invoice_number,$vat,$payment_mode,$payment_status,$toolbox_id,$subscribers,$number_of_years);
            
            //get the store of purchase
             $store_id = $this->getTheStoreOfPurchaseOfThisItem($toolbox_id,$order_id);
            if($result>0){
                    $available = $this->isThisServiceToDomainAvailable($toolbox_id,$domain_id);
                    if($this->isThisServiceToDomainAvailable($toolbox_id,$domain_id)){
                         //  if($this->ExtendThisServiceToThisDomain($toolbox_id,$domain_id,$subscribers,$number_of_years)){
                                $extending_toolboxes = $extending_toolboxes + 1;
                                
                           // } 
                        }else{
                            if($this->assignToolboxToDomain($toolbox_id,$domain_id,$subscribers,$store_id,$toolbox_status,$number_of_years)){
                            $assigning_toolboxes  = $assigning_toolboxes + 1;
                            } 
                        }
                        
                 
                    
                }
                
            }
            if($assigning_toolboxes > 0 || $extending_toolboxes>0){
                //change the status of the order to close
                if($this->changeOrderStatus($order_id)){
                    //empty the cart of this order
                    if($this->emptyCartOfThisOrder($order_id)){
                         $msg ="For easy request verification and service activation use the order number:'$order_number' and request number '$invoice_number' in confirming request";
                                header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysql_errno() == 0,
                                     "msg" => $msg,
                                    
                               
                            ));
                        
                    }else{
                        $message = "Request for this order was effected but the order status is not changed to close. The order number is '$order_number' and request number is '$invoice_number'";
                        $this->sendThisErrorMessageToTheServiceDesk($order_number,$invoice_number,$message);
                        $msg ="For easy request verification and service activation use the order number:'$order_number' and request number '$invoice_number' in confirming request";
                                header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysql_errno() == 0,
                                     "msg" => $msg,
                                    
                               
                            ));
                    }
                    
                }else{
                    
                    $message = "Request for this order was effected but the order status is not changed to close. The order number is '$order_number' and request number is '$invoice_number'";
                    $this->sendThisErrorMessageToTheServiceDesk($order_number,$invoice_number,$message);
                    $msg ="For easy request verification and service activation use the order number:'$order_number' and request number '$invoice_number' in confirming request";
                                header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysql_errno() == 0,
                                     "msg" => $msg,
                                    
                               
                            ));
                }
               
            }else{
                $message = "Request for this order was not effected. The order number is '$order_number' and request number is '$invoice_number'";
                $this->sendThisErrorMessageToTheServiceDesk($order_number,$invoice_number,$message);
                $msg ="Request for this order was not effected: Contact the Service Desk for assistance";
                                header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysql_errno() != 0,
                                     "msg" => $msg,
                                    "subscribers"=>$subscribers,
                                    "gross"=>$toolbox_gross,
                                    "net"=>$toolbox_net,
                                    "discount"=>$toolbox_discount,
                                    "number_of_years"=>$number_of_years,
                                    "vat"=>$vat,
                                    "toolboxes"=>$toolboxes,
                                    "toolbox_id"=>$toolbox_id,
                                    "order_id"=>$order_id,
                                    "invoice_number"=>$invoice_number,
                                    "store_id"=>$store_id,
                                    "available"=>$available
                                    
                                    
                               
                            ));
            }
             
            }
      }
        
      
      /**
       * This is the function that determines if an order is in a cart
       */
      public function isThisOrderNotAvailableInTheCart($order_id){
          
                $cmd =Yii::app()->db->createCommand();
                $cmd->select('COUNT(*)')
                    ->from('order_has_toolboxes')
                    ->where("order_id = $order_id");
                $result = $cmd->queryScalar();
                
                if($result <= 0){
                    return true;
                }else{
                    return false;
                }
      }
          
       /**
         * This is the function that computes the gross amount for a toolbox in an order
         */
        public function getTheGrossAmountForThisToolboxInThisOrder($toolbox_id,$subscribers,$order_id){
            
             $toolbox_amount = $this->getThisToolboxAmount($toolbox_id) * $subscribers * $this->getTheNumberOfYearsForThisSubscription($toolbox_id, $order_id);
         
             return $toolbox_amount;
             
            
            
            
              
        }
        
      
         /**
         * This is the function that gets the applicable discount of a toolbox in an order
         */
        public function getTheApplicableDiscountForThisToolboxInThisOrder($toolbox_id,$domain_id,$subscribers,$order_id){
          
               //get the applicable discount
                $discount_sum  = $this->getTheDiscountAmountForThisToolbox($toolbox_id,$domain_id,$subscribers)*$this->getTheNumberOfYearsForThisSubscription($toolbox_id, $order_id);
                return $discount_sum;
                 
        }
      
            
            /**
             * This is the function that gets all the toolbox items in a cart
             */
            public function getAllToolboxItemsInTheCart($order_id){
                             
                $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition='order_id=:id';
                $criteria->params = array(':id'=>$order_id);
                $toolboxes= OrderHasToolboxes::model()->findAll($criteria);
                
                $alltoolboxes = [];
                
                foreach($toolboxes as $toolbox){
                    
                    $alltoolboxes[]=$toolbox['toolbox_id'];
                }
                return $alltoolboxes;
                
            }
            
            /**
             * This is the function that gets the subscribers of this toolbox during purchase
             */
            public function getTheSubscribersToThisToolbox($toolbox_id,$order_id){
                
                $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition='order_id=:id and toolbox_id=:toolboxid';
                $criteria->params = array(':id'=>$order_id,':toolboxid'=>$toolbox_id);
                $toolboxes= Payment::model()->find($criteria);
                
                return (int)$toolboxes['subscribers'];
            }
            
            
             /**
             * This is the function that gets the subscribers of this toolbox during purchase
             */
            public function getTheSubscribersToThisToolboxForThisOrder($toolbox_id,$order_id){
                
                $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition='order_id=:id and toolbox_id=:toolboxid';
                $criteria->params = array(':id'=>$order_id,':toolboxid'=>$toolbox_id);
                $toolboxes= OrderHasToolboxes::model()->find($criteria);
                
                return (int)$toolboxes['number_of_users'];
            }
            
            /**
         * This is the function that gets the number of years for a subscription to a toolbox
         */
        public function getTheNumberOfYearsForThisSubscriptionInThisOrder($toolbox_id,$order_id){
            
                    $criteria = new CDbCriteria();
                    $criteria->select = '*';
                    $criteria->condition='order_id=:orderid and toolbox_id=:toolboxid';
                    $criteria->params = array(':orderid'=>$order_id,':toolboxid'=>$toolbox_id);
                    $order= Payment::model()->find($criteria);
                    
                    return $order['number_of_years'];
            
        }
        
            
            /**
             * This is the function that gets the store of purchase of this item
             */
            public function getTheStoreOfPurchaseOfThisItem($toolbox_id,$order_id){
                
                $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition='order_id=:id and toolbox_id=:toolboxid';
                $criteria->params = array(':id'=>$order_id,':toolboxid'=>$toolbox_id);
                $toolboxes= OrderHasToolboxes::model()->find($criteria);
                
                return (int)$toolboxes['store_id'];
                
                
            }
            
            /**
             * This is the function that assigns toolbox service to a domain
             */
            public function assignToolboxToDomain($toolbox_id,$domain_id,$subscribers,$store_id,$toolbox_status,$number_of_years){
                //get the number of years for this subscription
                //$number_of_years = $this->getTheNumberOfYearsForThisSubscription($toolbox_id, $order_id);
                $userid = Yii::app()->user->id;
                $today= mktime(0, 0, 0, date("m")  , date("d"), date("Y"));
                $year_later = mktime(0, 0, 0, date("m")-1  , date("d"), date("Y")+$number_of_years);
                
                $cmd =Yii::app()->db->createCommand();
                $result = $cmd->insert('resourcegroup_has_resourcegroupcategory',
                                  array(
                                    'resourcegroup_id'=>$toolbox_id,
                                    'category_id'=>$domain_id,
                                    'toolbox_status'=>$toolbox_status, 
                                    'no_of_subscribers'=>$subscribers, 
                                   'store_id'=>$store_id,
                                     //'start_date'=>date("Y-m-d",$today),
                                     //'min_date'=>date("Y-m-d",$today),
                                    // 'end_date'=>date("Y-m-d",$year_later),
                                    // 'max_date'=>date("Y-m-d",$year_later),
                                   'date_assigned'=>new CDbExpression('NOW()'),
                                   'assigned_by'=>$userid,
                                   'number_of_years'=> $number_of_years 
                               
		
                            )
			
                        );
                if($result>0){
                    return true;
                }else{
                    return false;
                }
                
            }
            
            /**
             * This is the function that changes the status of an order
             */
            public function changeOrderStatus($order_id){
                
             $cmd =Yii::app()->db->createCommand();
             $result = $cmd->update('order',
                                  array(
                                    'status'=>"closed",
                                    'order_updated_by'=>Yii::app()->user->id, 
                                    'last_updated_date'=>new CDbExpression('NOW()')
                                   
                               
		
                            ),
                     ("id=$order_id")
                );
             if($result>0){
                 return true;
             }else{
                 return false;
             }
            }
            
            
            /**
             * This is the function that deletes all items of an order from the cart
             */
            public function emptyCartOfThisOrder($order_id){
                
                $cmd =Yii::app()->db->createCommand();  
                $result = $cmd->delete('order_has_toolboxes', 'order_id=:orderid', array(':orderid'=>$order_id));
            
                if($result>0){
                    return true;
                    
                }else{
                    return false;
                }
                
            }
            /**
             * This is the function that generates the invoice number for a new order purchase
             */
            public function generateTheInvoiceNumberForThisOrder($order_number,$domain_id,$order_id){
                
                //get the first 3 letters of the domain name
                $domain_first_three_letters = strtoupper($this->getThePurchasingDomainNameFirstThreeLetters($domain_id));
                //get the date of purchase/renewal
                $date_when_order_was_initiated = date("dmY",strtotime($this->getTheDateWhenOrderWasInitiated($order_id)));
                
                //get a random number from 1 to 10
                $random_number = $this->generateTheRandomNumber();
                
                //get the first four letters of the order number
                $order_number_first_four_letters = strtoupper($this->getTheFirstFourLettersOfTheOrderNumber($order_number));
                
                //get the first three letters of the store of purchase
                if($this->isPurchaseOnMultipleStore($order_id)){
                    $store_first_three_letters='MULTI';
                    $store_id=0;
                }else{
                    $store_id = $this->getThisStoreId($order_id);
                    if($store_id  !== "0"){
                         $store_first_three_letters = strtoupper($this->getStoreTypeFirstThreeLetters($store_id));
                    }
                   
                    
                }
                            
                //get the first four letters of the buyer domain country
                $domain_country_first_four_letters = strtoupper($this->getTheDomainCountryNameFirstFourLetters($domain_id));
                
                $invoice_number = "$domain_first_three_letters$date_when_order_was_initiated-$random_number$store_first_three_letters$store_id-$domain_country_first_four_letters$order_number_first_four_letters";
                
                return $invoice_number; 
                 
            }
            
            /**
             * This is the function that gets the date when order was initaited
             */
            public function getTheDateWhenOrderWasInitiated($order_id){
              
                $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition='id=:id';
                $criteria->params = array(':id'=>$order_id);
                $order= Order::model()->find($criteria);
                
                return $order['order_initiation_date'];
          
            }
            
            /**
             * This is the function that determines if multiple stores were involved in an order
             */
            public function isPurchaseOnMultipleStore($order_id){
                
                $store_counter = 0;
                $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition='order_id=:id';
                $criteria->params = array(':id'=>$order_id);
                $stores= OrderHasToolboxes::model()->findAll($criteria);
                
                $dis_store = [];
                foreach($stores as $store){
                    $dis_store[] = $store['store_id'];
                    
                }
                //get the uniquesness of the order stores 
                $order_stores  = array_unique($dis_store);
                if($order_stores !== [] || $order_stores !== null){
                    //determine the length of the array
                    $store_array_length = count($order_stores);
                 if($store_array_length > 1){
                    return true;
                    
                }else{
                   return false;
                    
                }
                }else{
                    return false;
                }
                
                
                
                
            }
            
            /**
             * This is the function that gets the store id of a store
             */
            public function getThisStoreId($order_id){
                
                
               if($this->isPurchaseOnMultipleStore($order_id) == false){
                   
                    $criteria = new CDbCriteria();
                    $criteria->select = '*';
                    $criteria->condition='order_id=:id';
                    $criteria->params = array(':id'=>$order_id);
                    $stores= OrderHasToolboxes::model()->findAll($criteria);
                    
                    $allstores = [];
                    foreach($stores as $store){
                        $allstores[] = $store['store_id'];
                    }
                    return $allstores[0];
                }else{
                    return "MULTI";
                }
                
               
                
            }
            
            
            /**
             * This is the function that determines if a purchase/renewal is vat-able
             */
            public function isPayeeDomainVatLegibleOnThisPurchase($buyer_domain_id,$toolbox_id){
                
                //determine the domain that owns the toolbox
                $seller_domain = $this->getThisToolboxOwnerId($toolbox_id);
                
                //get the operating country of this seller domain
                $seller_domain_country = strtolower($this->getTheDomainOperatingCountry($seller_domain));
                
                //get the operating country of the buyer domain
                $buyer_domain_country = strtolower($this->getTheDomainOperatingCountry($buyer_domain_id));
                //confirm if the vat collection is enable
                if($this->isVatCollectionEnableForThisOwner($seller_domain)){
                    //get the prevailing vat policy for this country
                    $vat_policy = strtolower($this->getThePrevailingVatPolicyOfTheSellerCountry($seller_domain));
                    if($vat_policy == 'buyer_seller_same_country'){
                        if($seller_domain_country == $buyer_domain_country){
                            return true;
                          
                        }else{
                            return false;
                            
                        }
                    }elseif($vat_policy == 'all_country_store_purchases'){
                        //determine if the seller country has a store
                        if($this->domainHasACountryStore($seller_domain)){
                            if($this->isPurchaseOnCountryStore($buyer_domain_id,$toolbox_id)){
                                return true;
                              
                            }else{
                                return false;
                               
                            }
                            
                        }else{
                            return false;
                             
                        }
                    }elseif($vat_policy == 'only_country_domains_purchases_on_country_store'){
                        if($this->domainHasACountryStore($seller_domain_country)){
                             if($seller_domain_country == $buyer_domain_country){
                                 if($this->isPurchaseOnCountryStore($buyer_domain_id,$toolbox_id)){
                                     return true;
                                       
                                 }else{
                                     return false;
                                       
                                 }
                                 
                             }else{
                                 return false;
                                   
                             }
                            
                        }else{
                            return false;
                              
                        }
                    }
                }
            }
 
            
            /**
             * This is the function that retrieves the store id for this transaction
             */
            public function getTheStoreIdUsedInTheInitialPurchaseOfThisServicebyThisDomain($toolbox_id,$domain_id){
                
                return ($this->getTheStoreOfPurchase($domain_id,$toolbox_id));
                
            }
            /**
             * This is the function that retrieves the country of a toolbox owner
             */
            public function getThisToolboxOwnerId($toolbox_id){
                
                
                $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition='id=:id';
                $criteria->params = array(':id'=>$toolbox_id);
                $toolbox = Resourcegroup::model()->find($criteria);
                
               //$domain_name = $this->determineDomainNameGivenItId($toolbox['domain_id']);
               
               return $toolbox['domain_id'];
                
                
            }
            
            /**
             * this is the function that retrieves the operating country of this domain
             */
            public function getTheDomainOperatingCountry($domain_id){
                
                $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition='id=:id';
                $criteria->params = array(':id'=>$domain_id);
                $domain = ResourcegroupCategory::model()->find($criteria);
                
                $country_name = $this->getThisCountryName($domain['country_id']);
                
                return $country_name;
                
                
            }
            /**
             * This is the function that gets a country name
             */
            public function getThisCountryName($country_id){
                
                $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition='id=:id';
                $criteria->params = array(':id'=>$country_id);
                $domain = Country::model()->find($criteria);
                
                return $domain['name'];
            }
            
            
            
            /**
             * This is the function that determines if vat collection is enabled by this domain
             */
            public function isVatCollectionEnableForThisOwner($domain_id){
                
                $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition='id=:id';
                $criteria->params = array(':id'=>$domain_id);
                $domain = Country::model()->find($criteria);
                
                if($domain['enable_vat_collection'] == 1){
                   return true;
                }else{
                    return false;
                  } 
                
            }
            
            /**
             * This is the function that retrieves the vat policy of a domain's country
             */
            public function getThePrevailingVatPolicyOfTheSellerCountry($domain_id){
                
                $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition='id=:id';
                $criteria->params = array(':id'=>$domain_id);
                $domain = Country::model()->find($criteria);
                
                return $domain['prevailing_vat_policy'];
                
            }
            
            /**
             * This is the function that gets a country id of a domain
             */
            public function getTheCountryIdOfThisDomain($domain_id){
                $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition='id=:id';
                $criteria->params = array(':id'=>$domain_id);
                $domain = ResourceGroupCategory::model()->find($criteria);
                
                return $domain['country_id'];
            }
            
            /**
             * This is the function that determines if a domain has a country store
             */
            public function domainHasACountryStore($domain_id){
                //get the country id of this domain
                $country_id = $this->getTheCountryIdOfThisDomain($domain_id);
                
                //confirm if this country has a store
                if($this->confirmIfCountryHasStore($country_id)){
                    return true;
                }else{
                    return false;
                }
                
                
            }
            
            /**
             * This is the function that determines the store of purchase
             */
            public function isPurchaseOnCountryStore($domain_id,$toolbox_id){
                
                //confirm if domain has a country store
                if($this->domainHasACountryStore($domain_id)){
                    
                    //get the store of purchase
                    $store = $this->getTheStoreOfPurchase($domain_id,$toolbox_id);
                    //get the country id of this store
                    $country = $this->getTheCountryOfThisStore($store);
                    
                    if($country == $this->getTheCountryIdOfThisDomain($domain_id)){
                        return true;
                    }else{
                        return false;
                    }
                    
                }else{
                    return false;
                }
                
                
            }
            
            /**
             * This is the function that determines the store of purchase after payment is effected
             */
            public function getTheStoreOfPurchase($buyer_domain_id,$toolbox_id){
                
                $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition='category_id=:categoryid and resourcegroup_id=:toolboxid';
                $criteria->params = array(':categoryid'=>$buyer_domain_id,':toolboxid'=>$toolbox_id);
                $store = ResourceGroupHasResourcegroupcategory::model()->find($criteria);
                
                return $store['store_id'];
            }
            
            /**
             * This is the function that determines a store country
             */
            public function getTheCountryOfThisStore($store_id){
                
                $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition='id=:id';
                $criteria->params = array(':id'=>$store_id);
                $store = Stores::model()->find($criteria);
                
                return $store['country_id'];
                
            }
            
            /**
             * This is the function that confirms if a country has a store
             */
            public function confirmIfCountryHasStore($country_id){
                $cmd =Yii::app()->db->createCommand();
                $cmd->select('COUNT(*)')
                    ->from('stores')
                    ->where("country_id = $country_id");
                $result = $cmd->queryScalar();
                
                if($result > 0){
                    return true;
                }else{
                    return false;
                }
                
            }
            /**
             * This is the function that calculates vat for each purchase
             */
            public function obtainTheVatForThisPurchase($toolbox_id,$domain_id,$net_amount){
                
                //get the seller domains country vat rate
                $vat_rate = (DOUBLE)$this->getDomainVatRate($toolbox_id);
                //calculate the vat
                if($vat_rate >= 0.00){
                   $vat = ($vat_rate/100) * (DOUBLE)$net_amount;
                  
                }else{
                    $vat = 0.00;
                
                }
                return $vat;
               
            }
            
            /**
             * This is the function that gets the a domains vat rate
             */
            public function getDomainVatRate($toolbox_id){
                //get the domain for this toolbox
                $domain_id = $this->getThisToolboxOwnerId($toolbox_id);
                $country_id = $this->getTheCountryIdOfThisDomain($domain_id);
                $vat_rate = (DOUBLE)$this->getTheVatRateOfThisCountry($country_id);
                return $vat_rate;
                
                
            }
            
            
            /**
             * This is the function that actually fetches the domain vat rate
             */
            public function getTheVatRateOfThisCountry($country_id){
                
                $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition='id=:id';
                $criteria->params = array(':id'=>$country_id);
                $country = Country::model()->find($criteria);
                
                return (DOUBLE)$country['vat_rate'];
                
            }
            /**
             * This is the function that generates the invoice for payment
             */
            public function generateTheInvoiceNumberForPayment($order_number,$domain_id,$toolbox_id, $store_id){
                //get the first 3 letters of the domain name
                $domain_first_three_letters = strtoupper($this->getThePurchasingDomainNameFirstThreeLetters($domain_id));
                //get the date of purchase/renewal
                $date_of_renewal = date("dmY",$this->getTheDateOfRenewal($domain_id,$toolbox_id));
                
                //get a random number from 1 to 10
                $random_number = $this->generateTheRandomNumber();
                
                //get the first four letters of the order number
                $order_number_first_four_letters = strtoupper($this->getTheFirstFourLettersOfTheOrderNumber($order_number));
                
                //get the first three letters of the store of purchase
                $store_first_three_letters = strtoupper($this->getStoreTypeFirstThreeLetters($store_id));
                
                //get the first four letters of the buyer domain country
                $domain_country_first_four_letters = strtoupper($this->getTheDomainCountryNameFirstFourLetters($domain_id));
                
                $invoice_number = "$domain_first_three_letters$date_of_renewal-$random_number$store_first_three_letters$store_id-$domain_country_first_four_letters$order_number_first_four_letters";
                
                return $invoice_number; 
                
                
                
            }
            
            /**
             * This is the function that retrieves the first four letters  of the domain name for invoice number construction
             */
            public function getThePurchasingDomainNameFirstThreeLetters($domain_id){
                //get the domain name
                $domainname = $this->determineDomainNameGivenItId($domain_id);
                //obtain the first four letters
                $substring = substr($domainname,0,3);
                
                return $substring;
            }
            
            /**
             * This is the function that retrieves the date of renewal
             */
            public function getTheDateOfRenewal($domain_id,$toolbox_id){
                
                return (mktime(0, 0, 0, date("m")  , date("d"), date("Y")));
                
            }
            
            
            /**
             * This is the function that generates a random number
             */
            public function generateTheRandomNumber(){
                
                //get todays date
                $today = mktime(0, 0, 0, date("m")  , date("d"), date("Y"));
                //generate random numbe from 0 to $today
                $random_number = mt_rand(0,$today);
               return $random_number;
            }
            
            /**
             * This is teh function that gets the order number first four letters
             */
            public function getTheFirstFourLettersOfTheOrderNumber($order_number){
                
                return substr($order_number,0,4);
            }
            
            /**
             * This is the function that gets the first three letters of the store type
             */
            public function getStoreTypeFirstThreeLetters($store_id){
                
                $type = $this->getThisStoreType($store_id);
                return substr($type,0,3);
                
                
            }
            
            /**
             * This is the function that gets a store type
             */
            public function getThisStoreType($store_id){
               $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition='id=:id';
                $criteria->params = array(':id'=>$store_id);
                $store = Stores::model()->find($criteria);
                
                return $store['type']; 
                
            }
            
            /**
             * This is the function that gets the first four letters of the buyer domain country
             */
            public function getTheDomainCountryNameFirstFourLetters($domain_id){
                //get the domain country
                $country = $this->getTheCountryIdOfThisDomain($domain_id);
                
                return substr($this->getThisCountryName($country), 0, 3);
                
                
            }
            /**
             * This is the function that gets an order id of an order number
             */
            public function getTheOrderIdOfThisRenewalPurchase($order_number,$toolbox_id,$domain_id){
                //confirm if this order is already registered/generated
                if($this->isThisOrderAlreadyRegistered($order_number)){
                   //retrieve the order id
                    $order_id= $this->getTheOrderId($order_number);
                    
                }else{
                    $order_id = $this->registerAndRetrieveTheOrder($toolbox_id,$domain_id);
                }
                return $order_id;
               
            }
            
            /**
             * Thiis is the function that confirms if an order already exist and open
             */
            public function isThisOrderAlreadyRegistered($order_number){
                
                $cmd =Yii::app()->db->createCommand();
                $cmd->select('COUNT(*)')
                    ->from('order')
                    ->where("order_number = '$order_number' and status='open'");
                $result = $cmd->queryScalar();
                
                if($result <= 0){
                    return true;
                }else{
                    return false;
                }
            }
            
            /**
             * This is the function that verifies if an order exist and its closed already
             */
            public function isThisOrderAlreadyExistButClosed($order_number){
                $cmd =Yii::app()->db->createCommand();
                $cmd->select('COUNT(*)')
                    ->from('order')
                    ->where("order_number = '$order_number' and status='closed'");
                $result = $cmd->queryScalar();
                
                if($result <= 0){
                    return true;
                }else{
                    return false;
                }
            }
            
            /**
             * This is the function that retrieves an order id
             */
            public function getTheOrderId($order_number){
                
                 $criteria1 = new CDbCriteria();
                 $criteria1->select = '*';
                 $criteria1->condition='order_number=:number';
                 $criteria1->params = array(':number'=>$order_number);
                 $order= Order::model()->find($criteria1);
            
                 return $order['id'];
            }
            
            /**
             * This is the function that places an order and retrieves its id
             */
            public function registerAndRetrieveTheOrder($toolbox_id,$domain_id){
                //place the order
                $order_number = $this->generateRenewalOrderNumber($toolbox_id,$domain_id);
                //get the order id
                $order_id = $this->getTheOrderId($order_number);
               
                return $order_id;
            }
            
            
            /**
             * This is the function that generates the actual order number
             */
            public function generateTheNeededOrderNumber($toolbox_id,$domain_id){
                //get the domain country name first three letters
                $domain_country_first_three_letters = rtrim(strtoupper($this->getTheDomainCountryNameFirstFourLetters($domain_id)));
                
                //get the a substring of the domain name
                $domain_name_sub = rtrim(strtoupper($this->getThePurchasingDomainNameFirstThreeLetters($domain_id)));
                
                //get the date of order registration
                $order_date = date("dmY",$this->getTheDateOfThisOrder($toolbox_id,$domain_id));
                
                //generate a random number
                $random_number = $this->generateTheRandomNumber();
                
                //get a substring of the toolbox
                $toolbox_name_substring = rtrim($this->getTheToolboxSubstring($toolbox_id));
                
                //get the order number
                $order_number = "$toolbox_name_substring$order_date-$domain_name_sub$random_number-$domain_country_first_three_letters";
                
                //confirm if this $order_number already exist and open
               if($this->isThisOrderAlreadyRegistered($order_number)){
                    return $order_number; 
                  
               }else{
                    //if the order number exist but closed
                    if($this->isThisOrderAlreadyExistButClosed($order_number)){
                        //rearrange the order number
                        $order_number_1 = "$random_number$toolbox_name_substring$order_date$domain_name_sub$domain_country_first_three_letters";
                        return $order_number_1;
                    }else{
                        return $order_number;
                    }
                }
                 
                 
                
            }
            
           /**
            * This is the function that fetches the order date for order number construction
            */
            public function getTheDateOfThisOrder($toolbox_id,$domain_id){
                //get todays date
                $today = mktime(0, 0, 0, date("m")  , date("d"), date("Y"));
                
               return $today;
            }
            
            /**
             * This is the function that toolbox name substring
             */
            public function getTheToolboxSubstring($toolbox_id){
                
                //get the toolbox name
                $toolboxname = strtoupper($this->getToolboxname($toolbox_id));
                
                return substr($toolboxname,0,4);
                
            }
            
            /**
             * This is the function that gets a toolbox name
             */
            public function getToolboxname($toolbox_id){
                
                $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition='id=:id';
                $criteria->params = array(':id'=>$toolbox_id);
                $toolbox = Resourcegroup::model()->find($criteria);
                
                return $toolbox['name'];
            }
            
            /**
             * This is the function that registers an order
             */
            public function registerTheOrder($order_number){
                $userid = Yii::app()->user->id;
                $domain_id = $this->determineAUserDomainIdGiven($userid);
                $cmd =Yii::app()->db->createCommand();
                $result = $cmd->insert('order',
                                  array(
                                    'order_number'=>$order_number,
                                    'status'=>'closed', 
                                    'order_domain_id'=>$domain_id, 
                                   'order_initiation_date'=>new CDbExpression('NOW()'),
                                    'order_initiated_by'=>$userid
                               
		
                            )
			
                        );
                if($result>0){
                    return true;
                }else{
                    return false;
                }
            }
            
            
            /**
             * This is the function that effects payments to the payment table
             */
            public function effectThePaymentOfThisPurchase($gross_amount,$discount_amount,$net_amount,$order_id,$invoice_number,$vat,$payment_mode,$payment_status,$toolbox_id,$subscribers,$number_of_years){
                
                $userid = Yii::app()->user->id;
                $domain_id = $this->determineAUserDomainIdGiven($userid);
                
                //get the last end date of this service to this domain
                $end_date = $this->getTheLasTEndDateOfThisServiceToThisDomain($toolbox_id,$domain_id);
                
                //get the number of years for this toolbox subscription
                
                //$number_of_years = $this->getTheNumberOfYearsForThisSubscription($toolbox_id, $order_id);
                
                $remark="request of this order with post-request number '$invoice_number' is effected";
                
              $cmd =Yii::app()->db->createCommand();
                $result = $cmd->insert('payment',
                                  array(
                                    'status'=>$payment_status,
                                    'payment_mode'=>$payment_mode,
                                    'invoice_number'=>$invoice_number, 
                                    'order_id'=>$order_id,
                                    'remark'=>$remark, 
                                    'net_amount'=>$net_amount, 
                                    'gross_amount'=>$gross_amount,
                                    'discounted_amount'=>$discount_amount,
                                    'vat'=>$vat,
                                    'toolbox_id'=>$toolbox_id,
                                    'subscribers'=>$subscribers,
                                    'last_service_end_date'=> $end_date, 
                                    'payee_domain_id'=>$domain_id, 
                                    'payment_date'=>new CDbExpression('NOW()'),
                                    'paid_by'=>$userid,
                                    'number_of_years'=>$number_of_years
                               
		
                            )
			
                        );
               return $result;
               
            }
            
            /**
             * This is the function that retrieves the last end date of this service to this domain
             */
            public function getTheLasTEndDateOfThisServiceToThisDomain($toolbox_id,$domain_id){
               if($this->isThisServiceToDomainAvailable($toolbox_id,$domain_id)){
                   $criteria = new CDbCriteria();
                   $criteria->select = '*';
                   $criteria->condition='category_id=:categoryid and resourcegroup_id=:toolboxid';
                   $criteria->params = array(':categoryid'=>$domain_id,':toolboxid'=>$toolbox_id);
                   $date = ResourceGroupHasResourcegroupcategory::model()->find($criteria);
                
                if($date['end_date']=== NULL){
                    return NULL;
                }else{
                    return $date['end_date'];
                }
               }else{
                   return NULL;
               }
                
                
            }
            
            /**
             * This is the function to determine if service is already expired for this domain
             */
            public function isThisToolboxServiceToThisDomainAlreadyExpired($toolbox_id,$domain_id, $expiry_date){
                
                //confirm if this service to this domain exist
                if($this->isThisServiceToDomainAvailable($toolbox_id,$domain_id)){
                    //confirm if the service has an end date for time to live
                    if($this->isEndOfDateDeclaredForThisServiceToThisDomain($toolbox_id,$domain_id)){
                        $today = getdate(mktime(0, 0, 0, date("m")  , date("d"), date("Y")));
                        $expiry = getdate(strtotime($expiry_date));
                        $day = $today['mday'];
                        $month = $today['mon'];
                        $year = $today['year'];
                       if(($expiry['year'] - $year <= 0) and (($expiry['mon'] - $month)<=0 and $expiry['mday']-$day<=0)){
                            return true;
                        }else{
                            return false;
                        }
                      
                    }else{
                        return false;
                    }
                }else{
                    return false;
                }
                
            }
            
            /**
             * This is the function that determines if end of date is declared for a service to a domains
             */
            public function isEndOfDateDeclaredForThisServiceToThisDomain($toolbox_id,$domain_id){
                
                 $criteria1 = new CDbCriteria();
                 $criteria1->select = '*';
                 $criteria1->condition='resourcegroup_id=:toolboxid and category_id=:domainid';
                 $criteria1->params = array(':toolboxid'=>$toolbox_id,':domainid'=>$domain_id);
                 $date= ResourcegroupHasResourcegroupcategory::model()->find($criteria1);
            
                if(strtotime($date['max_date'])>0 || $date['max_date']!== NULL){
                   return true;
                 }else{
                     return false;
                 
                } 
                
            }
            
            /**
             * This is the function that determines if this service is actually available to this domain
             */
            public function isThisServiceToDomainAvailable($toolbox_id,$domain_id){
                
                $cmd =Yii::app()->db->createCommand();
                $cmd->select('COUNT(*)')
                    ->from('resourcegroup_has_resourcegroupcategory')
                    ->where("resourcegroup_id = $toolbox_id and category_id=$domain_id");
                $result = $cmd->queryScalar();
                
                if($result > 0){
                    return true;
                }else{
                    return false;
                }
                
            }
            
            /**
             * This is the function that extends the time to live of a service to a domain
             */
            public function ExtendThisServiceToThisDomain($toolbox_id,$domain_id,$subscribers,$number_of_years){
                
              //get the number of years of subscription
              //$number_of_years = $this->getTheNumberOfYearsForThisSubscription($toolbox_id, $order_id);
                //confirm if service exist for a domain
                if($this->isThisServiceToDomainAvailable($toolbox_id,$domain_id)){
                    //confirm if end of date is declared for this service to this domain
                    if($this->isEndOfDateDeclaredForThisServiceToThisDomain($toolbox_id,$domain_id)){
                        //get the end_date for the service to this domain
                        $end_date = getdate(strtotime($this->getTheEndDateOfThisServiceToThisToDomain($toolbox_id,$domain_id)));
                        $today = getdate(mktime(0, 0, 0, date("m")  , date("d"), date("Y")));
                        if($end_date['year'] -$today['year']<=0 ){
                            if($end_date['mon']- $today['mon']<=0 ){
                                if(($end_date['mday']- $today['mday']<=0 )){
                                    $new_end_date = (mktime(0, 0, 0, date("m")-1  , date("d"), date("Y")+$number_of_years));
                                }else{
                                    $day_diff = $end_date['mday']- $today['mday'];
                                     $new_end_date = (mktime(0, 0, 0, date("m")-1  , date("d")+$day_diff, date("Y")+$number_of_years));
                                }
                            }else{
                                $mon_diff = $end_date['mon']- $today['mon']-1;
                                if($end_date['mon']- $today['mon']<=0){
                                   $new_end_date = (mktime(0, 0, 0, date("m")+$mon_diff  , date("d"), date("Y")+$number_of_years));  
                                }else{
                                    $day_diff = $end_date['mday']- $today['mday'];
                                     $new_end_date = (mktime(0, 0, 0, date("m")+$mon_diff  , date("d")+$day_diff, date("Y")+$number_of_years));
                                }
                            }
                        }else{
                            $year_diff = $end_date['year'] -$today['year'];
                            if($end_date['mon']- $today['mon']<=0){
                                if($end_date['mday']- $today['mday']<=0){
                                    $new_end_date = (mktime(0, 0, 0, date("m")-1  , date("d"), date("Y")+$number_of_years+$year_diff));
                                }else{
                                   $day_diff = $end_date['mday']- $today['mday'];
                                     $new_end_date = (mktime(0, 0, 0, date("m")-1  , date("d")+$day_diff, date("Y")+$number_of_years+$year_diff)); 
                                }
                            }else{
                                $mon_diff = $end_date['mon']- $today['mon']-1;
                                if($end_date['mday']- $today['mday']<=0){
                                    $new_end_date = (mktime(0, 0, 0, date("m")+$mon_diff  , date("d"), date("Y")+$number_of_years+$year_diff));
                                }else{
                                    $day_diff = $end_date['mday']- $today['mday'];
                                     $new_end_date = (mktime(0, 0, 0, date("m")+$mon_diff  , date("d")+$day_diff, date("Y")+$number_of_years+$year_diff)); 
                                }
                            }
                        }
                       // extend the value of the service by then= new date value
                        $new_expiry_date = date("Y-m-d", $new_end_date);
                        if($this->extendThisServiceToDomain($toolbox_id,$domain_id,$new_expiry_date,$subscribers,$number_of_years)){
                            return true;
                        }else{
                            return false;
                        }
                        
                    }
                }
                
                
                
            }
            
            /**
             * This is the function that is used to get the end date of a toolbox service to a domain
             */
            public function getTheEndDateOfThisServiceToThisToDomain($toolbox_id,$domain_id){
                
                 $criteria1 = new CDbCriteria();
                 $criteria1->select = '*';
                 $criteria1->condition='resourcegroup_id=:toolboxid and category_id=:domainid';
                 $criteria1->params = array(':toolboxid'=>$toolbox_id,':domainid'=>$domain_id);
                 $date= ResourcegroupHasResourcegroupcategory::model()->find($criteria1);
                 
                 return $date['max_date'];
                 
            }
            
            /**
             * This is the function that writes the new extended expiry date value to server
             */
            public function extendThisServiceToDomain($toolbox_id,$domain_id,$new_expiry_date,$subscribers,$number_of_years ){
                
                $today = date("Y-m-d",mktime(0, 0, 0, date("m")  , date("d"), date("Y")));
                //get the number of years of subscription
                //$number_of_years = $this->getTheNumberOfYearsForThisSubscription($toolbox_id, $order_id);
                $cmd =Yii::app()->db->createCommand();
                $result = $cmd->update('resourcegroup_has_resourcegroupcategory',
                                  array(
                                   'min_date'=>$today,
                                   'start_date'=>$today,   
                                   'max_date'=>$new_expiry_date, 
                                   'end_date'=>$new_expiry_date,
                                   'no_of_subscribers'=>$subscribers,
                                   'number_of_years'=>$number_of_years   
                           ),
                        ("resourcegroup_id=$toolbox_id and category_id=$domain_id")
			
                        );
                if($result>0){
                    return true;
                }else{
                    return false;
                }
                
            }
            
            /**
             * This is the function that sends failed renewal attempts to the renewal team
             */
            public function sendThisPaymentIssueToTheRenewalTeamForResolution($toolbox_id,$domain_id,$order_id,$invoice_number,$expiry_date,$message){
                
                //treat this later
            }
            
            
            /**
             * This is the function that ends a failed payment attempts to ths service desk
             */
            public function sendThisErrorMessageToTheServiceDesk($order_number,$invoice_number,$message){
                
                
                
            }
        
            /**
             * This is the function that adds item/toolbox to a cart
             */
            public function actionaddThisItemToCart(){
                $model = new OrderHasToolboxes;
                
                //get the logged in id of this users;
                $userid = Yii::app()->user->id;
                
                //get the domain id of this users
                $domain_id = $this->determineAUserDomainIdGiven($userid);
                
                 //get the minimum subscriber number for this toolbox
                $min_sub = $this->getTheMinimumSubscriptionForThisToolbox($_POST['toolbox']);
                
                               
                if($_POST['number_of_users'] < $min_sub){
                    $model->number_of_users = $min_sub;
                }else{
                    $model->number_of_users = $_POST['number_of_users'];
                }
                
                if(is_numeric($_POST['toolbox'])){
                    $model->toolbox_id = $_POST['toolbox'];
                }else{
                  //$model->toolbox_id = $_POST['toolbox_id'];  
                }
                                
                $model->number_of_years = $_POST['number_of_years'];
                
               
                $model->order_id = $_POST['id'];
               
                
                //get this items name
                $toolboxname = $this->getThisToolboxname($model->toolbox_id);
                
                //confirm if the user domain has a store
                if($this->domainHasACountryStore($domain_id)){
                    $model->store_id = $this->getTheCountryStoreOfThisDomain($domain_id);
                }else{
                    $model->store_id = $this->getTheDefaultStoreForThePlatform();
                }
                if(isset($_POST['toolbox'])){
                    if($this->isThisToolboxItemAlreadyInThisCart($model->toolbox_id,$model->order_id)){
                   header('Content-Type: application/json');
                      $msg = "This '$toolboxname' item is already in the cart ";
                       echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                            "msg" => $msg
                            )
                           
                       );
                   
               }else{
                   if($this->addThisToolboxItemToCart($model->toolbox_id,$model->order_id,$model->number_of_users,$model->number_of_years,$model->store_id,$userid)){
                     header('Content-Type: application/json');
                      $msg = "'$toolboxname' item successfully added to the cart";
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            "msg" => $msg
                            )
                           
                       );
                }else{
                    header('Content-Type: application/json');
                    $message = "'$toolboxname' item could not be added to the cart";
                    $this->sendThisMessageToTheProductSupportTeam($message,$model->toolbox_id,$model->order_id,$domain_id);
                    $msg = "There is an issue adding '$toolboxname' item to the cart ";
                       echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                            "msg" => $msg
                            )
                           
                       );
                }
               } 
                    
                }else{
                    header('Content-Type: application/json');
                      $msg = "This is no content in the cart ";
                       echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                            "msg" => $msg
                            )
                           
                       );
                }
               
                
       
            }
            
            
             /**
             * This is the function that modifies the contents in a cart
             */
            public function actionmodifyThisItemInCart(){
                
                //get the logged in id of this users;
                $userid = Yii::app()->user->id;
                
                //get the domain id of this users
                $domain_id = $this->determineAUserDomainIdGiven($userid);
                
                $id = $_POST['virtual_id'];
                $model=VirtualBoxRequest::model()->findByPk($id);
                
               $box_id = $_POST['box_id']; 
                  
              
                //get the minimum subscriber number for this toolbox
                $min_sub = $this->getTheMinimumSubscriptionForThisToolbox($box_id);
                
                   
                if($_POST['number_of_subscribers'] < $min_sub){
                        $number_of_users = $min_sub;
                    }else{
                        $number_of_users = $_POST['number_of_subscribers'];
                 }
                
                $number_of_years = $_POST['virtual_maximum_requesting_period_in_days'];
                
                $order_id = $_POST['order_id'];
                
                
                
                //get this items name
                $boxname = $this->getTheBoxname($box_id);
                
              
                if($this->modifyThisToolboxItemInCart($box_id,$order_id,$number_of_users,$number_of_years,$userid)){
                    if($this->isTheVirtualBoxModificationInTheRequestListSuccessful($model,$userid)){
                      header('Content-Type: application/json');
                      $msg = "'$boxname' information in the cart folder as well as the information on the virtual request list had been modified ";
                        echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            "msg" => $msg
                            )
                           
                       );
                    }else{
                      header('Content-Type: application/json');
                      $msg = "'$boxname' information in the cart folder had been modified but the information in the virtual request list could not be modified. It probably does not exist";
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            "msg" => $msg
                            )
                           
                       );
                    } 
                   
                
               }else{
                   header('Content-Type: application/json');
                      $msg = "Could not effect any modification to '$boxname' item in the cart nor the information in the virtual request list";
                       echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                            "msg" => $msg
                            )
                           
                       );
               } 
                
                
            }
            
            
            
            /**
             * This is the function that modifies the information in virtual request list
             */
            public function isTheVirtualBoxModificationInTheRequestListSuccessful($model,$user_id){
                
           if($_POST['virtual_id'] != "" || $_POST['virtual_id'] != 0){
            $user_id = Yii::app()->user->id;
            $domain_id =  $this->getTheDomainIdOfThisUser($user_id);
            $model->virtual_box_id = $_POST['virtual_box_id'];
            $model->virtual_maximum_requesting_period_in_days = $_POST['virtual_maximum_requesting_period_in_days']; 
            $model->virtual_requesting_domain_id = $domain_id;
            $model->status = strtolower($_POST['status']);
           $model->virtual_requesting_user_id = $user_id;
           if(isset($_POST['virtual_group'])){
               $model->virtual_requesting_group_id = $_POST['virtual_group'];
               $model->virtual_is_group_request = 1;
               $model->virtual_is_subgroup_request = 0;
               $model->virtual_is_single_user_request = 0;
           }else if(isset($_POST['virtual_subgroup'])){
               $model->virtual_requesting_subgroup_id = $_POST['virtual_subgroup'];
               $model->virtual_is_group_request = 0;
               $model->virtual_is_subgroup_request = 1;
               $model->virtual_is_single_user_request = 0;
           }else{
               $model->virtual_is_group_request = 0;
               $model->virtual_is_subgroup_request = 0;
               $model->virtual_is_single_user_request = 1;
           }
           $model->virtual_request_initiation_date = new CDbExpression('NOW()');
           $model->virtual_request_initiated_by = Yii::app()->user->id;
           $model->virtual_is_request_initiated = 1;
           if(isset($_POST['virtual_is_electronic_instrument_request_included'])){
                    $model->virtual_is_electronic_instrument_request_included = $_POST['virtual_is_electronic_instrument_request_included'];
                }else{
                    $model->virtual_is_electronic_instrument_request_included = 0;
                }
           
          if($this->isThisRequestInConformityWithPolicy($domain_id)){
                  //modify this request for this batch
                    if($model->save()){
                        return true;            
                    }else{
                       return false;
                    }
                    
               
               
            }else{
                header('Content-Type: application/json');
                       return false;
            }
         
             
         }else{
             return false;
         } 
          
                
  }
         
            /**
             * This is the function that gets the toolbox item name
             */
            public function getThisToolboxname($toolbox_id){
                
                $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition='id=:id';
                $criteria->params = array(':id'=>$toolbox_id);
                $name= Resourcegroup::model()->find($criteria);
                
                return $name['name'];
            }
            
            /**
             * This is the function that gets the country store of a domain
             */
            public function getTheCountryStoreOfThisDomain($domain_id){
                //confirm if the country has a country store
                if($this->domainHasACountryStore($domain_id)){
                    //get the country id of this domain
                    $country_id = $this->getTheCountryIdOfThisDomain($domain_id);
                    return ($this->getThisCountryStoreid($country_id));
                    
                }
                
                
            }
            
            
            /**
             * This is the function that gets a country store
             */
            public function getThisCountryStoreid($country_id){
                    $criteria = new CDbCriteria();
                    $criteria->select = '*';
                    $criteria->condition='country_id=:id';
                    $criteria->params = array(':id'=>$country_id);
                    $store= Stores::model()->find($criteria);
                    
                    
                    return $store['id'];
                
            }
            
            /**
             * This is the function that retrieves the default store in the platform
             */
            public function getTheDefaultStoreForThePlatform(){
                    $criteria = new CDbCriteria();
                    $criteria->select = '*';
                    $criteria->condition='default_store=:default';
                    $criteria->params = array(':default'=>1);
                    $store= Stores::model()->find($criteria);
                    
                    
                    return $store['id'];
            }
            
            /**
             * This is the function that determines if a toolbox item is already in the cart
             */
            public function isThisToolboxItemAlreadyInThisCart($toolbox_id,$order_id){
                
                $cmd =Yii::app()->db->createCommand();
                $cmd->select('COUNT(*)')
                    ->from('order_has_toolboxes')
                    ->where("toolbox_id = $toolbox_id and order_id=$order_id");
                $result = $cmd->queryScalar();
                
                if($result > 0){
                    return true;
                }else{
                    return false;
                }
            }
            
            /**
             * This is the function that sends a the inability to add items to cart error to the support team
             */
            public function sendThisMessageToTheProductSupportTeam($message,$toolbox_id,$order_id,$domain_id){
                
                
                
            }
            
            
            /**
             * This is the function that adds items to cart
             */
            public function addThisToolboxItemToCart($toolbox_id,$order_id,$number_of_users,$number_of_years,$store_id,$userid){
                $cmd =Yii::app()->db->createCommand();
                $result = $cmd->insert('order_has_toolboxes',
                                  array(
                                    'order_id'=>$order_id,
                                    'toolbox_id'=>$toolbox_id,
                                    'store_id'=>$store_id,
                                    'number_of_users'=>$number_of_users,
                                    'number_of_years'=>$number_of_years,
                                    'date_ordered'=>new CDbExpression('NOW()'),
                                    'ordered_by'=>$userid
            
                            )
			
                        );
               if($result>0){
                   return true;
               }else{
                   return false;
               }
                
            }
            
            
               /**
             * This is the function that modifies the feature of an item in cart
             */
            public function modifyThisToolboxItemInCart($toolbox_id,$order_id,$number_of_users,$number_of_years,$userid){
                
                $cmd =Yii::app()->db->createCommand();
                $result = $cmd->update('order_has_toolboxes',
                                  array(
                                    'number_of_users'=>$number_of_users, 
                                    'number_of_years'=>$number_of_years,  
                                    'date_last_update'=>new CDbExpression('NOW()'),
                                    'updated_by'=>$userid
            
                            ),
                ("order_id=$order_id and toolbox_id=$toolbox_id")
			
                        );
               if($result>0){
                   return true;
               }else{
                   return false;
               }
            }
            
            
            /**
             * This is the function that removes an item from the cart folder as well from the virtual box request list
             */
            public function actionRemoveAnItemFromCart(){
                $order_id = $_REQUEST['order_id'];
                
                $box_id = $_REQUEST['toolbox_id'];
                
                $user_id = Yii::app()->user->id;
                
                //get the toolbox name
                $boxname = $this->getThisToolboxname($box_id);
                
                $cmd =Yii::app()->db->createCommand();  
                $result = $cmd->delete('order_has_toolboxes', "order_id=:orderid and toolbox_id=:toolboxid", array(':orderid'=>$order_id,':toolboxid'=>$box_id));
            
                if($result>0){
                    if($this->isTheVirtualBoxRequestRemovedSuccessfully($box_id,$user_id)){
                       $msg = "'$boxname' item is successfully removed from the both the cart folder and the virtual box & folder request list ";
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            "msg" => $msg
                            )
                           
                       );
                    }else{
                       $msg = "'$boxname' item is successfully removed from the cart folder but not from the virtual box & folder request list ";
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            "msg" => $msg
                            )
                           
                       );
                    }
                    
                    
                }else{
                    $msg = "Removal of '$boxname' item from the both the cart folder and the virtual request list was not successful ";
                       echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                            "msg" => $msg
                            )
                           
                       );
                }
                        
            }
            
            
            /**
             * This is the function removes items from the virtual request list
             */
            public function isTheVirtualBoxRequestRemovedSuccessfully($box_id,$user_id){
                //get the id of this virtual box & folder item in the request list
                
                $id = $this->getTheIdOfThisVirtualBoxOnRequest($box_id, $user_id);
                $cmd =Yii::app()->db->createCommand();  
                $result = $cmd->delete('virtual_box_request', "id=:requestid", array(':requestid'=>$id));
                
                if($result>0){
                    return true;
                }else{
                    return false;
                }
            }
            
            /**
             * This is the function that retrieves the name of a toolbox
             */
            public function actionretrieveToolboxName(){
                
               $order_id = $_REQUEST['order_id'];
                
                $toolbox_id = $_REQUEST['toolbox_id'];
               
                
                //get the name of the toolbox
                $toolboxname = $this->getThisToolboxname($toolbox_id);
                
                if($toolboxname !== NULL){
                    //$msg = "'$toolboxname' item is successfully removed from the cart ";
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            "toolboxname" => $toolboxname
                           
                            )
                           
                       );
                }
                        
            }
            
           /**
            * This is the function that retrieves the detail information of a toolbox
            */
            public function actiongetToolboxDetailInformation(){
                
                $toolbox_id = $_REQUEST['toolbox_id'];
                
                $owner_id = $_REQUEST['domain_id'];
                
                $min_subscribers = (int)$_REQUEST['subscribers'];
                
                $store_id = $_REQUEST['store_id'];
           
            $userid = Yii::app()->user->id;
            
            //get the logged in user domain
            $domain_id = $this->determineAUserDomainIdGiven($userid);
            
              
                //get the order beneficiary
                $owner = $this->determineDomainNameGivenItId($owner_id);
                
                //get the total number of tools in this toolbox
                $tools_in_toolbox = $this->getTheTotalNumberOfToolsInThisToolbox($toolbox_id);
                //get the total number of tasks in this toolbox
                $tasks_in_toolbox = $this->getTotalNumberOfTasksInThisToolbox($toolbox_id);
                
                //get the gross amount for this order
               
                    $toolbox_gross = $this->getTheGrossAmountForThisToolboxPerDomain($toolbox_id, $owner_id,$min_subscribers);
                
                
                //get the applicable discount for this toolbox by this domain
                $toolbox_discount = $this->getTheApplicableDiscountForThisToolbox($toolbox_id,$owner_id,$min_subscribers);
                
                //determine if this transaction will be vat-able
                $vatable = $this->isTransactionVatible($toolbox_id,$owner_id,$domain_id);
                
                //get the prevailing vat rate
                $vat_rate = $this->getTheProvailingVatRate($toolbox_id,$owner_id,$domain_id);
                
                $default_currency_code = $this->getThePlatformCurrencyCodeOfTheDefaultStore();
                
                $store_currency_code = $this->getTheRelevantCurrencyCodeForThisStore((int)$store_id);
                
                $cart_empty = $this->determineIfAUserCartIsEmpty($userid);
                
                //spool the details of the box & folder
                $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition="id=:id";
                $criteria->params = array(':id'=>$toolbox_id);
                $box= Resourcegroup::model()->find($criteria);
                     
                //get the number of this box's physical documents that are on transit
               $documents_on_transit = $this->getTheNumberOfThisBoxPhysicalDocumentOnTranst($toolbox_id,$userid, $domain_id);
                
                //get the number of this box's physical batches & files that are on transit
                $batches_on_transit = $this->getTheNumberOfThisBoxPhysicalBatchOnTranst($toolbox_id,$userid, $domain_id);
                
                //confirm if this box & folder is on transit
                $box_on_transit = $this->isThisBoxOnTransit($toolbox_id,$userid, $domain_id);
                
                //determine this physical box current location
                $physical_box_current_location = $this->getTheCurrentLocationOfThisPhysicalBox($toolbox_id,$userid, $domain_id);
                
                //determine this physical box current holder
                $physical_box_current_holder = $this->getTheCurrentHolderOfThisPhysicalBox($toolbox_id,$userid, $domain_id);
                
                //get the domain of the current holder of this physical box
                $physical_box_current_holder_domain = $this->getTheDomainOfTheCurrentHolderOfThisPhysicalBox($toolbox_id,$userid, $domain_id);
                
                //determine the estimated number of days this box will be away from locaton
                $out_of_station_estimated_days = $this->getTheEstimatedOutOfStationDaysForThisBox($toolbox_id,$userid, $domain_id);
                
                //determine the number of pending request for this box & folder
                $number_of_pending_request = $this->getTheNumberOfPendingRequestOnThisBox($toolbox_id,$userid, $domain_id);
                
                //get the number of pending own domain request
                $number_of_pending_own_domain_request = $this->getTheNumberOfPendingOwnDomainRequestOnThisBox($toolbox_id, $userid, $domain_id);
                
                //get the number of other domain box request
                $number_of_pending_other_domain_request = $this->getTheNumberOfPendingOtherDomainRequestOnThisBox($toolbox_id, $userid, $domain_id);
                       
          
                       
                if($toolbox_id===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                }else{
                    header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            "owner" => $owner,
                            "toolbox_tools" => $tools_in_toolbox,
                            "toolbox_tasks" => $tasks_in_toolbox,
                           "toolbox_gross_amount" => $toolbox_gross,
                           "vat"=>$vatable,
                           "vat_rate"=>$vat_rate,
                            "currency_code"=>$default_currency_code,
                           "store_currency_code"=> $store_currency_code,
                           "cart_number"=>$cart_empty,
                           "box_number"=>$box['box_number'],
                           "visibility"=>$box['visibility'],
                           "storage_location"=>$box['storage_location'],
                           "storage_rooom"=>$box['storage_room'],
                           "storage_device"=>$box['rack_number'],
                           "is_closeable"=>$box['is_closeable'],
                           "closed_status"=>$box['closed_status'],
                           "document_on_transit"=>$documents_on_transit,
                           "batches_on_transit"=>$batches_on_transit,
                           "box_on_transit"=>$box_on_transit,
                           "physical_box_current_location"=>$physical_box_current_location,
                           "physical_box_current_holder"=>$physical_box_current_holder,
                           "physical_box_current_holder_domain"=>$physical_box_current_holder_domain,
                           "out_of_station_estimated_days"=>$out_of_station_estimated_days,
                           "number_of_pending_request"=>$number_of_pending_request,
                           "number_of_pending_own_domain_request"=>$number_of_pending_own_domain_request,
                           "number_of_pending_other_domain_request"=>$number_of_pending_other_domain_request
                         
                           //"store"=>$store_id
                          
                       
                       ));
                    
                }
                
                
                
            }
            
            
          
            
            /**
             * This is the function that determines if a box & folder is currently on transit
             */
            public function isThisBoxOnTransit($box_id,$user_id, $domain_id){
                
                //get the id of this physically held box & folder
                
                $id = $this->getTheIdOfThisPhysicallyHeldBox($box_id, $user_id, $domain_id);
                
                if($id == 0){
                    return false;
                }else{
                    if($this->isThisBoxYetToBeReturned($id)){
                        return true;
                    }else{
                        return false;
                    }
                }
                
                
            }
            
            
            /**
             * This is the function that determines if a holder of a box is yet to return it
             */
            public function isThisBoxYetToBeReturned($id){
                
                $cmd =Yii::app()->db->createCommand();
                $cmd->select('COUNT(*)')
                    ->from('physical_box_holder')
                    ->where("id = $id and is_returned=0");
                $result = $cmd->queryScalar();
                
                if($result > 0){
                    return true;
                }else{
                    return false;
                }
            }
            
            
             /**
         * This is the function that derive the id of the current physical holder of this box if its the user in question
         */
        public function getTheIdOfThisPhysicallyHeldBox($box_id,$user_id,$domain_id){
            
             $criteria6 = new CDbCriteria();
             $criteria6->select = '*';
             $criteria6->condition='(box_id=:doc and user_id=:userid) and (is_returned=:returned and is_assigned=:assigned)';
             $criteria6->params = array(':doc'=>$box_id,':userid'=>$user_id,':returned'=>false,':assigned'=>true);
             $holder = PhysicalBoxHolder::model()->find($criteria6);
             
             if($holder['id'] != null){
                 return $holder['id'];
                 
             }else{
                 return 0;
             }
        }
     
           
            
            /**
             * This is the function that determines the number of this box's document that is currently on transit
             */
            public function getTheNumberOfThisBoxPhysicalDocumentOnTranst($box_id,$user_id,$domain_id){
                
                 //get the id of the physical box in question
               $id =  $this->getTheIdOfThisPhysicallyHeldBox($box_id, $user_id, $domain_id);
               //get the number of batch & file in the box
                
               $counter = 0;
               if($id == 0){
                    return 0;
                }else{
                    $batches = $this->getAllBatchesInThisBox($id);
                
                         
                foreach($batches as $batch){
                    
                   //get all documents in this batch
                    $documents = $this->getAllDocumentsInThisBatch($batch);
                    foreach($documents as $document){
                        if($this->isThisDocumentOnTransit($document,$user_id,$domain_id)){
                            $counter = $counter + 1;
                        }
                    }
                }
                return $counter;
                }
                
                
            }
            
            
            /**
             * This is the function that determines if a document is on transit
             */
            public function isThisDocumentOnTransit($document_id,$user_id,$domain_id){
                
                 
                $id = $this->getTheIdOfThisPhysicallyHeldDocument($document_id, $user_id, $domain_id);
               if($id == 0){
                   return false;
               }else{
                   if($this->isThisDocumentYetToBeReturned($id)){
                        return true;
                    }else{
                        return false;
                }
               }
                
                
            }
            
            
            /**
         * This is the function that derive the id of the current physical holder of this document if its the user in question
         */
        public function getTheIdOfThisPhysicallyHeldDocument($document_id,$user_id,$domain_id){
            
             $criteria6 = new CDbCriteria();
             $criteria6->select = '*';
             $criteria6->condition='(document_id=:doc and user_id=:userid) and (is_returned=:returned and is_assigned=:assigned)';
             $criteria6->params = array(':doc'=>$document_id,':userid'=>$user_id,':returned'=>false,':assigned'=>true);
             $holder = PhysicalDocumentHolder::model()->find($criteria6);
             
             if($holder['id'] != null){
                 return $holder['id'];
                 
             }else{
                 return 0;
             }
        }
        
        
        /**
         * This is the function that determines if a document is yet to be returned
         */
        public function isThisDocumentYetToBeReturned($id){
            
            $cmd =Yii::app()->db->createCommand();
                $cmd->select('COUNT(*)')
                    ->from('physical_document_holder')
                    ->where("id = $id and is_returned=0");
                $result = $cmd->queryScalar();
                
                if($result > 0){
                    return true;
                }else{
                    return false;
                }
        }
            
            /**
             * This is the function that determines the number of this box batches & files that is currently on transit
             */
            public function getTheNumberOfThisBoxPhysicalBatchOnTranst($box_id,$user_id,$domain_id){
               
               //get the id of the physical box in question
               $id =  $this->getTheIdOfThisPhysicallyHeldBox($box_id, $user_id, $domain_id);
               //get the number of batch & file in the box
                if($id == 0){
                    return 0;
                }else{
                     $batches = $this->getAllBatchesInThisBox($id);
                
                $counter = 0;
                
                foreach(batches as $batch){
                    if($this->isThisBatchOnTransit($batch,$user_id,$domain_id)){
                        $counter = $counter + 1;
                    }
                }
                return $counter;
                }
               
                
            }
            
            
            /**
             * This is the function that determines if a batch is on transit
             */
            public function isThisBatchOnTransit($batch_id,$user_id,$domain_id){
                //get the id of this physically held batch & file
                
                $id = $this->getTheIdOfThisPhysicallyHeldBatch($batch_id, $user_id, $domain_id);
                if($id == 0){
                   return false; 
                }else{
                    if($this->isThisBatchYetToBeReturned($id)){
                        return true;
                    }else{
                        return false;
                    }
                }
                
                
            }
            
            
            /**
             * This is the function that determines if a holder of a box is yet to return it
             */
            public function isThisBatchYetToBeReturned($id){
                
                $cmd =Yii::app()->db->createCommand();
                $cmd->select('COUNT(*)')
                    ->from('physical_batch_holder')
                    ->where("id = $id and is_returned=0");
                $result = $cmd->queryScalar();
                
                if($result > 0){
                    return true;
                }else{
                    return false;
                }
            }
            
             /**
         * This is the function that derive the id of the current physical holder of this box if its the user in question
         */
        public function getTheIdOfThisPhysicallyHeldBatch($batch_id,$user_id,$domain_id){
            
             $criteria6 = new CDbCriteria();
             $criteria6->select = '*';
             $criteria6->condition='(batch_id=:doc and user_id=:userid) and (is_returned=:returned and is_assigned=:assigned)';
             $criteria6->params = array(':doc'=>$batch_id,':userid'=>$user_id,':returned'=>false,':assigned'=>true);
             $holder = PhysicalBatchHolder::model()->find($criteria6);
             
             if($holder['id'] != null){
                 return $holder['id'];
                 
             }else{
                 return 0;
             }
        }
            /**
             * This is the function that retrieves the current location of this box * file
             */
            public function getTheCurrentLocationOfThisPhysicalBox($box_id,$user_id,$domain_id){
                //get the id of this box on the holder table
                
                $id = $this->getTheIdOfThisPhysicallyHeldBox($box_id, $user_id, $domain_id);
                if($id == 0){
                    return "";
                }else{
                    //get the id of the current holder
                $current_holder_id= $this->getTheCurrentHolderId($id);
                
                //get the current location of this box
                if($this->isThisBoxOutOfPermanentLocation($box_id)){
                    //get the current temporary location of this box
                    $box_temp_location_id = $this->getTheCurrentTempLocationOfThisBox($box_id,$current_holder_id);
                    //get the name of the location
                    if($box_temp_location_id == 0){
                        $location_name = $this->getTheLocationName($box_temp_location_id);
                        return $location_name ." ". "(A Suspicious Location for this box & folder)";
                    }else{
                        $location_name = $this->getTheLocationName($box_temp_location_id);
                        return $location_name;
                    }
                    
                    
                }else{
                    $permanent_location_id = $this->getThePermanentLocationOfThisBox($box_id);
                    $permanent_location_name = $this->getTheLocationName($permanent_location_id);
                    return $permanent_location_name;
                }
                }
                
                
            }
            
            
            /**
             * This is the function that gets the permament location of a box & folder
             */
            public function getThePermanentLocationOfThisBox($box_id){
                 $criteria = new CDbCriteria();
                 $criteria->select = '*';
                 $criteria->condition='box_id=:id';
                 $criteria->params = array(':id'=>$box_id);
                 $location = BoxHasPermanentLocation::model()->find($criteria);
                 
                 return $location['location_id'];
            }
            
            
            /**
             * This is the function that retrieves a location name
             */
            public function getTheLocationName($box_location_id){
                
             //get this storage device name
                $storage_device_name = $this->getTheStorageDeviceName($box_location_id);
                
                //get the storage room id and the room name
                $storage_room_id = $this->getTheStorageRoomId($box_location_id);
                
                $storage_room_name = $this->getThisStorageRoomName($storage_room_id);
                
                //get the storage room location id and its name
                $location_id = $this->getThisLocationId($storage_room_id);
                
                $location_name =$this->getThisDomainLocationName($location_id);
                
                return $location_name." ".'/'.$storage_room_name." ".'/'.$storage_device_name;
                
                
            }
            
            /**
             * This is the function that gets the domain location name
             */
            public function getThisDomainLocationName($location_id){
                
                 $criteria = new CDbCriteria();
                 $criteria->select = '*';
                 $criteria->condition='id=:id';
                 $criteria->params = array(':id'=>$location_id);
                 $location = Location::model()->find($criteria);
                 
                 return $location['name'];
            }
            
            
            /**
             * This is the function that gets the location of the storage room
             */
            public function getThisLocationId($storage_room_id){
                
                 $criteria = new CDbCriteria();
                 $criteria->select = '*';
                 $criteria->condition='id=:id';
                 $criteria->params = array(':id'=>$room_id);
                 $room = StorageRoom::model()->find($criteria);
                 
                 return $room['location_id'];
            }
            
            
            /**
             * This is the function that gets the storage room name
             */
            public function getThisStorageRoomName($room_id){
                
                 $criteria = new CDbCriteria();
                 $criteria->select = '*';
                 $criteria->condition='id=:id';
                 $criteria->params = array(':id'=>$room_id);
                 $room = StorageRoom::model()->find($criteria);
                 
                 return $room['name'].'/'.$room['room_number'];
                
            }
            
            /**
             * This is the function that retrieves the storage room id given the storage device id
             */
            public function getTheStorageRoomId($device_id){
                
                 $criteria = new CDbCriteria();
                 $criteria->select = '*';
                 $criteria->condition='id=:id';
                 $criteria->params = array(':id'=>$device_id);
                 $device = StorageDevice::model()->find($criteria);
                 
                 return $device['room_id'];
                
            }
            
            
            /**
             * This is the function that gets the storage device name
             */
            public function getTheStorageDeviceName($device_id){
                 $criteria = new CDbCriteria();
                 $criteria->select = '*';
                 $criteria->condition='id=:id';
                 $criteria->params = array(':id'=>$device_id);
                 $device = StorageDevice::model()->find($criteria);
                 
                 return $device['label'].'/'.$device['device_number'];
            }
            
            /**
             * This is the function that gets the current temporary location of a box
             */
            public function getTheCurrentTempLocationOfThisBox($box_id,$current_holder_id){
                
                $temp_location_id = $this->getThisBoxTempLocation($box_id);
                if($this->doesThisCurrentTempLocationBelongToThisHolder($temp_location_id,$current_holder_id)){
                    return $temp_location_id;
                }else{
                    return 0;
                }
                
            }
            
            
            /**
             * This is the function that gets a box & folder current temporary location
             */
            public function getThisBoxTempLocation($box_id){
                 $criteria = new CDbCriteria();
                 $criteria->select = '*';
                 $criteria->condition='id=:id and status=:status';
                 $criteria->params = array(':id'=>$box_id, ':status'=>'in');
                 $location = BoxInLocation::model()->find($criteria);
                 
                 return $location['location_id'];
            }
            
            
            /**
             * This is the function that determines if a location is mapped to a user
             */
            public function doesThisCurrentTempLocationBelongToThisHolder($location_id,$user_id){
                 $cmd =Yii::app()->db->createCommand();
                $cmd->select('COUNT(*)')
                    ->from('user_has_location')
                    ->where("user_id = $user_id and location_id=$location_id");
                $result = $cmd->queryScalar();
                
                if($result > 0){
                    return true;
                }else{
                    return false;
                }
            }
            
            
            /**
             * This is the function that confirms if a box & folder is actually out of its permanent location
             */
            public function isThisBoxOutOfPermanentLocation($box_id){
                
                $cmd =Yii::app()->db->createCommand();
                $cmd->select('COUNT(*)')
                    ->from('box_has_permanent_location')
                    ->where("box_id = $box_id and status='out'");
                $result = $cmd->queryScalar();
                
                if($result > 0){
                    return true;
                }else{
                    return false;
                }
                
            }
            
            /**
             * This is the function that retrieves the current holder of this box & folder
             */
            public function getTheCurrentHolderOfThisPhysicalBox($box_id,$user_id,$domain_id){
                
                 //get the id of this box on the holder table
                
                $id = $this->getTheIdOfThisPhysicallyHeldBox($box_id, $user_id, $domain_id);
                if($id == 0){
                    return "";
                }else{
                    //get the id of the current holder
                    $current_holder_id= $this->getTheCurrentHolderId($id);
                
                    $holder_name = $this->getTheNameOfThisUser($current_holder_id);
                
                    return $holder_name;
                }
                
                
            }
            
            
            /**
             * This is the function that gets the name of this user id
             */
            public function getTheNameOfThisUser($holder_id){
                $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition='(id=:id)';
                $criteria->params = array(':id'=>$holder_id);
                $user = User::model()->find($criteria);
                
                if($user['middlename'] == null or $user['middlename']==""){
                    $name = $user['firstname']." ". $user['lastname'];
                }else{
                    $name = $user['firstname']." ". $user['middlename']. " ". $user['lastname'];
                }
                return $name;
                
            }
                        
            /**
             * This is the function that retrieves the domain of the current holder of the physical box
             */
            public function getTheDomainOfTheCurrentHolderOfThisPhysicalBox($box_id,$user_id,$domain_id){
                //get the id of this box on the holder table
                
                $id = $this->getTheIdOfThisPhysicallyHeldBox($box_id, $user_id, $domain_id);
                if($id == 0){
                    return "";
                }else{
                    //get the id of the current holder
                    $current_holder_id= $this->getTheCurrentHolderId($id);
                
                    //get the domain of the current holder
                    $current_holder_domain_id = $this->getTheDomainIdOfThisUser($current_holder_id);
                
                    //get the domain name
                    $current_holder_domain_name = $this->determineDomainNameGivenItId($current_holder_domain_id);
                
                    return $current_holder_domain_name;
                }
                
            }
            
            
            /**
             * This is the function that retrieves the current holder id
             */
            public function getTheCurrentHolderId($id){
                
                $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition='(id=:id)';
                $criteria->params = array(':id'=>$id);
                $holder = PhysicalBoxHolder::model()->find($criteria);
                
                return $holder['user_id'];
            }
            
            /**
             * This is the function that gets the estimated number of days this box will be out of its store location
             */
            public function getTheEstimatedOutOfStationDaysForThisBox($box_id,$user_id,$domain_id){
                
                if($this->isThisBoxOnTransit($box_id,$user_id,$domain_id)){
                    //get the id of the current holder of this box
                    $id = $this->getTheIdOfThisPhysicallyHeldBox($box_id, $user_id, $domain_id);
                    
                    //get maximum assigned days for this document consumption
                    $max_box_holding_days = $this->getTheCurrentMaximumHoldingDaysForThisBox($id);
                    return $max_box_holding_day;
                    
                }else{
                    return 0;
                }
                
                
                
            }
            
            /**
             * This is the function that gets the maximum holding days of a box
             */
            public function getTheCurrentMaximumHoldingDaysForThisBox($id){
              
                $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition='(id=:id)';
                $criteria->params = array(':id'=>$id);
                $holder = PhysicalBoxHolder::model()->find($criteria);
                
                return $holder['maximum_holding_period_in_days'];
            }
            
            /**
             * This is the function that retrieves the number of pending request for a box & folder 
             */
            public function getTheNumberOfPendingRequestOnThisBox($box_id,$user_id,$domain_id){
                //get all the ids of the box on request
                $ids = $this->getTheIdsOfThisBoxOnRequest($box_id);
                
                $counter = 0;
                foreach($ids as $id){
                    $counter = $counter + 1;
                }
                return $counter;
                
            }
            
            
            /**
             * This is the function that retrieves the number of pending request for a box & folder 
             */
            public function getTheNumberOfPendingOwnDomainRequestOnThisBox($box_id,$user_id,$domain_id){
                //get all the ids of the box on request
                $ids = $this->getTheIdsOfThisBoxOnRequest($box_id);
                
                $counter = 0;
                foreach($ids as $id){
                    if($this->isRequestMadeByOwnDomainUser($id,$domain_id)){
                        $counter = $counter + 1;
                    }
                    
                }
                return $counter;
                
            }
            
            
             /**
             * This is the function that retrieves the number of pending request for a box & folder 
             */
            public function getTheNumberOfPendingOtherDomainRequestOnThisBox($box_id,$user_id,$domain_id){
                //get all the ids of the box on request
                $ids = $this->getTheIdsOfThisBoxOnRequest($box_id);
                
                $counter = 0;
                foreach($ids as $id){
                    if($this->isRequestMadeByOwnDomainUser($id,$domain_id)== false){
                        $counter = $counter + 1;
                    }
                    
                }
                return $counter;
                
            }
            
            
            /**
             * This is the function that confirms if request on box was by an own domain
             */
            public function isRequestMadeByOwnDomainUser($id,$domain_id){
                
                $cmd =Yii::app()->db->createCommand();
                $cmd->select('COUNT(*)')
                    ->from('physical_box_request')
                    ->where("id = $id and requesting_domain_id=$domain_id");
                $result = $cmd->queryScalar();
                
                if($result > 0){
                    return true;
                }else{
                    return false;
                }
                
            }
            
            
             /**
      * This is the function that gets the id of the  box on request
      */
     public function getTheIdsOfThisBoxOnRequest($box_id){
         
             $criteria = new CDbCriteria();
             $criteria->select = '*';
             $criteria->condition='(box_id=:doc and is_request_cancelled=:cancelled ) and (is_sent=:sent and is_requested=:requested)';
             $criteria->params = array(':doc'=>$box_id,':sent'=>false,':requested'=>false,':cancelled'=>false);
             $requests = PhysicalBoxRequest::model()->findAll($criteria);
             
             $id = [];
             
             foreach($requests as $request){
                 $id[] = $request['id'];
             }
             return $id;
             
             
             
           
         
     }
     
            
            /**
             * This is the function that determines if a transaction is vat-able
             */
            public function isTransactionVatible($toolbox_id,$owner_id,$domain_id){
                //get the country of this toolbox owner domain
                $country_id =  $this->getTheCountryIdOfThisDomain($owner_id);
                
                //confirm if the country store is the default store on the platform
                
                if($this->isCountryStoreTheDefaultstore($country_id)){
                    //determine the vat policy of that country
                    if($this->isPayeeDomainVatLegibleOnThisPurchase($domain_id,$toolbox_id)){
                        return true;
                    }else{
                        return false;
                    }
                }else{
                    return false;
                }
                
                
                
            }
            
            
            /**
             * This is the function that determines if a user cart is empty or not
             */
            public function determineIfAUserCartIsEmpty($user_id){
                if($this->isUserCartEmpty($user_id)){
                    return true;
                    
                }else{
                   return false;
                   
                }
                
            }
            
            /*
         * This is the function that determines if a cart is empty
         */
        public function isUserCartEmpty($user_id){
            //$user_id = Yii::app()->user->id;
            //retrieve the user's open order id
            $order_id = $this->getTheUsersOpenOrder($user_id);
            
            //verify if user cart is empty
            if($this->isCartEmpty($order_id)){
                return true;
                
            }else{
                return false;
            }
        }
        
        /**
         * This is the function that gets a users open order or return 0 if there are no open order
         */
        public function getTheUsersOpenOrder($user_id){
            if($user_id != null){
                $cmd =Yii::app()->db->createCommand();
                $cmd->select('COUNT(*)')
                    ->from('order')
                    ->where("order_initiated_by = $user_id && status ='open'");
                $result = $cmd->queryScalar();
                
                if($result > 0){
                    //fetch the order id
                    $order_id = $this->getTheOpenOrderId($user_id);
                    return $order_id;
                   
                }else{
                    return 0;
                    
                }
                
            }else{
               return 0; 
            }    
            
                     
        }
        
        /**
         * This is the function that verifies if an order cart is empty or not
         * 
         */
        public function isCartEmpty($order_id){
            
            $cmd =Yii::app()->db->createCommand();
            $cmd->select('COUNT(*)')
                    ->from('order_has_toolboxes')
                    ->where("order_id = $order_id");
                $result = $cmd->queryScalar();
                
                if($result <= 0){
                    return true;
                }else{
                    return false;
                }
        }
        
        /**
         * This is the function that returns the a user's open order
         */
        public function getTheOpenOrderId($user_id){
            
                     $criteria = new CDbCriteria();
                     $criteria->select = '*';
                     $criteria->condition="order_initiated_by=:userid and status='open'";
                     $criteria->params = array(':userid'=>$user_id);
                     $order= Order::model()->find($criteria);
                     
                     return $order['id'];
            
            
        }
            
            
            /**
             * This is the function that confirms if a country store is the default store
             */
            public function isCountryStoreTheDefaultStore($country_id){
                
                //confirm if country has store
                if($this->confirmIfCountryHasStore($country_id)){
                    //get the country store id
                    $store_id = $this->getThisCountryStoreid($country_id);
                    //confirm if store is the default store
                    if($this->isStoreAPlatformDefaultStore($store_id)){
                        return true;
                    }else{
                        return false;
                    }
                }else{
                    return false;
                }
                
            }
            
            /**
             * This is the function that determines if a srore platform default
             */
            public function isStoreAPlatformDefaultStore($store_id){
                
                $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition='id=:id';
                $criteria->params = array(':id'=>$store_id);
                $store = Stores::model()->find($criteria);
                
                if($store['default_store'] == 1){
                    return true;
                }else{
                    return false;
                }
            }
            
            /**
             * This is the function that retrieves a domains vat rate
             */
            public function getTheProvailingVatRate($toolbox_id,$owner_id,$domain_id){
                //confirm if transaction is vatible
                if($this->isTransactionVatible($toolbox_id,$owner_id,$domain_id)){
                    //get the country of this seller
                    $country_id = $this->getTheCountryIdOfThisDomain($owner_id);
                    //get the vat rate of this country
                    $vat_rate = $this->getTheVatRateOfThisCountry($country_id);
                    
                    return $vat_rate;
                }else{
                    return 0;
                }
            }
            
            /**
             * This is the function that retrieves the currency code of the default store
             */
            public function getThePlatformCurrencyCodeOfTheDefaultStore(){
                
                //get the currency id of the default store
                $currency_id = $this->getTheDefaultStoreCurrencyId();
                
                $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition='id=:id';
                $criteria->params = array(':id'=>$currency_id);
                $currency = Currencies::model()->find($criteria);
                
                return $currency['currency_code'];
                
               
            }
            
            /**
             * This is the function that retrieves the relevant currency code of a store
             */
            public function getTheRelevantCurrencyCodeForThisStore($store_id){
                //get the country of this store
                $country_id = $this->getTheCountryOfThisStore($store_id);
                
                //get the currency code of this country
                $currency_code = $this->getTheCurrencyCodeOfThisCountry($country_id);
                
                return $currency_code;
            
            }
            
            /**
             * This is the function that gets the currency code of a country
             */
            public function getTheCurrencyCodeOfThisCountry($country_id){
                
                $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition='country_id=:id';
                $criteria->params = array(':id'=>$country_id);
                $currency = Currencies::model()->find($criteria);
                
                return $currency['currency_code'];
               
            }
            
            /**
             * This is the function that gets the currency id of the default store
             */
            public function getTheDefaultStoreCurrencyId(){
                
                $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition='default_store=:default';
                $criteria->params = array(':default'=>1);
                $store = Stores::model()->find($criteria);
                
                return $store['currency_id'];
                
            }
            
            /**
             * This is the function that saves a new toolbox to a cart
             */
            public function actionaddNewItemToCart(){
                $user_id = Yii::app()->user->id;
                $domain_id =$this->determineAUserDomainIdGiven($user_id);
                
                $model = new VirtualBoxRequest;
                
                $box_id = $_POST['box_id'];
                $subscribers = $_POST['number_of_subscribers'];
                $number_of_years = $_POST['maximum_requesting_period_in_days'];
              //$number_of_years = 1;
                //get the minimum subscriber number for this toolbox
                $min_sub = $this->getTheMinimumSubscriptionForThisToolbox($box_id);
                
                               
                if($subscribers < $min_sub){
                    $subscribers = $min_sub;
                }
                //get the toolbox name
                $boxname = $this->getTheBoxName($box_id);
                
                $store_id = $this->getTheDefaultStoreForThePlatform();
                
                if($this->isUserAlreadyHasOpenOrder($user_id,$domain_id)){
                   //get the open order of this user
                    $order_id = $this->getTheOpenOrderOfThisUser($domain_id,$user_id);
                    
                    if($this->isThisItemAlreadyInTheCart($box_id,$domain_id,$user_id,$order_id)){
                        if($this->isThisItemInTheVirtualBoxRequestListAwaitingApproval($box_id,$domain_id,$user_id)){
                            $msg = "'$boxname' Box & Folder is already in the Virtual Request List as well as in the Cart folder. It is probably undergoing activation ";
                            echo CJSON::encode(array(
                                "success" => mysql_errno() != 0,
                                "msg" => $msg
                            )
                           
                        );
                            
                        }else{
                             $msg = "'$boxname' Box & Folder is in the cart folder but not in the Virtual Request List. This is strange. Please contact the Platform Administrator ";
                            echo CJSON::encode(array(
                                "success" => mysql_errno() != 0,
                                "msg" => $msg
                                )
                             );        
                        }
                        
                   }else{
                      if($this->addThisToolboxItemToCart($box_id,$order_id,$subscribers,$number_of_years,$store_id,$user_id)){
                          if($this->isBoxSuccessfullyAddedToTheVirtualBoxRequestList($model,$user_id)){
                                $msg = "'$boxname' Folder item is successfully added to the cart and to the virtual box request list";
                                echo CJSON::encode(array(
                                        "success" => mysql_errno() == 0,
                                        "msg" => $msg
                                    )
                           
                                  ); 
                          }else{
                             $msg = "'$boxname' Folder item is successfully added to the cart but not to the virtual box request list. It probably already exist in the virtual request list";
                                echo CJSON::encode(array(
                                "success" => mysql_errno() != 0,
                                "msg" => $msg
                            )
                           
                            );  
                          }
                          
                      }else{
                          $message = "This $boxname could not be added to the cart";
                          $this->sendThisMessageToTheProductSupportTeam($message, $box_id, $order_id, $domain_id);
                          $msg = "'$boxname' Folder  was not added to the cart ";
                            echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                            "msg" => $msg
                            )
                           
                       );
                      }
                      
                   }
                }else{
                    //create a new order
                    $order_id = $this->createNewOrderForThisTransaction($domain_id,$box_id,$user_id);
                    //insert the toolbox item to a new cart
                    if($this->addThisToolboxItemToCart($box_id,$order_id,$subscribers,$number_of_years,$store_id,$user_id)){
                         if($this->isBoxSuccessfullyAddedToTheVirtualBoxRequestList($model,$user_id)){
                            $msg = "'$boxname' Folder item is successfully added to the cart and to the virtual box request list";
                            echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            "msg" => $msg
                            )
                           
                            ); 
                          }else{
                             $msg = "'$boxname' Folder item is successfully added to the cart but not to the virtual box request list. It probably already exist in the virtual request list";
                                echo CJSON::encode(array(
                                "success" => mysql_errno() != 0,
                                "msg" => $msg
                            )
                           
                            );  
                          }
                                    
                    }else{
                        $message = "This $toolbox could not be added to the cart";
                          $this->sendThisMessageToTheProductSupportTeam($message, $box_id, $order_id, $domain_id);
                          $msg = "'$boxname' Folder  was not added to the cart ";
                            echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                            "msg" => $msg
                            )
                           
                       );
                    }
                }
            }
            
            
            /**
             * This is the function that determines if a box & folder is in the virtual box request list
             */
            public function isThisItemInTheVirtualBoxRequestListAwaitingApproval($box_id,$domain_id,$user_id){
                //get the id of the virtual box request in the request list 
                $id = $this->getTheIdOfThisVirtualBoxOnRequest($box_id, $user_id);
                if($id == 0){
                    return false;
                }else{
                    return true;
                }
            }
            
            
              /**
         * This is the function that gets the id of a virtual id request
         */
        public function getTheIdOfThisVirtualBoxOnRequest($box_id, $user_id){
            
             $criteria6 = new CDbCriteria();
             $criteria6->select = '*';
             $criteria6->condition='(virtual_box_id=:doc and virtual_requesting_user_id=:userid) and (status=:status and virtual_is_requested=:requested)';
             $criteria6->params = array(':doc'=>$box_id,':userid'=>$user_id,':status'=>"inactive",':requested'=>false);
             $holder = VirtualBoxRequest::model()->find($criteria6);  
             
             if($holder['id'] == 0 || $holder['id'] == null ){
                return 0;
            }else{
                return $holder['id'];
            }
            
        }
            
            /**
             * This is the function that adds box & folder to the virtual box request list
             */
            public function isBoxSuccessfullyAddedToTheVirtualBoxRequestList($model,$user_id){
                
            $domain_id =  $this->getTheDomainIdOfThisUser($user_id);
            $model->virtual_box_id = $_POST['virtual_box_id'];
            $model->virtual_maximum_requesting_period_in_days = $_POST['virtual_maximum_requesting_period_in_days']; 
            $model->virtual_requesting_domain_id = $domain_id;
            $model->status = strtolower($_POST['status']);
           $model->virtual_requesting_user_id = $user_id;
           if(isset($_POST['virtual_group'])){
               $model->virtual_requesting_group_id = $_POST['virtual_group'];
               $model->virtual_is_group_request = 1;
               $model->virtual_is_subgroup_request = 0;
               $model->virtual_is_single_user_request = 0;
           }else if(isset($_POST['virtual_subgroup'])){
               $model->virtual_requesting_subgroup_id = $_POST['virtual_subgroup'];
               $model->virtual_is_group_request = 0;
               $model->virtual_is_subgroup_request = 1;
               $model->virtual_is_single_user_request = 0;
           }else{
               $model->virtual_is_group_request = 0;
               $model->virtual_is_subgroup_request = 0;
               $model->virtual_is_single_user_request = 1;
           }
           $model->virtual_request_initiation_date = new CDbExpression('NOW()');
           $model->virtual_request_initiated_by = Yii::app()->user->id;
           $model->virtual_is_request_initiated = 1;
           if(isset($_POST['virtual_is_electronic_instrument_request_included'])){
                    $model->virtual_is_electronic_instrument_request_included = $_POST['virtual_is_electronic_instrument_request_included'];
                }else{
                    $model->virtual_is_electronic_instrument_request_included = 0;
                }
           
           $box_name = $this->getTheBoxName($model->virtual_box_id);
           
            if($this->isThisRequestInConformityWithPolicy($domain_id)){
                
                if($this->thereIsNoPendingRequestOfThisBoxByThisUser($model->virtual_box_id,$model->virtual_request_initiated_by,$model->status)){
                     //initiate the request for this batch
                    if($model->save()){
                        
                       return true;
                       
                    }else{
                       return false;
                        
                    }
                    
                    
                }else{
                   return false;
                }
                
                
            }else{
               return false;
            }
                
            }
            
            
               /**
     * This is the function that determines if a document request is in conformity with the prevailing domain policy
     */
     public function isThisRequestInConformityWithPolicy($domain_id){
         
         return true;
     }
     
     
          /**
      * This is the function that determines if there is a pending request of this batch by this user
      */
     public function thereIsNoPendingRequestOfThisBoxByThisUser($box_id,$request_initiated_by, $status){
         if($this->hasThisUserMadeThisBatchRequestBefore($box_id,$request_initiated_by,$status)){
             if($this->isThereAnyOpenRequestOfThisBatchByThisUser($box_id,$request_initiated_by,$status)){
                 return false;
             }else{
                 return true;
             }
             
         }else{
             return true;
         }
         
     }
        
        
        /**
      * This is the function that determines if this user had made a similar request before
      */
     public function hasThisUserMadeThisBatchRequestBefore($box_id,$request_initiated_by, $status){
         
          $cmd =Yii::app()->db->createCommand();
                $cmd->select('COUNT(*)')
                    ->from('virtual_box_request')
                    ->where("virtual_box_id = $box_id && virtual_request_initiated_by=$request_initiated_by");
                $result = $cmd->queryScalar();
                
                if($result > 0){
                    return true;
                }else{
                    return false;
                }
         
     }
     
     
     /**
      * This is the function that determines if there is any open request of this batch by this user
      */
     public function isThereAnyOpenRequestOfThisBatchByThisUser($batch_id,$request_initiated_by,$status){
         
            $cmd =Yii::app()->db->createCommand();
                $cmd->select('COUNT(*)')
                    ->from('virtual_box_request')
                    ->where("(virtual_box_id = $batch_id && virtual_request_initiated_by=$request_initiated_by) &&(virtual_is_requested=0 && status='inactive')");
                $result = $cmd->queryScalar();
                
                if($result > 0){
                    return true;
                }else{
                    return false;
                }
         
         
     }
     
       /**
         * This is the function that gets the domain id of a user
         */
        public function getTheDomainIdOfThisUser($user_id){
            
             $criteria = new CDbCriteria();
             $criteria->select = '*';
             $criteria->condition='id=:id';
             $criteria->params = array(':id'=>$user_id);
             $domain = User::model()->find($criteria);   
             
             return $domain['domain_id'];
        }
        
     
     
            
            /**
             * This is the function that checks if a user already has an open order
             */
            public function isUserAlreadyHasOpenOrder($user_id,$domain_id){
                
               $cmd =Yii::app()->db->createCommand();
                $cmd->select('COUNT(*)')
                    ->from('order')
                    ->where("order_initiated_by = $user_id && status ='open'");
                $result = $cmd->queryScalar();
                
                if($result > 0){
                    return true;
                }else{
                    return false;
                }
                
            }
            
            /**
             * This is the function that retrieves the open order of a user
             */
            public function getTheOpenOrderOfThisUser($domain_id,$user_id){
                
                $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition='order_initiated_by=:userid and status=:status';
                $criteria->params = array(':userid'=>$user_id,':status'=>'open');
                $order = Order::model()->find($criteria);
                
                return $order['id'];
            }
            
            /**
             * This is teh function that confirms if item is already in a cart
             */
            public function isThisItemAlreadyInTheCart($toolbox_id,$domain_id,$user_id,$order_id){
                
                $cmd =Yii::app()->db->createCommand();
                $cmd->select('COUNT(*)')
                    ->from('order_has_toolboxes')
                    ->where("order_id = $order_id && toolbox_id =$toolbox_id");
                $result = $cmd->queryScalar();
                
                if($result > 0){
                    return true;
                }else{
                    return false;
                }
            }
            
           /**
            * This is the function that createa a new order
            */
            public function createNewOrderForThisTransaction($domain_id,$toolbox_id,$user_id){
               
                //generate an order number
                $order_number = $this->generateTheNeededOrderNumber($toolbox_id,$domain_id);
                
                $cmd =Yii::app()->db->createCommand();
                $result = $cmd->insert('order',
                                  array(
                                    'order_number'=>$order_number,
                                    'status'=>'open', 
                                    'order_domain_id'=>$domain_id,  
                                    'order_initiation_date'=>new CDbExpression('NOW()'),
                                    'order_initiated_by'=>$user_id
            
                            )
			
                        );
               if($result>0){
                   return $this->getTheOrderId($order_number);
               }else{
                   return null;
               }
                
            }
            
            /**
             * This is the function that gets the minimum subscription required for a toolbox
             */
            public function getTheMinimumSubscriptionForThisToolbox($toolbox_id){
                
                $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition='id=:id';
                $criteria->params = array(':id'=>$toolbox_id);
                $toolbox = Resourcegroup::model()->find($criteria);
                
                
                if($toolbox['visibility'] =='private'){
                    return $this->getTheMinimumSubscriptionForPrivateToolboxServiceInThePlatform();
                }else{
                   return $toolbox['min_subscription_required']; 
                }
                
                
            }
            
            
            /**
             * This is the function that gets the minimum subscription number  to a domain's private toolbox
             */
            public function getTheMinimumSubscriptionForDomainPrivateToolboxService($domain_id){
                 
                $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition='domain_id=:id';
                $criteria->params = array(':id'=>$domain_id);
                $toolbox = DomainPolicy::model()->find($criteria);
                
                return $toolbox['private_toolbox_min_subscription_no'];
                
                
            }
            
            
            /**
             * This is the function that gets the minimum subscription number for a private toolbox
             */
            public function getTheMinimumSubscriptionForPrivateToolboxServiceInThePlatform(){
                 
                $criteria = new CDbCriteria();
                $criteria->select = '*';
               // $criteria->condition='domain_id=:id';
               // $criteria->params = array(':id'=>$domain_id);
                $settings = PlatformSettings::model()->find($criteria);
                
                return $settings['private_toolbox_min_subscription_no'];
                
                
            }
            
             /**
	 * Creates a new model.
	 * If creation is successful, the browser will be redirected to the 'view' page.
	 */
	public function actionAssignResourcegroupToCategory()
	{
		//get the id of the logged in user
                $user_id = Yii::app()->user->id;
                
                //get the domain of the logged in user
                
                //$domain_id = $this->determineAUserDomainIdGiven($user_id);
                
                $domain_id = $_POST['id'];
                
                                
                //get the store id of operating country of this domain
               //confirm if the user domain has a store
                if($this->domainHasACountryStore($domain_id)){
                    $store_id = $this->getTheCountryStoreOfThisDomain($domain_id);
                }else{
                    $store_id = $this->getTheDefaultStoreForThePlatform();
                }
		
               $number_of_years = $_POST['number_of_years'];
               $subscribers = $_POST['no_of_subscribers'];
               
                //get the toolbox name
               // $toolboxname = $this->getThisToolboxname($toolbox_id);
                
                //get the minimum subscriber number for this toolbox
                $min_sub = $this->getTheMinimumSubscriptionNumberRequiredForPrivateToolboxesForThisDomain($domain_id);
                if($subscribers < $min_sub){
                    $subscribers = $min_sub;
                }
               
                $toolbox_counter  = 0;
                $existing_toolbox_counter  = 0;
                       
             if($this->isUserAlreadyHasOpenOrder($user_id,$domain_id)){
                 
                 if(isset($_POST['resourcegroup'])){
                     //get the open order of this user
                 $order_id = $this->getTheOpenOrderOfThisUser($domain_id,$user_id);
                 
                 //spool all the toolboxes already assigned in this order
                    $existing_toolboxes = $this->alreadyAssignedToolboxesInCartToThisDomain($order_id);
                    $selected_toolboxes = [];
                  
                    foreach($_POST['resourcegroup'] as $toolbox_id){
                        
                        $selected_toolboxes[] = $toolbox_id;
                        
                    }
                    
                    //get the array difference
                    $discarded_toolboxes = array_diff($existing_toolboxes,$selected_toolboxes);
                    
                    //delete all the toolboxes in $discarded_toolboxes array
                    foreach($discarded_toolboxes as $discarded){
                        
                        $this->removeThisToolboxInCartFromThisDomain($discarded, $order_id);
                    }
                  
                    if (is_array($_POST['resourcegroup'])) {
                            foreach($_POST['resourcegroup'] as $toolbox){  
                               
                                if($this->isThisItemAlreadyInTheCart($toolbox,$domain_id,$user_id,$order_id)){
                                    if($this->updateToolboxInformationInCart($toolbox,$order_id,$user_id,$subscribers,$number_of_years)){
                                        $existing_toolbox_counter = $existing_toolbox_counter + 1;
                                    }
                                    
                                    
                                }else{
                                     if($this->addThisToolboxItemToCart($toolbox,$order_id,$subscribers,$number_of_years,$store_id,$user_id)){
                                       $toolbox_counter = $toolbox_counter + 1;
                           
                                    
                                  }
                                }
                      }
                             
                             
                             
                       }else {
                           $toolbox = $_POST['resourcegroup'];
                           if($this->isThisItemAlreadyInTheCart($toolbox,$domain_id,$user_id,$order_id)){
                                    $existing_toolbox_counter = $existing_toolbox_counter + 1;
                                    
                                }else{
                                     if($this->addThisToolboxItemToCart($toolbox,$order_id,$subscribers,$number_of_years,$store_id,$user_id)){
                                       $toolbox_counter = $toolbox_counter + 1;
                           
                                    
                                  }
                                }
                       }
                     $msg = "Fresh '$toolbox_counter' folder services requested for while additional '$existing_toolbox_counter' folder is already in the cart waiting payment"; 
                     header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                           "msg"=>$msg
                       ));
                        
                    } else{
                        header('Content-Type: application/json');
                        echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                            "msg" => 'Using this bulk module, you cannot effect or add zero number of folder to a domain. PLEASE USE THE SINGLE FOLDER TO DOMAIN ASSIGNMENT MODULE INTSTEAD'
                          )); 
                        
                    }
                 
                 
             }else{//user does not have an already open order
                               
                if(isset($_POST['resourcegroup'])){
                  
                    if (is_array($_POST['resourcegroup'])) {
                            foreach($_POST['resourcegroup'] as $toolbox){  
                                if($this->isUserAlreadyHasOpenOrder($user_id,$domain_id)){
                                   $order_id = $this->getTheOpenOrderOfThisUser($domain_id,$user_id); 
                                }else{
                                    $order_id = $this->createNewOrderForThisTransaction($domain_id,$toolbox,$user_id);
                                }
                               
                                if($this->isThisItemAlreadyInTheCart($toolbox,$domain_id,$user_id,$order_id)){
                                    $existing_toolbox_counter = $existing_toolbox_counter + 1;
                                    
                                }else{
                                     if($this->addThisToolboxItemToCart($toolbox,$order_id,$subscribers,$number_of_years,$store_id,$user_id)){
                                       $toolbox_counter = $toolbox_counter + 1;
                           
                                    
                                  }
                                }
                      }
                             
                             
                             
                       }else {
                           $toolbox = $_POST['resourcegroup'];
                           if($this->isUserAlreadyHasOpenOrder($user_id,$domain_id)){
                                   $order_id = $this->getTheOpenOrderOfThisUser($domain_id,$user_id); 
                                }else{
                                    $order_id = $this->createNewOrderForThisTransaction($domain_id,$toolbox,$user_id);
                                }
                           if($this->isThisItemAlreadyInTheCart($toolbox,$domain_id,$user_id,$order_id)){
                                    $existing_toolbox_counter = $existing_toolbox_counter + 1;
                                    
                                }else{
                                     if($this->addThisToolboxItemToCart($toolbox,$order_id,$subscribers,$number_of_years,$store_id,$user_id)){
                                       $toolbox_counter = $toolbox_counter + 1;
                           
                                    
                                  }
                                }
                       }
                     $msg = "Fresh '$toolbox_counter' folder services requested for while additional '$existing_toolbox_counter' folder is already in the cart waiting payment"; 
                     header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                           "msg"=>$msg
                       ));
                        
                    }else{
                        header('Content-Type: application/json');
                        echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                            "msg" => 'Using this bulk module, you cannot effect or add zero number of folder to a domain. PLEASE USE THE SINGLE FOLDER TO DOMAIN ASSIGNMENT MODULE INTSTEAD'
                          )); 
                    } 
                 
             }                 
                
                  
                       
            }
            
            
            
            /**
             * This is the function that updates toolboxes services in cart
             */
            public function updateToolboxInformationInCart($toolbox_id,$order_id,$user_id,$subscribers,$number_of_years){
                
                $cmd =Yii::app()->db->createCommand();
                $result = $cmd->update('order_has_toolboxes',
                                  array(
                                    'number_of_users'=>$subscribers,
                                    'number_of_years'=>$number_of_years,
                                    'date_ordered'=>new CDbExpression('NOW()'),
                                    'ordered_by'=>$user_id
            
                            ),
                        ("order_id=$order_id and toolbox_id=$toolbox_id")
			
                        );
               if($result>0){
                   return true;
               }else{
                   return false;
               }
                
            }
            
            
            
            /**
             * This is the function that will retrieve a users items in cart 
             */
            public function actiongetAUserCartDetailInformation(){
                
           // $store_id  = $_REQUEST['store_id'];

            $userid = Yii::app()->user->id;
            
            //get the logged in user domain
            $domain_id = $this->determineAUserDomainIdGiven($userid);
            
            //retrieve the this user's order that is open
            $order_id = $this->getTheOpenOrderOfThisUser($domain_id,$userid);
                           
                //get the order status
                $order_status = $this->getTheOrderStatus($order_id);
                //get the order beneficiary
                $order_beneficiary = $this->determineDomainNameGivenItId($domain_id);
                //get the total toolboxes in this order
                $order_toolboxes = $this->getTheTotalNumberOfToolboxesInThisOrder($order_id);
                
                //get the total number of tools in all this toolboxes
                $order_tools = $this->getTotalNumberOfToolsInToolboxes($order_id);
                //get the total number of tasks in the toolboxes
                $order_task = $this->getTotalNumberOfTasksInToolboxes($order_id);
                //get the total number of users subscribed to these toolboxes in this order
                $order_users =$this->getTheTotalNumberOfConsumingUsers($order_id);
                
                //get the user that initiated the order
                $order_initiator = $this->getTheInitiatorOfThisOrder($order_id);
                
                //get the gross amount for this order
                $order_gross = $this->getTheGrossAmountForThisOrder($order_id);
                
                //get the applicable discount for this order
                $order_discount = $this->getTheApplicableDiscountForThisOrder($order_id,$domain_id);
                
                //get the net payment for this order
                $order_net = $order_gross - $order_discount;
                
                //get the order number
                $order_number = $this->getTheOrderNumber($order_id);
                
                //get the currency code of this store
                
               // $currency_code = $this->getTheRelevantCurrencyCodeForThisStore($store_id);
                
                //get all the toolboxes in this order
                //$order_items = $this->getAllThisOrderItems($order_id);
            
                //retreive all the toolboxes in this order
                    $criteria = new CDbCriteria();
                    $criteria->select = '*';
                    $criteria->condition='order_id=:id';
                    $criteria->params = array(':id'=>$order_id);
                    $order_items= OrderHasToolboxes::model()->findAll($criteria);
                 
           
                if($order_id===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                }else{
                    header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            "order_status" => $order_status,
                            "order_number" => $order_number,
                            "order_beneficiary" => $order_beneficiary,
                            "order_toolboxes" => $order_toolboxes,
                            "order_tools" => $order_tools,
                            "order_tasks" => $order_task,
                           "order_users" => $order_users,
                           "order_initiator" => $order_initiator,
                           "order_gross_amount" => $order_gross,
                           "order_discount_granted" => $order_discount,
                           "order_net_payment" => $order_net,
                           "items" =>$order_items,
                           "order_id"=>$order_id,
                          // "currency_code"=>$currency_code
                          
                       
                       ));
                    
                }
                
                
            }
            
            /**
             * This is the function that get the total number of items in a user's cart
             */
            public function actiongetTheNumberOfItemsInUserCart(){
                //get the id of the logged in user
                $user_id = Yii::app()->user->id;
                
                //get the open order of this user
                $order_id = $this->getTheUserOpenOrder($user_id);
                //get the total item in this order
                $items = $this->getTheTotalItemInThisOrder($order_id);
                //return to the client
                 echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            "number_in_cart" => $items
                            ));
                
            }
            
          /**
           * This is the function that gets a user's open order
           */  
            public function getTheUserOpenOrder($user_id){
                    $criteria = new CDbCriteria();
                    $criteria->select = '*';
                    $criteria->condition='order_initiated_by=:userid and status="open"';
                    $criteria->params = array(':userid'=>$user_id);
                    $order= Order::model()->find($criteria);
                    
                    return $order['id'];
                
            }
            
            /**
             * This is the function that calculates the total number of items in a cart
             */
            public function getTheTotalItemInThisOrder($order_id){
                
                $cmd =Yii::app()->db->createCommand();
                $cmd->select('COUNT(*)')
                    ->from('order_has_toolboxes')
                    ->where("order_id = $order_id");
                $result = $cmd->queryScalar();
                
                return $result;
                
            }
            
            
            /**
	 * assign a a single new resourcegroup to a group for single assignment process
	 */
	public function actionAssignNewSingleResourcegroupToCategory()
	{
		
             $model = new OrderHasToolboxes;
                
                //get the logged in id of this users;
                $userid = Yii::app()->user->id;
                
                //get the domain id of this users
                $domain_id = $this->determineAUserDomainIdGiven($userid);
                
                if(is_numeric($_POST['toolbox'])){
                    $model->toolbox_id = $_POST['toolbox'];
                }else{
                  //$model->toolbox_id = $_POST['toolbox_id'];  
                }
                $model->number_of_users = $_POST['number_of_users'];
                
                $model->number_of_years = $_POST['number_of_years'];
                
                
                 //get the open order id of this user in this domain
               $model->order_id = $this->getTheOpenOrderOfThisUser($domain_id, $userid);
                
               $min_sub = $this->getTheMinimumSubscriptionNumberRequiredForPrivateToolboxesForThisDomain($domain_id);
                
                               
                if($model->number_of_users < $min_sub){
                    $model->number_of_users = $min_sub;
                }
                
                
                //get this items name
                $toolboxname = $this->getThisToolboxname($model->toolbox_id);
                
                //confirm if the user domain has a store
                if($this->domainHasACountryStore($domain_id)){
                    $model->store_id = $this->getTheCountryStoreOfThisDomain($domain_id);
                }else{
                    $model->store_id = $this->getTheDefaultStoreForThePlatform();
                }
                if(isset($_POST['toolbox'])){
                    if($this->isThisToolboxItemAlreadyInThisCart($model->toolbox_id,$model->order_id)){
                   header('Content-Type: application/json');
                      $msg = "This '$toolboxname' item is already in the cart ";
                       echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                            "msg" => $msg
                            )
                           
                       );
                   
               }else{
                   if($this->addThisToolboxItemToCart($model->toolbox_id,$model->order_id,$model->number_of_users,$model->number_of_years,$model->store_id,$userid)){
                     header('Content-Type: application/json');
                      $msg = "'$toolboxname' item successfully added to the cart";
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            "msg" => $msg
                            )
                           
                       );
                }else{
                    header('Content-Type: application/json');
                    $message = "'$toolboxname' item could not be added to the cart";
                    $this->sendThisMessageToTheProductSupportTeam($message,$model->toolbox_id,$model->order_id,$domain_id);
                    $msg = "There is an issue adding '$toolboxname' item to the cart ";
                       echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                            "msg" => $msg
                            )
                           
                       );
                }
               } 
                    
                }else{
                    header('Content-Type: application/json');
                      $msg = "This is no content in the cart ";
                       echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                            "msg" => $msg
                            )
                           
                       );
                }
               
               
	}
        
        /**
         * This is the function that gets the minimum subscription for private domains for this domain
         */
        public function getTheMinimumSubscriptionNumberRequiredForPrivateToolboxesForThisDomain($domain_id){
            
                     $criteria = new CDbCriteria();
                     $criteria->select = '*';
                     $criteria->condition='domain_id=:id and status="active"';
                     $criteria->params = array(':id'=>$domain_id);
                     $domain= DomainPolicy::model()->find($criteria);
                     
                     return $domain['private_toolbox_min_subscription_no'];
        }
        
        
         /**
	 * assign a resourcegroup to a category for single assignment process
	 */
	public function actionAssignSingleResourcegroupToCategory()
	{
		
             //get the logged in id of this users;
                $userid = Yii::app()->user->id;
                
                //get the domain id of this users
                $domain_id = $this->determineAUserDomainIdGiven($userid);
                
                if(is_numeric($_POST['toolbox'])){
                    $toolbox_id = $_POST['toolbox'];
                }else{
                  $toolbox_id = $_POST['toolbox_id'];  
                }
                $number_of_users = $_POST['number_of_users'];
                
                $number_of_years = $_POST['number_of_years'];
                
                $order_id = $_POST['order_id'];
                
                
                $min_sub = $this->getTheMinimumSubscriptionNumberRequiredForPrivateToolboxesForThisDomain($domain_id);
                
                               
                if($number_of_users < $min_sub){
                    $number_of_users = $min_sub;
                }
                
                
                //get this items name
                $toolboxname = $this->getThisToolboxname($toolbox_id);
                
              
                if($this->modifyThisToolboxItemInCart($toolbox_id,$order_id,$number_of_users,$number_of_years,$userid)){
                     header('Content-Type: application/json');
                      $msg = "'$toolboxname' service information in the cart had been modified";
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            "msg" => $msg
                            )
                           
                       );
                
               }else{
                   header('Content-Type: application/json');
                      $msg = "Could not effect any modification to '$toolboxname' item in the cart";
                       echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                            "msg" => $msg
                            )
                           
                       );
               } 
               
	}
        
        
        /**
	 * Deletes a particular assigned resourcegroup in a category.
	 * If deletion is successful, the browser will be redirected to the 'admin' page.
	 * @param integer $id the ID of the model to be deleted
	 */
	public function actionDeleteOneAssignedResourcegroupToCategory()
	{
            //delete a resourcegroup from subgroup
            $order_id = $_POST['order_id'];
            $toolbox_id = $_POST['toolbox_id'];
            
            $toolboxname = $this->getToolboxname($toolbox_id);
           
            //$model=GroupHasResourcegroup::model()->findByPk($_id);
           $cmd =Yii::app()->db->createCommand();  
           $result = $cmd->delete('order_has_toolboxes', 'order_id=:id and toolbox_id=:groupid', array(':id'=>$order_id, ':groupid'=>$toolbox_id ));
            
           if($result>0){
               header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                           "msg" =>"The '$toolboxname' folder had successfully been removed from the cart",
                       ));
           }else{
               header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                           "msg" =>"Could not remove The '$toolboxname' Folder from the cart",
                       ));
           }
             
	}
        
        
        /**
         * This is the function that extracts all toolboxes in this domain's cart
         */
        public function alreadyAssignedToolboxesInCartToThisDomain($order_id){
            
               $criteria = new CDbCriteria();
               $criteria->select = '*';
               $criteria->condition='order_id=:id';
               $criteria->params = array(':id'=>$order_id);
               $toolboxes= OrderHasToolboxes::model()->findAll($criteria); 
               
               $alltoolboxes = [];
               foreach($toolboxes as $toolbox){
                   $alltoolboxes[] = $toolbox['toolbox_id'];
               }
               
               return $alltoolboxes; 
        }
        
        
         /**
         * This is a function that determines if a user has a particular privilege assigned to him
         */
        public function determineIfAUserHasThisPrivilegeAssigned($userid, $privilegename){
            
             $allprivileges = [];
            //spool all the privileges assigned to a user
                $criteria7 = new CDbCriteria();
                $criteria7->select = 'itemname, userid';
                $criteria7->condition='userid=:userid';
                $criteria7->params = array(':userid'=>$userid);
                $priv= AuthAssignment::model()->find($criteria7);
                
                //retrieve all the children of the role
                
                $criteria = new CDbCriteria();
                $criteria->select = 'child';
                $criteria->condition='parent=:parent';
                $criteria->params = array(':parent'=>$priv['itemname']);
                $allprivs= Authitemchild::model()->findAll($criteria);
                 
                //check to see if this privilege exist for this user
                foreach($allprivs as $pris){
                    if($this->privilegeType($pris['child'])== 0){
                        $allprivileges[] = $pris['child'];
                        
                    }elseif($this->privilegeType($pris['child'])== 1){
                        
                       $allprivileges[] = $this->retrieveAllTaskPrivileges($pris['child']); 
                    }elseif($this->privilegeType($pris['child'])== 2){
                        
                        $allprivileges[] = $this->retrieveAllRolePrivileges($pris['child']);
                    }
                    
                    
                    
                    
                }
               
                
                if(in_array($privilegename, $allprivileges)){
                    
                    return true;
                     
                }else{
                    
                    return false;
                     
                }
      
        }
        
        
          /**
         * This is the function that determines a privilege type
         */
        public function privilegeType($privname){
            
            $criteria7 = new CDbCriteria();
                $criteria7->select = 'name, type';
                $criteria7->condition='name=:name';
                $criteria7->params = array(':name'=>$privname);
                $privs= Authitem::model()->find($criteria7);
                
                return $privs['type'];
                
                
        }
        
        
         /**
         * This is the function that returns all member privileges of a task
         */
        public function retrieveAllTaskPrivileges($task){
            
            $member = [];
            
                $criteria = new CDbCriteria();
                $criteria->select = 'child';
                $criteria->condition='parent=:parent';
                $criteria->params = array(':parent'=>$task);
                $allprivs= Authitemchild::model()->findAll($criteria);
                
                foreach($allprivs as $privs){
                    if($this->privilegeType($privs['child'])== 0){
                         $member[] = $privs['child'];
                        
                    }elseif($this->privilegeType($privs['child'])== 1){
                        
                        $member[] = $this->retrieveAllTaskPrivileges($privs['child']); 
                    }
                   
                    
                }
              return $member;
               
            
        }
        
        /**
         * This is the function that returns all members in a role
         */
        public function retrieveAllRolePrivileges($role){
            
            $member = [];
            
                $criteria = new CDbCriteria();
                $criteria->select = 'child';
                $criteria->condition='parent=:parent';
                $criteria->params = array(':parent'=>$role);
                $allprivs= Authitemchild::model()->findAll($criteria);
                
                foreach($allprivs as $privs){
                    if($this->privilegeType($privs['child'])== 0){
                         $member[] = $privs['child'];
                        
                    }elseif($this->privilegeType($privs['child'])== 1){
                        
                        $member[] = $this->retrieveAllTaskPrivileges($privs['child']); 
                    }elseif($this->privilegeType($privs['child'])== 2){
                        
                        $member[] = $this->retrieveAllRolePrivileges($privs['child']); 
                    }
                   
                    
                }
              return $member;
                
            
        }
        
        /**
         * This is the function that removes a toolbox from an order
         */
        public function removeThisToolboxInCartFromThisDomain($toolbox_id, $order_id){
            
             $cmd =Yii::app()->db->createCommand();  
                $result = $cmd->delete('order_has_toolboxes', 'order_id=:orderid and toolbox_id=:toolboxid', array(':orderid'=>$order_id, ':toolboxid'=>$toolbox_id ));
            
                return $result;
        }
        
        
        /**
         * This is the function that actual price for a toolbox with derived cumulative component pricing
         */
        public function actiongetTheActualToolboxPrice(){
            
            $toolbox_id = $_REQUEST['toolbox_id'];
            
            $toolbox_price = $this->getThisToolboxAmount($toolbox_id);
            
             header('Content-Type: application/json');
                     
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            "price" => $toolbox_price
                            )
                           
                       );
        }
        
        
        /**
         * This is the function that gets the number of items in cart for a user during login from the store
         */
        public function actiongetTheNumberOfItemsInCart(){
            
           // $user_id = $_REQUEST['user_id'];
            
            $user_id = Yii::app()->user->id;
            
            //get the number of items in cart
            $items_in_cart = $this->getTheNumberOfItemsInCartForThisUser($user_id);
            
            header('Content-Type: application/json');
                     
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            "items_in_cart" => $items_in_cart
                            )
                           
                       );
            
        }
        
        
        /**
         * This is the function that retrieves the number of items in cart for a user
         */
        public function getTheNumberOfItemsInCartForThisUser($user_id){
            
           $cmd =Yii::app()->db->createCommand();
                $cmd->select('COUNT(*)')
                    ->from('order_has_toolboxes')
                    ->where("ordered_by = $user_id");
                $result = $cmd->queryScalar();
                
                return $result;
        }
        
        
        
        /**
         * This is the function that confirms if there is already an existing box in the request list/cart
         */
        public function actionConfirmIfBoxAndFolderIsAlreadyInTheRequestList(){
            
            $box_id = $_POST['box_id'];
            
            $user_id = Yii::app()->user->id;
            
            $request_id = $this->getTheUserOpenOrder($user_id);
            
            //confirm if this box id is in the request list/cart
            if($this->isThisBoxAlreadyInTheRequestList($box_id,$request_id)){
                
                header('Content-Type: application/json');
                     
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            "is_exist" => true
                            )
                           
                       );
            }else{
                header('Content-Type: application/json');
                     
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            "is_exist" => false
                            )
                           
                       );
            }
            
        }
        
        
        /**
         * This is the function that determines if this box and folder is in the request list
         */
        public function isThisBoxAlreadyInTheRequestList($box_id,$request_id){
            
             $cmd =Yii::app()->db->createCommand();
                $cmd->select('COUNT(*)')
                    ->from('order_has_toolboxes')
                    ->where("toolbox_id = $box_id and order_id=$request_id");
                $result = $cmd->queryScalar();
                
                if($result>0){
                    return true;
                }else{
                    return false;
                }
        }
        
        
        /**
         * This is the function that adds a batch or file to an existing box in the request list
         */
        public function actionAddThisBatchOrFileToExistingBoxInTheRequestList(){
            
             $subscribers = $_POST['number_of_subscribers'];
             $period = $_POST['number_of_years'];
             $batch_id = $_POST['id'];
             $box_id = $_POST['box_id'];
             $user_id = Yii::app()->user->id;
             $domain_id = $this->determineAUserDomainIdGiven($user_id);
             
             $batch_name = $this->getThisBatchName($batch_id);
             $box_name = $this->getTheBoxName($box_id);
             $request_id = $this->getTheUserOpenOrder($user_id);
             
             
             //confirm if this box already exist in the request list
             if($this->isThisBoxAlreadyInTheRequestList($box_id,$request_id)){
               if($this->isAdditionOfThisBatchToThisBoxASuccess($batch_id,$box_id,$subscribers,$period,$domain_id)){
                   header('Content-Type: application/json');
                     
                        echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            "msg" => "'$batch_name' batch is successfully included to the '$box_name' box in the request list"
                            )
                           
                       );
               }else{
                   
                    header('Content-Type: application/json');
                     
                        echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                            "msg" => "Error adding '$batch_name' batch to '$box_name' box in the request list"
                            )
                           
                       );
               }
             }else{
                 if($this->isTheAdditionOfThisBoxToTheRequestListASuccess($batch_id,$box_id,$subscribers,$period,$domain_id)){
                      header('Content-Type: application/json');
                     
                        echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            "msg" => "'$batch_name' batch is successfully included to the '$box_name' box in the request list"
                            )
                           
                       );
                     
                 }else{
                      header('Content-Type: application/json');
                     
                        echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                            "msg" => "Error adding '$batch_name' batch to '$box_name' box in the request list"
                            )
                           
                       );
                 }
             }
             
            
            
        }
        
        
        /**
         * This is the function that adds a batch to a request list with no existing box of folder in it
         */
        public function actionAddThisBatchOrFileToNewBoxInTheRequestList(){
            
            $subscribers = $_POST['number_of_subscribers'];
             $period = $_POST['number_of_years'];
             $batch_id = $_POST['id'];
             $box_id = $_POST['box_id'];
             $user_id = Yii::app()->user->id;
             $domain_id = $this->determineAUserDomainIdGiven($user_id);
             
             $batch_name = $this->getThisBatchName($batch_id);
             $box_name = $this->getTheBoxName($box_id);
             $request_id = $this->getTheUserOpenOrder($user_id);
             
             //confirm if this box already exist in the request list
             if($this->isThisBoxAlreadyInTheRequestList($box_id,$request_id)){
               if($this->isAdditionOfThisBatchToThisBoxASuccess($batch_id,$box_id,$subscribers,$period,$domain_id)){
                   header('Content-Type: application/json');
                     
                        echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            "msg" => "'$batch_name' batch is successfully included to the '$box_name' box in the request list"
                            )
                           
                       );
               }else{
                   
                    header('Content-Type: application/json');
                     
                        echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                            "msg" => "Error adding '$batch_name' batch to '$box_name' box in the request list"
                            )
                           
                       );
               }
             }else{
                 if($this->isTheAdditionOfThisBoxToTheRequestListASuccess($batch_id,$box_id,$subscribers,$period,$domain_id)){
                      header('Content-Type: application/json');
                     
                        echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            "msg" => "'$batch_name' batch is successfully included to the '$box_name' box in the request list"
                            )
                           
                       );
                     
                 }else{
                      header('Content-Type: application/json');
                     
                        echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                            "msg" => "Error adding '$batch_name' batch to '$box_name' box in the request list"
                            )
                           
                       );
                 }
             }
            
        }
        
        /**
         * This is the function that gets a batch name
         */
        public function getThisBatchName($id){
            
               $criteria = new CDbCriteria();
               $criteria->select = '*';
               $criteria->condition='id=:id';
               $criteria->params = array(':id'=>$id);
               $name= Resources::model()->find($criteria); 
            
               return $name['name'];
        }
        
        
        /**
         * This is the function that gets a box name
         */
        public function getTheBoxName($id){
            
               $criteria = new CDbCriteria();
               $criteria->select = '*';
               $criteria->condition='id=:id';
               $criteria->params = array(':id'=>$id);
               $name= Resourcegroup::model()->find($criteria); 
            
               return $name['name'];
        }
        
        
        /**
         * This is the function that deterines if the addtion of a batch to a box in the request list is a success
         */
        public function isAdditionOfThisBatchToThisBoxASuccess($batch_id,$box_id,$subscribers,$period,$domain_id){
          
            if($this->isThisBatchAlreadyIncludedForThisDomain($batch_id,$box_id,$domain_id)){
               return false;
            }else{
                if($this->isAdditionOfThisBatchSuccessful($batch_id,$box_id,$subscribers,$period,$domain_id)){
                      return true;
                }else{
                    return false;
                }       
            }
        }
        
        /**
         * This is the function that determines if a batch is already assigned to a domain
         */
        public function isThisBatchAlreadyIncludedForThisDomain($batch_id,$box_id,$domain_id){
            
           if($this->isBatchInBox($batch_id,$box_id)){
             $cmd =Yii::app()->db->createCommand();
                $cmd->select('COUNT(*)')
                    ->from('domain_has_document')
                    ->where("domain_id = $domain_id and batch_id = $batch_id ");
                $result = $cmd->queryScalar();
                
                if($result>0){
                    return true;
                }else{
                    return false;
                }
               
           }else{
              return false; 
           }
            
        }
        
        
       /**
        * This is the function that gets all documents in a batch
        */ 
        public function getAllDocumentsInThisBatch($batch_id){
            
               $criteria = new CDbCriteria();
               $criteria->select = '*';
               $criteria->condition='parent_id=:id';
               $criteria->params = array(':id'=>$batch_id);
               $documents= Resources::model()->findAll($criteria); 
               
               $all_document_ids = [];
               foreach($documents as $doc){
                   $all_document_ids[]= $doc['id'];
               }
               return $all_document_ids;
            
        }
        
       /**
        * This is the function that determines if the addition of a batch to a domain is successful
        */
        public function isAdditionOfThisBatchSuccessful($batch_id,$box_id,$subscribers,$period,$domain_id){
            
           //get all the documents in this batch
            $documents = $this->getAllDocumentsInThisBatch($batch_id);
            $counter = 0;
            foreach($documents as $document){
                if($this->isDocumentNotAlreadyWithThisDomain($document,$domain_id)){
                  if($this->isDocumentSuccessfullyAddedToThisDomain($document,$domain_id,$batch_id,$box_id,$subscribers,$period)){
                    $counter = $counter + 1;
                 }
                }
                
            }
            if($counter >0){
                return true;
            }else{
                return false;
            }
        }
        
        
        /**
         * This is the function that determines if the inclusion of a document to a domain is a success
         */
        public function isDocumentSuccessfullyAddedToThisDomain($document_id,$domain_id,$batch_id,$box_id,$subscribers,$period){
            
            $cmd =Yii::app()->db->createCommand();
            $result = $cmd->insert('domain_has_document',
                          array(
                              'domain_id'=>$domain_id,
                              'document_id'=>$document_id, 
                              'batch_id'=>$batch_id,
                              'box_id'=>$box_id, 
                              'no_of_subscribers'=>$subscribers, 
                              'period'=>$period,     
                              'date_requested'=>new CDbExpression('NOW()'),
                              'requested_by'=>Yii::app()->user->id
            
                            )
			
                        );
            if($result>0){
                return true;
            }else{
                return false;
            }
        }
        
        
        /**
         * This is the function that verifies if a document is already with a domain
         */
        public function isDocumentNotAlreadyWithThisDomain($document_id,$domain_id){
            
            $cmd =Yii::app()->db->createCommand();
                $cmd->select('COUNT(*)')
                    ->from('domain_has_document')
                    ->where("domain_id = $domain_id and document_id = $document_id ");
                $result = $cmd->queryScalar();
            
                if($result>0){
                    return false;
                }else{
                    return true;
                }
        }
        
        
        
        
        /**
         * This is the function that determines if batch is actually in box
         */
        public function isBatchInBox($batch_id,$box_id){
         
             $cmd =Yii::app()->db->createCommand();
             $cmd->select('COUNT(*)')
                    ->from('resource_has_resourcegroups')
                    ->where("resource_id = $batch_id and resourcegroup_id = $box_id ");
                $result = $cmd->queryScalar();
                
                if($result>0){
                    return true;
                }else{
                    return false;
                }
        }
        
        
        
         /**
         * This is the function that determines if the addition of a box to the request list is a success
         */
        public function isTheAdditionOfThisBoxToTheRequestListASuccess($batch_id,$box_id,$subscribers,$period,$domain_id){
            
            $user_id = Yii::app()->user->id;
            $request_id = $this->getTheUserOpenOrder($user_id);
            if($this->isThisBoxAlreadyInTheRequestList($box_id,$request_id)){
                return false;
            }else{
               //confirm if there is an open order from this domain
                if($this->isUserWithOpenRequestOrOrder($domain_id,$user_id)){
                   //get the open request or order number
                    //$request_id = getTheUserOpenOrder($user_id);
                    if($this->isBookingThisRequestToTheRequestListASuccess($box_id,$request_id,$subscribers,$period,$domain_id)){
                        if($this->isIncludeThisBoxForThisDomainASuccess($domain_id,$box_id,$subscribers,$period,$request_id)){
                            return true;
                        }else{
                            return false;
                        }
                    }else{
                        return false;
                    }
                }else{
                   //create a new order/request
                    if($this->isNewRequestMadeByDomainSuccessful($domain_id,$user_id,$box_id)){
                       //get the new request id 
                    // $request_id = $this->getTheUserOpenOrder($user_id);
                      if($this->isBookingThisRequestToTheRequestListASuccess($box_id,$request_id,$subscribers,$period,$domain_id)){
                            if($this->isIncludeThisBoxForThisDomainASuccess($domain_id,$box_id,$subscribers,$period,$request_id)){
                                return true;
                            }else{
                            return false;
                            }
                         }else{
                            return false;
                         }
                    }else{
                        return false;
                    }
                }
                
                
            }
            
            
        }
        
        
        /**
         * This is the function that deterines if the new request made is successful
         */
        public function isNewRequestMadeByDomainSuccessful($domain_id,$user_id,$box_id){
            //generate an order/request number number
            
            $request_number = $this->generateTheNeededOrderNumber($box_id, $domain_id);
            
            $cmd =Yii::app()->db->createCommand();
            $result = $cmd->insert('order',
                          array(
                              'order_number'=>$request_number, 
                              'status'=>'open', 
                              'order_domain_id'=>$domain_id, 
                              'order_initiation_date'=>new CDbExpression('NOW()'),
                              'order_initiated_by'=>Yii::app()->user->id
            
                            )
			
                        );
            
            if($result>0){
                return true;
            }else{
                return false;
            }
            
        }
        
        
        
        /**
         * This is the function that confirms if there is an open request/order for this user
         */
        public function isUserWithOpenRequestOrOrder($domain_id,$user_id){
            
            $cmd =Yii::app()->db->createCommand();
                $cmd->select('COUNT(*)')
                    ->from('order')
                    ->where("order_initiated_by = $user_id and status = 'open'");
                $result = $cmd->queryScalar();
            
                if($result>0){
                    return false;
                }else{
                    return true;
                }
        }
        
        /**
         * This is the function that confirms if assigning request to request list for a domain is successful
         */
        public function isBookingThisRequestToTheRequestListASuccess($box_id,$request_id,$subscribers,$period,$domain_id){
          if($this->isThisBoxAlreadyInTheRequestList($box_id,$request_id)){
              return false;
          }else{
            $store_id = $this->getTheDefaultStoreForThePlatform(); 
            $cmd =Yii::app()->db->createCommand();
            $result = $cmd->insert('order_has_toolboxes',
                          array(
                             'order_id'=>$request_id,
                             'toolbox_id'=>$box_id, 
                             'number_of_users'=>$subscribers, 
                              'number_of_years'=>$period, 
                              'store_id'=>$store_id,
                              'date_ordered'=>new CDbExpression('NOW()'),
                              'ordered_by'=>Yii::app()->user->id
            
                            )
			
                        );
            if($result>0){
                return true;
            }else{
                return false;
            }
          }  
           
            
        }
        
        
        
        /**
         * This is the function that includes a box/folder and its entire content for a domain
         */
        public function isIncludeThisBoxForThisDomainASuccess($domain_id,$box_id,$subscribers,$period,$request_id){
            if($this->isThisBoxAlreadyInTheRequestList($box_id,$request_id)){
                //get all the batches in this box
                $batches = $this->getAllBatchesInThisBox($box_id);
                
                $counter = 0;
                foreach($batches as $batch){
                    //get all the documents in each batch
                    if($this->isAdditionOfThisBatchToThisBoxASuccess($batch,$box_id,$subscribers,$period,$domain_id)){
                        $counter = $counter + 1;
                    }
                }
                if($counter>0){
                    return true;
                }else{
                    return false;
                }
                
            }else{
                return false;
            }
            
        }
        
        
        
        /**
         * This is the function that gets all batches/folder in a box
         */
        public function getAllBatchesInThisBox($id){
            
               $criteria = new CDbCriteria();
               $criteria->select = '*';
               $criteria->condition='resourcegroup_id=:id';
               $criteria->params = array(':id'=>$id);
               $batches= ResourceHasResourcegroups::model()->findAll($criteria); 
               
               $all_batch_ids = [];
               foreach($batches as $batch){
                   $all_batch_ids[]= $batch['resource_id'];
               }
               return $all_batch_ids;
        }
        
        
        /**
         * This is the function that removes a batch from a box or folder in a request list
         */
        public function actionRemoveThisBatchOrFileFromAnExistingBoxInTheRequestList(){
            
             $batch_id = $_POST['batch_id'];
             $box_id = $_POST['box_id'];
             $user_id = Yii::app()->user->id;
             $request_id = $this->getTheUserOpenOrder($user_id);
             
             $domain_id = $this->determineAUserDomainIdGiven($user_id);
             $batch_name = $this->getThisBatchName($batch_id);
             $box_name = $this->getTheBoxName($box_id);
             
             //confirm if this box already in the request list
             if($this->isThisBoxAlreadyInTheRequestList($box_id,$request_id)){
                 if($this->isThisBatchAlreadyIncludedForThisDomain($batch_id,$box_id,$domain_id)){
                     if($this->isRemovingThisBatchFromTheDomainRequestListASuccess($batch_id,$box_id,$domain_id)){
                         if($this->isBoxInTheRequestListEmpty($box_id,$request_id,$domain_id,$batch_id)){
                             if($this->isRemoveEmptyBoxFromRequestlistSuccessful($box_id,$request_id)){
                                 header('Content-Type: application/json');
                     
                                     echo CJSON::encode(array(
                                        "success" => mysql_errno() == 0,
                                        "msg" => "'$batch_name' batch and '$box_name' box/folder is successfully removed from the request list"
                                    )
                           
                       );
                             }
                         }
                         header('Content-Type: application/json');
                     
                        echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            "msg" => "'$batch_name' batch is successfully removed from the request list"
                            )
                           
                       );
                     }else{
                         header('Content-Type: application/json');
                     
                        echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                            "msg" => "Error removing '$batch_name' batch from the request list"
                            )
                           
                       );
                     }
                 }else{
                     header('Content-Type: application/json');
                     
                        echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                            "msg" => "Removal error: '$batch_name' batch/file is not found in the request list"
                            )
                           
                       );
                     
                 }
             }else{
                  header('Content-Type: application/json');
                     
                        echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                            "msg" => "Removal error: '$box_name' box/folder is not found in the request list"
                            )
                           
                       );
             }
            
        }
        
        
        
        /**
         * This is the function that determines if the request list is empty for this domain
         */
        public function isBoxInTheRequestListEmpty($box_id,$request_id,$domain_id,$batch_id){
            
            if($this->isThisBoxAlreadyInTheRequestList($box_id,$request_id)){
                if($this->isBoxEmpty($box_id,$batch_id,$domain_id)){
                    return true;
                }else{
                    return false;
                }
                
            }else{
                return true;
            }
            
            
        }
        
        
        
        /**
         * This is the function that confirms if box/folder in the request list is empty
         */
        public function isBoxEmpty($box_id,$batch_id,$domain_id){
            
             $cmd =Yii::app()->db->createCommand();
                $cmd->select('COUNT(*)')
                    ->from('domain_has_document')
                    ->where("(domain_id = $domain_id and batch_id = $batch_id) and (box_id = $box_id and is_approved=0)");
                $result = $cmd->queryScalar();
            
                if($result==0){
                    return true;
                }else{
                    return false;
                }
            
        }
        
        
        
        /**
         * This is the function that removes empty box/folder from the request list
         */
        public function isRemoveEmptyBoxFromRequestlistSuccessful($box_id,$request_id){
             if($this->isThisBoxAlreadyInTheRequestList($box_id,$request_id)){
                 $cmd =Yii::app()->db->createCommand();  
                    $result = $cmd->delete('order_has_toolboxes', "order_id=:requestid and toolbox_id=:boxid", array(':requestid'=>$request_id,':boxid'=>$box_id));
           
                    if($result>0){
                        return true;
                    }else{
                        return false;
                    }   
                 
             }else{
                 return true;
             }
            
        }
        
        /**
         * This is the function that removes a batch from a domain in the request 
         */
        public function isRemovingThisBatchFromTheDomainRequestListASuccess($batch_id,$box_id,$domain_id){
            
            if($this->isThisBatchAlreadyIncludedForThisDomain($batch_id,$box_id,$domain_id)){
                if($this->isBatchSuccessfullyRemovedFromDomainInTheRequestList($batch_id,$domain_id)){
                    return true;
                }else{
                    return false;
                }
                
            }else{
                return false;
            }
        }
        
        
        /**
         * This is the function that actually removes a batch from a domain
         */
        public function isBatchSuccessfullyRemovedFromDomainInTheRequestList($batch_id,$domain_id){
            
           $cmd =Yii::app()->db->createCommand();  
           $result = $cmd->delete('domain_has_document', "domain_id=:domainid and batch_id=:batchid", array(':domainid'=>$domain_id,':batchid'=>$batch_id));
           
        if($result>0){
               return true;
           }else{
               return false;
           }    
        }
       
       
	/**
	 * Performs the AJAX validation.
	 * @param Order $model the model to be validated
	 */
	protected function performAjaxValidation($model)
	{
		if(isset($_POST['ajax']) && $_POST['ajax']==='order-form')
		{
			echo CActiveForm::validate($model);
			Yii::app()->end();
		}
	}
        
        
         /**
      * This is the function that modifies virtual box request in the request list
      */
     public function actionModifyRequestForThisVirtualBox(){
         
         $id = $_POST['virtual_id'];
          $model=VirtualBoxRequest::model()->findByPk($id);
          
         if($_POST['virtual_id'] != "" || $_POST['virtual_id'] != 0){
             $user_id = Yii::app()->user->id;
            $domain_id =  $this->getTheDomainIdOfThisUser($user_id);
            $model->virtual_box_id = $_POST['virtual_box_id'];
            $model->virtual_maximum_requesting_period_in_days = $_POST['virtual_maximum_requesting_period_in_days']; 
            $model->virtual_requesting_domain_id = $domain_id;
            $model->status = strtolower($_POST['status']);
           $model->virtual_requesting_user_id = $user_id;
           if(isset($_POST['virtual_group'])){
               $model->virtual_requesting_group_id = $_POST['virtual_group'];
               $model->virtual_is_group_request = 1;
               $model->virtual_is_subgroup_request = 0;
               $model->virtual_is_single_user_request = 0;
           }else if(isset($_POST['virtual_subgroup'])){
               $model->virtual_requesting_subgroup_id = $_POST['virtual_subgroup'];
               $model->virtual_is_group_request = 0;
               $model->virtual_is_subgroup_request = 1;
               $model->virtual_is_single_user_request = 0;
           }else{
               $model->virtual_is_group_request = 0;
               $model->virtual_is_subgroup_request = 0;
               $model->virtual_is_single_user_request = 1;
           }
           $model->virtual_request_initiation_date = new CDbExpression('NOW()');
           $model->virtual_request_initiated_by = Yii::app()->user->id;
           $model->virtual_is_request_initiated = 1;
           if(isset($_POST['virtual_is_electronic_instrument_request_included'])){
                    $model->virtual_is_electronic_instrument_request_included = $_POST['virtual_is_electronic_instrument_request_included'];
                }else{
                    $model->virtual_is_electronic_instrument_request_included = 0;
                }
           
           $box_name = $this->getTheBoxName($model->virtual_box_id);
           
           $number_of_users =1;
           
           $order_id = $this->getTheOpenOrderOfThisUser($domain_id, $user_id);

           if($this->isThisRequestInConformityWithPolicy($domain_id)){
                  //modify this request for this batch
                    if($model->save()){
                        if($order_id > 0){
                         if($this->isModificationOnTheCartSuccessful($model->virtual_box_id,$order_id,$number_of_users,$model->virtual_maximum_requesting_period_in_days,$user_id)){
                           header('Content-Type: application/json');
                            echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            "msg" => "The request for virtual '$box_name' box & folder  is successfully modified on both virtual request list and on the cart folder"
                        ));
                     }else{
                       header('Content-Type: application/json');
                            echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            "msg" => "Request for the virtual '$box_name' box & folder was modified on the virtual request list but not the cart folder. Please contact the support team for assistance"
                        ));
                        
                            
                        }
                            
                        }else{
                          header('Content-Type: application/json');
                            echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            "msg" => "Request for the virtual '$box_name' box & folder was modified on the virtual request list but there is no open order in the cart folder to modify.This is strange. Contact the Platform Administrator"
                            ));
                        
                        }
                        
                      
                    }else{
                         header('Content-Type: application/json');
                            echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            "msg" => "Request for the virtual '$box_name' box & folder could not be modified. Probably a validation error"
                        ));
                        
                    }
                    
               
               
            }else{
                header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                            "msg" => "Your domain policy bars you from requesting for the modification of  virtual '$box_name' box & folder. Please contact your domain administrator"
                        ));
            }
         
             
         }else{
              $box_name = $this->getTheBoxName($_POST['virtual_box_id']);
               header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                            "msg" => "You do not have an open request of virtual '$box_name' border & folder."
                        ));
         } 
          
         
     }
     
     /**
      * This is the function that confirms if the items on the cart request list is modified
      */
     public function isModificationOnTheCartSuccessful($virtual_box_id,$order_id,$number_of_users,$number_of_years,$user_id){
         if($this->modifyThisToolboxItemInCart($virtual_box_id,$order_id,$number_of_users,$number_of_years,$user_id)){
             
            return true; 
         }else{
             return false;
         }
         
     }
}
