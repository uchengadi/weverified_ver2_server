<?php

class InvoiceController extends Controller
{
	/**
	 * @var string the default layout for the views. Defaults to '//layouts/column2', meaning
	 * using two-column layout. See 'protected/views/layouts/column2.php'.
	 */
	public $layout='//layouts/column2';

	/**
	 * @return array action filters
	 */
	public function filters()
	{
		return array(
			'accessControl', // perform access control for CRUD operations
			'postOnly + delete', // we only allow deletion via POST request
		);
	}

	/**
	 * Specifies the access control rules.
	 * This method is used by the 'accessControl' filter.
	 * @return array access control rules
	 */
	public function accessRules()
	{
		return array(
			array('allow',  // allow all users to perform 'index' and 'view' actions
				'actions'=>array('index','view'),
				'users'=>array('*'),
			),
			array('allow', // allow authenticated user to perform 'create' and 'update' actions
				'actions'=>array('create','update','ListAllPendingInvoices','ListAllInvoices'),
				'users'=>array('@'),
			),
			array('allow', // allow admin user to perform 'admin' and 'delete' actions
				'actions'=>array('admin','delete'),
				'users'=>array('admin'),
			),
			array('deny',  // deny all users
				'users'=>array('*'),
			),
		);
	}

	/**
         * This is the function that list all pending invoices
         */
        public function actionListAllPendingInvoices(){
                        
            $model = new Invoice;
            
            //get the prevailing transactions cut off date 
            $cutoff_date = $this->getThePrevailingCutoffDate();
            
             $targets = [];
                
                 $criteria = new CDbCriteria();
                 $criteria->select = '*';
                 $criteria->condition='status=:status';
                 $criteria->params = array(':status'=>"pending");
                 $invoices= Invoice::model()->findAll($criteria);
                 
                 foreach($invoices as $invoice){
                     if($model->isTransactionValidForProcessing($cutoff_date,$invoice['date_initiated'])){
                         $targets[] = $invoice;
                     }
                 }
            
                if($invoices===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            "invoice" => $targets)
                       );
                       
                }
            
           
        }
        
        
        /**
         * This is the function that gets the prevailing cut off date
         */
        public function getThePrevailingCutoffDate(){
            $model = new Settings;
            return $model->getThePrevailingCutoffDate();
        }
        
        
        
        /**
         * This is the function that list all pending invoices
         */
        public function actionListAllInvoices(){
                        
            $model = new Invoice;
           
              
                 $criteria = new CDbCriteria();
                 $criteria->select = '*';
                 $invoices= Invoice::model()->findAll($criteria);
                 
              
                if($invoices===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            "invoice" => $invoices)
                       );
                       
                }
            
           
        }
}
