<?php

class IssuesAndValuesController extends Controller
{
	/**
	 * @var string the default layout for the views. Defaults to '//layouts/column2', meaning
	 * using two-column layout. See 'protected/views/layouts/column2.php'.
	 */
	public $layout='//layouts/column2';

	/**
	 * @return array action filters
	 */
	public function filters()
	{
		return array(
			'accessControl', // perform access control for CRUD operations
			'postOnly + delete', // we only allow deletion via POST request
		);
	}

	/**
	 * Specifies the access control rules.
	 * This method is used by the 'accessControl' filter.
	 * @return array access control rules
	 */
	public function accessRules()
	{
		return array(
			array('allow',  // allow all users to perform 'index' and 'view' actions
				'actions'=>array('index','view'),
				'users'=>array('*'),
			),
			array('allow', // allow authenticated user to perform 'create' and 'update' actions
				'actions'=>array('create','update','addThisNewIssueAndValue','DeleteThisIssueAndValue','updateIssueAndValue',
                                    'retrieveDomainIssuesAndValues'),
				'users'=>array('@'),
			),
			array('allow', // allow admin user to perform 'admin' and 'delete' actions
				'actions'=>array('admin','delete'),
				'users'=>array('admin'),
			),
			array('deny',  // deny all users
				'users'=>array('*'),
			),
		);
	}

        
        /**
         * This is the function that adds new issues and values for a domain
         */
        public function actionaddThisNewIssueAndValue(){
            
            $model=new IssuesAndValues;

		 $user_id = Yii::app()->user->id;
                
                $domain_id = $this->determineAUserDomainId($user_id);
                
                $model->name = $_POST['name'];
                $model->domain_id = $domain_id;
                $model->description = $_POST['description'];
                $model->date_created = new CDbExpression('NOW()');
                if($model->save()){
                         // $result['success'] = 'true';
                          $msg = 'New Issue and Value Created Successfully';
                          header('Content-Type: application/json');
                          echo CJSON::encode(array(
                                    "success" => mysql_errno() == 0,
                                        "msg" => $msg)
                           );
                 }else {
                         //$result['success'] = 'false';
                         $msg = 'Attempt to create this Issue and Value was not successful';
                         header('Content-Type: application/json');
                         echo CJSON::encode(array(
                                    "success" => mysql_errno() != 0,
                                        "msg" => $msg)
                           );
                  } 
            
            
        }
        
        
         /**
         * This is the function that updates issues and values infor for a domain
         */
        public function actionupdateIssueAndValue(){
            
         $user_id = Yii::app()->user->id;
                
          $domain_id = $this->determineAUserDomainId($user_id);
            
            $_id = $_POST['id'];
            $model=  IssuesAndValues::model()->findByPk($_id);
            
            $model->name = $_POST['name'];
            $model->domain_id = $domain_id;
            $model->description = $_POST['description'];
            $model->date_updated = new CDbExpression('NOW()');
            if($model->save()){
                        //$data['success'] = 'true';
                        $msg = 'Update of this information was successful';
                         header('Content-Type: application/json');
                        echo CJSON::encode(array(
                                    "success" => mysql_errno() == 0,
                                        "msg" => $msg)
                           );
                }else {
                    //$data['success'] = 'false';
                    $msg = 'Attempt to update this information was not successful';
                     header('Content-Type: application/json');
                     echo CJSON::encode(array(
                                    "success" => mysql_errno() != 0,
                                        "msg" => $msg)
                           );
                }
            
            
        }
        
        
        /**
         * This is the function that retrieves all issues and values for d domain
         */
        public function actionretrieveDomainIssuesAndValues(){
            
           $user_id = Yii::app()->user->id;            
           $domain_id =  $this->determineAUserDomainId($user_id);
           
           $criteria = new CDbCriteria();
           $criteria->select = '*';
           $criteria->condition='domain_id=:domainid';
           $criteria->params = array(':domainid'=>$domain_id);
           $criteria->order = 'name';
           $values = IssuesAndValues::model()->findAll($criteria);
                 
           if($values===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            "values" => $values
            
                       ));
                       
                }
           
           
            
        }
        
        
         /**
         * This is the function that deletes issues and values for a domain
         */
        public function actionDeleteThisIssueAndValue(){
            
            $_id = $_POST['id'];
            //get the name of this designation
            $value = $this->getThisIssueAndValueName($_id);
            $model=  IssuesAndValues::model()->findByPk($_id);
            if($model === null){
                 $msg = 'No Such Record Exist'; 
                    header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            //"selected" => $selected,
                            "msg" => $msg
                            //"category" =>$category,
                           
                           
                          
                       ));
                                      
            }else if($model->delete()){
                    $msg = "'$value' Issue and Value was Successfully Deleted"; 
                    header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            //"selected" => $selected,
                            "msg" => $msg
                            //"category" =>$category,
                           
                           
                          
                       ));
                       
            } else {
                    $msg = "'$value' Issue and Values was Not Deleted"; 
                    header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                            //"selected" => $selected,
                            "msg" => $msg
                            //"category" =>$category,
                           
                           
                          
                       ));
                            
                }
            
        }
        
        
        
         /**
         * Determine a domain id of a user given his user id 
         */
        public function determineAUserDomainId($userid){
            
            $criteria1 = new CDbCriteria();
            $criteria1->select = '*';
            $criteria1->condition='id=:id';
            $criteria1->params = array(':id'=>$userid);
            $user= User::model()->find($criteria1);
            
            return $user['domain_id'];
        }
	
        
        /**
         * This is the function that gets the name of an issue and value
         */
        public function getThisIssueAndValueName($id){
            
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='id=:id';
            $criteria->params = array(':id'=>$id);
            $value = IssuesAndValues::model()->find($criteria);   
            
            return $value['name'];
        }
}
