<?php

class DeviceTypeController extends Controller
{
	
         private $_id;
         /**
	 * @var string the default layout for the views. Defaults to '//layouts/column2', meaning
	 * using two-column layout. See 'protected/views/layouts/column2.php'.
	 */
	public $layout='//layouts/column2';

	/**
	 * @return array action filters
	 */
	public function filters()
	{
		return array(
			'accessControl', // perform access control for CRUD operations
			'postOnly + delete', // we only allow deletion via POST request
		);
	}

	/**
	 * Specifies the access control rules.
	 * This method is used by the 'accessControl' filter.
	 * @return array access control rules
	 */
	public function accessRules()
	{
		return array(
			array('allow',  // allow all users to perform 'index' and 'view' actions
				'actions'=>array('index','view'. 'listalldevicetypes'),
				'users'=>array('*'),
			),
			array('allow', // allow authenticated user to perform 'create' and 'update' actions
				'actions'=>array('create','update'),
				'users'=>array('@'),
			),
			array('allow', // allow admin user to perform 'admin' and 'delete' actions
				'actions'=>array('listalldevicetypes','deleteonedevicetype'),
				'users'=>array('@'),
			),
			array('deny',  // deny all users
				'users'=>array('*'),
			),
		);
	}

	/**
	 * Displays a particular model.
	 * @param integer $id the ID of the model to be displayed
	 */
	public function actionView($id)
	{
		$this->render('view',array(
			'model'=>$this->loadModel($id),
		));
	}

	/**
	 * Creates a new model.
	 * If creation is successful, the browser will be redirected to the 'view' page.
	 */
	public function actionCreate()
	{
		$model=new DeviceType;

		// Uncomment the following line if AJAX validation is needed
		// $this->performAjaxValidation($model);

                $model->name = $_POST['name'];
                $model->category = $_POST['category'];
                $model->description = $_POST['description'];
                $model->create_time = new CDbExpression('NOW()');
                //$model->create_user_id = Yii::app()->user->id;
                
                if($_FILES['image']['name'] == null) {
                            
                        if($model->save()) {
                        // $result['success'] = 'true';
                         $msg = 'Creation of Device type was successful';
                         header('Content-Type: application/json');
                         echo CJSON::encode(array(
                           "success" => mysql_errno() == 0,
                             "msg" => $msg)
                       );
                         
                     }else {
                         //$result['success'] = 'false';
                         $msg = 'Creation of Device type was  not successful';
                         header('Content-Type: application/json');
                         echo CJSON::encode(array(
                                    "success" => mysql_errno() != 0,
                                        "msg" => $msg)
                           );
                         
                         
                     }
                    
                    
                }else if($_FILES['image']['name'] != null) {
                    
                        if(isset($_FILES)){
                                 $tmpName = $_FILES['image']['tmp_name'];
                                 $fileName = $_FILES['image']['name'];
                                 $type = $_FILES['image']['type'];
                                 $size = $_FILES['image']['size'];
                  
                         }
                        if($fileName !== null) {
                                $iconFileName = time().'_'.$fileName;
                             $model->image = $iconFileName;
                         }
                        //Testing for the file extension and size
                             if($type === 'image/png'|| $type === 'image/jpg' || $type === 'image/jpeg'){
                                      if($size <= 256 * 256){
                                          if($model->save())
                                           {
                                                // upload the file
                                                if($fileName !== null) // validate to save file
                                                 $filepath = Yii::app()->params['icons'].$iconFileName;
                                                 move_uploaded_file($tmpName,  $filepath);
                           
                                              //  $result['success'] = 'true';
                                                 $msg = 'Creation of Device type was successful';
                                                 header('Content-Type: application/json');
                                                echo CJSON::encode(array(
                                                     "success" => mysql_errno() == 0,
                                                     "msg" => $msg)
                                                 );
                                            }else {
                                                 //$result['success'] = 'false';
                                                 $msg = 'Device type creation was not successfull.Check your input data';
                                                 header('Content-Type: application/json');
                                                 echo CJSON::encode(array(
                                                     "success" => mysql_errno() != 0,
                                                     "msg" => $msg)
                                                 );
                                            }
                                     }else {
                                         //$result['success'] = 'false';
                                        $msg = 'Failed. image/Image File is too large. Maximum size allowed is 65.5kb';
                                        header('Content-Type: application/json');
                                       echo CJSON::encode(array(
                                                     "success" => mysql_errno() != 0,
                                                     "msg" => $msg)
                                                 );                   
                                    }
                   
                         }else {
                                 //$result['success'] = 'false';
                                 $msg = 'Failed: Wrong File Type. Only jpeg, jpg or png file is allowed';
                                 header('Content-Type: application/json');
                                 echo CJSON::encode(array(
                                              "success" => mysql_errno() != 0,
                                              "msg" => $msg)
                                    );
                    
                    
                        }
                    
                    
                }//end of the if-else statement
	}

	/**
	 * Updates a particular model.
	 * If update is successful, the browser will be redirected to the 'view' page.
	 * @param integer $id the ID of the model to be updated
	 */
	public function actionUpdate()
	{
            // Uncomment the following line if AJAX validation is needed
		// $this->performAjaxValidation($model);
            
            $_id = $_POST['id'];
            $model=DeviceType::model()->findByPk($_id);
            $model->name = $_POST['name'];
            $model->description = $_POST['description'];
            $model->category = $_POST['category'];
            $model->update_time = new CDbExpression('NOW()');
            //$model->update_user_id = Yii::app()->user->id;
                
                if($_FILES['image']['name'] == null) {
                            
                        if($model->save()) {
                        // $result['success'] = 'true';
                         $msg = 'Update of Device Type Information was successful';
                         header('Content-Type: application/json');
                         echo CJSON::encode(array(
                           "success" => mysql_errno() == 0,
                             "msg" => $msg)
                       );
                         
                     }else {
                         //$result['success'] = 'false';
                         $msg = 'Device Type Information update was unsuccessful';
                         header('Content-Type: application/json');
                         echo CJSON::encode(array(
                                    "success" => mysql_errno() != 0,
                                        "msg" => $msg)
                           );
                         
                         
                     }
                    
                    
                }else if($_FILES['image']['name'] != null) {
                    
                        if(isset($_FILES)){
                                 $tmpName = $_FILES['image']['tmp_name'];
                                 $fileName = $_FILES['image']['name'];
                                 $type = $_FILES['image']['type'];
                                 $size = $_FILES['image']['size'];
                  
                         }
                        if($fileName !== null) {
                                $iconFileName = time().'_'.$fileName;
                             $model->image = $iconFileName;
                         }
                        //Testing for the file extension and size
                             if($type === 'image/png'|| $type === 'image/jpg' || $type === 'image/jpeg'){
                                      if($size <= 256 * 256){
                                          if($model->save())
                                           {
                                                // upload the file
                                                if($fileName !== null) // validate to save file
                                                 $filepath = Yii::app()->params['icons'].$iconFileName;
                                                 move_uploaded_file($tmpName,  $filepath);
                           
                                              //  $result['success'] = 'true';
                                                 $msg = 'Update of Device Type Information was successful';
                                                 header('Content-Type: application/json');
                                                echo CJSON::encode(array(
                                                     "success" => mysql_errno() == 0,
                                                     "msg" => $msg)
                                                 );
                                            }else {
                                                 //$result['success'] = 'false';
                                                 $msg = 'Device Type Information update was not successfull.Check your input data';
                                                 header('Content-Type: application/json');
                                                 echo CJSON::encode(array(
                                                     "success" => mysql_errno() != 0,
                                                     "msg" => $msg)
                                                 );
                                            }
                                     }else {
                                         //$result['success'] = 'false';
                                        $msg = 'Update failed. image/Image File is too large. Maximum size allowed is 65.5kb';
                                        header('Content-Type: application/json');
                                       echo CJSON::encode(array(
                                                     "success" => mysql_errno() != 0,
                                                     "msg" => $msg)
                                                 );                   
                                    }
                   
                         }else {
                                 //$result['success'] = 'false';
                                 $msg = 'Failed: Wrong File Type. Only jpeg, jpg or png file is allowed';
                                 header('Content-Type: application/json');
                                 echo CJSON::encode(array(
                                              "success" => mysql_errno() != 0,
                                              "msg" => $msg)
                                    );
                    
                    
                        }
                    
                    
                }//end of the if-else statement
	}

	/**
	 * Deletes a particular model.
	 * If deletion is successful, the browser will be redirected to the 'admin' page.
	 * @param integer $id the ID of the model to be deleted
	 */
	public function actionDeleteOneDeviceType()
	{
            
            //delete one device type
            $_id = $_POST['id'];
            $model=DeviceType::model()->findByPk($_id);
            if($model === null){
                $data['success'] = 'undefined';
                $data['msg'] = 'No such record exist';
                header('Content-Type: application/json');
                echo CJSON::encode($data);
                                      
            }else if($model->delete()){
                    $data['success'] = 'true';
                    $data['msg'] = 'The data was successfully deleted';
                     header('Content-Type: application/json');
                    echo CJSON::encode($data);
            } else {
                    $data['success'] = 'false';
                    $data['msg'] = 'deletion unsuccessful';
                     header('Content-Type: application/json');
                    echo CJSON::encode($data);
                            
                }
	}

	/**
	 * Lists all models.
	 */
	public function actionIndex()
	{
		$dataProvider=new CActiveDataProvider('DeviceType');
		$this->render('index',array(
			'dataProvider'=>$dataProvider,
		));
	}

	/**
	 * Manages all models.
	 */
	public function actionListAllDeviceTypes()
	{
		$devicetype = DeviceType::model()->findAll();
                if($devicetype===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode($devicetype);
                       
                }
	}

	/**
	 * Returns the data model based on the primary key given in the GET variable.
	 * If the data model is not found, an HTTP exception will be raised.
	 * @param integer $id the ID of the model to be loaded
	 * @return DeviceType the loaded model
	 * @throws CHttpException
	 */
	public function loadModel($id)
	{
		$model=DeviceType::model()->findByPk($id);
		if($model===null)
			throw new CHttpException(404,'The requested page does not exist.');
		return $model;
	}

	/**
	 * Performs the AJAX validation.
	 * @param DeviceType $model the model to be validated
	 */
	protected function performAjaxValidation($model)
	{
		if(isset($_POST['ajax']) && $_POST['ajax']==='device-type-form')
		{
			echo CActiveForm::validate($model);
			Yii::app()->end();
		}
	}
}
