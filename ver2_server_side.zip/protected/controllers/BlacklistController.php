<?php

class BlacklistController extends Controller
{
	/**
	 * @var string the default layout for the views. Defaults to '//layouts/column2', meaning
	 * using two-column layout. See 'protected/views/layouts/column2.php'.
	 */
	public $layout='//layouts/column2';

	/**
	 * @return array action filters
	 */
	public function filters()
	{
		return array(
			'accessControl', // perform access control for CRUD operations
			'postOnly + delete', // we only allow deletion via POST request
		);
	}

	/**
	 * Specifies the access control rules.
	 * This method is used by the 'accessControl' filter.
	 * @return array access control rules
	 */
	public function accessRules()
	{
		return array(
			array('allow',  // allow all users to perform 'index' and 'view' actions
				'actions'=>array('index','view'),
				'users'=>array('*'),
			),
			array('allow', // allow authenticated user to perform 'create' and 'update' actions
				'actions'=>array('create','update','AddNewUserblacklist','AddNewDomainblacklist','UpdateUserblacklist','UpdateDomainblacklist','DeleteOneBlacklist',
                                    'listPlatformBlacklist','listDomainUserBlacklist','listDomainBlacklist'),
				'users'=>array('@'),
			),
			array('allow', // allow admin user to perform 'admin' and 'delete' actions
				'actions'=>array('admin','delete'),
				'users'=>array('admin'),
			),
			array('deny',  // deny all users
				'users'=>array('*'),
			),
		);
	}

	
        
        /**
         * This is the function that creates a new user blacklist
         */
        public function actionAddNewUserblacklist(){
            
            $model = new Blacklist;
            
            $user_id = Yii::app()->user->id;
            
            $domain_id = $this->getTheDomainIdOfThisUser($user_id);
            
            $domain_name = $this->getTheNameOfThisDomain($domain_id);
            
                       
            $model->name = $_POST['name'];
            $model->description = $_POST['description'];
            $model->reason = $_POST['reason'];
            if(isset($_POST['is_conditional'])){
                $model->is_conditional = $_POST['is_conditional'];
            }
            $model->domain_id = $domain_id;
            if(isset($_POST['type'])){
                $model->type = strtolower($_POST['type']);
            }
            $model->date_created = new CDbExpression('NOW()');
            $model->create_user_id = Yii::app()->user->id;
            
           if($model->save()){
               $msg = "Successfully created '$model->name' user blacklist";
               header('Content-Type: application/json');
               echo CJSON::encode(array(
                      "success" => mysql_errno() == 0,
                       "msg" => $msg
                       ));
           }else{
                $msg = "'$model->name' user blacklist could not be created";
               header('Content-Type: application/json');
               echo CJSON::encode(array(
                      "success" => mysql_errno() != 0,
                       "msg" => $msg
                       ));
           } 
            
            
        }
        
        
        
         /**
         * This is the function that creates a new user blacklist
         */
        public function actionAddNewDomainblacklist(){
            
            $model = new Blacklist;
            
            $user_id = Yii::app()->user->id;
            
            $domain_id = $this->getTheDomainIdOfThisUser($user_id);
            
            $domain_name = $this->getTheNameOfThisDomain($domain_id);
            
                       
            $model->name = $_POST['name'];
            $model->description = $_POST['description'];
            $model->reason = $_POST['reason'];
            if(isset($_POST['is_conditional'])){
                $model->is_conditional = $_POST['is_conditional'];
            }else{
                $model->is_conditional = 0;
            }
            $model->domain_id = $domain_id;
            if(isset($_POST['type'])){
                $model->type = strtolower($_POST['type']);
            }
            $model->date_created = new CDbExpression('NOW()');
            $model->create_user_id = Yii::app()->user->id;
            
           if($model->save()){
               $msg = "Successfully created '$model->name' domain blacklist";
               header('Content-Type: application/json');
               echo CJSON::encode(array(
                      "success" => mysql_errno() == 0,
                       "msg" => $msg
                       ));
           }else{
                $msg = "'$model->name' domain blacklist could not be created";
               header('Content-Type: application/json');
               echo CJSON::encode(array(
                      "success" => mysql_errno() != 0,
                       "msg" => $msg
                       ));
           } 
            
            
        }
        
        
        
        /**
         * This is the function that gets the domain id of a user
         */
        public function getTheDomainIdOfThisUser($user_id){
            
             $criteria = new CDbCriteria();
             $criteria->select = '*';
             $criteria->condition='id=:id';
             $criteria->params = array(':id'=>$user_id);
             $domain = User::model()->find($criteria);   
             
             return $domain['domain_id'];
        }
        
        
        /**
         * This  is the function that gets the name of a domain
         */
        public function getTheNameOfThisDomain($domain_id){
            
             $criteria = new CDbCriteria();
             $criteria->select = '*';
             $criteria->condition='id=:id';
             $criteria->params = array(':id'=>$domain_id);
             $domain = Resourcegroupcategory::model()->find($criteria);   
             
             return $domain['name'];
        }
        
        
        /**
         * This is the function that updates a user blacklist information
         */
        public function actionUpdateUserblacklist(){
            
           $_id = $_POST['id'];
           $model= Blacklist::model()->findByPk($_id); 
           
           $user_id = Yii::app()->user->id;
            
            $domain_id = $this->getTheDomainIdOfThisUser($user_id);
            
            $domain_name = $this->getTheNameOfThisDomain($domain_id);
            
                       
            $model->name = $_POST['name'];
            $model->description = $_POST['description'];
            $model->reason = $_POST['reason'];
            if(isset($_POST['is_conditional'])){
                $model->is_conditional = $_POST['is_conditional'];
            }else{
                $model->is_conditional = 0;
            }
            $model->domain_id = $domain_id;
            if(isset($_POST['type'])){
                $model->type = strtolower($_POST['type']);
            }
            $model->date_updated = new CDbExpression('NOW()');
            $model->update_user_id = Yii::app()->user->id;
            
           if($model->save()){
               $msg = "Successfully updated '$model->name' user blacklist";
               header('Content-Type: application/json');
               echo CJSON::encode(array(
                      "success" => mysql_errno() == 0,
                       "msg" => $msg
                       ));
           }else{
                $msg = "'$model->name' user blacklist could not be updated";
               header('Content-Type: application/json');
               echo CJSON::encode(array(
                      "success" => mysql_errno() != 0,
                       "msg" => $msg
                       ));
           } 
           
            
        }
        
        /**
         * This is the function that updates a user blacklist information
         */
        public function actionUpdateDomainblacklist(){
            
           $_id = $_POST['id'];
           $model= Blacklist::model()->findByPk($_id); 
           
           $user_id = Yii::app()->user->id;
            
            $domain_id = $this->getTheDomainIdOfThisUser($user_id);
            
            $domain_name = $this->getTheNameOfThisDomain($domain_id);
            
                       
            $model->name = $_POST['name'];
            $model->description = $_POST['description'];
            $model->reason = $_POST['reason'];
            if(isset($_POST['is_conditional'])){
                $model->is_conditional = $_POST['is_conditional'];
            }else{
                $model->is_conditional = 0;
            }
            $model->domain_id = $domain_id;
            if(isset($_POST['type'])){
                $model->type = strtolower($_POST['type']);
            }
            $model->date_updated = new CDbExpression('NOW()');
            $model->update_user_id = Yii::app()->user->id;
            
           if($model->save()){
               $msg = "Successfully updated '$model->name' domain blacklist";
               header('Content-Type: application/json');
               echo CJSON::encode(array(
                      "success" => mysql_errno() == 0,
                       "msg" => $msg
                       ));
           }else{
                $msg = "'$model->name' domain blacklist could not be updated";
               header('Content-Type: application/json');
               echo CJSON::encode(array(
                      "success" => mysql_errno() != 0,
                       "msg" => $msg
                       ));
           } 
           
            
        }
        
        
        /**
         * This is the function that deletes a user blacklist
         */
        public function actionDeleteOneBlacklist(){
            
            $_id = $_POST['id'];
            //get the name of this location
            $blacklist = $this->getBlacklistName($_id);
            $model= Blacklist::model()->findByPk($_id);
            if($model === null){
                 $msg = 'No Such Record Exist'; 
                    header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            //"selected" => $selected,
                            "msg" => $msg
                            //"category" =>$category,
                           
                           
                          
                       ));
                                      
            }else if($model->delete()){
                    $msg = "'$blacklist' blacklist was successfully deleted"; 
                    header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            //"selected" => $selected,
                            "msg" => $msg
                            //"category" =>$category,
                           
                           
                          
                       ));
                       
            } else {
                    $msg = "'$blacklist' blacklist could not be deleted"; 
                    header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                            //"selected" => $selected,
                            "msg" => $msg
                            //"category" =>$category,
                           
                           
                          
                       ));
                            
                }
            
        }
        
        
        /**
         * This is the function that gets the blacklist name
         */
        public function getBlacklistName($id){
            
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='id=:id';
            $criteria->params = array(':id'=>$id); 
            $name =  Blacklist::model()->find($criteria);
            
            return $name['name'];
            
        }
        
        /**
         * This is the function that list all user blacklists on the platform
         */
        public function actionlistPlatformBlacklist(){
            
            $criteria = new CDbCriteria();
            $criteria->select = '*';
           // $criteria->condition='type!=:type';
            //$criteria->params = array(':type'=>'special_report');
            $blacklists =  Blacklist::model()->findAll($criteria);
                 
            if($blacklists===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            "blacklist" => $blacklists
            
                       ));
                       
                }
            
            
            
        }
        
        /**
         * This is the function that list all user blacklists for a domain
         */
        public function actionlistDomainUserBlacklist(){
            
            $user_id = Yii::app()->user->id;
            
           $domain_id =  $this->getTheDomainIdOfThisUser($user_id);
           
                     
           $criteria = new CDbCriteria();
           $criteria->select = '*';
           $criteria->condition='domain_id=:domainid and type=:type';
           $criteria->params = array(':domainid'=>$domain_id,':type'=>'user');
           $blacklist =  Blacklist::model()->findAll($criteria);
                 
           if($blacklist===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            "blacklist" => $blacklist
            
                       ));
                       
                }
            
            
            
        }
        
        
        /**
         * This is the function that list all user blacklists for a domain
         */
        public function actionlistDomainBlacklist(){
            
            $user_id = Yii::app()->user->id;
            
           $domain_id =  $this->getTheDomainIdOfThisUser($user_id);
           
                     
           $criteria = new CDbCriteria();
           $criteria->select = '*';
           $criteria->condition='domain_id=:domainid and type=:type';
           $criteria->params = array(':domainid'=>$domain_id,':type'=>'domain');
           $blacklist =  Blacklist::model()->findAll($criteria);
                 
           if($blacklist===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            "blacklist" => $blacklist
            
                       ));
                       
                }
            
            
            
        }
        
}
