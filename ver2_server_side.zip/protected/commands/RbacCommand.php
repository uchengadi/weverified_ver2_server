<?php
class RbacCommand extends CConsoleCommand
{
   
    private $_authManager;
 
    
	public function getHelp()
	{
		
		$description = "DESCRIPTION\n";
		$description .= '    '."This command generates an initial RBAC authorization hierarchy.\n";
		return parent::getHelp() . $description;
	}

	
	/**
	 * The default action - create the RBAC structure.
	 */
	public function actionIndex()
	{
		 
		$this->ensureAuthManagerDefined();
		
		//provide the oportunity for the use to abort the r$message = "This command will create 13"
        $message = " This will create operations, task and  roles for the platform.";
		$message .= "Would you like to continue?";
	    
	    //check the input from the user and continue if 
		//they indicated yes to the above question
	    if($this->confirm($message)) 
		{
		     //first we need to remove all operations, 
			 //roles, child relationship and assignments
			 $this->_authManager->clearAll();

			 //create the lowest level operations for groups
			 $this->_authManager->createOperation(
				"createCity",
				"create a new city"); 
			 $this->_authManager->createOperation(
				"readCity",
				"read city information"); 
			 $this->_authManager->createOperation(
				"updateCity",
				"update a city information"); 
			 $this->_authManager->createOperation(
				"deleteCity",
				"remove a city from the system"); 

			 //create the lowest level operations for users
			 $this->_authManager->createOperation(
				"createUser",
				"create a new user"); 
			 $this->_authManager->createOperation(
				"readUser",
				"read user information"); 
	 		 $this->_authManager->createOperation(
				"updateUser",
				"update user information"); 
			 $this->_authManager->createOperation(
				"deleteUser",
				"delete a user from the system"); 

			 //create the lowest level operations for user types
			 $this->_authManager->createOperation(
				"createUsertype",
				"create a new usertype"); 
			 $this->_authManager->createOperation(
				"readUsertype",
				"read usertype information"); 
			 $this->_authManager->createOperation(
				"updateUsertype",
				"update usertype information"); 
			 $this->_authManager->createOperation(
				"deleteUsertype",
				"delete a usertype from the system");   
                         
                         //create the lowest level operations for state
                          $this->_authManager->createOperation(
				"createState",
				"create a new state"); 
			 $this->_authManager->createOperation(
				"readState",
				"read state information"); 
			 $this->_authManager->createOperation(
				"updateState",
				"update state information"); 
			 $this->_authManager->createOperation(
				"deleteState",
				"delete a state from the project");   
                         
                         //create the lowest level operations for country
                          $this->_authManager->createOperation(
				"createCountry",
				"create a new country"); 
			 $this->_authManager->createOperation(
				"readCountry",
				"read country information"); 
			 $this->_authManager->createOperation(
				"updateCountry",
				"update country information"); 
			 $this->_authManager->createOperation(
				"deleteCountry",
				"delete a country from the system");   
                         
                         //create the lowest level operations for grouptype
                          $this->_authManager->createOperation(
				"createGrouptype",
				"create a new grouptype"); 
			 $this->_authManager->createOperation(
				"readGrouptype",
				"read grouptype information"); 
			 $this->_authManager->createOperation(
				"updateGrouptype",
				"update grouptype information"); 
			 $this->_authManager->createOperation(
				"deleteGrouptype",
				"delete a grouptype from the system");   
                         
                         
                         //create the lowest level operations for group
                          $this->_authManager->createOperation(
				"createGroup",
				"create a new group"); 
			 $this->_authManager->createOperation(
				"readGroup",
				"read group information"); 
			 $this->_authManager->createOperation(
				"updateGroup",
				"update group information"); 
			 $this->_authManager->createOperation(
				"deleteGroup",
				"delete a group from the system");   
                                     
                        
                //create the lowest level operations for containers
                          $this->_authManager->createOperation(
				"createContainer",
				"create a new resource type container"); 
			 $this->_authManager->createOperation(
				"readContainer",
				"read container information"); 
			 $this->_authManager->createOperation(
				"updateContainer",
				"update container information"); 
			 $this->_authManager->createOperation(
				"deleteContainer",
				"delete a container from the system");  
                         
                         //create the lowest level operations for Device Type
                          $this->_authManager->createOperation(
				"createDevicetype",
				"create a new devicetype"); 
			 $this->_authManager->createOperation(
				"readDevicetype",
				"read devicetype information"); 
			 $this->_authManager->createOperation(
				"updateDevicetype",
				"update devicetype information"); 
			 $this->_authManager->createOperation(
				"deleteDevicetype",
				"delete a devicetype from the system");   
                         
                         //create the lowest level operations for Device
                          $this->_authManager->createOperation(
				"createDevice",
				"create a new device"); 
			 $this->_authManager->createOperation(
				"readDevice",
				"read device information"); 
			 $this->_authManager->createOperation(
				"updateDevice",
				"update device information"); 
			 $this->_authManager->createOperation(
				"deleteDevice",
				"delete a device from the system"); 
                 
				                        
                //create the lowest level operations for Resource group category
                          $this->_authManager->createOperation(
				"createNewCategoryOrDomain",
				"create a new Toolbox domain  category"); 
			 $this->_authManager->createOperation(
				"readCategoryOrDomain",
				"read resourcegroup category information"); 
			 $this->_authManager->createOperation(
				"updateCategoryOrDomain",
				"update resourcegroup category information"); 
			 $this->_authManager->createOperation(
				"deleteCategoryOrDomain",
				"delete a resourcegroup category from the system");   
                         
                         
                         //create the lowest level operations for Tooltype
                          $this->_authManager->createOperation(
				"createNewTooltype",
				"create a new tooltype"); 
			 $this->_authManager->createOperation(
				"readTooltype",
				"read Tooltype information"); 
			 $this->_authManager->createOperation(
				"updateTooltype",
				"update Tooltype information"); 
			 $this->_authManager->createOperation(
				"deleteTooltype",
				"delete a tooltype from the system");   
                        
                         
                         //create the lowest level operations for Subgroup
                          $this->_authManager->createOperation(
				"createSubgroup",
				"create a new subgroup"); 
			 $this->_authManager->createOperation(
				"readSubgroup",
				"read subgroup information"); 
			 $this->_authManager->createOperation(
				"updateSubgroup",
				"update subgroup information"); 
			 $this->_authManager->createOperation(
				"deleteSubgroup",
				"delete a subgroup from the system"); 
                       
                         
                         
             //create the lowest level operations for Toolbox
             $this->_authManager->createOperation(
				"createNewToolbox",
				"create a new toolbox"); 
			 $this->_authManager->createOperation(
				"readToolbox",
				"read toolbox information"); 
			 $this->_authManager->createOperation(
				"updateToolbox",
				"update Toolbox information"); 
			 $this->_authManager->createOperation(
				"deleteToolbox",
				"delete a Toolbox from the system"); 
                        
                         
                         
              //create the lowest level operations for general Tools & Task
                         $this->_authManager->createOperation(
				"createNewGeneralTool",
				"this is the privilege that enables the creation of general too"); 
			 $this->_authManager->createOperation(
				"createNewGeneralTask",
				"this is the privilege that enables the creation of general task"); 
			 $this->_authManager->createOperation(
				"updateGeneralToolAndTask",
				"this is the privilege that enables the update of general tools and task"); 
			 $this->_authManager->createOperation(
				"deleteGeneralToolAndTask",
				"this is the privilege that enables the removal of a general tool or task");
                         $this->_authManager->createOperation(
				"readGeneralToolAndTask",
				"this is the privilege that enables the ability to read general tools and task"); 
			
			//creates the lowest level operation for accounts & finance tools & task
			$this->_authManager->createOperation(
				"createNewAccountsAndFinanceTask",
				"this is the privilege that enables the creation of accounts & finance task"); 
			 $this->_authManager->createOperation(
				"createNewAccountsAndFinanceTool",
				"this is the privilege that enables the creation of accounts & finance tool"); 
			 $this->_authManager->createOperation(
				"deleteAccountsAndFinanceToolAndTask",
				"this is the privilege that enables the removal of accounts & finance tool and task"); 
                         $this->_authManager->createOperation(
				"updateAccountsAndFinanceToolAndTask",
				"this is the privilege that enables the update of accounts & finance tool and task"); 
			 $this->_authManager->createOperation(
				"readAccountsAndFinanceToolAndTask",
				"this is the privilege that enables the ability to read accounts & finance tools or task"); 
			
				
				//creates the lowest level operation for Operation tools & task
				$this->_authManager->createOperation(
				"createNewOperationsTask",
				"this is the privilege that enables the creation of operations task"); 
			 $this->_authManager->createOperation(
				"createNewOperationsTool",
				"this is the privilege that enables the creation of operations tool"); 
			 $this->_authManager->createOperation(
				"deleteOperationsToolsAndTask",
				"this is the privilege that enables the removal of operations tool and task"); 
                         $this->_authManager->createOperation(
				"updateOperationsToolsAndTask",
				"this is the privilege that enables the update of operations tool and task"); 
			 $this->_authManager->createOperation(
				"readOperationsToolsAndTask",
				"this is the privilege that enables the ability to read operations tools or task"); 
				
				
		    //creates the lowest level operations for Human Resources tools & task
				$this->_authManager->createOperation(
				"createNewHumanResourcesTask",
				"this is the privilege that enables the creation of human resources task"); 
			 $this->_authManager->createOperation(
				"createNewHumanResourcesTool",
				"this is the privilege that enables the creation of human resources tool"); 
			 $this->_authManager->createOperation(
				"deleteHumanResourcesToolAndTask",
				"this is the privilege that enables the removal of human resources tool and task"); 
                         $this->_authManager->createOperation(
				"updateHumanResourcesToolAndTask",
				"this is the privilege that enables the update of human resources tool and task"); 
			 $this->_authManager->createOperation(
				"readHumanResourcesToolAndTask",
				"this is the privilege that enables the ability to read human resources tools or task"); 	


			//creates the lowest level operations for CRM tools & task
				$this->_authManager->createOperation(
				"createNewCrmTask",
				"this is the privilege that enables the creation of crm task"); 
			 $this->_authManager->createOperation(
				"createNewCrmTool",
				"this is the privilege that enables the creation of crm tool"); 
			 $this->_authManager->createOperation(
				"deleteCrmToolAndTask",
				"this is the privilege that enables the removal of crm tool and task"); 
                         $this->_authManager->createOperation(
				"updateCrmToolAndTask",
				"this is the privilege that enables the update of crm tool and task"); 
			 $this->_authManager->createOperation(
				"readCrmToolAndTask",
				"this is the privilege that enables the ability to read crm tools or task"); 	


			//creates the lowest level operations for operating system tools & task
				$this->_authManager->createOperation(
				"createNewOperatingSystemsTask",
				"this is the privilege that enables the creation of operating system task"); 
			 $this->_authManager->createOperation(
				"createNewOperatingSystemsTool",
				"this is the privilege that enables the creation of operating system tool"); 
			 $this->_authManager->createOperation(
				"deleteOperatingSystemToolAndTask",
				"this is the privilege that enables the removal of operating system tool and task"); 
                         $this->_authManager->createOperation(
				"updateOperatingSystemToolAndTask",
				"this is the privilege that enables the update of operating system tool and task"); 
			 $this->_authManager->createOperation(
				"readOperatingSystemToolAndTask",
				"this is the privilege that enables the ability to read operating system tools or task"); 		
				
				
				//creates the lowest level operations for hardware & mobile tools & task
				$this->_authManager->createOperation(
				"createNewHardwareAndMobileTask",
				"this is the privilege that enables the creation of hardware & mobile task"); 
			 $this->_authManager->createOperation(
				"createNewHardwareAndMobileTool",
				"this is the privilege that enables the creation of hardware & mobile tool"); 
			 $this->_authManager->createOperation(
				"deleteHardwareAndMobileToolAndTask",
				"this is the privilege that enables the removal of hardware & mobile tool and task"); 
                         $this->_authManager->createOperation(
				"updateHardwareAndMobileToolAndTask",
				"this is the privilege that enables the update of hardware & mobile tool and task"); 
			 $this->_authManager->createOperation(
				"readHardwareAndMobileToolAndTask",
				"this is the privilege that enables the ability to read hardware & mobile tools or task"); 	
				
				
				//creates the lowest level operations for  networks & Communication tools & task
				$this->_authManager->createOperation(
				"createNewNetworksAndCommsTask",
				"this is the privilege that enables the creation of network & comms task"); 
			 $this->_authManager->createOperation(
				"createNewNetworksAndCommsTool",
				"this is the privilege that enables the creation of network & comms tool"); 
			 $this->_authManager->createOperation(
				"deleteNetworkAndCommToolAndTask",
				"this is the privilege that enables the removal of networks & Comms tool and task"); 
                         $this->_authManager->createOperation(
				"updateNetworkAndCommToolAndTask",
				"this is the privilege that enables the update of network & Comms tool and task"); 
			 $this->_authManager->createOperation(
				"readNetworkAndCommToolAndTask",
				"this is the privilege that enables the ability to read network & comms tools or task"); 


			//creates the lowest level operations for  database tools & task
				$this->_authManager->createOperation(
				"createNewDatabaseTask",
				"this is the privilege that enables the creation of database task"); 
			 $this->_authManager->createOperation(
				"createNewDatabaseTool",
				"this is the privilege that enables the creation of database tool"); 
			 $this->_authManager->createOperation(
				"deleteDatabaseToolAndTask",
				"this is the privilege that enables the removal of database tool and task"); 
                         $this->_authManager->createOperation(
				"updateDatabaseToolAndTask",
				"this is the privilege that enables the update of database tool and task"); 
			 $this->_authManager->createOperation(
				"readDatabaseToolAndTask",
				"this is the privilege that enables the ability to read database tools or task"); 			
				
				
		//creates the lowest level operations for  data cleaning tools & task
				$this->_authManager->createOperation(
				"createNewDataCleaningTask",
				"this is the privilege that enables the creation of data cleaning task"); 
			 $this->_authManager->createOperation(
				"createNewDataCleaningTool",
				"this is the privilege that enables the creation of data cleaning tool"); 
			 $this->_authManager->createOperation(
				"deleteDataCleaningToolAndTask",
				"this is the privilege that enables the removal of data cleaning tool and task"); 
                         $this->_authManager->createOperation(
				"updateDataCleaningToolAndTask",
				"this is the privilege that enables the update of data cleaning tool and task"); 
			 $this->_authManager->createOperation(
				"readDataCleaningToolAndTask",
				"this is the privilege that enables the ability to read data cleaning tools or task"); 			
				
				
				
				//creates the lowest level operations for  data analysis tools & task
				$this->_authManager->createOperation(
				"createNewDataAnalysisTask",
				"this is the privilege that enables the creation of data analysis task"); 
			 $this->_authManager->createOperation(
				"createNewDataAnalysisTool",
				"this is the privilege that enables the creation of data analysis tool"); 
			 $this->_authManager->createOperation(
				"deleteDataAnalysisToolAndTask",
				"this is the privilege that enables the removal of data analysis tool and task"); 
                         $this->_authManager->createOperation(
				"updateDataAnalysisToolAndTask",
				"this is the privilege that enables the update of data analysis tool and task"); 
			 $this->_authManager->createOperation(
				"readDataAnalysisToolAndTask",
				"this is the privilege that enables the ability to read data analysis tools or task"); 	

				
				
				//creates the lowest level operations for  data visualization tools & task
				$this->_authManager->createOperation(
				"createNewDataVisualizationTask",
				"this is the privilege that enables the creation of data visualization task"); 
			 $this->_authManager->createOperation(
				"createNewDataVisualizationTool",
				"this is the privilege that enables the creation of data visualiztion tool"); 
			 $this->_authManager->createOperation(
				"deleteDataVisualizationToolAndTask",
				"this is the privilege that enables the removal of data visualization tool and task"); 
                         $this->_authManager->createOperation(
				"updateDataVisualizationToolAndTask",
				"this is the privilege that enables the update of data visualization tool and task"); 
			 $this->_authManager->createOperation(
				"readDataVisualizationToolAndTask",
				"this is the privilege that enables the ability to read data visualization tools or task"); 

				
				
	
		//creates the lowest level operations for  data acquisition tools & task
				$this->_authManager->createOperation(
				"createNewDataAcquisitionTask",
				"this is the privilege that enables the creation of data acquisition task"); 
			 $this->_authManager->createOperation(
				"createNewDataAcquisitionTool",
				"this is the privilege that enables the creation of data acquisition tool"); 
			 $this->_authManager->createOperation(
				"deleteDataAcquisitionToolAndTask",
				"this is the privilege that enables the removal of data acquisition tool and task"); 
                         $this->_authManager->createOperation(
				"updateDataAcquisitionToolAndTask",
				"this is the privilege that enables the update of data acquisition tool and task"); 
			 $this->_authManager->createOperation(
				"readDataAcquisitionToolAndTask",
				"this is the privilege that enables the ability to read data acquisition tools or task"); 
				
				
				
			//creates the lowest level operations for  processes tools & task
				$this->_authManager->createOperation(
				"createNewProcessesTask",
				"this is the privilege that enables the creation of processes task"); 
			 $this->_authManager->createOperation(
				"createNewProcessesTool",
				"this is the privilege that enables the creation of processes tool"); 
			 $this->_authManager->createOperation(
				"deleteProcessesToolAndTask",
				"this is the privilege that enables the removal of processes tool and task"); 
                         $this->_authManager->createOperation(
				"updateProcessesToolAndTask",
				"this is the privilege that enables the update of processes tool and task"); 
			 $this->_authManager->createOperation(
				"readProcessesToolAndTask",
				"this is the privilege that enables the ability to read processes tools or task"); 	
				
				
				
				//creates the lowest level operations for  equipments & machinery tools & task
				$this->_authManager->createOperation(
				"createNewEquipmentAndMachineryTask",
				"this is the privilege that enables the creation of equipment & machinery task"); 
			 $this->_authManager->createOperation(
				"createNewEquipmentAndMachineryTool",
				"this is the privilege that enables the creation of equipment & machinery tool"); 
			 $this->_authManager->createOperation(
				"deleteEquipmentAndMachineryToolAndTask",
				"this is the privilege that enables the removal of equipments & machinery tool and task"); 
                         $this->_authManager->createOperation(
				"updateEquipmentAndMachineryToolAndTask",
				"this is the privilege that enables the update of equipments & machinery tool and task"); 
			 $this->_authManager->createOperation(
				"readEquipmentAndMachineryToolAndTask",
				"this is the privilege that enables the ability to read equipments & machinery tools or task"); 	
				
				
				
				//creates the lowest level operations for  research tools & task
				$this->_authManager->createOperation(
				"createNewResearchTask",
				"this is the privilege that enables the creation of research task"); 
			 $this->_authManager->createOperation(
				"createNewResearchTool",
				"this is the privilege that enables the creation of research tool"); 
			 $this->_authManager->createOperation(
				"deleteResearchToolAndTask",
				"this is the privilege that enables the removal of research tool and task"); 
                         $this->_authManager->createOperation(
				"updateResearchToolAndTask",
				"this is the privilege that enables the update of research tool and task"); 
			 $this->_authManager->createOperation(
				"readResearchToolAndTask",
				"this is the privilege that enables the ability to read research tools or task"); 	
				
				
				
				//creates the lowest level operations for  production tools & task
				$this->_authManager->createOperation(
				"createProductionTask",
				"this is the privilege that enables the creation of production task"); 
			 $this->_authManager->createOperation(
				"createProductionTool",
				"this is the privilege that enables the creation of production tool"); 
			 $this->_authManager->createOperation(
				"deleteProductionToolAndTask",
				"this is the privilege that enables the removal of production tool and task"); 
                         $this->_authManager->createOperation(
				"updateProductionToolAndTask",
				"this is the privilege that enables the update of production tool and task"); 
			 $this->_authManager->createOperation(
				"readProductionToolAndTask",
				"this is the privilege that enables the ability to read production tools or task"); 

				
		//creates the lowest level operations for  maintenance tools & task
				$this->_authManager->createOperation(
				"createNewMaintenanceTask",
				"this is the privilege that enables the creation of maintenance task"); 
			 $this->_authManager->createOperation(
				"createNewMaintenanceTool",
				"this is the privilege that enables the creation of maintenance tool"); 
			 $this->_authManager->createOperation(
				"deleteMaintenanceToolAndTask",
				"this is the privilege that enables the removal of maintenance tool and task"); 
                         $this->_authManager->createOperation(
				"updateMaintenanceToolOrTask",
				"this is the privilege that enables the update of maintenance tool and task"); 
			 $this->_authManager->createOperation(
				"readMaintenanceToolAndTask",
				"this is the privilege that enables the ability to read maintenance tools or task"); 
				
				
				
				//creates the lowest level operations for  customer relation management tools & task
				$this->_authManager->createOperation(
				"createNewCustomerRelationTask",
				"this is the privilege that enables the creation of customer relation task"); 
			 $this->_authManager->createOperation(
				"createNewCustomerRelationTool",
				"this is the privilege that enables the creation of customer relation tool"); 
			 $this->_authManager->createOperation(
				"deleteCustomerRelationToolAndTask",
				"this is the privilege that enables the removal of customer relation tool and task"); 
                         $this->_authManager->createOperation(
				"updateCustomerRelationToolAndTask",
				"this is the privilege that enables the update of customer relation tool and task"); 
			 $this->_authManager->createOperation(
				"readCustomerRelationToolAndTask",
				"this is the privilege that enables the ability to read customer relation tools or task"); 
				
				
				
				//creates the lowest level operations for  supply chain tools & task
				$this->_authManager->createOperation(
				"createNewSupplyChainTask",
				"this is the privilege that enables the creation of supply chain task"); 
			 $this->_authManager->createOperation(
				"createNewSupplyChainTool",
				"this is the privilege that enables the creation of supply chain tool"); 
			 $this->_authManager->createOperation(
				"deleteSupplyChainToolAndTask",
				"this is the privilege that enables the removal of supply chain tool and task"); 
                         $this->_authManager->createOperation(
				"updateSupplyChainToolAndTask",
				"this is the privilege that enables the update of supply chain tool and task"); 
			 $this->_authManager->createOperation(
				"readSupplyChainToolAndTask",
				"this is the privilege that enables the ability to read supply chain tools or task"); 
				
				
				
				//creates the lowest level operations for  treasury tools & task
				$this->_authManager->createOperation(
				"createNewTreasuryTask",
				"this is the privilege that enables the creation of treasury task"); 
			 $this->_authManager->createOperation(
				"createNewTreasuryTool",
				"this is the privilege that enables the creation of treasury tool"); 
			 $this->_authManager->createOperation(
				"deleteTreasuryToolAndTask",
				"this is the privilege that enables the removal of treasury tool and task"); 
                         $this->_authManager->createOperation(
				"updateTreasuryToolAndTask",
				"this is the privilege that enables the update of treasury tool and task"); 
			 $this->_authManager->createOperation(
				"readTreasuryToolAndTask",
				"this is the privilege that enables the ability to read treasury tools or task");

		

				//creates the lowest level operations for  loan & credit tools & task
				$this->_authManager->createOperation(
				"createNewLoanAndCreditTask",
				"this is the privilege that enables the creation of loan & credit task"); 
			 $this->_authManager->createOperation(
				"createNewLoanAndCreditTool",
				"this is the privilege that enables the creation of loan & credit tool"); 
			 $this->_authManager->createOperation(
				"deleteLoansAndCreditToolAndTask",
				"this is the privilege that enables the removal of loan & credit tool and task"); 
                         $this->_authManager->createOperation(
				"updateLoanAndCreditToolAndTask",
				"this is the privilege that enables the update of loan & credit tool and task"); 
			 $this->_authManager->createOperation(
				"readLoansAndCreditToolAndTask",
				"this is the privilege that enables the ability to read loans & credit tools or task"); 
				
				
				//creates the lowest level operations for  erp tools & task
				$this->_authManager->createOperation(
				"createErpTask",
				"this is the privilege that enables the creation of erp task"); 
			 $this->_authManager->createOperation(
				"createErpTool",
				"this is the privilege that enables the creation of erp tool"); 
			 $this->_authManager->createOperation(
				"deleteErpToolAndTask",
				"this is the privilege that enables the removal of erp tool and task"); 
                         $this->_authManager->createOperation(
				"updateErpToolAndTask",
				"this is the privilege that enables the update of erp tool and task"); 
			 $this->_authManager->createOperation(
				"readErpToolAndTask",
				"this is the privilege that enables the ability to read erp tools or task"); 
		
		
		//creates the lowest level operations for  security tools & task
				$this->_authManager->createOperation(
				"createNewSecurityTask",
				"this is the privilege that enables the creation of security task"); 
			 $this->_authManager->createOperation(
				"createNewSecurityTool",
				"this is the privilege that enables the creation of security tool"); 
			 $this->_authManager->createOperation(
				"deleteSecurityToolAndTask",
				"this is the privilege that enables the removal of security tool and task"); 
                         $this->_authManager->createOperation(
				"updateSecurityToolAndTask",
				"this is the privilege that enables the update of security tool and task"); 
			 $this->_authManager->createOperation(
				"readSecurityToolAndTask",
				"this is the privilege that enables the ability to read security tools or task"); 
				
				
				
		//creates the lowest level operations for  compliance & control tools & task
				$this->_authManager->createOperation(
				"createNewControlAndComplianceTask",
				"this is the privilege that enables the creation of compliance & control task"); 
			 $this->_authManager->createOperation(
				"createNewControlAndComplianceTool",
				"this is the privilege that enables the creation of compliance & control tool"); 
			 $this->_authManager->createOperation(
				"deleteControlAndComplianceToolAndTask",
				"this is the privilege that enables the removal of compliance & control tool and task"); 
                         $this->_authManager->createOperation(
				"updateControlAndComplianceToolAndTask",
				"this is the privilege that enables the update of compliance & control tool and task"); 
			 $this->_authManager->createOperation(
				"readControlAndComplianceToolAndTask",
				"this is the privilege that enables the ability to read compliance & control tools or task"); 		
				
				
			//creates the lowest level operations for  risk assessment tools & task
				$this->_authManager->createOperation(
				"createNewRiskAssessmentTask",
				"this is the privilege that enables the creation of risk assessment task"); 
			 $this->_authManager->createOperation(
				"createNewRiskAssessmentTool",
				"this is the privilege that enables the creation of risk assessment tool"); 
			 $this->_authManager->createOperation(
				"deleteRiskAssessmentToolAndTask",
				"this is the privilege that enables the removal of risk assessment tool and task"); 
                         $this->_authManager->createOperation(
				"updateRiskAssessmentToolAndTask",
				"this is the privilege that enables the update of risk assessment tool and task"); 
			 $this->_authManager->createOperation(
				"readRiskAssessmentToolAndTask",
				"this is the privilege that enables the ability to read risk assessment tools or task"); 		



			//creates the lowest level operations for  automation tools & task
				$this->_authManager->createOperation(
				"createNewAutomationTask",
				"this is the privilege that enables the creation of automation task"); 
			 $this->_authManager->createOperation(
				"createNewAutomationTool",
				"this is the privilege that enables the creation of automation tool"); 
			 $this->_authManager->createOperation(
				"deleteAutomationToolAndTask",
				"this is the privilege that enables the removal of automation tool and task"); 
                         $this->_authManager->createOperation(
				"updateAutomationToolAndTask",
				"this is the privilege that enables the update of automation tool and task"); 
			 $this->_authManager->createOperation(
				"readAutomationToolAndTask",
				"this is the privilege that enables the ability to read automation tools or task"); 	



		//creates the lowest level operations for  investment tools & task
				$this->_authManager->createOperation(
				"createNewInvestmentTask",
				"this is the privilege that enables the creation of investment task"); 
			 $this->_authManager->createOperation(
				"createNewInvestmentTool",
				"this is the privilege that enables the creation of investment tool"); 
			 $this->_authManager->createOperation(
				"deleteInvestmentToolAndTask",
				"this is the privilege that enables the removal of investment tool and task"); 
                         $this->_authManager->createOperation(
				"updateInvestmentToolAndTask",
				"this is the privilege that enables the update of investment tool and task"); 
			 $this->_authManager->createOperation(
				"readInvestmentToolAndTask",
				"this is the privilege that enables the ability to read investment tools or task");      


		//creates the lowest level operations for  user_to_subgroup assignment
			$this->_authManager->createOperation(
				"assignBulkUsersToSubgroup",
				"this is the privilege that enables the bulk assignment of users to subgroup"); 
			 $this->_authManager->createOperation(
				"assignSingleUserToSubgroup",
				"this is the privilege that enables the single assignment of user to subgroup"); 
			 $this->_authManager->createOperation(
				"deleteAssignedUserFromSubgroup",
				"this is the privilege that enables the removal of assigned users from subgroup"); 
                         $this->_authManager->createOperation(
				"updateAssignedUserInSubgroup",
				"this is the privilege that enables the update of assigned user to subgroup information"); 
			 $this->_authManager->createOperation(
				"readAssignedUserSubgroup",
				"this is the privilege that enables the ability to read assigned users in subgroup");     		


			//creates the lowest level operations for  toolboxes_to_Domain assignment
			$this->_authManager->createOperation(
				"assignBulkToolboxesToDomainOrCategory",
				"this is the privilege that enables the bulk assignment of toolboxes to a domain"); 
			 $this->_authManager->createOperation(
				"assignSingleToolboxToDomainOrCategory",
				"this is the privilege that enables the single assignment of toolboxes to a category"); 
			 $this->_authManager->createOperation(
				"deleteAssignedToolboxInDomainOrCategory",
				"this is the privilege that enables the removal of assigned toolboxes from domain"); 
                         $this->_authManager->createOperation(
				"updateAssignedToolboxInDomainOrCategory",
				"this is the privilege that enables the update of assigned toolboxes to domain information"); 
			 $this->_authManager->createOperation(
				"readAssignedToolboxToDomainOrCategory",
				"this is the privilege that enables the ability to read assigned toolboxes in domain");     


			
			//creates the lowest level operations for  tools_to_toolbox assignment
			$this->_authManager->createOperation(
				"assignBulkToolsToToolbox",
				"this is the privilege that enables the bulk assignment of tools to a toolbox"); 
			 $this->_authManager->createOperation(
				"assignSingleToolToToolbox",
				"this is the privilege that enables the single assignment of tool to a toolbox"); 
			 $this->_authManager->createOperation(
				"deleteAssignedToolFromToolbox",
				"this is the privilege that enables the removal of assigned tool from toolbox"); 
                         $this->_authManager->createOperation(
				"updateAssignedToolsInToolbox",
				"this is the privilege that enables the update of assigned tool to toolbox information"); 
			 $this->_authManager->createOperation(
				"readAssignedToolsInToolbox",
				"this is the privilege that enables the ability to read assigned tools in toolbox");    	
				
				
				
				//creates the lowest level operations for  toolbox_to_group assignment
			$this->_authManager->createOperation(
				"assignBulkToolboxesToGroup",
				"this is the privilege that enables the bulk assignment of toolbox to a group"); 
			 $this->_authManager->createOperation(
				"assignSingleToolboxToGroup",
				"this is the privilege that enables the single assignment of toolbox to group"); 
			 $this->_authManager->createOperation(
				"deleteAssignedToolboxFromGroup",
				"this is the privilege that enables the removal of assigned toolbox from a group"); 
                         $this->_authManager->createOperation(
				"updateAssignedToolboxToGroup",
				"this is the privilege that enables the update of assigned toolbox to group information"); 
			 $this->_authManager->createOperation(
				"readAssignedToolboxesToGroup",
				"this is the privilege that enables the ability to read assigned toolbox in group");    
				
				
				
				//creates the lowest level operations for  toolbox_to_subgroup assignment
			$this->_authManager->createOperation(
				"assignBulkToolboxesToSubgroup",
				"this is the privilege that enables the bulk assignment of toolbox to a subgroup"); 
			 $this->_authManager->createOperation(
				"assignSingleToolboxToSubgroup",
				"this is the privilege that enables the single assignment of toolbox to subgroup"); 
			 $this->_authManager->createOperation(
				"deleteAssignedToolboxFromSubgroup",
				"this is the privilege that enables the removal of assigned toolbox from a subgroup"); 
                         $this->_authManager->createOperation(
				"updateAssignedToolboxToSubgroup",
				"this is the privilege that enables the update of assigned toolbox to subgroup information"); 
			 $this->_authManager->createOperation(
				"readAssignedToolboxesToSubgroup",
				"this is the privilege that enables the ability to read assigned toolbox in subgroup");    
				
				
				
				//creates the lowest level operations for  toolbox_to_user assignment
			$this->_authManager->createOperation(
				"assignBulkToolboxesToUser",
				"this is the privilege that enables the bulk assignment of toolbox to a user"); 
			 $this->_authManager->createOperation(
				"assignSingleToolboxToUser",
				"this is the privilege that enables the single assignment of toolbox to user"); 
			 $this->_authManager->createOperation(
				"deleteAssignedToolboxToUser",
				"this is the privilege that enables the removal of assigned toolbox from user"); 
                         $this->_authManager->createOperation(
				"updateAssignedToolboxToUser",
				"this is the privilege that enables the update of assigned toolbox to user information"); 
			 $this->_authManager->createOperation(
				"readAssignedToolboxesToUser",
				"this is the privilege that enables the ability to read assigned toolbox in user");    
								
				
				
				//creates the lowest level operations for  user_in_subgroup scheduling
			$this->_authManager->createOperation(
				"scheduleBulkUsersInSubgroup",
				"this is the privilege that enables the bulk scheduling of users in subgroup"); 
			 $this->_authManager->createOperation(
				"scheduleSingleUserInSubgroup",
				"this is the privilege that enables the single scheduling of users in subgroup"); 
				
				
			//creates the lowest level operations for  toolbox_in_category scheduling	
			 $this->_authManager->createOperation(
				"scheduleBulkToolboxesInCategoryOrDomain",
				"this is the privilege that enables the bulk scheduling of toolboxes in a domain"); 
                         $this->_authManager->createOperation(
				"scheduleSingleToolboxInCategoryOrDomain",
				"this is the privilege that enables the single scheduling of toolbox in a domain"); 
				
				
				
				//creates the lowest level operations for  tool_in_toolbox scheduling	
			 $this->_authManager->createOperation(
				"scheduleBulkToolsInToolbox",
				"this is the privilege that enables the bulk scheduling of tools in a toolbox"); 
                         $this->_authManager->createOperation(
				"scheduleSingleToolInToolbox",
				"this is the privilege that enables the single scheduling of tool in a toolbox"); 
				
				
				//creates the lowest level operations for  toolbox_in_group scheduling	
			 $this->_authManager->createOperation(
				"scheduleBulkToolboxesInGroup",
				"this is the privilege that enables the bulk scheduling of toolbox in a group"); 
                         $this->_authManager->createOperation(
				"scheduleSingleToolboxInGroup",
				"this is the privilege that enables the single scheduling of toolbox in a group"); 
				
				
				
				//creates the lowest level operations for  toolbox_in_subgroup scheduling	
			 $this->_authManager->createOperation(
				"scheduleBulkToolboxesInSubgroup",
				"this is the privilege that enables the bulk scheduling of toolbox in a subgroup"); 
                         $this->_authManager->createOperation(
				"scheduleSingleToolboxInSubgroup",
				"this is the privilege that enables the single scheduling of toolbox in a subgroup"); 
				
				
				
				//creates the lowest level operations for  toolbox_in_user scheduling	
			 $this->_authManager->createOperation(
				"scheduleBulkToolboxesForUser",
				"this is the privilege that enables the bulk scheduling of toolbox in a user"); 
                         $this->_authManager->createOperation(
				"scheduleSingleToolboxForUser",
				"this is the privilege that enables the single scheduling of toolbox in a user");
			 
			 
			  
			//creates the lowest level operations for role privileges
			$this->_authManager->createOperation(
				"createNewRole",
				"this is the privilege that enables the creation of a new role"); 
			 $this->_authManager->createOperation(
				"deleteRole",
				"this is the privilege that enables the removal of a role from the system"); 
            $this->_authManager->createOperation(
				"updateRole",
				"this is the privilege that enables the update of a role"); 
			 $this->_authManager->createOperation(
				"assignPrivilegesToRole",
				"this is the privilege that enables the ability to assigned privilege to role");    
				
				
				
				
				//creates the lowest level operations for task privileges
			$this->_authManager->createOperation(
				"createNewTask",
				"this is the privilege that enables the creation of a new task"); 
			 $this->_authManager->createOperation(
				"deleteTask",
				"this is the privilege that enables the removal of a task from the system"); 
            $this->_authManager->createOperation(
				"updateTask",
				"this is the privilege that enables the update of a task"); 
			 $this->_authManager->createOperation(
				"assignPrivilegesToTask",
				"this is the privilege that enables the ability to assigned privilege to task");    
				
				
				
				//creates the lowest level operations for user authorisation privileges
			$this->_authManager->createOperation(
				"performUserAuthorisation",
				"this is the privilege that enables the ability to perform user authorisation"); 
			 $this->_authManager->createOperation(
				"deleteUserAuthorisation",
				"this is the privilege that enables the removal of a user authorisation from the system"); 
            $this->_authManager->createOperation(
				"updateBusinessRulesAndData",
				"this is the privilege that enables the update of a business rule and data"); 
			 $this->_authManager->createOperation(
				"createBusinessRulesAndData",
				"this is the privilege that enables the ability to create business rules and data");    
				
				
				
				//creates the lowest level operations for privileges
			$this->_authManager->createOperation(
				"createNewPrivilege",
				"this is the privilege that enables the creation of a new privilege"); 
			 $this->_authManager->createOperation(
				"deletePrivilege",
				"this is the privilege that enables the removal of a privilege from the system"); 
            $this->_authManager->createOperation(
				"updatePrivilege",
				"this is the privilege that enables the update of a privilege");
            $this->_authManager->createOperation(
				"createNewTechnology",
				"this is the privilege that confers the ability to create new technology"); 
            $this->_authManager->createOperation(
				"updateTechnology",
				"this is the privilege that confers the ability to update technology information"); 
            $this->_authManager->createOperation(
				"deleteTechnology",
				"this is the privilege that confers the ability to remove technology from that platform");
            $this->_authManager->createOperation(
				"readTechnology",
				"this is the privilege that confers the ability to read technology information from the database"); 
            $this->_authManager->createOperation(
				"createNewToolDuplicate",
				"this is the privilege that confers the ability to create new tool duplicates");
            $this->_authManager->createOperation(
				"updateToolDuplicate",
				"this is the privilege that confers the ability to update tool duplicate information");
            $this->_authManager->createOperation(
				"deleteToolDuplicate",
				"this is the privilege that confers the ability to remove tool duplicate information from the platform");
            $this->_authManager->createOperation(
				"readToolDuplicate",
				"this is the privilege that confers the ability to read tool duplicate information from the database");
            $this->_authManager->createOperation(
				"createNewToolboxDuplicate",
				"this is the privilege that confers the ability to create new toolbiox duplicate");
            $this->_authManager->createOperation(
				"updateToolboxDuplicate",
				"this is the privilege that confers the ability to update toolbox duplicate information");
            $this->_authManager->createOperation(
				"deleteToolboxDuplicate",
				"this is the privilege that confers the ability to remove toolbox duplicate information from the platform");
            $this->_authManager->createOperation(
				"readToolboxDuplicate",
				"this is the privilege that confers the ability to read toolbox duplicate information from the platform");
            $this->_authManager->createOperation(
				"removeToolFromDuplicateToolboxes",
				"this is the privilege that confers the ability to removw tools from duplicate toolboxes");
            $this->_authManager->createOperation(
				"createNewAnnouncement",
				"this is the privilege that confers the ability to create new announcement");
            $this->_authManager->createOperation(
				"updateAnnouncement",
				"this is the privilege that confers the ability to update announcement information");
            $this->_authManager->createOperation(
				"deleteAnnouncement",
				"this is the privilege that confers the ability to delete announcement information");
            $this->_authManager->createOperation(
				"readAnnouncement",
				"this is the privilege that confers the ability to read announcement information from the database");
            $this->_authManager->createOperation(
				"readNeed",
				"this is the privilege that confers the ability to read Need information");
            $this->_authManager->createOperation(
				"deleteNeed",
				"this is the privilege that confers the ability to delete Need information");
            $this->_authManager->createOperation(
				"viewNeed",
				"this is the privilege that confers the ability to view Need information");
            $this->_authManager->createOperation(
				"readWish",
				"this is the privilege that confers the ability to read Wish information");
            $this->_authManager->createOperation(
				"viewWish",
				"this is the privilege that confers the ability to view Wish information");
            $this->_authManager->createOperation(
				"deleteWish",
				"this is the privilege that confers the ability to delete wish information");
            $this->_authManager->createOperation(
				"createNewDomainPolicy",
				"this is the privilege that confers the ability to create new domain policy");
            $this->_authManager->createOperation(
				"updateDomainPolicy",
				"this is the privilege that confers the ability to update domain policy information");
            $this->_authManager->createOperation(
				"deleteDomainPolicy",
				"this is the privilege that confers the ability to delete domain policy");
            $this->_authManager->createOperation(
				"readDomainPolicy",
				"this is the privilege that confers the ability to read domain policy");
            $this->_authManager->createOperation(
				"createNewTimezone",
				"this is the privilege that confers the ability to create new timezone");
            $this->_authManager->createOperation(
				"updateTimezone",
				"this is the privilege that confers the ability to update timezone information");
            $this->_authManager->createOperation(
				"deleteTimezone",
				"this is the privilege that confers the ability to delete timezone information");
            $this->_authManager->createOperation(
				"readTimezone",
				"this is the privilege that confers the ability to read timezone information");
            $this->_authManager->createOperation(
				"createNewCurrency",
				"this is the privilege that confers the ability to create new currency");
            $this->_authManager->createOperation(
				"updateCurrency",
				"this is the privilege that confers the ability to update currency information");
            $this->_authManager->createOperation(
				"deleteCurrency",
				"this is the privilege that confers the ability to delete currency");
            $this->_authManager->createOperation(
				"readCurrency",
				"this is the privilege that confers the ability to read currency information");
            $this->_authManager->createOperation(
				"createNewPlatformSettings",
				"this is the privilege that confers the ability to create new platform settings");
            $this->_authManager->createOperation(
				"updatePlatformSettings",
				"this is the privilege that confers the ability to update platform settings information");
            $this->_authManager->createOperation(
				"readPlatformSettings",
				"this is the privilege that confers the ability to read platform settings information");
            $this->_authManager->createOperation(
				"deletePlatformSettings",
				"this is the privilege that confers the ability to delete platform settings information");
            $this->_authManager->createOperation(
				"createNewStoreParameters",
				"this is the privilege that confers the ability to create new store parameters");
            $this->_authManager->createOperation(
				"updateStoreParameters",
				"this is the privilege that confers the ability to update store parameters");
            $this->_authManager->createOperation(
				"deleteStoreParameters",
				"this is the privilege that confers the ability to delete store parameters");
            $this->_authManager->createOperation(
				"readStoreParameters",
				"this is the privilege that confers the ability to read store parameters");
            $this->_authManager->createOperation(
				"createNewCurrencyExchange",
				"this is the privilege that confers the ability to create new currency exchange");
            $this->_authManager->createOperation(
				"updateCurrencyExchange",
				"this is the privilege that confers the ability to update currency exchange");
            $this->_authManager->createOperation(
				"deleteCurrencyExchange",
				"this is the privilege that confers the ability to delete currency exchange");
            $this->_authManager->createOperation(
				"readCurrencyExchange",
				"this is the privilege that confers the ability to read currency exchange");
            $this->_authManager->createOperation(
				"modifyPartnershipStatus",
				"this is the privilege that confers the ability to modify partnership status");
            $this->_authManager->createOperation(
				"deletePartnership",
				"this is the privilege that confers the ability to delete partnership");
            $this->_authManager->createOperation(
				"accessPartnerInlineStore",
				"this is the privilege that confers the ability to access partner inline store");
            $this->_authManager->createOperation(
				"readDomainPartners",
				"this is the privilege that confers the ability to read domain partners");
            $this->_authManager->createOperation(
				"createNewNetwork",
				"this is the privilege that confers the ability to create new networks");
            $this->_authManager->createOperation(
				"modifyNetwork",
				"this is the privilege that confers the ability to update network information");
            $this->_authManager->createOperation(
				"assignToolboxToNetwork",
				"this is the privilege that confers the ability to assign toolbox to network");
            $this->_authManager->createOperation(
				"deleteNetwork",
				"this is the privilege that confers the ability to delete network");
            $this->_authManager->createOperation(
				"addToolboxToNetwork",
				"this is the privilege that confers the ability to add toolbox to network");
            $this->_authManager->createOperation(
				"modifyToolboxStatusInNetwork",
				"this is the privilege that confers the ability to modify toolbox status in a network");
            $this->_authManager->createOperation(
				"removeToolboxFromNetwork",
				"this is the privilege that confers the ability to remove toolbox from a network");
            $this->_authManager->createOperation(
				"readToolboxInNetwork",
				"this is the privilege that confers the ability to read toolbox in a network");
            $this->_authManager->createOperation(
				"removeAMemberFromNetwork",
				"this is the privilege that confers the ability to remove a member from a network");
            $this->_authManager->createOperation(
				"addingToolboxToAnotherDomainNetwork",
				"this is the privilege that confers the ability to add toolbox to another domain network");
            $this->_authManager->createOperation(
				"removeToolboxFromNetworkConnection",
				"this is the privilege that confers the ability to remove toolbox from network connection");
            $this->_authManager->createOperation(
				"initiateNewPartnership",
				"this is the privilege that confers the ability to initiate new partnership");
            $this->_authManager->createOperation(
				"updatePartnershipInfo",
				"this is the privilege that confers the ability to update partnership info");
            $this->_authManager->createOperation(
				"deletePendingDomainToPartnershipRequest",
				"this is the privilege that confers the ability to delete any pending domain to a partner request");
            $this->_authManager->createOperation(
				"readDomainToPartnerRequest",
				"this is the privilege that confers the ability to read domain to partner request");
            $this->_authManager->createOperation(
				"acceptOrRejectPartnerRequest",
				"this is the privilege that confers the ability to accept or reject a partner domain");
            $this->_authManager->createOperation(
				"keepRequestInView",
				"this is the privilege that confers the ability to keep a request in view");
            $this->_authManager->createOperation(
				"deletePendingPartnerToDomainRequest",
				"this is the privilege that confers the ability to delete pending partner to domain request");
            $this->_authManager->createOperation(
				"readPartnerToDomainRequest",
				"this is the privilege that confers the ability to read partner to domain request");
            $this->_authManager->createOperation(
				"initiateNewNetworkMember",
				"this is the privilege that confers the ability to initiate new network member");
            $this->_authManager->createOperation(
				"modifyNetworkMembership",
				"this is the privilege that confers the ability to modify network membership");
            $this->_authManager->createOperation(
				"removeMemberFromNetwork",
				"this is the privilege that confers the ability to remove member from Network");
            $this->_authManager->createOperation(
				"acceptOrRejectWouldBeNetworkMembership",
				"this is the privilege that confers the ability to accept or reject would be network member");
            $this->_authManager->createOperation(
				"keepNetworkMembershipInView",
				"this is the privilege that confers the ability to keep network membership in view");
            $this->_authManager->createOperation(
				"removeNetworkMembershipRequest",
				"this is the privilege that confers the ability to remove network membership request");
            $this->_authManager->createOperation(
				"readNetworkMembershipRequest",
				"this is the privilege that confers the ability to read network membership request");
            $this->_authManager->createOperation(
				"readOrders",
				"this is the privilege that confers the ability to read domain orders");
            $this->_authManager->createOperation(
				"makePaymentFromOrder",
				"this is the privilege that confers the ability to make payments from domain orders module");
            $this->_authManager->createOperation(
				"addToCartFromOrder",
				"this is the privilege that confers the ability to add to cart from domain orders module");
            $this->_authManager->createOperation(
				"updateCartContentFromOrder",
				"this is the privilege that confers the ability to update cart content from domain order module");
            $this->_authManager->createOperation(
				"removeFromCartFromOrder",
				"this is the privilege that confers the ability to remove items from the cart from the orders module");
            $this->_authManager->createOperation(
				"effectToolboxServiceRenewal",
				"this is the privilege that confers the ability to effect toolbox service renewal");
            $this->_authManager->createOperation(
				"readDueToolboxServicesForRenewal",
				"this is the privilege that confers the ability to read due services for renewal");
            $this->_authManager->createOperation(
				"readDomainReceipt",
				"this is the privilege that confers the ability to read domain receipt");
            $this->_authManager->createOperation(
				"makePaymentConfirmations",
				"this is the privilege that confers the ability to make payment confirmations");
            $this->_authManager->createOperation(
				"readUnconfirmedPayments",
				"this is the privilege that confers the ability to read unconfirmed payments");
            $this->_authManager->createOperation(
				"readInactiveToolboxService",
				"this is the privilege that confers the ability to read inactive toolbox services");
            
            $this->_authManager->createOperation(
				"activateToolboxService",
				"this is the privilege that confers the ability to activate toolbox service");
            $this->_authManager->createOperation(
				"readActiveToolboxService",
				"this is the privilege that confers the ability to read active toolbox service");
            $this->_authManager->createOperation(
				"deactivateToolboxService",
				"this is the privilege that confers the ability to deactivate toolbox service");
            $this->_authManager->createOperation(
				"viewPaymentForRemittance",
				"this is the privilege that confers the ability to view payments due for remittance");
            $this->_authManager->createOperation(
				"processPaymentForRemittance",
				"this is the privilege that confers the ability to process payment for remittance");
            $this->_authManager->createOperation(
				"deferPaymentRemittance",
				"this is the privilege that confers the ability to defer Payment for Remittance");
            $this->_authManager->createOperation(
				"includePaymentForRemittance",
				"this is the privilege that confers the ability to include payment in remittance");
            $this->_authManager->createOperation(
				"addTaskToDuplicateTool",
				"this is the privilege that confers the ability to add task to duplicate tool");
            $this->_authManager->createOperation(
				"updateTaskInDuplicateTool",
				"this is the privilege that confers the ability to update task in duplicate tool");
            $this->_authManager->createOperation(
				"removeTaskFromDuplicateTool",
				"this is the privilege that confers the ability to remove task from duplicate tool");
            $this->_authManager->createOperation(
				"addToolToDuplicateToolbox",
				"this is the privilege that confers the ability to add tool to duplicate toolbox");
            $this->_authManager->createOperation(
				"removeToolFromDuplicateToolbox",
				"this is the privilege that confers the ability to remove tool from duplicate toolbox");
            $this->_authManager->createOperation(
				"accessInlineNetworkStore",
				"this is the privilege that confers the ability to access inline network store");
		//create the platformwide supports
             $this->_authManager->createOperation(
				"platformAdmin",
				"this is the privilege that confers the ability to conduct platform-wide administration on the platform");
             $this->_authManager->createOperation(
				"platformPartnerSupport",
				"this is the privilege that confers the ability to provide support on domain partnerships");
             $this->_authManager->createOperation(
				"platformStoreSupport",
				"this is the privilege that confers the ability to provide support on all domain stores");
             $this->_authManager->createOperation(
				"platformPolicySupport",
				"this is the privilege that confers the ability to provide support on domain policies");
             $this->_authManager->createOperation(
				"platformNeedSupport",
				"this is the privilege that confers the ability to provide support on domain Needs");
             $this->_authManager->createOperation(
				"platformAnnouncementSupport",
				"this is the privilege that confers the ability to provide support on announcements");
             $this->_authManager->createOperation(
				"platformToolboxDuplicationSupport",
				"this is the privilege that confers the ability to provide support on toolbox duplication activities");
             $this->_authManager->createOperation(
				"platformToolDuplicationSupport",
				"this is the privilege that confers the ability to provide support on tool duplication activities");
             $this->_authManager->createOperation(
				"platformGroupSupport",
				"this is the privilege that confers the ability to provide support on domain groups");
             $this->_authManager->createOperation(
				"platformSubgroupSupport",
				"this is the privilege that confers the ability to provide support on domain subgroups");
             $this->_authManager->createOperation(
				"platformWishSupport",
				"this is the privilege that confers the ability to provide support on domain wishes");
             $this->_authManager->createOperation(
				"platformUserSupport",
				"this is the privilege that confers the ability to provide support on domain users");
             $this->_authManager->createOperation(
				"platformOrdersSupport",
				"this is the privilege that confers the ability to provide support on domain orders");
             $this->_authManager->createOperation(
				"platformRenewalSupport",
				"this is the privilege that confers the ability to provide support on domain renewals");
             $this->_authManager->createOperation(
				"platformPaymentConfirmationSupport",
				"this is the privilege that confers the ability to provide support on payment confirmations");
             $this->_authManager->createOperation(
				"platformToolboxActivationSupport",
				"this is the privilege that confers the ability to provide support on toolbox activation activities");
             $this->_authManager->createOperation(
				"platformToolboxDeactivationSupport",
				"this is the privilege that confers the ability to provide support on toolbox deactivation activities");
             $this->_authManager->createOperation(
				"platformRemittanceSupport",
				"this is the privilege that confers the ability to provide support on domain remittance");
              $this->_authManager->createOperation(
				"platformRemittanceAdmin",
				"this is the privilege that confers the ability to provide adminitration on domain remittance");
               $this->_authManager->createOperation(
				"platformToolboxDeactivationAdmin",
				"this is the privilege that confers the ability to  administer toolbox deactivation");
               $this->_authManager->createOperation(
				"platformToolboxActivationAdmin",
				"this is the privilege that confers the ability to administer toolbox activation");
               $this->_authManager->createOperation(
				"platformPaymentConfirmationAdmin",
				"this is the privilege that confers the ability to administer payment confirmation");
               $this->_authManager->createOperation(
				"platformRenewalAdmin",
				"this is the privilege that confers the ability to administer service renewals");
                $this->_authManager->createOperation(
				"platformOrdersAdmin",
				"this is the privilege that confers the ability to administer purchase orders");
                $this->_authManager->createOperation(
				"platformUserAdmin",
				"this is the privilege that confers the ability to administer platform users");
                $this->_authManager->createOperation(
				"platformWishAdmin",
				"this is the privilege that confers the ability to administer platform wishes");
                $this->_authManager->createOperation(
				"platformSubgroupAdmin",
				"this is the privilege that confers the ability to administer platform subgroups");
                $this->_authManager->createOperation(
				"platformGroupAdmin",
				"this is the privilege that confers the ability to administer platform groups");
                $this->_authManager->createOperation(
				"platformToolDuplicationAdmin",
				"this is the privilege that confers the ability to administer platform tool duplications");
                $this->_authManager->createOperation(
				"platformToolboxDuplicationAdmin",
				"this is the privilege that confers the ability to administer platform toolbox duplications");
                $this->_authManager->createOperation(
				"platformAnnouncementAdmin",
				"this is the privilege that confers the ability to administer platform announcements");
                $this->_authManager->createOperation(
				"platformNeedAdmin",
				"this is the privilege that confers the ability to administer platform needs");
                $this->_authManager->createOperation(
				"platformPolicyAdmin",
				"this is the privilege that confers the ability to administer platform policies");
                $this->_authManager->createOperation(
				"platformStoreAdmin",
				"this is the privilege that confers the ability to administer stores");
                $this->_authManager->createOperation(
				"platformPartnerAdmin",
				"this is the privilege that confers the ability to administer partnerships");
                $this->_authManager->createOperation(
				"platformNetworkSupport",
				"this is the privilege that confers the ability to administer domain networks");
                 $this->_authManager->createOperation(
				"changeUserPassword",
				"this is the privilege that confers the ability to change users password");
                 $this->_authManager->createOperation(
				"readToolsAndTask",
				"this is the privilege that confers the ability to read tools and task");
                 $this->_authManager->createOperation(
				"platformPaymentConfirmation",
				"this is the privilege that confers the ability to verify payments on the platform");
                  $this->_authManager->createOperation(
				"grantSpecialPrivilegesToDomains",
				"this is the privilege that confers the ability to grant special privileges to domains");
                  $this->_authManager->createOperation(
				"activateAccountForCountry",
				"this is the privilege that confers the ability to activate accounts for country");
                  $this->_authManager->createOperation(
				"deactivateAccountForCountry",
				"this is the privilege that confers the ability to deactivate accounts for country");
                  $this->_authManager->createOperation(
				"approveAccountForCountry",
				"this is the privilege that confers the ability to approve accounts for country");
                  $this->_authManager->createOperation(
				"disapproveAccountForCountry",
				"this is the privilege that confers the ability to disapprove accounts for country");
                  $this->_authManager->createOperation(
				"assignAccountForCountry",
				"this is the privilege that confers the ability to assign accounts for country");
                  $this->_authManager->createOperation(
				"addNewBankAccount",
				"this is the privilege that confers the ability to add new bank account ");
                  $this->_authManager->createOperation(
				"updateAccountNumber",
				"this is the privilege that confers the ability to update bank account ");
                  $this->_authManager->createOperation(
				"deleteAccountNumber",
				"this is the privilege that confers the ability to delete bank account ");
                  $this->_authManager->createOperation(
				"readBankAccount",
				"this is the privilege that confers the ability to read bank account ");
		
			 
            //create all the task security module
			$generalToolsAndTaskManager=$this->_authManager->createTask("generalToolsAndTaskManager");
                        $generalToolsAndTaskManager->addChild('createNewGeneralTask');
                        $generalToolsAndTaskManager->addChild('createNewGeneralTool');
                        $generalToolsAndTaskManager->addChild('deleteGeneralToolAndTask');
                        $generalToolsAndTaskManager->addChild('readGeneralToolAndTask');
                        $generalToolsAndTaskManager->addChild('updateGeneralToolAndTask');
       
			$accountsAndFinanceToolsAndTaskManager=$this->_authManager->createTask("accountsAndFinanceToolsAndTaskManager"); 
                        $accountsAndFinanceToolsAndTaskManager->addChild('createNewAccountsAndFinanceTask');
                        $accountsAndFinanceToolsAndTaskManager->addChild('createNewAccountsAndFinanceTool');
                        $accountsAndFinanceToolsAndTaskManager->addChild('deleteAccountsAndFinanceToolAndTask');
                        $accountsAndFinanceToolsAndTaskManager->addChild('readAccountsAndFinanceToolAndTask');
                        $accountsAndFinanceToolsAndTaskManager->addChild('updateAccountsAndFinanceToolAndTask');
                        
			$operationsToolsAndTaskManager=$this->_authManager->createTask("operationsToolsAndTaskManager"); 
                        $operationsToolsAndTaskManager->addChild('createNewOperationsTask');
                        $operationsToolsAndTaskManager->addChild('createNewOperationsTool');
                        $operationsToolsAndTaskManager->addChild('deleteOperationsToolsAndTask');
                        $operationsToolsAndTaskManager->addChild('readOperationsToolsAndTask');
                        $operationsToolsAndTaskManager->addChild('updateOperationsToolsAndTask');
                        
			$humanResourcesToolsAndTaskManager=$this->_authManager->createTask("humanResourcesToolsAndTaskManager"); 
                        $humanResourcesToolsAndTaskManager->addChild('createNewHumanResourcesTask');
                        $humanResourcesToolsAndTaskManager->addChild('createNewHumanResourcesTool');
                        $humanResourcesToolsAndTaskManager->addChild('deleteHumanResourcesToolAndTask');
                        $humanResourcesToolsAndTaskManager->addChild('readHumanResourcesToolAndTask');
                        $humanResourcesToolsAndTaskManager->addChild('updateHumanResourcesToolAndTask');
                        
			$crmToolsAndTaskManager=$this->_authManager->createTask("crmToolsAndTaskManager"); 
                        $crmToolsAndTaskManager->addChild('createNewCrmTask');
                        $crmToolsAndTaskManager->addChild('createNewCrmTool');
                        $crmToolsAndTaskManager->addChild('deleteCrmToolAndTask');
                        $crmToolsAndTaskManager->addChild('readCrmToolAndTask');
                        $crmToolsAndTaskManager->addChild('updateCrmToolAndTask');
                        
			$operatingSystemToolsAndTaskManager=$this->_authManager->createTask("operatingSystemToolsAndTaskManager");
                        $operatingSystemToolsAndTaskManager->addChild('createNewOperatingSystemsTask');
                        $operatingSystemToolsAndTaskManager->addChild('createNewOperatingSystemsTool');
                        $operatingSystemToolsAndTaskManager->addChild('deleteOperatingSystemToolAndTask');
                        $operatingSystemToolsAndTaskManager->addChild('readOperatingSystemToolAndTask');
                        $operatingSystemToolsAndTaskManager->addChild('updateOperatingSystemToolAndTask');
                        
			$hardwareAndMobileToolsAndTaskManager=$this->_authManager->createTask("hardwareAndMobileToolsAndTaskManager");
                        $hardwareAndMobileToolsAndTaskManager->addChild('createNewHardwareAndMobileTask');
                        $hardwareAndMobileToolsAndTaskManager->addChild('createNewHardwareAndMobileTool');
                        $hardwareAndMobileToolsAndTaskManager->addChild('deleteHardwareAndMobileToolAndTask');
                        $hardwareAndMobileToolsAndTaskManager->addChild('readHardwareAndMobileToolAndTask');
                        $hardwareAndMobileToolsAndTaskManager->addChild('updateHardwareAndMobileToolAndTask');
                        
			$databaseToolsAndTaskManager=$this->_authManager->createTask("databaseToolsAndTaskManager");
                        $databaseToolsAndTaskManager->addChild('createNewDatabaseTask');
                        $databaseToolsAndTaskManager->addChild('createNewDatabaseTool');
                        $databaseToolsAndTaskManager->addChild('deleteDatabaseToolAndTask');
                        $databaseToolsAndTaskManager->addChild('readDatabaseToolAndTask');
                        $databaseToolsAndTaskManager->addChild('updateDatabaseToolAndTask');
                        
			$dataCleaningToolsAndTaskManager=$this->_authManager->createTask("dataCleaningToolsAndTaskManager");
                        $dataCleaningToolsAndTaskManager->addChild('createNewDataCleaningTask');
                        $dataCleaningToolsAndTaskManager->addChild('createNewDataCleaningTool');
                        $dataCleaningToolsAndTaskManager->addChild('deleteDataCleaningToolAndTask');
                        $dataCleaningToolsAndTaskManager->addChild('readDataCleaningToolAndTask');
                        $dataCleaningToolsAndTaskManager->addChild('updateDataCleaningToolAndTask');
                        
			$dataAnalysisToolsAndTaskManager=$this->_authManager->createTask("dataAnalysisToolsAndTaskManager");
                        $dataAnalysisToolsAndTaskManager->addChild('createNewDataAnalysisTask');
                        $dataAnalysisToolsAndTaskManager->addChild('createNewDataAnalysisTool');
                        $dataAnalysisToolsAndTaskManager->addChild('deleteDataAnalysisToolAndTask');
                        $dataAnalysisToolsAndTaskManager->addChild('readDataAnalysisToolAndTask');
                        $dataAnalysisToolsAndTaskManager->addChild('updateDataAnalysisToolAndTask');
                        
			$dataVisualizationToolsAndTaskManager=$this->_authManager->createTask("dataVisualizationToolsAndTaskManager");
                        $dataVisualizationToolsAndTaskManager->addChild('createNewDataVisualizationTask');
                        $dataVisualizationToolsAndTaskManager->addChild('createNewDataVisualizationTool');
                        $dataVisualizationToolsAndTaskManager->addChild('deleteDataVisualizationToolAndTask');
                        $dataVisualizationToolsAndTaskManager->addChild('readDataVisualizationToolAndTask');
                        $dataVisualizationToolsAndTaskManager->addChild('updateDataVisualizationToolAndTask');
                        
			$dataAcquisitionToolsAndTaskManager=$this->_authManager->createTask("dataAcquisitionToolsAndTaskManager");
                        $dataAcquisitionToolsAndTaskManager->addChild('createNewDataAcquisitionTask');
                        $dataAcquisitionToolsAndTaskManager->addChild('createNewDataAcquisitionTool');
                        $dataAcquisitionToolsAndTaskManager->addChild('deleteDataAcquisitionToolAndTask');
                        $dataAcquisitionToolsAndTaskManager->addChild('readDataAcquisitionToolAndTask');
                        $dataAcquisitionToolsAndTaskManager->addChild('updateDataAcquisitionToolAndTask');
                        
			$processesToolsAndTaskManager=$this->_authManager->createTask("processesToolsAndTaskManager");
                        $processesToolsAndTaskManager->addChild('createNewProcessesTask');
                        $processesToolsAndTaskManager->addChild('createNewProcessesTool');
                        $processesToolsAndTaskManager->addChild('deleteProcessesToolAndTask');
                        $processesToolsAndTaskManager->addChild('readProcessesToolAndTask');
                        $processesToolsAndTaskManager->addChild('updateProcessesToolAndTask');
                        
			$equipmentAndMachineryToolsAndTaskManager=$this->_authManager->createTask("equipmentAndMachineryToolsAndTaskManager");
                        $equipmentAndMachineryToolsAndTaskManager->addChild('createNewEquipmentAndMachineryTask');
                        $equipmentAndMachineryToolsAndTaskManager->addChild('createNewEquipmentAndMachineryTool');
                        $equipmentAndMachineryToolsAndTaskManager->addChild('deleteEquipmentAndMachineryToolAndTask');
                        $equipmentAndMachineryToolsAndTaskManager->addChild('readEquipmentAndMachineryToolAndTask');
                        $equipmentAndMachineryToolsAndTaskManager->addChild('updateEquipmentAndMachineryToolAndTask');
                        
			$researchToolsAndTaskManager=$this->_authManager->createTask("researchToolsAndTaskManager");
                        $researchToolsAndTaskManager->addChild('createNewResearchTask');
                        $researchToolsAndTaskManager->addChild('createNewResearchTool');
                        $researchToolsAndTaskManager->addChild('deleteResearchToolAndTask');
                        $researchToolsAndTaskManager->addChild('readResearchToolAndTask');
                        $researchToolsAndTaskManager->addChild('updateResearchToolAndTask');
                        
			$productionToolsAndTaskManager=$this->_authManager->createTask("productionToolsAndTaskManager");
                        $productionToolsAndTaskManager->addChild('createProductionTask');
                        $productionToolsAndTaskManager->addChild('createProductionTool');
                        $productionToolsAndTaskManager->addChild('deleteProductionToolAndTask');
                        $productionToolsAndTaskManager->addChild('readProductionToolAndTask');
                        $productionToolsAndTaskManager->addChild('updateProductionToolAndTask');
                        
			$maintenanceToolsAndTaskManager=$this->_authManager->createTask("maintenanceToolsAndTaskManager");
                        $maintenanceToolsAndTaskManager->addChild('createNewMaintenanceTask');
                        $maintenanceToolsAndTaskManager->addChild('createNewMaintenanceTool');
                        $maintenanceToolsAndTaskManager->addChild('deleteMaintenanceToolAndTask');
                        $maintenanceToolsAndTaskManager->addChild('readMaintenanceToolAndTask');
                        $maintenanceToolsAndTaskManager->addChild('updateMaintenanceToolOrTask');
                        
			$customerRelationToolsAndTaskManager=$this->_authManager->createTask("customerRelationToolsAndTaskManager");
                        $customerRelationToolsAndTaskManager->addChild('createNewCustomerRelationTask');
                        $customerRelationToolsAndTaskManager->addChild('createNewCustomerRelationTool');
                        $customerRelationToolsAndTaskManager->addChild('deleteCustomerRelationToolAndTask');
                        $customerRelationToolsAndTaskManager->addChild('readCustomerRelationToolAndTask');
                        $customerRelationToolsAndTaskManager->addChild('updateCustomerRelationToolAndTask');
                        
			$supplyChainToolsAndTaskManager=$this->_authManager->createTask("supplyChainToolsAndTaskManager");
                        $supplyChainToolsAndTaskManager->addChild('createNewSupplyChainTask');
                        $supplyChainToolsAndTaskManager->addChild('createNewSupplyChainTool');
                        $supplyChainToolsAndTaskManager->addChild('deleteSupplyChainToolAndTask');
                        $supplyChainToolsAndTaskManager->addChild('readSupplyChainToolAndTask');
                        $supplyChainToolsAndTaskManager->addChild('updateSupplyChainToolAndTask');
                        
			$treasuryToolsAndTaskManager=$this->_authManager->createTask("treasuryToolsAndTaskManager");
                        $treasuryToolsAndTaskManager->addChild('createNewTreasuryTask');
                        $treasuryToolsAndTaskManager->addChild('createNewTreasuryTool');
                        $treasuryToolsAndTaskManager->addChild('deleteTreasuryToolAndTask');
                        $treasuryToolsAndTaskManager->addChild('readTreasuryToolAndTask');
                        $treasuryToolsAndTaskManager->addChild('updateTreasuryToolAndTask');
                        
			$loanAndCreditToolsAndTaskManager=$this->_authManager->createTask("loanAndCreditToolsAndTaskManager");
                        $loanAndCreditToolsAndTaskManager->addChild('createNewLoanAndCreditTask');
                        $loanAndCreditToolsAndTaskManager->addChild('createNewLoanAndCreditTool');
                        $loanAndCreditToolsAndTaskManager->addChild('deleteLoansAndCreditToolAndTask');
                        $loanAndCreditToolsAndTaskManager->addChild('readLoansAndCreditToolAndTask');
                        $loanAndCreditToolsAndTaskManager->addChild('updateLoanAndCreditToolAndTask');
                        
			$erpToolsAndTaskManager=$this->_authManager->createTask("erpToolsAndTaskManager");
                        $erpToolsAndTaskManager->addChild('createNewErpTask');
                        $erpToolsAndTaskManager->addChild('createNewErpTool');
                        $erpToolsAndTaskManager->addChild('deleteErpToolAndTask');
                        $erpToolsAndTaskManager->addChild('readErpToolAndTask');
                        $erpToolsAndTaskManager->addChild('updateErpToolAndTask');
                        
			$securityToolsAndTaskManager=$this->_authManager->createTask("securityToolsAndTaskManager");
                        $securityToolsAndTaskManager->addChild('createNewSecurityTask');
                        $securityToolsAndTaskManager->addChild('createNewSecurityTool');
                        $securityToolsAndTaskManager->addChild('deleteSecurityToolAndTask');
                        $securityToolsAndTaskManager->addChild('readSecurityToolAndTask');
                        $securityToolsAndTaskManager->addChild('updateSecurityToolAndTask');
                        
			$controlAndComplianceToolsAndTaskManager=$this->_authManager->createTask("controlAndComplianceToolsAndTaskManager");
                        $controlAndComplianceToolsAndTaskManager->addChild('createNewControlAndComplianceTask');
                        $controlAndComplianceToolsAndTaskManager->addChild('createNewControlAndComplianceTool');
                        $controlAndComplianceToolsAndTaskManager->addChild('deleteControlAndComplianceToolAndTask');
                        $controlAndComplianceToolsAndTaskManager->addChild('readControlAndComplianceToolAndTask');
                        $controlAndComplianceToolsAndTaskManager->addChild('updateControlAndComplianceToolAndTask');
                        
			$riskAssessmentToolsAndTaskManager=$this->_authManager->createTask("riskAssessmentToolsAndTaskManager");
                        $riskAssessmentToolsAndTaskManager->addChild('createNewRiskAssessmentTask');
                        $riskAssessmentToolsAndTaskManager->addChild('createNewRiskAssessmentTool');
                        $riskAssessmentToolsAndTaskManager->addChild('deleteRiskAssessmentToolAndTask');
                        $riskAssessmentToolsAndTaskManager->addChild('readRiskAssessmentToolAndTask');
                        $riskAssessmentToolsAndTaskManager->addChild('updateRiskAssessmentToolAndTask');
                        
			$automationToolsAndTaskManager=$this->_authManager->createTask("automationToolsAndTaskManager");
                        $automationToolsAndTaskManager->addChild('createNewAutomationTask');
                        $automationToolsAndTaskManager->addChild('createNewAutomationTool');
                        $automationToolsAndTaskManager->addChild('deleteAutomationToolAndTask');
                        $automationToolsAndTaskManager->addChild('readAutomationToolAndTask');
                        $automationToolsAndTaskManager->addChild('updateAutomationToolAndTask');
                        
			$investmentToolsAndTaskManager=$this->_authManager->createTask("investmentToolsAndTaskManager");
                        $investmentToolsAndTaskManager->addChild('createNewInvestmentTask');
                        $investmentToolsAndTaskManager->addChild('createNewInvestmentTool');
                        $investmentToolsAndTaskManager->addChild('deleteInvestmentToolAndTask');
                        $investmentToolsAndTaskManager->addChild('readInvestmentToolAndTask');
                        $investmentToolsAndTaskManager->addChild('updateInvestmentToolAndTask');
                        
			$userToSubgroupAssignmentManager=$this->_authManager->createTask("userToSubgroupAssignmentManager");
                        $userToSubgroupAssignmentManager->addChild('assignBulkUsersToSubgroup');
                        $userToSubgroupAssignmentManager->addChild('assignSingleUserToSubgroup');
                        $userToSubgroupAssignmentManager->addChild('deleteAssignedUserFromSubgroup');
                        $userToSubgroupAssignmentManager->addChild('readAssignedUserSubgroup');
                        $userToSubgroupAssignmentManager->addChild('updateAssignedUserInSubgroup');
                        
			$toolboxToCategoryAssignmentManager=$this->_authManager->createTask("toolboxToCategoryAssignmentManager");
                        $toolboxToCategoryAssignmentManager->addChild('assignBulkToolboxesToDomainOrCategory');
                        $toolboxToCategoryAssignmentManager->addChild('assignSingleToolboxToDomainOrCategory');
                        $toolboxToCategoryAssignmentManager->addChild('deleteAssignedToolboxInDomainOrCategory');
                        $toolboxToCategoryAssignmentManager->addChild('readAssignedToolboxToDomainOrCategory');
                        $toolboxToCategoryAssignmentManager->addChild('updateAssignedToolboxInDomainOrCategory');
                        
			$toolsToToolboxAssignmentManager=$this->_authManager->createTask("toolsToToolboxAssignmentManager");
                        $toolsToToolboxAssignmentManager->addChild('assignBulkToolsToToolbox');
                        $toolsToToolboxAssignmentManager->addChild('assignSingleToolToToolbox');
                        $toolsToToolboxAssignmentManager->addChild('deleteAssignedToolFromToolbox');
                        $toolsToToolboxAssignmentManager->addChild('readAssignedToolsInToolbox');
                        $toolsToToolboxAssignmentManager->addChild('updateAssignedToolsInToolbox');
                        
			$toolboxToGroupAssignmentManager=$this->_authManager->createTask("toolboxToGroupAssignmentManager");
                        $toolboxToGroupAssignmentManager->addChild('assignBulkToolboxesToGroup');
                        $toolboxToGroupAssignmentManager->addChild('assignSingleToolboxToGroup');
                        $toolboxToGroupAssignmentManager->addChild('deleteAssignedToolboxFromGroup');
                        $toolboxToGroupAssignmentManager->addChild('readAssignedToolboxesToGroup');
                        $toolboxToGroupAssignmentManager->addChild('updateAssignedToolboxToGroup');
                        
			$toolboxToSubgroupAssignmentManager=$this->_authManager->createTask("toolboxToSubgroupAssignmentManager");
                        $toolboxToSubgroupAssignmentManager->addChild('assignBulkToolboxesToSubgroup');
                        $toolboxToSubgroupAssignmentManager->addChild('assignSingleToolboxToSubgroup');
                        $toolboxToSubgroupAssignmentManager->addChild('deleteAssignedToolboxFromSubgroup');
                        $toolboxToSubgroupAssignmentManager->addChild('readAssignedToolboxesToSubgroup');
                        $toolboxToSubgroupAssignmentManager->addChild('updateAssignedToolboxToSubgroup');
                        
			$toolboxToUserAssignmentManager=$this->_authManager->createTask("toolboxToUserAssignmentManager");
                        $toolboxToUserAssignmentManager->addChild('assignBulkToolboxesToUser');
                        $toolboxToUserAssignmentManager->addChild('assignSingleToolboxToUser');
                        $toolboxToUserAssignmentManager->addChild('deleteAssignedToolboxToUser');
                        $toolboxToUserAssignmentManager->addChild('readAssignedToolboxesToUser');
                        $toolboxToUserAssignmentManager->addChild('updateAssignedToolboxToUser');
                        
			$userToSubgroupSchedulingManager=$this->_authManager->createTask("userToSubgroupSchedulingManager");
                        $userToSubgroupSchedulingManager->addChild('scheduleBulkUsersInSubgroup');
                        $userToSubgroupSchedulingManager->addChild('scheduleSingleUserInSubgroup');
                        
			$toolboxToCategorySchedulingManager=$this->_authManager->createTask("toolboxToCategorySchedulingManager");
                        $toolboxToCategorySchedulingManager->addChild('scheduleBulkToolboxesInCategoryOrDomain');
                        $toolboxToCategorySchedulingManager->addChild('scheduleSingleToolboxInCategoryOrDomain');
                        
			$toolsInToolboxSchedulingManager=$this->_authManager->createTask("toolsInToolboxSchedulingManager");
                        $toolsInToolboxSchedulingManager->addChild('scheduleBulkToolsInToolbox');
                        $toolsInToolboxSchedulingManager->addChild('scheduleSingleToolInToolbox');
                        
			$toolboxToGroupSchedulingManager=$this->_authManager->createTask("toolboxToGroupSchedulingManager");
                        $toolboxToGroupSchedulingManager->addChild('scheduleBulkToolboxesInGroup');
                        $toolboxToGroupSchedulingManager->addChild('scheduleSingleToolboxInGroup');
                        
			$toolboxToSubgroupSchedulingManager=$this->_authManager->createTask("toolboxToSubgroupSchedulingManager");
                        $toolboxToSubgroupSchedulingManager->addChild('scheduleBulkToolboxesInSubgroup');
                        $toolboxToSubgroupSchedulingManager->addChild('scheduleSingleToolboxInSubgroup');
                        
			$toolboxToUserSchedulingManager=$this->_authManager->createTask("toolboxToUserSchedulingManager");
                        $toolboxToUserSchedulingManager->addChild('scheduleBulkToolboxesForUser');
                        $toolboxToUserSchedulingManager->addChild('scheduleSingleToolboxForUser');
                        
			$userManager=$this->_authManager->createTask("userManager");
                        $userManager->addChild('createUser');
                        $userManager->addChild('deleteUser');
                        $userManager->addChild('readUser');
                        $userManager->addChild('updateUser');
                        
			$usertypeManager=$this->_authManager->createTask("usertypeManager");
                        
			$countryManager=$this->_authManager->createTask("countryManager");
                        $countryManager->addChild('createCountry');
                        $countryManager->addChild('deleteCountry');
                        $countryManager->addChild('readCountry');
                        $countryManager->addChild('updateCountry');
                        
			$stateManager=$this->_authManager->createTask("stateManager");
                        $stateManager->addChild('createState');
                        $stateManager->addChild('deleteState');
                        $stateManager->addChild('readState');
                        $stateManager->addChild('updateState');
                        
			$cityManager=$this->_authManager->createTask("cityManager");
                        $cityManager->addChild('createCity');
                        $cityManager->addChild('deleteCity');
                        $cityManager->addChild('readCity');
                        $cityManager->addChild('updateCity');
                        
			$grouptypeManager=$this->_authManager->createTask("grouptypeManager");
                        
			$groupManager=$this->_authManager->createTask("groupManager");
                        $groupManager->addChild('createGroup');
                        $groupManager->addChild('deleteGroup');
                        $groupManager->addChild('readGroup');
                        $groupManager->addChild('updateGroup');
                        
			$subgroupManager=$this->_authManager->createTask("subgroupManager");
                        $subgroupManager->addChild('createSubgroup');
                        $subgroupManager->addChild('deleteSubgroup');
                        $subgroupManager->addChild('readSubgroup');
                        $subgroupManager->addChild('updateSubgroup');
                        
			$containerManager=$this->_authManager->createTask("containerManager");
                        $containerManager->addChild('createContainer');
                        $containerManager->addChild('deleteContainer');
                        $containerManager->addChild('readContainer');
                        $containerManager->addChild('updateContainer');
                        
			$tooltypeManager=$this->_authManager->createTask("tooltypeManager");
                        $tooltypeManager->addChild('createNewTooltype');
                        $tooltypeManager->addChild('deleteTooltype');
                        $tooltypeManager->addChild('readTooltype');
                        $tooltypeManager->addChild('updateTooltype');
                        
			$toolboxManager=$this->_authManager->createTask("toolboxManager");
                        $toolboxManager->addChild('createNewToolbox');
                        $toolboxManager->addChild('deleteToolbox');
                        $toolboxManager->addChild('readToolbox');
                        $toolboxManager->addChild('updateToolbox');
                        
			$categoryManager=$this->_authManager->createTask("categoryManager");
                        $categoryManager->addChild('createNewCategoryOrDomain');
                        $categoryManager->addChild('deleteCategoryOrDomain');
                        $categoryManager->addChild('readCategoryOrDomain');
                        $categoryManager->addChild('updateCategoryOrDomain');
                        
			$roleManager=$this->_authManager->createTask("roleManager");
                        $roleManager->addChild('createNewRole');
                        $roleManager->addChild('deleteRole');
                        $roleManager->addChild('updateRole');
                        
			$taskManager=$this->_authManager->createTask("taskManager");
                        $taskManager->addChild('createNewTask');
                        $taskManager->addChild('deleteTask');
                        $taskManager->addChild('updateTask');
                        
			$privilegesManager=$this->_authManager->createTask("privilegesManager");
                        $privilegesManager->addChild('createNewPrivilege');
                        $privilegesManager->addChild('deletePrivilege');
                        $privilegesManager->addChild('updatePrivilege');
                        
			$userAuthorizationManager=$this->_authManager->createTask("userAuthorizationManager");
                        $userAuthorizationManager->addChild('deleteUserAuthorisation');
                        $userAuthorizationManager->addChild('performUserAuthorisation');
                        
			$networksAndCommsManager=$this->_authManager->createTask("networksAndCommsManager");
                        $networksAndCommsManager->addChild('createNewNetworksAndCommsTask');
                        $networksAndCommsManager->addChild('createNewNetworksAndCommsTool');
                        $networksAndCommsManager->addChild('deleteNetworkAndCommToolAndTask');
                        $networksAndCommsManager->addChild('readNetworkAndCommToolAndTask');
                        $networksAndCommsManager->addChild('updateNetworkAndCommToolAndTask');
                        //include the task for some addtional modules
                        $activeToolboxServiceManager=$this->_authManager->createTask("activeToolboxServiceManager");
                        $activeToolboxServiceManager->addChild('activateToolboxService');
                        $activeToolboxServiceManager->addChild('deactivateToolboxService');
                        $activeToolboxServiceManager->addChild('readActiveToolboxService');
                        $activeToolboxServiceManager->addChild('readInactiveToolboxService');
                        
                        $announcementManager=$this->_authManager->createTask("announcementManager");
                        $announcementManager->addChild('createNewAnnouncement');
                        $announcementManager->addChild('deleteAnnouncement');
                        $announcementManager->addChild('readAnnouncement');
                        $announcementManager->addChild('updateAnnouncement');
                        
                        $currencyExchangeManager=$this->_authManager->createTask("currencyExchangeManager");
                        $currencyExchangeManager->addChild('createNewCurrencyExchange');
                        $currencyExchangeManager->addChild('deleteCurrencyExchange');
                        $currencyExchangeManager->addChild('readCurrencyExchange');
                        $currencyExchangeManager->addChild('updateCurrencyExchange');
                        
                        $currencyManagement=$this->_authManager->createTask("currencyManagement");
                        $currencyManagement->addChild('createNewCurrency');
                        $currencyManagement->addChild('deleteCurrency');
                        $currencyManagement->addChild('readCurrency');
                        $currencyManagement->addChild('updateCurrency');
                        
                        $domainNetworkConnectionManager=$this->_authManager->createTask("domainNetworkConnectionManager");
                        $domainNetworkConnectionManager->addChild('removeAMemberFromNetwork');
                        $domainNetworkConnectionManager->addChild('addingToolboxToAnotherDomainNetwork');
                        $domainNetworkConnectionManager->addChild('removeToolboxFromNetworkConnection');
                        $domainNetworkConnectionManager->addChild('accessInlineNetworkStore');
                        
                        $domainNetworkManager=$this->_authManager->createTask("domainNetworkManager");
                        $domainNetworkManager->addChild('acceptOrRejectWouldBeNetworkMembership');
                        $domainNetworkManager->addChild('initiateNewNetworkMember');
                        $domainNetworkManager->addChild('keepNetworkMembershipInView');
                        $domainNetworkManager->addChild('modifyNetworkMembership');
                        $domainNetworkManager->addChild('readNetworkMembershipRequest');
                        $domainNetworkManager->addChild('removeMemberFromNetwork');
                        $domainNetworkManager->addChild('removeNetworkMembershipRequest');
                        
                        $domainOrdersManager=$this->_authManager->createTask("domainOrdersManager");
                        $domainOrdersManager->addChild('addToCartFromOrder');
                        $domainOrdersManager->addChild('makePaymentFromOrder');
                        $domainOrdersManager->addChild('readOrders');
                        $domainOrdersManager->addChild('removeFromCartFromOrder');
                        $domainOrdersManager->addChild('updateCartContentFromOrder');
                        
                        $domainPolicyManager=$this->_authManager->createTask("domainPolicyManager");
                        $domainPolicyManager->addChild('createNewDomainPolicy');
                        $domainPolicyManager->addChild('deleteDomainPolicy');
                        $domainPolicyManager->addChild('readDomainPolicy');
                        $domainPolicyManager->addChild('updateDomainPolicy');
                        
                        $domainToPartnerManager=$this->_authManager->createTask("domainToPartnerManager");
                        $domainToPartnerManager->addChild('acceptOrRejectPartnerRequest');
                        $domainToPartnerManager->addChild('deletePendingDomainToPartnershipRequest');
                        $domainToPartnerManager->addChild('deletePendingPartnerToDomainRequest');
                        $domainToPartnerManager->addChild('initiateNewPartnership');
                        $domainToPartnerManager->addChild('readDomainToPartnerRequest');
                        $domainToPartnerManager->addChild('readPartnerToDomainRequest');
                        $domainToPartnerManager->addChild('updatePartnershipInfo');
                        
                        $needManager=$this->_authManager->createTask("needManager");
                        $needManager->addChild('deleteNeed');
                        $needManager->addChild('readNeed');
                        $needManager->addChild('viewNeed');
                        
                        $partnerToDomainManager=$this->_authManager->createTask("partnerToDomainManager");
                        $partnerToDomainManager->addChild('acceptOrRejectPartnerRequest');
                        $partnerToDomainManager->addChild('deletePendingPartnerToDomainRequest');
                        $partnerToDomainManager->addChild('keepRequestInView');
                        $partnerToDomainManager->addChild('readPartnerToDomainRequest');
                        
                        $paymentConfirmationManager=$this->_authManager->createTask("paymentConfirmationManager");
                        $paymentConfirmationManager->addChild('makePaymentConfirmations');
                        $paymentConfirmationManager->addChild('readUnconfirmedPayments');
                        
                        $paymentRemittanceManager=$this->_authManager->createTask("paymentRemittanceManager");
                        $paymentRemittanceManager->addChild('deferPaymentRemittance');
                        $paymentRemittanceManager->addChild('includePaymentForRemittance');
                        $paymentRemittanceManager->addChild('processPaymentForRemittance');
                        $paymentRemittanceManager->addChild('viewPaymentForRemittance');
                        
                        $platformSettingsManager=$this->_authManager->createTask("platformSettingsManager");
                        $platformSettingsManager->addChild('createNewPlatformSettings');
                        $platformSettingsManager->addChild('deletePlatformSettings');
                        $platformSettingsManager->addChild('readPlatformSettings');
                        $platformSettingsManager->addChild('updatePlatformSettings');
                        
                        $receiptManager=$this->_authManager->createTask("receiptManager");
                        $receiptManager->addChild('readDomainReceipt');
                        
                        $serviceRenewalManager=$this->_authManager->createTask("serviceRenewalManager");
                        $serviceRenewalManager->addChild('effectToolboxServiceRenewal');
                        $serviceRenewalManager->addChild('readDueToolboxServicesForRenewal');
                        
                        $storeManager=$this->_authManager->createTask("storeManager");
                        $storeManager->addChild('createNewStoreParameters');
                        $storeManager->addChild('deleteStoreParameters');
                        $storeManager->addChild('readStoreParameters');
                        $storeManager->addChild('updateStoreParameters');
                        
                        $timezoneManager=$this->_authManager->createTask("timezoneManager");
                        $timezoneManager->addChild('createNewTimezone');
                        $timezoneManager->addChild('deleteTimezone');
                        $timezoneManager->addChild('readTimezone');
                        $timezoneManager->addChild('updateTimezone');
                        
                        $toolboxDuplicationManager=$this->_authManager->createTask("toolboxDuplicationManager");
                        $toolboxDuplicationManager->addChild('createNewToolboxDuplicate');
                        $toolboxDuplicationManager->addChild('deleteToolboxDuplicate');
                        $toolboxDuplicationManager->addChild('readToolboxDuplicate');
                        $toolboxDuplicationManager->addChild('removeToolFromDuplicateToolboxes');
                        $toolboxDuplicationManager->addChild('updateToolboxDuplicate');
                        
                        $toolDuplicationManager=$this->_authManager->createTask("toolDuplicationManager");
                        $toolDuplicationManager->addChild('createNewToolDuplicate');
                        $toolDuplicationManager->addChild('deleteToolDuplicate');
                        $toolDuplicationManager->addChild('readToolDuplicate');
                        $toolDuplicationManager->addChild('updateToolDuplicate');
                        
                        $wishManager=$this->_authManager->createTask("wishManager");
                        $wishManager->addChild('deleteWish');
                        $wishManager->addChild('readWish');
                        $wishManager->addChild('viewWish');
                        
                        $partnershipManager=$this->_authManager->createTask("partnershipManager");
                        $partnershipManager->addChild('accessPartnerInlineStore');
                        $partnershipManager->addChild('deletePartnership');
                        $partnershipManager->addChild('modifyPartnershipStatus');
                        $partnershipManager->addChild('readDomainPartners');
                        
                        $technologyManager=$this->_authManager->createTask("technologyManager");
                        $technologyManager->addChild('createNewTechnology');
                        $technologyManager->addChild('deleteTechnology');
                        $technologyManager->addChild('readTechnology');
                        $technologyManager->addChild('updateTechnology');
                        
                        $networkManager=$this->_authManager->createTask("networkManager");
                        $networkManager->addChild('addToolboxToNetwork');
                        $networkManager->addChild('assignToolboxToNetwork');
                        $networkManager->addChild('createNewNetwork');
                        $networkManager->addChild('deleteNetwork');
                        $networkManager->addChild('modifyNetwork');
                        $networkManager->addChild('modifyToolboxStatusInNetwork');
			
	//list of user roles on the platform	 
	     $adminrole=$this->_authManager->createRole("platformSuperAdmin", "This is the role that manages the entire platform"); 
             $adminrole->addChild('generalToolsAndTaskManager');
             $adminrole->addChild('accountsAndFinanceToolsAndTaskManager');
             $adminrole->addChild('operationsToolsAndTaskManager');
             $adminrole->addChild('humanResourcesToolsAndTaskManager');
             $adminrole->addChild('crmToolsAndTaskManager');
             $adminrole->addChild('operatingSystemToolsAndTaskManager');
             $adminrole->addChild('hardwareAndMobileToolsAndTaskManager');
             $adminrole->addChild('databaseToolsAndTaskManager');
             $adminrole->addChild('dataCleaningToolsAndTaskManager');
             $adminrole->addChild('dataAnalysisToolsAndTaskManager');
             $adminrole->addChild('dataVisualizationToolsAndTaskManager');
             $adminrole->addChild('dataAcquisitionToolsAndTaskManager');
             $adminrole->addChild('processesToolsAndTaskManager');
             $adminrole->addChild('equipmentAndMachineryToolsAndTaskManager');
             $adminrole->addChild('researchToolsAndTaskManager');
             $adminrole->addChild('productionToolsAndTaskManager');
             $adminrole->addChild('maintenanceToolsAndTaskManager');
             $adminrole->addChild('customerRelationToolsAndTaskManager');
             $adminrole->addChild('supplyChainToolsAndTaskManager');
             $adminrole->addChild('treasuryToolsAndTaskManager');
             $adminrole->addChild('loanAndCreditToolsAndTaskManager');
             $adminrole->addChild('erpToolsAndTaskManager');
             $adminrole->addChild('securityToolsAndTaskManager');
             $adminrole->addChild('controlAndComplianceToolsAndTaskManager');
             $adminrole->addChild('riskAssessmentToolsAndTaskManager');
             $adminrole->addChild('automationToolsAndTaskManager');
             $adminrole->addChild('investmentToolsAndTaskManager');
             $adminrole->addChild('userToSubgroupAssignmentManager');
             $adminrole->addChild('toolboxToCategoryAssignmentManager');
             $adminrole->addChild('toolsToToolboxAssignmentManager');
             $adminrole->addChild('toolboxToGroupAssignmentManager');
             $adminrole->addChild('toolboxToSubgroupAssignmentManager');
             $adminrole->addChild('toolboxToUserAssignmentManager');
             $adminrole->addChild('userToSubgroupSchedulingManager');
             $adminrole->addChild('toolboxToCategorySchedulingManager');
             $adminrole->addChild('toolsInToolboxSchedulingManager');
             $adminrole->addChild('toolboxToGroupSchedulingManager');
             $adminrole->addChild('toolboxToSubgroupSchedulingManager');
             $adminrole->addChild('toolboxToUserSchedulingManager');
             $adminrole->addChild('userManager');
             $adminrole->addChild('countryManager');
             $adminrole->addChild('stateManager');
             $adminrole->addChild('cityManager');
             $adminrole->addChild('groupManager');
             $adminrole->addChild('subgroupManager');
             $adminrole->addChild('containerManager');
             $adminrole->addChild('tooltypeManager');
             $adminrole->addChild('toolboxManager');
             $adminrole->addChild('categoryManager');
             $adminrole->addChild('roleManager');
             $adminrole->addChild('taskManager');
             $adminrole->addChild('privilegesManager');
             $adminrole->addChild('userAuthorizationManager');
             $adminrole->addChild('networksAndCommsManager');
             $adminrole->addChild('activeToolboxServiceManager');
             $adminrole->addChild('announcementManager');
             $adminrole->addChild('currencyExchangeManager');
             $adminrole->addChild('currencyManagement');
             $adminrole->addChild('domainNetworkConnectionManager');
             $adminrole->addChild('domainNetworkManager');
             $adminrole->addChild('domainOrdersManager');
             $adminrole->addChild('domainPolicyManager');
             $adminrole->addChild('domainToPartnerManager');
             $adminrole->addChild('needManager');
             $adminrole->addChild('partnerToDomainManager');
             $adminrole->addChild('paymentConfirmationManager');
             $adminrole->addChild('paymentRemittanceManager');
             $adminrole->addChild('platformSettingsManager');
             $adminrole->addChild('receiptManager');
             $adminrole->addChild('serviceRenewalManager');
             $adminrole->addChild('storeManager');
             $adminrole->addChild('timezoneManager');
             $adminrole->addChild('toolboxDuplicationManager');
             $adminrole->addChild('toolDuplicationManager');
             $adminrole->addChild('wishManager');
             $adminrole->addChild('partnershipManager');
             $adminrole->addChild('technologyManager');
             $adminrole->addChild('networkManager');
             $adminrole->addChild('readToolsAndTask');
             $adminrole->addChild('readAssignedToolboxesToSubgroup');
             $adminrole->addChild('platformPaymentConfirmation');
             $adminrole->addChild('platformAdmin');
             $adminrole->addChild('grantSpecialPrivilegesToDomains');
             $adminrole->addChild('changeUserPassword');
             
             $domainSuperAdmin=$this->_authManager->createRole("domainSuperAdmin","This is the role in charge of domain administration"); 
             $domainSuperAdmin->addChild('generalToolsAndTaskManager');
             $domainSuperAdmin->addChild('accountsAndFinanceToolsAndTaskManager');
             $domainSuperAdmin->addChild('operationsToolsAndTaskManager');
             $domainSuperAdmin->addChild('humanResourcesToolsAndTaskManager');
             $domainSuperAdmin->addChild('crmToolsAndTaskManager');
             $domainSuperAdmin->addChild('operatingSystemToolsAndTaskManager');
             $domainSuperAdmin->addChild('hardwareAndMobileToolsAndTaskManager');
             $domainSuperAdmin->addChild('databaseToolsAndTaskManager');
             $domainSuperAdmin->addChild('dataCleaningToolsAndTaskManager');
             $domainSuperAdmin->addChild('dataAnalysisToolsAndTaskManager');
             $domainSuperAdmin->addChild('dataVisualizationToolsAndTaskManager');
             $domainSuperAdmin->addChild('dataAcquisitionToolsAndTaskManager');
             $domainSuperAdmin->addChild('processesToolsAndTaskManager');
             $domainSuperAdmin->addChild('equipmentAndMachineryToolsAndTaskManager');
             $domainSuperAdmin->addChild('researchToolsAndTaskManager');
             $domainSuperAdmin->addChild('productionToolsAndTaskManager');
             $domainSuperAdmin->addChild('maintenanceToolsAndTaskManager');
             $domainSuperAdmin->addChild('customerRelationToolsAndTaskManager');
             $domainSuperAdmin->addChild('supplyChainToolsAndTaskManager');
             $domainSuperAdmin->addChild('treasuryToolsAndTaskManager');
             $domainSuperAdmin->addChild('loanAndCreditToolsAndTaskManager');
             $domainSuperAdmin->addChild('erpToolsAndTaskManager');
             $domainSuperAdmin->addChild('securityToolsAndTaskManager');
             $domainSuperAdmin->addChild('controlAndComplianceToolsAndTaskManager');
             $domainSuperAdmin->addChild('riskAssessmentToolsAndTaskManager');
             $domainSuperAdmin->addChild('automationToolsAndTaskManager');
             $domainSuperAdmin->addChild('investmentToolsAndTaskManager');
             $domainSuperAdmin->addChild('userToSubgroupAssignmentManager');
             $domainSuperAdmin->addChild('toolboxToCategoryAssignmentManager');
             $domainSuperAdmin->addChild('toolsToToolboxAssignmentManager');
             $domainSuperAdmin->addChild('toolboxToGroupAssignmentManager');
             $domainSuperAdmin->addChild('toolboxToSubgroupAssignmentManager');
             $domainSuperAdmin->addChild('toolboxToUserAssignmentManager');
             $domainSuperAdmin->addChild('userToSubgroupSchedulingManager');
             $domainSuperAdmin->addChild('toolboxToCategorySchedulingManager');
             $domainSuperAdmin->addChild('toolsInToolboxSchedulingManager');
             $domainSuperAdmin->addChild('toolboxToGroupSchedulingManager');
             $domainSuperAdmin->addChild('toolboxToSubgroupSchedulingManager');
             $domainSuperAdmin->addChild('toolboxToUserSchedulingManager');
             $domainSuperAdmin->addChild('userManager');
             $domainSuperAdmin->addChild('groupManager');
             $domainSuperAdmin->addChild('subgroupManager');
             $domainSuperAdmin->addChild('toolboxManager');
             $domainSuperAdmin->addChild('categoryManager');
             $domainSuperAdmin->addChild('networksAndCommsManager');
             $domainSuperAdmin->addChild('announcementManager');
             $domainSuperAdmin->addChild('domainNetworkConnectionManager');
             $domainSuperAdmin->addChild('domainNetworkManager');
             $domainSuperAdmin->addChild('domainOrdersManager');
             $domainSuperAdmin->addChild('domainPolicyManager');
             $domainSuperAdmin->addChild('domainToPartnerManager');
             $domainSuperAdmin->addChild('needManager');
             $domainSuperAdmin->addChild('partnerToDomainManager');
             $domainSuperAdmin->addChild('receiptManager');
             $domainSuperAdmin->addChild('serviceRenewalManager');
             $domainSuperAdmin->addChild('storeManager');
             $domainSuperAdmin->addChild('toolboxDuplicationManager');
             $domainSuperAdmin->addChild('toolDuplicationManager');
             $domainSuperAdmin->addChild('wishManager');
             $domainSuperAdmin->addChild('partnershipManager');
             $domainSuperAdmin->addChild('networkManager');
             $domainSuperAdmin->addChild('readToolsAndTask');
             $domainSuperAdmin->addChild('changeUserPassword');
             
             $domainToolsCentralAdmin=$this->_authManager->createRole("domainToolsCentralAdmin","This role manages all the tools and task activity  for a domain"); 
             $domainToolsCentralAdmin->addChild('generalToolsAndTaskManager');
             $domainToolsCentralAdmin->addChild('accountsAndFinanceToolsAndTaskManager');
             $domainToolsCentralAdmin->addChild('operationsToolsAndTaskManager');
             $domainToolsCentralAdmin->addChild('humanResourcesToolsAndTaskManager');
             $domainToolsCentralAdmin->addChild('crmToolsAndTaskManager');
             $domainToolsCentralAdmin->addChild('operatingSystemToolsAndTaskManager');
             $domainToolsCentralAdmin->addChild('hardwareAndMobileToolsAndTaskManager');
             $domainToolsCentralAdmin->addChild('databaseToolsAndTaskManager');
             $domainToolsCentralAdmin->addChild('dataCleaningToolsAndTaskManager');
             $domainToolsCentralAdmin->addChild('dataAnalysisToolsAndTaskManager');
             $domainToolsCentralAdmin->addChild('dataVisualizationToolsAndTaskManager');
             $domainToolsCentralAdmin->addChild('dataAcquisitionToolsAndTaskManager');
             $domainToolsCentralAdmin->addChild('processesToolsAndTaskManager');
             $domainToolsCentralAdmin->addChild('equipmentAndMachineryToolsAndTaskManager');
             $domainToolsCentralAdmin->addChild('researchToolsAndTaskManager');
             $domainToolsCentralAdmin->addChild('productionToolsAndTaskManager');
             $domainToolsCentralAdmin->addChild('maintenanceToolsAndTaskManager');
             $domainToolsCentralAdmin->addChild('customerRelationToolsAndTaskManager');
             $domainToolsCentralAdmin->addChild('supplyChainToolsAndTaskManager');
             $domainToolsCentralAdmin->addChild('treasuryToolsAndTaskManager');
             $domainToolsCentralAdmin->addChild('loanAndCreditToolsAndTaskManager');
             $domainToolsCentralAdmin->addChild('erpToolsAndTaskManager');
             $domainToolsCentralAdmin->addChild('securityToolsAndTaskManager');
             $domainToolsCentralAdmin->addChild('controlAndComplianceToolsAndTaskManager');
             $domainToolsCentralAdmin->addChild('riskAssessmentToolsAndTaskManager');
             $domainToolsCentralAdmin->addChild('automationToolsAndTaskManager');
             $domainToolsCentralAdmin->addChild('investmentToolsAndTaskManager');
             $domainToolsCentralAdmin->addChild('networksAndCommsManager');
             
             $domainAssignmentAdmin=$this->_authManager->createRole("domainAssignmentAdmin","This role is responsible for all assignment activities for a domain");
             $domainAssignmentAdmin->addChild('userToSubgroupAssignmentManager');
             $domainAssignmentAdmin->addChild('toolboxToCategoryAssignmentManager');
             $domainAssignmentAdmin->addChild('toolsToToolboxAssignmentManager');
             $domainAssignmentAdmin->addChild('toolboxToGroupAssignmentManager');
             $domainAssignmentAdmin->addChild('toolboxToSubgroupAssignmentManager');
             $domainAssignmentAdmin->addChild('toolboxToUserAssignmentManager');
             
             $domainSchedulingAdmin=$this->_authManager->createRole("domainSchedulingAdmin","This role is responsible for all scheduling activities for a domain");
             $domainSchedulingAdmin->addChild('userToSubgroupSchedulingManager');
             $domainSchedulingAdmin->addChild('toolboxToCategorySchedulingManager');
             $domainSchedulingAdmin->addChild('toolsInToolboxSchedulingManager');
             $domainSchedulingAdmin->addChild('toolboxToGroupSchedulingManager');
             $domainSchedulingAdmin->addChild('toolboxToSubgroupSchedulingManager');
             $domainSchedulingAdmin->addChild('toolboxToUserSchedulingManager');
             
             $domainGroupAdmin=$this->_authManager->createRole("domainGroupAdmin","This role is in charge of group administration for a domain");
             $domainGroupAdmin->addChild('groupManager');
             $domainSubgroupAdmin=$this->_authManager->createRole("domainSubgroupAdmin","This role is in charge of subgroup administration for a domain");
             $domainSubgroupAdmin->addChild('subgroupManager');
             $domainAnnouncementAdmin=$this->_authManager->createRole("domainAnnouncementAdmin","This role is in charge of announcement administration for a domain");
             $domainAnnouncementAdmin->addChild('announcementManager');
             $domainNeedsAdmin=$this->_authManager->createRole("domainNeedsAdmin","This role is in charge of needs administration for a domain");
             $domainNeedsAdmin->addChild('needManager');
             $domainWishesAdmin=$this->_authManager->createRole("domainWishesAdmin","This role is in charge of wishes administration for a domain");
             $domainWishesAdmin->addChild('wishManager');
             $domainUserAdmin=$this->_authManager->createRole("domainUserAdmin","This role is in charge of user administration for a domain");
             $domainUserAdmin->addChild('userManager');
             $domainLocationAdmin=$this->_authManager->createRole("domainLocationAdmin","This role is in charge of country, state and city management on the platform");
             $domainLocationAdmin->addChild('countryManager');
             $domainLocationAdmin->addChild('stateManager');
             $domainLocationAdmin->addChild('cityManager');             
             $domainPolicyAdmin=$this->_authManager->createRole("domainPolicyAdmin","This role is in charge of policy administration for a domain");
             $domainPolicyAdmin->addChild('domainPolicyManager');
             $domainStoreAdmin=$this->_authManager->createRole("domainStoreAdmin","This role is in charge of store administration for a domain");
             $domainStoreAdmin->addChild('storeManager');
             $domainSecurityAdmin=$this->_authManager->createRole("domainSecurityAdmin","This role is in charge of security administration on the platform");
             $domainSecurityAdmin->addChild('roleManager');
             $domainSecurityAdmin->addChild('taskManager');
             $domainSecurityAdmin->addChild('privilegesManager');
             $domainSecurityAdmin->addChild('userAuthorizationManager');
             $domainPartnerAdmin=$this->_authManager->createRole("domainPartnerAdmin","This role is in charge of partnership administration for a domain");
             $domainPartnerAdmin->addChild('domainToPartnerManager');
             $domainPartnerAdmin->addChild('partnershipManager');
             $domainPartnerAdmin->addChild('partnerToDomainManager');
             $domainNetworkAdmin=$this->_authManager->createRole("domainNetworkAdmin","This role is in charge of network management for a domain");
             $domainNetworkAdmin->addChild('networkManager');
             $domainNetworkAdmin->addChild('domainNetworkConnectionManager');
             $domainOrdersAdmin=$this->_authManager->createRole("domainOrdersAdmin","This role is in charge of Service Orders administration for a domain");
             $domainOrdersAdmin->addChild('domainOrdersManager');
             $domainRenewalsAdmin=$this->_authManager->createRole("domainRenewalsAdmin","This role is in charge of service renewals administration for a domain");
             $domainRenewalsAdmin->addChild('serviceRenewalManager');
             $domainReceiptAdmin=$this->_authManager->createRole("domainReceiptAdmin","This role is in charge of receipt administration for a domain");
             $domainReceiptAdmin->addChild('receiptManager');
             $domainDomainAdmin=$this->_authManager->createRole("domainDomainAdmin","This role is in charge of domainn administration for a domain");
             $domainDomainAdmin->addChild('categoryManager');
             $domainToolboxAdmin=$this->_authManager->createRole("domainToolboxAdmin","This role is in charge of toolbox administration for a domain");
             $domainToolboxAdmin->addChild('toolboxManager');
             $domainToolDuplicationAdmin=$this->_authManager->createRole("domainToolDuplicationAdmin","This role is in charge of tool duplication administration for a domain");
             $domainToolDuplicationAdmin->addChild('toolDuplicationManager');
             $domainToolboxDuplicationAdmin=$this->_authManager->createRole("domainToolboxDuplicationAdmin","This role is in charge of toolbox duplication administration for a domain"); 
             $domainToolboxDuplicationAdmin->addChild('toolboxDuplicationManager');
             $user=$this->_authManager->createRole("user","This is the user only role"); 
			
                         
                         
                         
			 
		
		     //provide a message indicating success
		     echo "Authorization hierarchy successfully generated.\n";
        }
 		else
			echo "Operation cancelled.\n";
    }

	public function actionDelete()
	{
		$this->ensureAuthManagerDefined();
		$message = "This command will clear all RBAC definitions.\n";
		$message .= "Would you like to continue?";
	    //check the input from the user and continue if they indicated 
	    //yes to the above question
	    if($this->confirm($message)) 
	    {
			$this->_authManager->clearAll();
			echo "Authorization hierarchy removed.\n";
		}
		else
			echo "Delete operation cancelled.\n";
			
	}
	
	protected function ensureAuthManagerDefined()
	{
		//ensure that an authManager is defined as this is mandatory for creating an auth heirarchy
		if(($this->_authManager=Yii::app()->authManager)===null)
		{
		    $message = "Error: an authorization manager, named 'authManager' must be con-figured to use this command.";
			$this->usageError($message);
		}
	}
}
